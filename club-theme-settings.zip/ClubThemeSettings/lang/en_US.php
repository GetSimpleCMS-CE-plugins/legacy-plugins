<?php
/**
 * English Language File for Club Theme Plugin
 *
 * Date:		23 Sept 2012
 * Revision:	1.1
 * Version:		GetSimple 3.1
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	
	"CLUB_THEME_TITLE"=>  "Club Theme Settings",
	"CLUB_THEME_DESC" =>  "Settings for the GetSimple Club Theme",
	"FACEBOOK_ERROR"	=>	"Facebook URL is not valid.",
	"TWITTER_ERROR"		=>	"Twitter URL is not valid.",
	"LINKEDIN_ERROR"	=>	"LinkedIn URL is not valid.",
	"GOOGLEPLUS_ERROR"  => "Google Plus URL is not valid.",
	"FOOTERSEPERATOR_ERROR" => "Footer Seperator must be one character.",
	"THEMECOLOR_ERROR"	=> "Color must be inputted as a 6 digit HEX. (#D70000)",
	"THEMECOLOR_ERROR_DIM"	=> "Theme Color needs to be darker.",
	"FACEBOOK_URL"		=>	"Facebook URL",
	"TWITTER_URL"			=>	"Twitter URL",
	"LINKEDIN_URL"		=>	"LinkedIn URL",
	"GOOGLEPLUS_URL"		=>	"Google Plus URL",
	"FOOTER_TEXT"		=>	"Footer Text <span style=\"font-weight:normal;\"> - default is © YEAR Site Title </span>",
	"FOOTER_SEPERATOR"		=>	"Footer Seperator",
	"THEME_COLOR"		=>	"Theme Color <span style=\"font-weight:normal;\"> - must be <a href=\"http://www.colorpicker.com/\">HEX</a></span>",
	"CONTACTUSEMAIL"		=>	"Email",
	"CLUB_THEME_CUSTOMIZATION" => "Additional Customization",
	"CLUB_THEME_CUSTOMIZATION_TEXT" => "In addition the the settings above you can add a header image, logo, and sidebar. To add a header image or logo please upload logo.png or header.png under the images folder in the files tab. (A new folder called images may need to be created.) If you want a certain header image to only appear on one page simply name it header-<em>slug</em>.png <em>slug</em> being the page slug found under page options on the page edit window. The default template (under page options as well) contains a sidebar, you can select no-sidebar.php to not have a sidebar. If you want a custom page sidebar for a specific page simply name it sidebar-<em>slug</em>.  The sidebars are edited are created under the Components page to the right of this page.",
	"CLUB_THEME_CREATING_COLUMNS" => "Creating Columns",
	"CLUB_THEME_CREATING_COLUMNS_TEXT" => "Columns can be created using the HTML listed below. To create columns, it is best to start with a new page, click source, paste in the desired HTML, and then click source again. The edit page will not appear to be in columns but the columns will be present on the public page. Below is the code one column. Simply choose the desired amount of columns (two, three, or four). Paste in the code that many times, and change twocolumn to the respective amount.",
	"CLUB_THEME_CREATING_COLUMNS_HTML" => "Column HTML",
	"PAGE_TITLE_STYLE" => "Page Title Style",
	"PAGE_TITLE_STYLE_TEXT" => "The following is the HTML for the page title, it can be used if you want to match the style of the page title:"
);