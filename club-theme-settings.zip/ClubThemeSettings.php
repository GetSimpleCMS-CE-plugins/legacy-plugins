<?php
/*
Plugin Name: Club Theme Settings
Description: Settings for the Club Theme
Version: 1.1
Author: Michael Lindahl
Author URI: http://clubtheme.michaellindahl.com
*/

# get correct id for plugin
$thisfile_clubtheme=basename(__FILE__, ".php");
$clubtheme_file=GSDATAOTHERPATH .'ClubThemeSettings.xml';
# ^^ Also hard coded into common_functions.php
#$innovation_file=GSDATAOTHERPATH .'InnovationSettings.xml';

# add in this plugin's language file
i18n_merge($thisfile_clubtheme) || i18n_merge($thisfile_clubtheme, 'en_US');

# register plugin
register_plugin(
	$thisfile_clubtheme, //Plugin id
	i18n_r($thisfile_clubtheme.'/CLUB_THEME_TITLE'), 	//Plugin name
	'1.1', 		//Plugin version
	'Michael Lindahl',  //Plugin author
	'http://www.michaellindahl.com/', //author website
	i18n_r($thisfile_clubtheme.'/CLUB_THEME_DESC'), //Plugin description
	'theme', //page type - on which admin tab to display
	'club_theme_show'  //main function (administration)
);

# add common_functions
include GSPLUGINPATH.'/ClubThemeSettings/common_functions.php'; 

# hooks
add_action('theme-extras',club_theme_show); 

# get XML data
if (file_exists($clubtheme_file)) {
	$x = getXML($clubtheme_file);
	#$facebook = $x->facebook;
	#$twitter = $x->twitter;
	#$linkedin = $x->linkedin;
	#$googleplus = $x->googleplus;
	$footertext = $x->footertext;
	$footerseperator = $x->footerseperator;
	$themecolor = $x->themecolor;
	#$contactusemail = $x->contactusemail;
} else {
	#$facebook = '';
	#$twitter = '';
	#$linkedin = '';
	#$googleplus = '';
	$footertext = 'default';
	$footerseperator = '|';
	$themecolor = '#D70000';
	#$contactusemail = '';
}

/*if (file_exists($innovation_file)) {
	$y = getXML($innovation_file);
	$facebook = $y->facebook;
	$twitter = $y->twitter;
	$linkedin = $y->linkedin;
}*/

function check_version() {
$my_plugin_id = 517; // replace this with yours

$apiback = file_get_contents('http://get-simple.info/api/extend/?id='.$my_plugin_id);
$response = json_decode($apiback);
if ($response->status == 'successful') {
	// Successful api response sent back. 
	$clubthemesettings_current_ver = $response->version;
		return $clubthemesettings_current_ver;
}
}


function club_theme_show() {

// check versions!

	global $clubtheme_file, $TEMPLATE, /*$facebook, $twitter, $linkedin, $googleplus,*/ $footertext, $footerseperator, $themecolor, /*$contactusemail,*/ $thisfile_clubtheme;
	$success=null;$error=null;
	if ($TEMPLATE == "ClubTheme") {
	// submitted form
	if (isset($_POST['submit'])) {
		/*$facebook=null;	$twitter=null; $linkedin=null; $googleplus=null;*/ $footertext=null; $footerseperator=null; $themecolor=null; /*$contactusemail=null;*/
		
		# check to see if the URLs provided are valid
		/*if ($_POST['facebook'] != '') {
			if (validate_url($_POST['facebook'])) {
				$facebook = $_POST['facebook'];
			} else {
				$error .= i18n_r($thisfile_clubtheme.'/FACEBOOK_ERROR').' ';
			}
		}
		
		if ($_POST['twitter'] != '') {
			if (validate_url($_POST['twitter'])) {
				$twitter = $_POST['twitter'];
			} else {
				$error .= i18n_r($thisfile_clubtheme.'/TWITTER_ERROR').' ';
			}
		}
		
		if ($_POST['linkedin'] != '') {
			if (validate_url($_POST['linkedin'])) {
				$linkedin = $_POST['linkedin'];
			} else {
				$error .= i18n_r($thisfile_clubtheme.'/LINKEDIN_ERROR').' ';
			}
		}
		
		if ($_POST['googleplus'] != '') {
			if (validate_url($_POST['googleplus'])) {
				$linkedin = $_POST['googleplus'];
			} else {
				$error .= i18n_r($thisfile_clubtheme.'/GOOGLEPLUS_ERROR').' ';
			}
		}
		*/
		if ($_POST['footertext'] != '') {
			if (strlen($_POST['footertext']) != '') {
				$footertext = $_POST['footertext'];
			}
		}
		
		if ($_POST['footerseperator'] != '') {
			if (strlen($_POST['footerseperator']) == 1) {
				$footerseperator = $_POST['footerseperator'];
			} else {
				$error .= i18n_r($thisfile_clubtheme.'/FOOTERSEPERATOR_ERROR').' ';
			}
		}
		
		if ($_POST['themecolor'] != '') {
			if (!preg_match('/^#[a-f0-9]{6}$/i', $_POST['themecolor'])) {
				$error .= i18n_r($thisfile_clubtheme.'/THEMECOLOR_ERROR').' ';
			} else if (get_brightness($_POST['themecolor']) > 200) {
				$error .= i18n_r($thisfile_clubtheme.'/THEMECOLOR_ERROR_DIM').' ';
			} else {
				$themecolor = $_POST['themecolor'];
			}
		}
		
		/*if ($_POST['contactusemail'] != '') {
			if (strlen($_POST['contactusemail']) != '') {
				$contactusemail = $_POST['contactusemail'];
			}
		}*/
				
				
				
		# if there are no errors, dave data
		if (!$error) {
			$xml = @new SimpleXMLElement('<item></item>');
			#$xml->addChild('facebook', $facebook);
			#$xml->addChild('twitter', $twitter);
			#$xml->addChild('linkedin', $linkedin);
			#$xml->addChild('googleplus', $googleplus);
			$xml->addChild('footertext', $footertext);
			$xml->addChild('footerseperator', $footerseperator);
			$xml->addChild('themecolor', $themecolor);
			#$xml->addChild('contactusemail', $contactusemail);

			/*if (file_exists($innovation_file)) {
			$yxml = @new SimpleXMLElement('<item></item>');
			$yxml->addChild('facebook', $facebook);
			$yxml->addChild('twitter', $twitter);
			$yxml->addChild('linkedin', $linkedin);
			$yxml->asXML($innovation_file);
			}*/


			if (! $xml->asXML($clubtheme_file)) {
				$error = i18n_r('CHMOD_ERROR');
			} else {
				$x = getXML($clubtheme_file);
				#$facebook = $x->facebook;
				#$twitter = $x->twitter;
				#$linkedin = $x->linkedin;
				#$googleplus = $x->googleplus;
				$footertext = $x->footertext;
				$footerseperator = $x->footerseperator;
				$themecolor = $x->themecolor;
				#$contactusemail = $x->contactusemail;
				$success = i18n_r('SETTINGS_UPDATED');
			}
		}
	}
	
	?>
	<h3><?php i18n($thisfile_clubtheme.'/CLUB_THEME_TITLE'); ?></h3>
	
	<?php 
	if($success) { 
		echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
	} 
	if($error) { 
		echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
	}
	?>
	
	<form method="post" action="<?php	echo $_SERVER ['REQUEST_URI']?>">
		
		<!--<p><label for="inn_facebook" ><?php i18n($thisfile_clubtheme.'/FACEBOOK_URL'); ?></label><input id="inn_facebook" name="facebook" class="text" value="<?php echo $facebook; ?>" type="url" /></p>
		<p><label for="inn_twitter" ><?php i18n($thisfile_clubtheme.'/TWITTER_URL'); ?></label><input id="inn_twitter" name="twitter" class="text" value="<?php echo $twitter; ?>" type="url" /></p>
		<p><label for="inn_linkedin" ><?php i18n($thisfile_clubtheme.'/LINKEDIN_URL'); ?></label><input id="inn_linkedin" name="linkedin" class="text" value="<?php echo $linkedin; ?>" type="url" /></p>
		<p><label for="inn_googleplus" ><?php i18n($thisfile_clubtheme.'/GOOGLEPLUS_URL'); ?></label><input id="inn_googleplus" name="googleplus" class="text" value="<?php echo $googleplus; ?>" type="url" /></p>-->
		<p><label for="inn_footertext" ><?php i18n($thisfile_clubtheme.'/FOOTER_TEXT'); ?></label><input id="inn_footertext" name="footertext" class="text" onfocus="copyText()" value="<?php echo $footertext; ?>" type="text" /></p>
		<p><label for="inn_footerseperator" ><?php i18n($thisfile_clubtheme.'/FOOTER_SEPERATOR'); ?></label><input id="inn_footerseperator" name="footerseperator" class="text" value="<?php echo $footerseperator; ?>" type="character" /></p>
		<p><label for="inn_themecolor" ><?php i18n($thisfile_clubtheme.'/THEME_COLOR'); ?></label><input id="inn_themecolor" name="themecolor" class="text" value="<?php echo $themecolor; ?>" type="text" /></p>
		<!--<p><label for="inn_contactusemail" ><?php i18n($thisfile_clubtheme.'/CONTACTUSEMAIL'); ?></label><input id="inn_contactusemail" name="contactusemail" class="text" value="<?php echo $contactusemail; ?>" type="text" /></p>-->
			
		<p><input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" /></p>
	</form>
	
	<h3><?php i18n($thisfile_clubtheme.'/CLUB_THEME_CUSTOMIZATION'); ?></h3>
	<p><?php i18n($thisfile_clubtheme.'/CLUB_THEME_CUSTOMIZATION_TEXT'); ?></p>
	
	<h3><?php i18n($thisfile_clubtheme.'/PAGE_TITLE_STYLE'); ?></h3>
	<p><?php i18n($thisfile_clubtheme.'/PAGE_TITLE_STYLE_TEXT'); ?>
	<br/>&lt;span class="arrows"&gt;&amp;gt;&lt;/span&gt;&lt;span class="SubHead"&gt; Creating Columns&lt;/span&gt;</p>
	
	<h3><?php i18n($thisfile_clubtheme.'/CLUB_THEME_CREATING_COLUMNS'); ?></h3>
	<p><?php i18n($thisfile_clubtheme.'/CLUB_THEME_CREATING_COLUMNS_TEXT'); ?></p>
	
	<h3><?php i18n($thisfile_clubtheme.'/CLUB_THEME_CREATING_COLUMNS_HTML'); ?></h3>
	
	<p>
&lt;div class="<em>two</em>column"&gt;<br />
&lt;h2 class="columntitle"&gt;Column Title Here&lt;/h2&gt;<br />
&lt;p class="columntext"&gt;Column Text Here&lt;/p&gt;<br />
&lt;/div&gt;
	</p>
	
	<?php
}
}
