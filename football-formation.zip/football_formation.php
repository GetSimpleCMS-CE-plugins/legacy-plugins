<?php
/*
Plugin Name: Football Formation
Description: Display a football pitch with player names in formation.
Version: 1.0
Author: Adrian D. Elgar
Author URI: http://mrdragonraaar.com
*/

// plugin id
define('FOOTFORM_PLUGIN_ID', basename(__FILE__, '.php'));
// plugin path
define('FOOTFORM_PLUGIN_PATH', GSPLUGINPATH . FOOTFORM_PLUGIN_ID . '/');
// plugin includes path
define('FOOTFORM_INC_PATH', FOOTFORM_PLUGIN_PATH . 'inc/');

// add in this plugin's language file
i18n_merge(FOOTFORM_PLUGIN_ID) || i18n_merge(FOOTFORM_PLUGIN_ID, 'en_US');

// register plugin
register_plugin(
	FOOTFORM_PLUGIN_ID,
	i18n_r(FOOTFORM_PLUGIN_ID . '/FOOTFORM_TITLE'),
	'1.0',
	'Adrian D. Elgar',
	'http://mrdragonraaar.com',
	i18n_r(FOOTFORM_PLUGIN_ID . '/FOOTFORM_DESC'),
	'plugins',
	'footform_main'
);

// hooks
add_filter('content', 'footform_filter');

// includes
require_once(FOOTFORM_INC_PATH . 'functions.php');

// javascript
register_script(FOOTFORM_PLUGIN_ID, $SITEURL . 'plugins/' . FOOTFORM_PLUGIN_ID . '/js/' . FOOTFORM_PLUGIN_ID . '.js', '1.0', true);
//queue_script('jquery-ui', GSBACK);
//queue_script('jquery-validate', GSBACK);
//queue_script(FOOTFORM_PLUGIN_ID, GSBACK);

// stylesheet
register_style(FOOTFORM_PLUGIN_ID, $SITEURL . 'plugins/' . FOOTFORM_PLUGIN_ID . '/css/' . FOOTFORM_PLUGIN_ID . '.css', '1.0', 'screen');
queue_style(FOOTFORM_PLUGIN_ID, GSFRONT);

?>
