<?php
/**
 * English Language File for Football Formation Plugin
 *
 * (c)2013 mrdragonraaar.com
 */

$i18n = array(
	"FOOTFORM_TITLE"=> "Football Formation",
	"FOOTFORM_DESC" => "Display a football pitch with player names in formation.",
);
?>
