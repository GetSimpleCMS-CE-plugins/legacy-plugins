<?php
/**
 * Football Formation template for formation html.
 *
 * (c)2013 mrdragonraaar.com
 */
if (!defined('IN_GS')) { die('you cannot load this page directly.'); }

?>
<!-- Football: Formation -->
<div class="football_formation">

<!-- Pitch -->
<div class="pitch">

<!-- Formation -->
<div class="formation f<?php echo $formation; ?>">

<!-- Goalkeeper -->
<div class="pos gk"><?php if (isset($players[0])) { echo $players[0]; } ?></div>
<!-- END Goalkeeper -->

<div class="pos p1"><?php if (isset($players[1])) { echo $players[1]; } ?></div>
<div class="pos p2"><?php if (isset($players[2])) { echo $players[2]; } ?></div>
<div class="pos p3"><?php if (isset($players[3])) { echo $players[3]; } ?></div>
<div class="pos p4"><?php if (isset($players[4])) { echo $players[4]; } ?></div>
<div class="pos p5"><?php if (isset($players[5])) { echo $players[5]; } ?></div>
<div class="pos p6"><?php if (isset($players[6])) { echo $players[6]; } ?></div>
<div class="pos p7"><?php if (isset($players[7])) { echo $players[7]; } ?></div>
<div class="pos p8"><?php if (isset($players[8])) { echo $players[8]; } ?></div>
<div class="pos p9"><?php if (isset($players[9])) { echo $players[9]; } ?></div>
<div class="pos p10"><?php if (isset($players[10])) { echo $players[10]; } ?></div>

</div>
<!-- END Formation -->

</div>
<!-- END Pitch -->

<!-- Info -->
<div class="info">
<span class="info_formation">Formation: <?php echo $formation; ?></span>
<span class="info_players">Players: <?php echo implode(', ', $players); ?></span>
</div>
<!-- END Info -->

</div>
<!-- END Football: Formation -->
