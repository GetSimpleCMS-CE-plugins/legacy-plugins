<?php
/**
 * General functions used by Football Formation plugin.
 *
 * (c)2013 mrdragonraaar.com
 */
if (!defined('IN_GS')) { die('you cannot load this page directly.'); }

// plugin template path
if (!defined('FOOTFORM_TEMPLATE_PATH')) {
define('FOOTFORM_TEMPLATE_PATH', FOOTFORM_PLUGIN_PATH . 'template/');
}

// valid formations
if (!defined('FOOTFORM_DEFAULT_FORMATION')) {
define('FOOTFORM_DEFAULT_FORMATION', 442);
}
$FOOTFORM_VALID_FORMATIONS = array(442, 4231, 41212, 4411, 4123, 4213, 433);

/**
 * Main back-end plugin function.
 * Determine what action to take.
 */
function footform_main()
{
}

/**
 * Front-end plugin function.
 * Display football formation.
 * @param $formation formation
 * @param $players array of player names
 */
function football_formation($formation = FOOTFORM_DEFAULT_FORMATION, 
   $players = array())
{
	echo get_football_formation($formation, $players);
}

/**
 * Front-end plugin function.
 * Return football formation.
 * @param $formation formation
 * @param $players array of player names
 */
function get_football_formation($formation = FOOTFORM_DEFAULT_FORMATION, 
   $players = array())
{
	if (!is_valid_formation($formation))
		$formation = FOOTFORM_DEFAULT_FORMATION;

	if (count($players) > 11) { array_splice($players, 11); }

	ob_start();
	include(FOOTFORM_TEMPLATE_PATH . 'formation_html.php');
	return ob_get_clean();
}

/**
 * Check if formation is valid.
 * @param $formation formation
 * @return true if formation is valid
 */
function is_valid_formation($formation)
{
	global $FOOTFORM_VALID_FORMATIONS;

	return in_array($formation, $FOOTFORM_VALID_FORMATIONS);
}

/**
 * Front-end plugin function for filter.
 * Insert formation into content.
 * @param $content page content
 */
function footform_filter($content)
{
	if (preg_match('/\[%\s*formation:(\d*):(.+?)\s*%\]/', $content, $matches))
	{
		$formation = intval($matches[1]);
		$players = explode(';', $matches[2]);
		$html = get_football_formation($formation, $players);

		$content = preg_replace('/\[%\s*formation:\d*:.+?\s*%\]/', $html, $content);
	}

	return $content;
}

?>
