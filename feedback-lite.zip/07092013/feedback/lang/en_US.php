<?php

/**
 * Guestbook German language file by Thomas Klinski <thomas.klinski(at)ymail.com>
 */

$i18n = array(

# general
"PLUGIN_NAME"		=>  "Feedback",
"BACKEND_TITLE"		=>  "Feedback",
"FRONTEND_TITLE"	=>  "Feedback",

# feedback form
"MESSAGE"			=>	"Feedback",
"TITLE"				=>	"Title",
"TITLE_LIST"		=>	"Mrs., Miss, Mr.",
"FIRSTNAME"			=>	"First name",
"LASTNAME"			=>	"Last name",
"EMAIL"				=>	"Email",
"WEB"				=>	"Homepage",
"LOCATION" 			=>	"City",
"SUBMIT"			=>	"Send message",
"SUBMIT_TEXT"		=> 	"<b>Thank you.</b>Your opinion is very important.<br />Your message will be shown after the routine check .",

# form error messages
"MESSAGE_REQUIRED"	=>	"Your massage has to be at least {0} token",
"LASTNAME_REQUIRED"	=>	"Last name is a mandatory field",
"FIRSTNAME_REQUIRED"=>	"First name is a mandatory field",
"LOCATION_REQUIRED" =>	"City is a mandatory field",
"EMAIL_REQUIRED" 	=>	"Email is a mandatory field",
"EMAIL_FORMAT" 		=>	"Email has a wrong format",
"WEB_REQUIRED" 		=>	"Homepage is a mandatory field",

# options
"OPTIONS_SAVE"			=>	"Save options",
"OPTIONS_MESSAGE_MIN"	=>	"Minimal lenght of massage",
"OPTIONS_MESSAGE_MAX"	=>	"Maximal lenght of massage",
"OPTIONS_TITLE_MIN"		=>	"Minimal lenght of title",
"OPTIONS_TITLE_MAX"		=>	"Maximal lenght of title",
"OPTIONS_FIRSTNAME_MIN"	=>	"Minimal lenght of first name",
"OPTIONS_FIRSTNAME_MAX"	=>	"Maximal lenght of first name",
"OPTIONS_LASTNAME_MIN"	=>	"Minimal lenght of last name",
"OPTIONS_LASTNAME_MAX"	=>	"Maximal lenght of last name",
"OPTIONS_EMAIL_MIN"		=>	"Minimal lenght of email",
"OPTIONS_EMAIL_MAX"		=>	"Maximal lenght of email",
"OPTIONS_WEB_MIN"		=>	"Minimal lenght of homepage",
"OPTIONS_WEB_MAX"		=>	"Maximal lenght of homepage",
"OPTIONS_LOCATION_MIN" 	=>	"Minimal lenght of city",
"OPTIONS_LOCATION_MAX" 	=>	"Maximal lenght of city",
"OPTIONS_EPP_FRONTEND"	=>	"Entries per page on frontend side",
"OPTIONS_EPP_BACKEND"	=>	"Entries per page on backend side",
"ONLY_ONE_PRO_SESSION"	=>	"Only one submit pro session", 

# entry output format
"ENTRY_FROM"		=>	"from",
"ENTRY_WRITE"		=>	"wrote",
"ENTRY_HIDE"		=>	"hide",
"ENTRY_RELEASE"		=>	"release",
"ENTRY_DELETE"		=>	"delete",
"ENTRY_CHANGE"		=>	"change",
"ENTRY_SAVE"		=>	"Save changes",
"ENTRY_OR"			=>	"or",
"ENTRY_CANCEL"		=>	"cancel",
"ENTRY_NEW"			=>	"write new",
"ENTRY_VIEW"		=>	"view",
"ENTRY_OPTIONS"		=>	"options",
"ENTRY_FILTER"		=>	"filter",
"ENTRY_RELEASED"	=>	"Released",
"ENTRY_HIDDEN"		=>	"Hidden",

# information messages
"INFO_NOT_FOUND"	=>	"No entry found",
"INFO_CONFIRM_DEL"	=>	"Are you sure you want to <b>delete</b> {0}'s message?",

# success messages
"SUCCESS_SAVE"		=>  "Entry was stored successful",
"SUCCESS_UPDATE"	=>  "Entry was updated successful",
"SUCCESS_DELETE"	=>  "Entry was deleted successful",
"SUCCESS_INACTIVE"	=>  "Entry was deactivated successful",
"SUCCESS_ACTIVE"	=>  "Entry was released successful",
"SUCCESS_OPTIONS"	=>	"Options were stored successful",

# date and time formats
"DATE_FORMAT"		=>  "%e.%b %Y"

);

?>
