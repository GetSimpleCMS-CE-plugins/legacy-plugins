<?php

/**
 * Guestbook German language file by Thomas Klinski <thomas.klinski(at)ymail.com>
 */

$i18n = array(

# general
"PLUGIN_NAME"		=>  "Feedback",
"BACKEND_TITLE"		=>  "Feedback",
"FRONTEND_TITLE"	=>  "Feedback",

# feedback form
"MESSAGE"			=>	"Feedback",
"TITLE"				=>	"Titel",
"TITLE_LIST"		=>	"Frau, Herr",
"FIRSTNAME"			=>	"Vorname",
"LASTNAME"			=>	"Nachname",
"EMAIL"				=>	"Email",
"WEB"				=>	"Homepage",
"LOCATION" 			=>	"Ort",
"SUBMIT"			=>	"Nachricht senden",
"SUBMIT_TEXT"		=> 	"<b>Vielen Dank für Ihre Mitteilung.</b>Ihre Meinung ist uns wichtig.<br />Nach kurzer &Uuml;berpr&uuml;fung wird Ihre Nachricht freigeschaltet.",

# form error messages
"MESSAGE_REQUIRED"	=>	"Die Nachricht muss mindestens {0} Zeichen enthalten",
"LASTNAME_REQUIRED"	=>	"Nachname ist ein Pflichtfeld",
"FIRSTNAME_REQUIRED"=>	"Vorname ist ein Pflichtfeld",
"LOCATION_REQUIRED" =>	"Ort ist ein Pflichtfeld",
"EMAIL_REQUIRED" 	=>	"Email ist ein Pflichtfeld",
"EMAIL_FORMAT" 		=>	"Email wurde falsch eingegeben",
"WEB_REQUIRED" 		=>	"Homepage ist ein Pflichtfeld",

# options
"OPTIONS_SAVE"			=>	"Einstellungen speichern",
"OPTIONS_MESSAGE_MIN"	=>	"Minimale L&auml;nge des Feedbacks",
"OPTIONS_MESSAGE_MAX"	=>	"Maximale L&auml;nge des Feedbacks",
"OPTIONS_TITLE_MIN"		=>	"Minimale L&auml;nge des Titels",
"OPTIONS_TITLE_MAX"		=>	"Maximale L&auml;nge des Titels",
"OPTIONS_FIRSTNAME_MIN"	=>	"Minimale L&auml;nge des Vornamen",
"OPTIONS_FIRSTNAME_MAX"	=>	"Maximale L&auml;nge des Vornamen",
"OPTIONS_LASTNAME_MIN"	=>	"Minimale L&auml;nge des Nachnamen",
"OPTIONS_LASTNAME_MAX"	=>	"Maximale L&auml;nge des Nachnamen",
"OPTIONS_EMAIL_MIN"		=>	"Minimale L&auml;nge der Email",
"OPTIONS_EMAIL_MAX"		=>	"Maximale L&auml;nge der Email",
"OPTIONS_WEB_MIN"		=>	"Minimale L&auml;nge der Homepage",
"OPTIONS_WEB_MAX"		=>	"Maximale L&auml;nge der Homepage",
"OPTIONS_LOCATION_MIN" 	=>	"Minimale L&auml;nge des Ortes",
"OPTIONS_LOCATION_MAX" 	=>	"Maximale L&auml;nge des Ortes",
"OPTIONS_EPP_FRONTEND"	=>	"Beitr&auml;ge auf der Seite in der Adminoberfl&auml;che",
"OPTIONS_EPP_BACKEND"	=>	"Beitr&auml;ge auf der Seite in der Benutzeroberfl&auml;che", 
"ONLY_ONE_PRO_SESSION"	=>	"Nur ein Beitrag pro Session", 

# entry output format
"ENTRY_FROM"		=>	"aus",
"ENTRY_WRITE"		=>	"schreibt",
"ENTRY_HIDE"		=>	"Verbergen",
"ENTRY_RELEASE"		=>	"Freigeben",
"ENTRY_DELETE"		=>	"L&ouml;schen",
"ENTRY_CHANGE"		=>	"&Auml;ndern",
"ENTRY_SAVE"		=>	"Beitrag speichern",
"ENTRY_OR"			=>	"oder",
"ENTRY_CANCEL"		=>	"Abbrechen",
"ENTRY_NEW"			=>	"Neuen Beitrag hinzuf&uuml;gen",
"ENTRY_VIEW"		=>	"Anzeigen",
"ENTRY_OPTIONS"		=>	"Einstellungen",
"ENTRY_FILTER"		=>	"Filter",
"ENTRY_RELEASED"	=>	"Freigegebene",
"ENTRY_HIDDEN"		=>	"Verborgene",

# information messages
"INFO_NOT_FOUND"	=>	"Es wurden keine Beitr&auml;re gefunden",
"INFO_CONFIRM_DEL"	=>	"M&ouml;chten Sie den Beitrag von <b>{0}</b> wirklich l&ouml;schen?",

# success messages
"SUCCESS_SAVE"		=>  "Die &Auml;nderungen wurde erfolgreich gespeichert.",
"SUCCESS_UPDATE"	=>  "Die Nachricht wurde erfolgreich aktualisiert.",
"SUCCESS_DELETE"	=>  "Die Nachricht wurde gel&ouml;scht.",
"SUCCESS_INACTIVE"	=>  "Die Nachricht wurde freigegeben.",
"SUCCESS_ACTIVE"	=>  "Die Nachricht wurde deaktiviert.",
"SUCCESS_OPTIONS"	=>	"Neue Einstellungen wurde erfolgreich gespeichert.",

# date and time formats
"DATE_FORMAT"		=>  "%e.%b %Y"

);

?>
