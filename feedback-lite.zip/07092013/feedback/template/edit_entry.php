<?php


$titles = explode (',', i18n_r('feedback/TITLE_LIST'));

if(isset($todo) && $todo == 'edit') {
	$id = substr($_POST['id'], 0, 32);
	
	if(file_exists(GBCONTENTPATH . $id . '.xml')) {
		$xml = @getXML(GBCONTENTPATH . $id . '.xml');
		$title = $xml->title;
		$lastname = $xml->name;
		$firstname = $xml->firstname;
		$location = $xml->location;
		$email = $xml->email;
		$homepage = $xml->homepage;
		$message = $xml->message;
	}
}

echo '
<script type="text/javascript">
	$(document).ready(function () {
		$("#filter-btn").hide();
	});
</script>
<form id="guestbook" action="load.php?id=feedback" method="post" accept-charset="utf-8">
	<table cellpadding="0" cellspacing="0" barder="0" class="entry-input">
		<tr>
			<td colspan="2">
				<label for="message">'. i18n_r('feedback/MESSAGE') .'</label>
				<textarea id="message" name="message" cols="40" rows="6">'. (isset($message) ? html_entity_decode($message, ENT_QUOTES, 'UTF-8') : '') . '</textarea>
			</td>
		</tr>
		<tr>
			<td><label for="title">'. i18n_r('feedback/TITLE') .'</label></td>
			<td>
				<select id="title" name="title" class="text" style="width: 100px;">';
				foreach ($titles as $title_key => $title_value) {
					echo '<option value="' . $title_key . '" ' . ((isset($title) && $title == $title_key) ? 'selected="selected"' : '') . '>' . $title_value . '</option>';
				}
				echo '
				</select>
			</td>
		</tr>
		<tr>
			<td><label for="firstname">'. i18n_r('feedback/FIRSTNAME') .'</label></td>
			<td><input type="text" size="35" maxlength="40" name="firstname" value="' . (isset($firstname) ? html_entity_decode($firstname, ENT_QUOTES, 'UTF-8') : '') . '"/></td>
		</tr>
		<tr>
			<td><label for="name">'. i18n_r('feedback/LASTNAME') .'</label></td>
			<td><input type="text" size="35" maxlength="40" id="name" name="name" value="' . (isset($lastname) ? html_entity_decode($lastname, ENT_QUOTES, 'UTF-8') : '') . '"/></td>
		</tr>
		<tr>
			<td><label for="location">'. i18n_r('feedback/LOCATION') .'</label></td>
			<td><input type="text" size="35" maxlength="40" id="location" name="location" value="' . (isset($location) ? html_entity_decode($location, ENT_QUOTES, 'UTF-8') : '') . '"/></td>
		</tr>
		<tr>
			<td><label for="email">'. i18n_r('feedback/EMAIL') .'</label></td>
			<td><input type="text" size="35" maxlength="40" id="email" name="email" value="' . (isset($email) ? $email : '') . '" /></td>
		</tr>
		<tr>
			<td><label for="homepage">'. i18n_r('feedback/WEB') .'</label></td>
			<td><input type="text" size="35" maxlength="40" id="homepage" name="homepage" value="' . (isset($homepage) ? $homepage : '') . '"/></td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="hidden" name="id" value="' . (isset($id) ? $id : '') . '" />
				<input type="hidden" name="flag" value="save" />
				<p id="submit_line">
					<span><input class="submit" type="submit" name="submitted" value="' . i18n_r('feedback/ENTRY_SAVE') . '"></span>
					&nbsp;&nbsp;' . i18n_r('OR') . '&nbsp;&nbsp; <a class="cancel" href="load.php?id=feedback">' . i18n_r('CANCEL') . '</a>
				</p>
			</td>
		</tr>
	</table>
</form>';
?>
