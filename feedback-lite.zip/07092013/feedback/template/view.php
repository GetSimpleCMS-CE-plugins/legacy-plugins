<script type="text/javascript">
<? if (isset($_SESSION['filter'])) { ?>
$(function() {
<? if ($_SESSION['filter'] == 0) { ?>
	$('.edit-nav a').removeClass('current');
	$('#hidden-btn').addClass('current');	
<? } ?>
<? if ($_SESSION['filter'] == 1) { ?>
	$('.edit-nav a').removeClass('current');
	$('#released-btn').addClass('current');	
<? } ?>
	$('.edit-nav').prepend('<a href="load.php?id=feedback&amp;filter=x">x</a>');
});
<? } else { ?>
	$('.edit-nav a').removeClass('current');
	$('#view-btn').addClass('current');
<? } ?>
</script>
<form id="guestbook" action="load.php?id=feedback" method="post" accept-charset="utf-8">
<?php
debugLog(date('H:i:s') . " todo -> " . $todo);
switch ($todo) {
	case 'delete':
		echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_DELETE') 	. '</p></div>';
		break;
	case 'edit':
		echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_UPDATE') 	. '</p></div>';
		break;
	case 'release':
		echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_ACTIVE') 	. '</p></div>';
		break;
	case 'save':
		echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_SAVE') 		. '</p></div>';
		break;
	case 'unrelease':
		echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_INACTIVE') 	. '</p></div>';
		break;
}

echo '<div id="feedback-wrapper">';

$titles = explode (',', i18n_r('feedback/TITLE_LIST'));
$entries = getFiles(GBCONTENTPATH);

$entriesArray = array();
$entriesSorted = array();
$count = 0;

foreach ($entries as $file) {
	if (isFile($file, GBCONTENTPATH, 'xml')) {
		$id = basename($file, '.xml');
		$entry = @getXML(GBCONTENTPATH . $id . '.xml');	
		
		if (isset($_SESSION['filter']) && $_SESSION['filter'] == 0 && $entry['hide'] != '0') {
			continue;
		}
		
		if (isset($_SESSION['filter']) && $_SESSION['filter'] == 1 && $entry['hide'] != '1') {
			continue;
		}
		
		$entriesArray[$count]['id'] = $id;
		$entriesArray[$count]['date'] = strtotime($entry['date']); 
		$entriesArray[$count]['hide'] = $entry['hide'];
		$entriesArray[$count]['url'] = trim((string)$entry->homepage);
		$entriesArray[$count]['title'] = $titles[(string)$entry->title];
				
		if(!empty($entriesArray[$count]['url'])) {
			$entriesArray[$count]['salution'] = '<a href="' . $entry->homepage . '">' . $entry->firstname . ' ' . $entry->name . '</a>';
		} else {
			$entriesArray[$count]['salution'] = $entry->firstname . ' ' . $entry->name;
		}
		$entriesArray[$count]['entry'] = $entry;
		$count++;
	}
	debugLog(date('H:i:s') . " " . $file);
}

debugLog(date('H:i:s') . " entries -> " . $count);

// pager vars definition
$step = (int) $settings->entries_per_page['backend'];
if(is_frontend ()) {
	$step = (int) $settings->entries_per_page['frontend'];
}
$step = ($step == 0) ? 10 : $step; // default step is 10
$pages = (int) ($count / $step);
if ($count % $step != 0) $pages++;

$current = 1;
if(isset($_GET['page']) && !empty($_GET['page']) && $pages >= (int) $_GET['page'] && (int)$_GET['page'] > 0) {
	$current = (int)$_GET['page'];
}

if ($count > 0) {
	$entriesSorted = @array_reverse(subval_sort($entriesArray, 'date'));
	$index = ($current <= 1) ? 0 : (($current - 1) * $step);
	
	debugLog(date('H:i:s') . " index -> " . $index . " n -> ". ($index + $step));
	for ($i = $index, $n = $index + $step; $i < $n && $i < $count; $i++) {
		$entry = $entriesSorted[$i]['entry'];
		$id = $entriesSorted[$i]['id'];
		$url = $entriesSorted[$i]['url'];
		$title = $entriesSorted[$i]['title'];
		$salution = $entriesSorted[$i]['salution'];
		include 'entry.php';
	}
} else {
	echo '
	<div class="updated">
		<p>' . i18n_r('feedback/INFO_NOT_FOUND') . '</p>
	</div>';
} 

?>
</div>
</form>
<?php pager($count, $current, $step, $pages); ?>
