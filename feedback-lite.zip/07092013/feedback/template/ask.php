<?php

if(file_exists(GBCONTENTPATH . $id . '.xml')) {
	$currentEntry = @getXML(GBCONTENTPATH . $id . '.xml');
	
	$text = str_replace('{0}', $currentEntry->firstname . ' ' . $currentEntry->name , i18n_r('feedback/INFO_CONFIRM_DEL'));
	
	echo '
	<form id="guestbook" action="load.php?id=feedback" method="post" accept-charset="utf-8">
		<div class="error">
			<p>' . $text . '&nbsp;
				<input type="submit" class="submit" onclick="todo(\'delete\', \'' . $currentEntry['id'] . '\');" value="' . i18n_r('feedback/ENTRY_DELETE') . '" />&nbsp;'. i18n_r('OR') . ' 
				<a href="load.php?id=feedback" class="cancel">' . i18n_r('CANCEL') . '</a>
				<input type="hidden" name="id" value="' . $currentEntry['id'] . '" />
				<input type="hidden" name="flag" value="delete" />
			</p> 
		</div>
	</form>';
}
?>
