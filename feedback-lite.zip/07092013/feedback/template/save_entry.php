<?php

if(isset($_POST['flag']) && $_POST['flag'] == 'save') {
	$errors = array();	
	
	# prepare ans validate form fields
	$id 		= substr(prepareValue($_POST['id']), 0, 32);
	$title 		= (int)prepareValue($_POST['title']);
	$message 	= substr(prepareValue($_POST['message']), 	0, (int) $settings->message['max']);
	$lastname 	= substr(prepareValue($_POST['name']), 		0, (int) $settings->lastname['max']);
	$firstname 	= substr(prepareValue($_POST['firstname']), 0, (int) $settings->firstname['max']);
	$location 	= substr(prepareValue($_POST['location']), 	0, (int) $settings->location['max']);
	$email 		= substr(prepareValue($_POST['email']), 	0, (int) $settings->email['max']);
	$homepage 	= substr(prepareValue($_POST['homepage']), 	0, (int) $settings->homepage['max']);
	
	if ((int) $settings->firstname['min'] > strlen($firstname)) {
		$errors['firstname'] = str_replace('{0}', $settings->firstname['min'], i18n_r('feedback/FIRSTNAME_REQUIRED'));
	}
	
	if ((int) $settings->lastname['min'] > strlen($lastname)) {
		$errors['name'] = str_replace('{0}', $settings->lastname['min'], i18n_r('feedback/LASTNAME_REQUIRED'));
	}
	
	if ((int) $settings->location['min'] > strlen($location)) {
		$errors['location'] = str_replace('{0}', $settings->location['min'], i18n_r('feedback/LOCATION_REQUIRED'));
	}
	
	if ((int) $settings->email['min'] > strlen($email)) {
		$errors['email'] = str_replace('{0}', $settings->email['min'], i18n_r('feedback/EMAIL_REQUIRED'));
	}
	
	if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE) {
		$errors['email'] = i18n_r('feedback/EMAIL_FORMAT');
	}
	
	if ((int) $settings->homepage['min'] > strlen($homepage)) {
		$errors['homepage'] = str_replace('{0}', $settings->homepage['min'], i18n_r('feedback/WEB_REQUIRED'));
	}
	
	if ((int) $settings->message['min'] > strlen($message)) {
		$errors['message'] = str_replace('{0}', $settings->message['min'], i18n_r('feedback/MESSAGE_REQUIRED'));
	}
	
	if(count($errors) == 0) {
		if(!empty($id))	{
			editEntry($id, $title, $firstname, $lastname, $location, $email, $homepage, $message);
		} else {
			newEntry($title, $firstname, $lastname, $location, $email, $homepage, $message);
		}
		$submited = TRUE;
		include GBTEMPLATEPATH . 'view.php';
	} else {
		echo '<div class="error">';
		$ids = array();
		foreach ($errors as $key => $val) {
			echo '<p>' . $val . '</p>';
			$ids[] = '#' . $key;
		}
		echo '</div>
		<script type="text/javascript">
			$(document).ready(function () {
		  		$("' . implode(', ', $ids) . '").css(\'border-color\', \'#FF3333\');
			});
		</script>';
		include GBTEMPLATEPATH . 'edit_entry.php';
	}
}
?>