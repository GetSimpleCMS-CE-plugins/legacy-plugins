<?php

if(isset($_POST['stored']) && $_POST['stored'] == '1') {
	// entries pro page
	$op_entries_per_page['backend'] = (int) $_POST['entries_per_page_backend'];
	$op_entries_per_page['frontend'] = (int) $_POST['entries_per_page_frontend'];
	
	// only one submit pro session
	$op_only_one_per_session['frontend'] = (int) $_POST['only_one_per_session_frontend'];
	
	// field lenght definitions
	$op_firstname['min'] 	= (int) $_POST['firstname_min'];
	$op_firstname['max'] 	= (int) $_POST['firstname_max'];
	$op_lastname['min']		= (int) $_POST['lastname_min'];
	$op_lastname['max']		= (int) $_POST['lastname_max'];
	$op_location['min'] 	= (int) $_POST['location_min'];
	$op_location['max'] 	= (int) $_POST['location_max'];
	$op_email['min'] 		= (int) $_POST['email_min'];
	$op_email['max'] 		= (int) $_POST['email_max'];
	$op_homepage['min'] 	= (int) $_POST['homepage_min'];
	$op_homepage['max'] 	= (int) $_POST['homepage_max'];
	$op_message['min'] 		= (int) $_POST['message_min'];
	$op_message['max'] 		= (int) $_POST['message_max'];
	
	saveOptions($op_firstname, $op_lastname, $op_location, $op_email, $op_homepage, $op_message, $op_entries_per_page, $op_only_one_per_session);
	echo '<div id="msg" class="updated"><p>' . i18n_r('feedback/SUCCESS_OPTIONS') . '</p></div>';
} else {
	// entries pro page
	$op_entries_per_page['backend'] = (int) $settings->entries_per_page['backend'];
	$op_entries_per_page['frontend'] = (int) $settings->entries_per_page['frontend'];
	
	// only one submit pro session
	$op_only_one_per_session['frontend'] = (int) $settings->only_one_per_session['frontend'];
	
	// field lenght definitions
	$op_firstname['min'] 	= (int) $settings->firstname['min'];
	$op_firstname['max'] 	= (int) $settings->firstname['max'];
	$op_lastname['min']		= (int) $settings->lastname['min'];
	$op_lastname['max']		= (int) $settings->lastname['max'];
	$op_location['min'] 	= (int) $settings->location['min'];
	$op_location['max'] 	= (int) $settings->location['max'];
	$op_email['min'] 		= (int) $settings->email['min'];
	$op_email['max'] 		= (int) $settings->email['max'];
	$op_homepage['min'] 	= (int) $settings->homepage['min'];
	$op_homepage['max'] 	= (int) $settings->homepage['max'];
	$op_message['min'] 		= (int) $settings->message['min'];
	$op_message['max'] 		= (int) $settings->message['max'];
}

echo '
<form id="guestbook" action="load.php?id=feedback" method="post" accept-charset="utf-8">
<div class="leftsec">
	<p>
		<label for="entries_per_page_frontend">'. i18n_r('feedback/OPTIONS_EPP_FRONTEND') .'</label>
		<input id="entries_per_page_frontend" class="text short" type="text" value="'. $op_entries_per_page['frontend'] .'" name="entries_per_page_frontend">
	</p>
	<p>
		<label for="message">'. i18n_r('feedback/OPTIONS_MESSAGE_MIN') .'</label>
		<input id="message" class="text short" type="text" value="'. $op_message['min'] .'" name="message_min">
	</p>
	<p>
		<label for="firsname">'. i18n_r('feedback/OPTIONS_FIRSTNAME_MIN') .'</label>
		<input id="firsname" class="text short" type="text" value="'. $op_firstname['min'] .'" name="firstname_min">
	</p>
	<p>
		<label for="lastname">'. i18n_r('feedback/OPTIONS_LASTNAME_MIN') .'</label>
		<input id="lastname" class="text short" type="text" value="'. $op_lastname['min'] .'" name="lastname_min">
	</p>
	<p>
		<label for="location">'. i18n_r('feedback/OPTIONS_LOCATION_MIN') .'</label>
		<input id="location" class="text short" type="text" value="'. $op_location['min'] .'" name="location_min">
	</p>
	<p>
		<label for="email">'. i18n_r('feedback/OPTIONS_EMAIL_MIN') .'</label>
		<input id="email" class="text short" type="text" value="'. $op_email['min'] .'" name="email_min">
	</p>
	<p>
		<label for="web">'. i18n_r('feedback/OPTIONS_WEB_MIN') .'</label>
		<input id="web" class="text short" type="text" value="'. $op_homepage['min'] .'" name="homepage_min">
	</p>
	<p>
		<label for="only_one_per_session_frontend">'. i18n_r('feedback/ONLY_ONE_PRO_SESSION') .'</label>
		<input id="only_one_per_session_frontend" class="text short" type="text" value="'. $op_only_one_per_session['frontend'] .'" name="only_one_per_session_frontend">
	</p>
</div>
<div class="rightsec">
	<p>
		<label for="entries_per_page_backend">'. i18n_r('feedback/OPTIONS_EPP_BACKEND') .'</label>
		<input id="entries_per_page_backend" class="text short" type="text" value="'. $op_entries_per_page['backend'] .'" name="entries_per_page_backend">
	</p>
	<p>
		<label for="message">'. i18n_r('feedback/OPTIONS_MESSAGE_MAX') .'</label>
		<input id="message" class="text short" type="text" value="'. $op_message['max'] .'" name="message_max">
	</p>
	<p>
		<label for="firsname">'. i18n_r('feedback/OPTIONS_FIRSTNAME_MAX') .'</label>
		<input id="firsname" class="text short" type="text" value="'. $op_firstname['max'] .'" name="firstname_max">
	</p>
	<p>
		<label for="lastname">'. i18n_r('feedback/OPTIONS_LASTNAME_MAX') .'</label>
		<input id="lastname" class="text short" type="text" value="'. $op_lastname['max'] .'" name="lastname_max">
	</p>
	<p>
		<label for="location">'. i18n_r('feedback/OPTIONS_LOCATION_MAX') .'</label>
		<input id="location" class="text short" type="text" value="'. $op_location['max'] .'" name="location_max">
	</p>
	<p>
		<label for="email">'. i18n_r('feedback/OPTIONS_EMAIL_MAX') .'</label>
		<input id="email" class="text short" type="text" value="'. $op_email['max'] .'" name="email_max">
	</p>
	<p>
		<label for="web">'. i18n_r('feedback/OPTIONS_WEB_MAX') .'</label>
		<input id="web" class="text short" type="text" value="'. $op_homepage['max'] .'" name="homepage_max">
	</p>	
</div>
<div class="clear"></div>
<p id="submit_line">
	<input name="flag" type="hidden" value="settings" />
	<input name="stored" type="hidden" value="1" />
	<span><input class="submit" type="submit" name="submitted" value="' . i18n_r('feedback/OPTIONS_SAVE') . '"></span>
	&nbsp;&nbsp;' . i18n_r('OR') . '&nbsp;&nbsp; <a class="cancel" href="load.php?id=feedback">' . i18n_r('CANCEL') . '</a>
</p>
</form>
';

?>

