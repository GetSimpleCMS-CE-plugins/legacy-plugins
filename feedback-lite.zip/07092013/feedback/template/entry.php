<?php 
	
$titles = explode (',', i18n_r('feedback/TITLE_LIST'));
if(is_frontend ()) {
	echo '
	<div class="entry">
		<div class="entry-header">
			<b>' . $titles[(string)$entry->title] . ' ' . html_entity_decode($entry->name, ENT_QUOTES, 'UTF-8') . '</b> '. i18n_r('feedback/ENTRY_FROM') .' 
			<b>' . $entry->location . '</b> '. i18n_r('feedback/ENTRY_WRITE') .':
		</div>
		<div class="entry-body">' . html_entity_decode($entry->message, ENT_QUOTES, 'UTF-8')  . '</div>
	</div>';
} else {
	echo '
	<div class="entry">
		<div class="entry-header"><b>' . $title . ' ' . $salution . '</b>';
	$email = trim((string)$entry->email);
	if(!empty($email)) {
		echo '&laquo;<a href="mailto:' . $entry->email . '">' . $entry->email . '</a>&raquo;'; 
	} 
	echo ' '. i18n_r('feedback/ENTRY_FROM') .' <b>' . html_entity_decode($entry->location, ENT_QUOTES, 'UTF-8') . '</b> '. i18n_r('feedback/ENTRY_WRITE') .':
		</div>
	<div class="entry-body">' . html_entity_decode($entry->message, ENT_QUOTES, 'UTF-8') . '</div>
	<div class="entry-footer">';
	
	if($entry['hide'] == '1') {
		echo '<input type="submit" class="submit" onclick="todo(\'unrelease\', \'' . $entry['id'] . '\');" value="'. i18n_r('feedback/ENTRY_HIDE') .'" />&nbsp;';
	} else {
		echo '<input type="submit" class="submit" onclick="todo(\'release\', \'' . $entry['id'] . '\');" value="'. i18n_r('feedback/ENTRY_RELEASE') .'" />&nbsp;';
	}
	
	echo '
		<input type="submit" class="submit" onclick="todo(\'ask\', \'' . $entry['id'] . '\');" value="'. i18n_r('feedback/ENTRY_DELETE') .'" />&nbsp;
		<input type="submit" class="submit" onclick="todo(\'edit\', \'' . $entry['id'] . '\');" value="'. i18n_r('feedback/ENTRY_CHANGE') .'" />
	</div>
</div>';
} 
?>