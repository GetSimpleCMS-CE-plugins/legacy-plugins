<?php 

$submited = FALSE;

if(isset($_POST['todo'])) {
	$errors = array();
	
	# prepare ans validate form fields
	$title 		= (int)prepareValue($_POST['title']);
	$message 	= substr(prepareValue($_POST['message']), 	0, (int) $settings->message['max']);
	$lastname 	= substr(prepareValue($_POST['name']), 		0, (int) $settings->lastname['max']);
	$firstname 	= substr(prepareValue($_POST['firstname']), 0, (int) $settings->firstname['max']);
	$location 	= substr(prepareValue($_POST['location']), 	0, (int) $settings->location['max']);
	$email 		= substr(prepareValue($_POST['email']), 	0, (int) $settings->email['max']);
	$homepage 	= substr(prepareValue($_POST['homepage']), 	0, (int) $settings->homepage['max']);
	
	if ((int) $settings->firstname['min'] > strlen($firstname)) {
		$errors['firstname'] = str_replace('{0}', $settings->firstname['min'], i18n_r('feedback/FIRSTNAME_REQUIRED'));
	}
	
	if ((int) $settings->lastname['min'] > strlen($lastname)) {
		$errors['name'] = str_replace('{0}', $settings->lastname['min'], i18n_r('feedback/LASTNAME_REQUIRED'));
	}
	
	if ((int) $settings->location['min'] > strlen($location)) {
		$errors['location'] = str_replace('{0}', $settings->location['min'], i18n_r('feedback/LOCATION_REQUIRED'));
	}
	
	if ((int) $settings->email['min'] > strlen($email)) {
		$errors['email'] = str_replace('{0}', $settings->email['min'], i18n_r('feedback/EMAIL_REQUIRED'));
	}
	
	if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE) {
		$errors['email'] = i18n_r('feedback/EMAIL_FORMAT');
	}
	
	if ((int) $settings->homepage['min'] > strlen($homepage)) {
		$errors['homepage'] = str_replace('{0}', $settings->homepage['min'], i18n_r('feedback/WEB_REQUIRED'));
	}
	
	if ((int) $settings->message['min'] > strlen($message)) {
		$errors['message'] = str_replace('{0}', $settings->message['min'], i18n_r('feedback/MESSAGE_REQUIRED'));
	}
	
	if(count($errors) == 0) {
		newEntry($title, $firstname, $lastname, $location, $email, $homepage, $message);
		$_SESSION['submited'] = TRUE;
	} else {
		echo '<div class="inline-warning"><ul>';
		$ids = array();
		foreach ($errors as $key => $val) {
			echo '<li>' . $val . '</li>';
			$ids[] = '#' . $key;
		}
		echo '</ul></div>
		<script type="text/javascript">
			$(document).ready(function () {
		  		$("' . implode(', ', $ids) . '").css(\'border-color\', \'#FF3333\');
			});
		</script>';
	}
}

?>

<? if(!isset($_SESSION['submited'])) { ?>
<a name="submit-form"></a>
<form action="" method="post">
	<table cellpadding="0" cellspacing="0" barder="0" class="entry-input">
		<tr>
			<td colspan="2">
				<label for="message"><?php i18n('feedback/MESSAGE'); ?>*</label><br />
				<textarea id="message" name="message" cols="40" rows="6"><?=(empty($message)) ? '' : $message ?></textarea>
			</td>
		</tr>
		<tr>
			<td><label for="title"><?php i18n('feedback/TITLE'); ?></label></td>
			<td>
				<div class="select-box">	
					<select id="title" name="title"> 
					<?php	
						$titles = explode (',', i18n_r('feedback/TITLE_LIST'));
						$title = (empty($title)) ? '0' : $title;
						foreach ($titles as $title_key => $title_value) {
							echo '<option value="' . $title_key . '" ' . ((isset($title) && $title == $title_key) ? 'selected="selected"' : '') . '>' . $title_value . '</option>';
						}
					?>
					</select>
				</div>
			</td>
		</tr>
		<tr>
			<td><label for="firstname"><?php i18n('feedback/FIRSTNAME'); ?></label></td>
			<td><input type="text" size="35" maxlength="<?=$settings->firstname['max']?>" name="firstname" value="<?=(empty($firstname)) ? '' : $firstname ?>"/></td>
		</tr>
		<tr>
			<td><label for="name"><?php i18n('feedback/LASTNAME'); ?>*</label></td>
			<td><input type="text" size="35" maxlength="<?=$settings->lastname['max']?>" id="name" name="name" value="<?=(empty($lastname)) ? '' : $lastname ?>"/></td>
		</tr>
		<tr>
			<td><label for="location"><?php i18n('feedback/LOCATION'); ?>*</label></td>
			<td><input type="text" size="35" maxlength="<?=$settings->location['max']?>" id="location" name="location" value="<?=(empty($location)) ? '' : $location ?>"/></td>
		</tr>
		<tr>
			<td><label for="email"><?php i18n('feedback/EMAIL'); ?></label></td>
			<td><input type="text" size="35" maxlength="<?=$settings->email['max']?>" id="email" name="email" value="<?=(empty($email)) ? '' : $email ?>"/></td>
		</tr>
		<tr>
			<td><label for="homepage"><?php i18n('feedback/WEB'); ?></label></td>
			<td><input type="text" size="35" maxlength="<?=$settings->homepage['max']?>" id="homepage" name="homepage" value="<?=(empty($homepage)) ? '' : $homepage ?>"/></td>
		</tr>
		<tr>
			<td colspan="2" style="text-align:right">
				<input name="todo" type="hidden" value="1" />
				<input type="submit" value="<?php i18n('feedback/SUBMIT'); ?>" />
			</td>
		</tr>
	</table>
</form>
<? } else { ?>
<div class="inline-warning">
	<? if ((int) $settings->only_one_per_session['frontend'] == 0) { unset($_SESSION['submited']); } ?>
	<?php i18n('feedback/SUBMIT_TEXT'); ?>
</div>
<? } ?>
