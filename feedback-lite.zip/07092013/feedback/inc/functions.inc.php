<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

/*
 *	Plugin Name: Feedback
 *	Description: Feedback plugin for GetSimple
 *	Version: 0.1.1
 *	Thomas Klinski <thomas.klinski(at)ymail.com>
 * 
 *	This plugin is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

function checkEnviroment() {
	if (@mkdir(GBDATAPATH, 0777)) {
		$fh = fopen(GBDATAPATH . '.htaccess', 'w');
		fwrite($fh, 'Deny from all');
		fclose($fh);
	}
	
	if (@mkdir(GBCONTENTPATH, 0777)) {
		$fh = fopen(GBCONTENTPATH . '.htaccess', 'w');
		fwrite($fh, 'Deny from all');
		fclose($fh);
	}
	
	if (!file_exists(GBSETTINGS)) {
		$xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><settings />');
		$only_one_per_session = $xml->addChild('only_one_per_session');
		$only_one_per_session->addAttribute('frontend', 0);
		$entries_per_page = $xml->addChild('entries_per_page');
		$entries_per_page->addAttribute('frontend', 5);
		$entries_per_page->addAttribute('backend', 5);
		
		$message = $xml->addChild('message');
		$message->addAttribute('min', 50);
		$message->addAttribute('max', 1023);
		
		$firstname = $xml->addChild('firstname');
		$firstname->addAttribute('min', 0);
		$firstname->addAttribute('max', 31);
		
		$lastname = $xml->addChild('lastname');
		$lastname->addAttribute('min', 1);
		$lastname->addAttribute('max', 31);
		
		$location = $xml->addChild('location');
		$location->addAttribute('min', 1);
		$location->addAttribute('max', 31);
		
		$email = $xml->addChild('email');
		$email->addAttribute('min', 0);
		$email->addAttribute('max', 31);
		
		$homepage = $xml->addChild('homepage');
		$homepage->addAttribute('min', 0);
		$homepage->addAttribute('max', 31);
		
		@XMLsave($xml, GBSETTINGS);
 	}
}
 
function prepareValue($val, $len = 0) {
	$old_val = $val;
	$val = antixss($val);
	if ($old_val != $val) {
		debugLog(date('H:i:s') . " xss found [" . htmlentities($old_val) . ", " . $_SERVER['REMOTE_ADDR'] . "]");	
	}	
	$val = stripslashes($val);
	$val = htmlentities($val, ENT_NOQUOTES, 'UTF-8');
	return trim($val);
}
 
function newEntry($title, $firstname, $name, $location, $email, $homepage, $message) {
	$id = md5(uniqid(mt_rand(), true));
	$createDate = date("d.m.Y H:i");
	$time = time();
	$ip = $_SERVER['REMOTE_ADDR'];
	
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><entry />');
	$xml->addAttribute('id', $id);
	$xml->addAttribute('date', $createDate);
	$xml->addAttribute('hide', 0);
	$newTitle = $xml->addChild('title', $title);
	$newFirstname = $xml->addChild('firstname');
	$newFirstname->addCData($firstname);
	$newName = $xml->addChild('name');
	$newName->addCData($name);
	$newLocation = $xml->addChild('location');
	$newLocation->addCData($location);
	$newName = $xml->addChild('email', $email);
	$newHomepage = $xml->addChild('homepage', $homepage);
	$newText = 	$xml->addChild('message');
	$newText->addCData($message);
	$newIp = $xml->addChild('ip', $ip);
	
	@XMLsave($xml, GBCONTENTPATH . $id . '.xml');
}

function editEntry($id, $title, $firstname, $name, $location, $email, $homepage, $message) {
	$xml = @getXML(GBCONTENTPATH . $id . '.xml');
	$xml->title = $title;
	$xml->firstname = $firstname;
	$xml->name = $name;
	$xml->location = $location;
	$xml->email = $email;
	$xml->homepage = $homepage;
	$xml->message = safe_slash_html($message);
	@XMLsave($xml, GBCONTENTPATH . $id . '.xml');
}

function saveOptions($firstname, $lastname, $location, $email, $homepage, $message, $entries_per_page, $op_only_one_per_session) {
	$settings = @getXML(GBSETTINGS);
	
	$settings->entries_per_page['frontend'] = $entries_per_page['frontend'];
	$settings->entries_per_page['backend'] = $entries_per_page['backend'];
	
	$settings->only_one_per_session['frontend'] = $op_only_one_per_session['frontend'];
	
	$settings->firstname['min'] = (int) $firstname['min'];
	$settings->firstname['max'] = (int) $firstname['max'];
	$settings->lastname['min'] 	= (int) $lastname['min'];
	$settings->lastname['max'] 	= (int) $lastname['max'];
	$settings->location['min'] 	= (int) $location['min'];
	$settings->location['max'] 	= (int) $location['max'];
	$settings->email['min'] 	= (int) $email['min'];
	$settings->email['max'] 	= (int) $email['max'];
	$settings->homepage['min'] 	= (int) $homepage['min'];
	$settings->homepage['max'] 	= (int) $homepage['max'];
	$settings->message['min'] 	= (int) $message['min'];
	$settings->message['max'] 	= (int) $message['max'];
	
	@XMLsave($settings, GBSETTINGS);
}

function releaseEntry($id, $val) {
	$xml = @getXML(GBCONTENTPATH . $id . '.xml');
	$xml['hide'] = $val;
	@XMLsave($xml, GBCONTENTPATH . $id . '.xml');
}

function deleteEntry($id) {
	unlink(GBCONTENTPATH . $id . '.xml');
}

function getAllEntries($echo = false) {
	global $settings;
	$count = 0;	
	ob_start();
	$entries = @getFiles(GBCONTENTPATH);
	$entriesArray = array();
	$entriesSorted = array();
	$titles = explode (',', i18n_r('feedback/TITLE_LIST'));

	foreach ($entries as $file) {
		if (isFile($file, GBCONTENTPATH, 'xml')) {
			$id = basename($file, '.xml');
			$entry = @getXML(GBCONTENTPATH . $id . '.xml');
			
			if($entry['hide'] != 1) {
				continue;
			}
			
			$entriesArray[$count]['id'] = $id;
			$entriesArray[$count]['date'] = strtotime($entry['date']);
			$entriesArray[$count]['hide'] = $entry['hide'];
			$entriesArray[$count]['url'] = trim((string)$entry->homepage);
			$entriesArray[$count]['title'] = $titles[(string)$entry->title];

			if(!empty($entriesArray[$count]['url'])) {
				$entriesArray[$count]['salution'] = '<a href="' . $entry->homepage . '">' . $entry->firstname . ' ' . $entry->name . '</a>';
			} else {
				$entriesArray[$count]['salution'] = $entry->firstname . ' ' . $entry->name;
			}
			$entriesArray[$count]['entry'] = $entry;
			$count++;
		}
	}
	
	// pager vars definition
	$step = (int) $settings->entries_per_page['backend'];
	if(is_frontend ()) {
		$step = (int) $settings->entries_per_page['frontend'];
	}
	$step = ($step == 0) ? 10 : $step; // default step is 10
	$pages = (int) ($count / $step);
	if ($count % $step != 0) $pages++;
	
	$current = 1;
	if(isset($_GET['page']) && !empty($_GET['page']) && $pages >= (int) $_GET['page'] && (int)$_GET['page'] > 0) {
		$current = (int)$_GET['page'];
	}
	
	if ($count > 0) {
		$entriesSorted = @array_reverse(subval_sort($entriesArray, 'date'));
		$index = ($current <= 1) ? 0 : (($current - 1) * $step);
		
		debugLog(date('H:i:s') . " index -> " . $index . " n -> ". ($index + $step));
		for ($i = $index, $n = $index + $step; $i < $n && $i < $count; $i++) {
			$entry = $entriesSorted[$i]['entry'];
			$id = $entriesSorted[$i]['id'];
			$url = $entriesSorted[$i]['url'];
			$title = $entriesSorted[$i]['title'];
			$salution = $entriesSorted[$i]['salution'];
			include GBTEMPLATEPATH . 'entry.php';
		}
	} else {
		echo '<div class="inline-warning">'. i18n_r('feedback/INFO_NOT_FOUND') .'</div>';
	}
	// pagination:) 
	pager($count, $current, $step, $pages);

	$content = ob_get_contents();
	ob_end_clean();
	if ($echo) echo $content;
	return '<div class="feedback-wrapper">' . $content . '</div>';
}

function getSubmitFormular($echo = false) {
	global $settings;
	ob_start();
	include(GBTEMPLATEPATH . 'add_entry.php');
	$content = ob_get_contents();
	ob_end_clean();
	if ($echo) echo $content;
	return $content;
}

function getLanguages() {
	$langs = array();
	$files = getFiles(GBLANGPATH);
	foreach ($files as $file) {
		if (isFile($file, GBLANGPATH, 'php')) {
			$lang = basename($file, '.php');
			$langs[$lang] = GBLANGPATH . $file;
		}
	}
	ksort($langs);
	return $langs;
}

function getRandomEntry() {
	$titles = explode (',', i18n_r('feedback/TITLE_LIST'));
	$entriesArray = array();
	$entries = getFiles(GBCONTENTPATH);
	$count = 0;
	
	foreach ($entries as $file) {
		if (isFile($file, GBCONTENTPATH, 'xml')) {
			$id = basename($file, '.xml');
			$entry = @getXML(GBCONTENTPATH . $id . '.xml');
			if($entry['hide'] == 1) {
				$entriesArray[$count]['id'] = $id;
				$entriesArray[$count]['date'] = $entry['date'];
				$entriesArray[$count]['title'] = $titles[(string)$entry->title];
				$entriesArray[$count]['name'] = $entry->name;
				$entriesArray[$count]['location'] = $entry->location;
				$entriesArray[$count]['message'] = $entry->message;
				
				$count++;
			}
		}
	}
	return entry2string($entriesArray[array_rand($entriesArray)]);
}


function entry2string($entry) {
	echo '
	<div class="entry">
		<div class="entry-header">
			<b>' . $entry['title'] . ' ' . $entry['name'] . '</b> '. i18n_r('feedback/ENTRY_FROM') .' 
			<b>' . $entry['location'] . '</b> '. i18n_r('feedback/ENTRY_WRITE') .':
		</div>
		<div class="entry-body">' . html_entity_decode($entry['message'], ENT_QUOTES, 'UTF-8') . '</div>
	</div>';
}

function pager($total, $current, $step, $pages) {
	global $PRETTYURLS;
	$prev = ($current <= 1) ? 1 : ($current - 1);
	$next = ($current >= $pages) ? $pages : ($current + 1);
	$url = "load.php?id=feedback&amp;page=";
	if(is_frontend ()) {
		$url = find_url(get_page_slug(false), get_parent(false));
		if ($PRETTYURLS == 1) {
			$url .= "?page=";
		} else {
			$url .= "&amp;page=";
		}
	}
	
	debugLog(date('H:i:s') . " pages -> " . $pages . " entries per page -> " . $step . " current -> " . $current);
	if ($total > $step) { // pager
		echo '<div class="pager">';
		echo '<a href="' . $url . $prev . '" class="page">&laquo;</a>';
		for ($i = 1; $i <= $pages; $i++) {
			if($current == $i) {
				echo '<span class="page current">' . $i . '</span>';
			} else {
				echo '<a href="' . $url . $i . '" class="page">'. $i .'</a>';
			}
		}
		echo '<a href="' . $url . $next . '" class="page">&raquo;</a>';
		echo '</div>';
	}
}

?>
