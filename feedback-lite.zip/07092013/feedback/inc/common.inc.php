<?php if (!defined('IN_GS')) { die('you cannot load this page directly.'); }

# path definitions
define('GBDATAPATH', 		GSDATAPATH  . 'feedback/');
define('GBBACKUPPATH', 		GSBACKUPSPATH  . 'feedback/');
define('GBINCPATH', 		GSPLUGINPATH . 'feedback/inc/');
define('GBLANGPATH', 		GSPLUGINPATH . 'feedback/lang/');
define('GBTEMPLATEPATH', 	GSPLUGINPATH . 'feedback/template/');
define('GBCSSPATH', 		GSPLUGINPATH . 'feedback/css/');
define('GBBACKENDCSS', 		GBCSSPATH . 'default.css');
define('GBSETTINGS', 		GBDATAPATH . 'settings.xml');
define('GBCONTENTPATH', 	GBDATAPATH . 'entries/');

$views_backend = array(
	"ask", "delete", "edit", "save", "release", "unrelease", 
	"unrelease", "settings", "add", "default" => "view"
);

$settings = @getXML(GBSETTINGS);

?>