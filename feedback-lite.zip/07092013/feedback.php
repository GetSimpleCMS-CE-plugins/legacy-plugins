<?php

/*
 *	Plugin Name: Feedback
 *	Description: Feedback plugin for GetSimple
 *	Version: 0.1.1
 *	Thomas Klinski <thomas.klinski(at)ymail.com>
 */
 
/*	The plugin is free software and you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  any later version.
 * 
 *	This plugin is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

# get correct id for plugin
$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
	$thisfile,
	'Feedback Lite',
	'0.2',
	'Thomas Klinski',
	'',
	'Feedback plugin for GetSimple',
	'pages',
	'gb_backend'
);

session_start(); // session need for filter

# includes
require_once('feedback/inc/functions.inc.php');
require_once('feedback/inc/common.inc.php');

# languages
i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');

# hooks
add_filter('content','gb_frontend');
add_action('header', 'gb_header');
add_action('pages-sidebar', 'createSideMenu', array($thisfile, i18n_r('feedback/PLUGIN_NAME')));

function gb_backend() {
	global $settings, $views_backend;	
	@checkEnviroment();
	
	$todo = 'view';
	if(isset($_POST['flag']) && !empty($_POST['flag']) && in_array($_POST['flag'], $views_backend)) {
		$todo = $_POST['flag'];
	} else {
		$todo = $views_backend['default'];
	}
	
	$id = '';
	if(isset($_POST['id']) && !empty($_POST['id'])) {
		$id = substr($_POST['id'], 0, 32);
	}
	
	if (isset($_GET['filter'])) { // filter 
		if (is_numeric($_GET['filter'])) {
			$_SESSION['filter'] = (int)$_GET['filter'];
		} else if (isset($_SESSION['filter'])) {
			unset($_SESSION['filter']);
		}	
	}
	
	echo '<h3 class="floated">'. i18n_r('feedback/BACKEND_TITLE') .'</h3>
	<div class="edit-nav clearfix">
		<a accesskey="h" id="hidden-btn" href="load.php?id=feedback&amp;filter=0">'. i18n_r('feedback/ENTRY_HIDDEN') .'</a>
		<a accesskey="r" id="released-btn" href="load.php?id=feedback&amp;filter=1">'. i18n_r('feedback/ENTRY_RELEASED') .'</a>
		<a accesskey="s" id="settings-btn" href="javascript:todo(\'settings\',\'\')">'. i18n_r('feedback/ENTRY_OPTIONS') .'</a>
		<a accesskey="n" id="add-btn" href="javascript:todo(\'add\',\'\')">'. i18n_r('feedback/ENTRY_NEW') .'</a>
		<a accesskey="v" id="view-btn" href="javascript:todo(\'\',\'\')">'. i18n_r('feedback/ENTRY_VIEW') .'</a>
	</div>';
	
	echo '<script type="text/javascript">
		function todo(flag, id) {
			$("<input>").attr({
			    type: "hidden",
			    id: "current",
			    name: "id",
			    value: id
			}).appendTo("#guestbook");
			
			$("<input>").attr({
			    type: "hidden",
			    id: "action",
			    name: "flag",
			    value: flag
			}).appendTo("#guestbook");
			
			$("#guestbook").submit();
			return false;
		}
		
		$(document).ready(function () {
			$("#msg").delay(5000).fadeOut(200);
			$("#' . $todo . '-btn").attr("class", "current");
		});
	</script>';
	
	switch ($todo) {
		case 'ask':
			include(GBTEMPLATEPATH . 'ask.php');
			include(GBTEMPLATEPATH . 'view.php');
			break;
		case 'delete':
			deleteEntry($id);
			include(GBTEMPLATEPATH . 'view.php');
			break;
		case 'edit':
			include(GBTEMPLATEPATH . 'edit_entry.php');
			break;
		case 'save':
			include(GBTEMPLATEPATH . 'save_entry.php');
			break;
		case 'release':
			releaseEntry($id, 1);
			include(GBTEMPLATEPATH . 'view.php');
			break;
		case 'unrelease':
			releaseEntry($id, 0);
			include(GBTEMPLATEPATH . 'view.php');
			break;
		case 'settings':
			include(GBTEMPLATEPATH . 'settings.php');
			break;
		case 'add':
			include(GBTEMPLATEPATH . 'edit_entry.php');
			break;
		default:
			include(GBTEMPLATEPATH . 'view.php');
	}
}

function gb_frontend($content) {
	$pattern = '`(?<!<code>)\(%\s*feedback\s*(\w*)\s*%\)`';	
	preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);
	foreach ($matches as $match) {
		if ('submit' == $match[1]) { // replace with submit form
			$replacement = getSubmitFormular();
		}
		
		if ('show' == $match[1]) { // replace with entries
			$replacement = getAllEntries();
		}
		
		if ('random' == $match[1]) { // replace with random entry
			$replacement = getRandomEntry();
		}
		$content = preg_replace('`(?<!<code>)\(%\s*feedback\s*(' . trim($match[1]) . ')\s*%\)`', $replacement, $content, 1);
	}
	
	return $content;
}

function gb_header() {
	echo '<style type="text/css">';
	include(GBBACKENDCSS);
	echo '</style>';
}

?>