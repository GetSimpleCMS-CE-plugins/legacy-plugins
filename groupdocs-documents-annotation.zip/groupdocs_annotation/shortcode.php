<?php

function addGroupDocsAnnotation($atts, $content = null) {
 extract(gdan_shortcode_atts(array(
    "id" => null,
    "width" => '500',
    "height" => '600'    
  ), $atts));
  return '<div><iframe src="https://apps.groupdocs.com/document-annotation/embed/'.$id.'?quality=50&use_pdf=true&download=false&referer=getsimple/1.0" frameborder="0" width="'.$width.'" height="'.$height.'"></iframe></div>';
}
gdan_add_shortcode('GroupDocsAnnotation','addGroupDocsAnnotation', '[groupdocs id="" width="" height="" /]');
