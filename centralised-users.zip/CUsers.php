<?php
/*
  Plugin Name: Centralised Users (CUsers)
  Description: Allows users to sign in to your site and access various defined services.
  Author:      Lawrence Okoth-Odida
*/

# session
require_once(GSPLUGINPATH.'/CUsers/include/session.php');

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile,
	'CU Base',
	'1.1',
	'Lawrence Okoth-Odida',
	'http://lokida.co.uk/',
	'Allows users to register/sign in to your site and access user-only content and services.',
	'plugins',
	'CUsers'
);

# activate actions/filters
add_action('theme-header', 		'CU_front_end',   array());
add_action('plugins-sidebar',	'createSideMenu', array($thisfile,'CUsers'));
add_action('search-index',    'CUser_search_index');
add_filter('search-item',     'CUser_search_item');

# language
i18n_merge('CUsers') || i18n_merge('CUsers','en_US');

# constants
define ('CUCOMMONIMG',  $SITEURL.'plugins/CUsers/img/');
define ('CUCOMMONJS',   $SITEURL.'plugins/CUsers/js/');
define ('CUCOMMONCSS',  $SITEURL.'plugins/CUsers/css/');

# scripts
register_script('markitup',       CUCOMMONJS.'jquery.markitup.min.js', '1.0', FALSE);
register_script('markitupBBCode', CUCOMMONJS.'jquery.markitup.bbcode.js', '1.0', FALSE);
register_script('markitupHTML',   CUCOMMONJS.'jquery.markitup.html.js', '1.0', FALSE);
register_script('sortable',       CUCOMMONJS.'jquery.sortable.min.js', '1.0', FALSE);
queue_script('markitup', GSBOTH);
queue_script('markitupBBCode', GSBOTH);
queue_script('markitupHTML', GSBACK);
queue_script('sortable', GSBOTH);
queue_script('jquery', GSBOTH);

# styles
register_style('markitup',        CUCOMMONCSS.'markitup.css', '1.0', 'screen');
register_style('markitupBBCode',  CUCOMMONCSS.'markitup_set_bbcode.css', '1.0', 'screen');
register_style('markitupHTML',    CUCOMMONCSS.'markitup_set_html.css', '1.0', 'screen');
queue_style('markitup', GSBOTH); 
queue_style('markitupBBCode', GSBOTH); 
queue_style('markitupHTML', GSBACK);

# functions
function CUsers() {
	require_once(GSPLUGINPATH.'/CUsers/include/tables.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/validation.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/users.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/forms.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/common.php');
	require_once(GSPLUGINPATH.'/CUsers/include/display.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/admin.php');
}

function CU_front_end() {
	require_once(GSPLUGINPATH.'/CUsers/captcha/index.php');
  require_once(GSPLUGINPATH.'/CUsers/include/tables.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/validation.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/users.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/forms.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/common.php');
	require_once(GSPLUGINPATH.'/CUsers/include/display.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/search.php');
}


?>