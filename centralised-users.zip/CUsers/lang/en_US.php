<?php
$i18n = array(
  // general terms (used across CUser plugins)
    'USER'	                =>	'User',
    'USERS'               	=>	'Users',
    'PAGE'	                =>	'Page',
    'PAGES'	                =>	'Pages',
    'DOMAIN'	              =>	'Domain',
    'URLS'	                =>	'URLs',
    'TABLE'	                =>	'Table',
    'TABLES'	              =>	'Tables',
    'SEND'	                =>	'Send',
    'EDIT'			            =>	'Edit',
    'SAVE'			            =>	'Save',
    'PREVIEW'			          =>	'Preview',
    'REPLY'			            =>	'Reply',
    'SUCCESS'	              =>	'Success',
    'CONTENT'	              =>	'Content',
    'AUTHOR'	              =>	'Author',
    'UNDO'	                =>	'Undo',
    'CREATE'	              =>	'Create',
    'EDIT'	                =>	'Edit',
    'DELETE'	              =>	'Delete',
    'CURRENT'	              =>	'Current',
    'CHANGES_SUCCESSFULL'	  =>	'Your changes have been saved.',
    'NO_PERMISSION'	        =>	'You do not have permission to access this page.',
    'OPTIONS'	              =>	'Options',
    'SEARCH'	              =>	'Search',
    'SEARCH_KEYWORD'	      =>	'Search by Keyword',
    'SEARCH_USERS'	        =>	'Search by Username',
    
  // signin/out
    'WELCOME'         	    =>	'Welcome',
    'WELCOME_BACK'	        =>	'Welcome back,',
    'USER_NAME'       	    =>	'Username',
    'USER_PASS'       	    =>	'Password',
    'SIGNUP'	              =>	'Sign up',
    'SIGNUP_SUCCESS'        => 'You have succesfully signed up!',
    'SIGNIN'	              =>	'Sign in',
    'SIGNOUT'	              =>	'Sign out',
    'SIGNOUT_SUCCESS'	      =>	'You have successfully signed out.',
    'SIGNED_OUT'	          =>	'You have successfully signed out.',
    'CAPTCHA'               =>  'Captcha',

  // pagination
  
    'FIRST'	                =>	'First',
    'PREV'	                =>	'Prev',
    'NEXT'	                =>	'Next',
    'LAST'	                =>	'Last',
	
  // user levels
    'MEMBER'	              =>	'Member',
    'MODERATOR'	            =>	'Moderator',
    'ADMINISTRATOR'	        =>	'Adminstrator',
    'BANNED'	              =>	'Banned',
    'INACTIVE'	            =>	'Inactive',
	
  // field names and validation
    'ID'			              =>	'ID',
    'USER_NAME'			        =>	'Username',
    'USER_DISPLAY'			    =>	'Display',
    'USER_AVATAR'		        =>	'Avatar',
    'USER_SIGNATURE'			  =>	'Signature',
    'USER_DATE'			        =>	'Registered',
    'USER_EMAIL'			      =>	'Email',
    'USER_LEVEL'			      =>	'Level',
    'USER_IP'			          =>	'IP Address',
    'CHANGE_PASS'			      =>	'Change Password',
    'CHANGE_PASS_CONFIRM'	  =>	'Confirm Password', // used on editing profile
    'USER_PASS_CONFIRM'	    =>	'Confirm Password', // used on registration
    'CENSOR_LIST'			      =>	'Censor List',
    'BAN_LIST'			        =>	'Ban List',
    'ADMIN_EMAIL'			      =>	'Admin Email',
    
    // message board
    'POST_CONTENT'			    =>	'Content',
    'TOPIC_SUBJECT'			    =>	'Subject',
  
    'ERROR_REQUIRED'		    =>	'This field is required. Please enter a value.',
    'ERROR_ALPHA'			      =>	'This field should contain only alphabetical characters',
    'ERROR_ALPHA_NUM'		    =>	'This field should contain only alphabetical characters and numbers.',
    'ERROR_EMAIL'			      =>	'Please input a valid email address.',
    'ERROR_USER_MATCH'		  =>	'This username does not exist.',
    'ERROR_USER_EXISTS'		  =>	'This username is already being used.',
    'ERROR_EMAIL_EXISTS'	  =>	'This email address is already being used.',
    'ERROR_PASS_MATCH'		  =>	'These passwords do not match.',
    'ERROR_MIN_LENGTH'		  =>	'This field does not meet the minimum length.',
    'ERROR_MAX_LENGTH'		  =>	'This field exceeds the maximum length.',
    'ERROR_NUMERIC'			    =>	'This field should hold a numeric value.',
    'ERROR_NO_MATCH'			  =>	'This field does not match.',
    'ERROR_DETAILS_EXISTS'	=>	'A user with these details already exists.',
    'ERROR_URL'				      =>	'This is not a valid URL.',
    'ERROR_IMG'				      =>	'Your image does not have a valid file extension. The allowed types are:
                                   <ul>
                                     <li>gif</li>
                                     <li>png</li>
                                     <li>jpg/jpeg</li>
                                   </ul>',
    'ERROR_CAPTCHA'			    =>	'The captcha field has been filled out incorrectly.',
    'UPDATE_SUCCESS'        =>  'Updates succesfull.',
    
  // require other plugins
    'NEED_I18N'             =>  'This feature requires <a href="http://get-simple.info/extend/plugin/i18n/69/">i18n</a> to be installed and enabled.',
    'NEED_I18N_CUSTSPEC'    =>  'This feature requires <a href="http://get-simple.info/extend/plugin/i18n-custom-fields/100/">i18n Special Pages</a> or <a href="http://get-simple.info/extend/plugin/i18n-special-pages/319/">Custom Fields</a> to be installed and enabled.',
    'NEED_I18N_SEARCH'      =>  'This feature requires <a href="http://get-simple.info/extend/plugin/i18n-search/82/">i18n Search</a> to be installed and enabled.',
    'NEED_CUPMS'            =>  'This feature requires <a href="">CUsers Private Messages</a> to be installed and enabled.',
    
  // search plugin
    'MAX'                   => 'Maximum',
    'MIN'                   => 'Minimum',
    'SORT_BY'               => 'Sort by',
    'ASC'                   => 'Ascending',
    'DESC'                  => 'Descending',
    'YOU_MUST_WAIT'         => 'You must wait',
    'SECS_TO_SEARCH'        => 'Seconds to search',
    'NO_RESULTS'            => 'No search results.',
    
  // pms (this is here because of the validation script being part of the core)
    'INBOX_FULL_VALIDATION'		=>	'This user\'s inbox is full. They will not be able to receieve any further messages until they delete some from their inbox.',
  
  // admin
    'HOME'			            =>	'Home',
    'SETUP'			            =>	'Setup',
    'SETUP_DESCRIPTION'		  =>	'Performs initial configuration for Centralised Users. <strong>You must go here if you have just installed the plugin.</strong>',
    'SETUP_SUCCESS'			    =>	'Setup successfull.',
    'USERS_DESCRIPTION'		  =>	'Modify/administrate existing user profiles.',
    'SETTINGS'			        =>	'Settings',
    'SETTINGS_DESCRIPTION'	=>	'Configure general settings for this plugin (e.g. IP ban list).',
    'EDIT_USER'			        =>	'Edit User',
    'SUCCESSFULLY_CREATED'  =>	'Successfully created',
    'GOTO_SETUP'            =>	'Go to the SETUP tab to configure this plugin.',
    
  );
?>