<?php
class CUForms {
  public function signUp($captcha=false) {
    if(!empty($_POST['signup'])) {
      $validation_rules = array(
        'user_name'     => array(
          'required'		=> true,
          'alpha_num'		=> true,
          'user_signup'	      => $_POST['user_name'],
        ),
        'user_pass'     => array(
          'required'    => true,
        ),
        'user_pass_confirm' => array(
          'required'    => true,
          'match'       => $_POST['user_pass'],
        ),
        'user_email'    => array(
          'required'    => true,
          'email'       => true,
          'email_match' => array(FALSE, $_POST['user_email']),
        ),
        'captcha'   => array(
          'required'    => true,
          'captcha'    => (isset($_POST['captcha']) ? $_SESSION['captcha']['code'] : ''),
        )
      );
      if(empty($_SESSION['captcha'])) unset($validation_rules['captcha']);
      $validator = new CUValidator($_POST, $validation_rules);
      if (!$validator->validate()) {
        $errors = $validator->get_errors();
       
        return $validator->print_errors();
      }
      else {
        $clean_data = $validator->get_fields();
        unset($clean_data['signup']);
        $clean_data['user_pass'] = sha1($clean_data['user_pass']);
        $clean_data['user_display'] = $clean_data['user_name'];
        
        mail($clean_data['user_email'],'Centralised User account activated','user: '.$clean_data['user_name'].' | pass: '.$clean_data['user_pass_confirm'], $clean_data['user_email']);
        unset($clean_data['user_pass_confirm']);
        
        // fills in the rest of the required fields
        $clean_data['user_ip'] = CUSession::findIP();
        $clean_data['user_level'] = 0;
        $clean_data['user_avatar'] = $clean_data['user_signature'] = '';
        $clean_data['user_date'] = time();
        var_dump($clean_data);
        
        createRecord('CU_users', $clean_data);
        CUTable::refreshIndex();
        return '<div class="success">'.i18n_r('CUsers/SIGNUP_SUCCESS').'</div>'.return_CU_redirect($_SERVER['REQUEST_URI'], 3000);
      }
    }
    else {
      $_SESSION['captcha'] = ($captcha==true ? captcha() : '');
      $form = '<label>'.i18n_r('CUsers/USER_NAME').'</label>
                 <input type="text" name="user_name" />
               <label>'.i18n_r('CUsers/USER_PASS').'</label>
                  <input type="password" name="user_pass" />
               <label>'.i18n_r('CUsers/USER_PASS_CONFIRM').'</label>
                  <input type="password" name="user_pass_confirm" />
               <label>'.i18n_r('CUsers/USER_EMAIL').'</label>
                  <input type="text" name="user_email" />'.($captcha==true ? 
              '<label>'.i18n_r('CUsers/CAPTCHA').'</label>
                <input type="text" name="captcha" />
                <img src="'.$_SESSION['captcha']['image_src'].'" class="captcha" alt="CAPTCHA security code" />' : '').'
              <input type="submit" name="signup" value="'.i18n_r('CUsers/SIGNUP').'" />';
      return $form;
    }
  }
  
  public function signIn($captcha=false) {
    if(!empty($_POST['signin'])) {
      $validation_rules = array(
        'user_name'   => array(
          'required'		=> true,
          'alpha_num'		=> true,
          'user'	=> $_POST['user_name'],
        ),
        'user_pass'   => array(
          'required'    => true,
          'pass_match'  => $_POST['user_name'],
        ),
        'captcha'   => array(
          'required'    => true,
          'captcha'    => (isset($_POST['captcha']) ? $_SESSION['captcha']['code'] : ''),
        )
      );
      if(empty($_SESSION['captcha'])) unset($validation_rules['captcha']);
      $validator = new CUValidator($_POST, $validation_rules);
      if (!$validator->validate()) {
        // Get errors from validator
        $errors = $validator->get_errors();
       
        // Return errors
        return $validator->print_errors();
      }
      else {
        $clean_data = $validator->get_fields();
        $status = CUSession::signIn();
        if($status===true) {
          $user = new CUser($clean_data['signin']['id']);
          return '<span class="welcome">'.i18n_r('CUsers/WELCOME_BACK').' '.$user->getName().'.</span>
                  <form method="post"><input type="submit" name="signout" value="'.i18n_r('CUsers/SIGNOUT').'" /></form>';
        }
        else { 
          return i18n_r('CUsers/ACCOUNT_LOCKED');
        }
      }
    }
    elseif(!empty($_POST['signout'])) {
      CUSession::signOut();
      return '<span class="welcome">'.i18n_r('CUsers/SIGNOUT_SUCCESS').'</span>';
    }
    elseif(CUSession::status()) {
      $user = new CUser($_SESSION['CUser']['user_id']);
      return '<div class="signOut"><span class="welcome">'.i18n_r('CUsers/WELCOME_BACK').' '.$user->getName().'.</span>
              <form method="post"><input type="submit" name="signout" value="'.i18n_r('CUsers/SIGNOUT').'" /></form></div>';
    }
    else {
      $_SESSION['captcha'] = ($captcha==true ? captcha() : '');
      $form = '<div class="signIn">
                <label>'.i18n_r('CUsers/USER_NAME').'</label>
                   <input type="text" name="user_name" />
                 <label>'.i18n_r('CUsers/USER_PASS').'</label>
                    <input type="password" name="user_pass" />'.($captcha==true ? 
                '<label>'.i18n_r('CUsers/CAPTCHA').'</label>
                  <input type="text" name="captcha" />
                  <img src="'.$_SESSION['captcha']['image_src'].'" class="captcha" alt="CAPTCHA security code" />' : '').'
                <input type="submit" name="signin" value="'.i18n_r('CUsers/SIGNIN').'" />
              </div>';
      return $form;
    }
  }
  
  // edit details
  public function editUserDetails($id) {
    if(CUSession::status()) {
      $user = DM_query("SELECT * FROM CU_users WHERE id = ".$id, "DM_SINGLE");
      
      if(!empty($user)) {
        $profile = new CUser($user['id']);
        $title = $profile->getName();
        $content = '';
        $field = array();
        
        // sets user_pass settings
        $field['user_pass']['status'] = $field['user_pass_change']['status'] = $field['user_pass_confirm']['status'] = '';
        
        if(empty($_POST['save_profile_changes'])) {
          foreach ($user as $setting=>$value) {
            $field[$setting]['value'] = $value;
            $field[$setting]['status']	= 'success';
          }
          foreach ($field as $name=>$array) $field[$name]['status'] = 'success';
        }
        else {
          foreach ($_POST as $setting=>$value) {
            $field[$setting]['value'] = $value;
            $field[$setting]['status']	= 'success';
          }
          if(!empty($_POST['save_profile_changes'])) {
            // validation rules
            $validation_rules = array(
              'user_display' 		=> array(
                'required'    => true,
                'alpha_num'     => true,
                'user_match'	=> array(array('user_display', 'user_name'), $field['user_display']['value'], $user['id']),
              ),
              'user_email'		=> array(
                'required'   	=> true,
                'email'		 	=> true,
                'user_match'	=> array('user_email', $field['user_email']['value'], $user['id']),
              ),
              'user_avatar'		=> array(
                'url'		 	=> true,
                'img'		 	=> true,
              ),
              'user_pass'		=> array(
                'required'  =>true,
                'pass_match'  => trim($_POST['user_name']),
              ),
              'user_pass_change'		=> array(
                'required'  =>true,
                'min_length'  => 8,
                'match'  => $_POST['user_pass_confirm'],
              ),
              'user_pass_confirm'		=> array(
                'required'  =>true,
                'match'  => $_POST['user_pass_change'],
              ),
            );
            
            // unset the password validation rules under specific conditions
            if(empty($_POST['user_pass']) && empty($_POST['user_pass_change']) && empty($_POST['user_pass_confirm'])) {
              unset($validation_rules['user_pass']);
            }
            if(empty($_POST['user_pass_change'])) {
              unset($validation_rules['user_pass_confirm']);
            }
            if(empty($_POST['user_pass_confirm'])) {
              unset($validation_rules['user_pass_change']);
            }
            
            $validator = new CUValidator($_POST, $validation_rules);
            if (!$validator->validate()) {
              // Get errors from validator
              $errors = $validator->get_errors();
        
              // styles each field that has an error
              foreach ($errors as $name=>$error) $field[$name]['status'] = 'error';
              // Return errors
              CU_msg_update($validator->print_errors(), $success=FALSE);
            }
            else {
              $clean_data = $validator->get_fields();
              unset($clean_data['save_profile_changes']);
              if(!empty($clean_data['user_pass_confirm'])) $clean_data['user_pass'] = sha1($clean_data['user_pass_confirm']);
              else unset($clean_data['user_pass']); 
              unset($clean_data['user_pass_change']);
              unset($clean_data['user_pass_confirm']);
              CUTable::updateRecord('CU_users', $user['id'], $clean_data);
              CUTable::refreshIndex();
              CU_msg_update(i18n_r('CUsers/UPDATE_SUCCESS'), $success=TRUE);
            }
          }
        }
        $content .= ' <form class="bbcode" method="post">
                        <input type="hidden" name="user_name" value="'.$user['user_name'].'">
                        <label>'.i18n_r('CUsers/USER_DISPLAY').'</label>
                          <input type="text" name="user_display" class="'.$field['user_display']['status'].'" value="'.$field['user_display']['value'].'"/>
                        <label>'.i18n_r('CUsers/USER_EMAIL').'</label>
                            <input type="text" name="user_email" class="'.$field['user_email']['status'].'" value="'.$field['user_email']['value'].'"/>
                        <label>'.i18n_r('CUsers/USER_AVATAR').'</label>
                            <input type="text" name="user_avatar" class="'.$field['user_avatar']['status'].'" value="'.$field['user_avatar']['value'].'"/>
                        <label>'.i18n_r('CUsers/USER_SIGNATURE').'</label>
                            <textarea type="text" class="'.$field['user_signature']['status'].'" name="user_signature">'.$field['user_signature']['value'].'</textarea>
                        <label>'.i18n_r('CUsers/USER_PASS').'</label>
                            <input type="password" name="user_pass" class="'.$field['user_pass']['status'].'"/>
                        <label>'.i18n_r('CUsers/CHANGE_PASS').'</label>
                            <input type="password" name="user_pass_change" class="'.$field['user_pass_change']['status'].'"/>
                        <label>'.i18n_r('CUsers/CHANGE_PASS_CONFIRM').'</label>
                            <input type="password" name="user_pass_confirm" class="'.$field['user_pass_confirm']['status'].'"/>
                        <input type="submit" name="save_profile_changes" value="'.i18n_r('CUsers/SAVE').'">
                      </form>';
      }
      return $content;
    }
    return false;
  }
  
  // forgot password
  public function forgotPass($captcha=false) {
    if(!empty($_POST['forgotpass'])) {
      $user = DM_query("SELECT * FROM CU_users WHERE user_email = '".$_POST['user_email']."'", "DM_SINGLE");
      $validation_rules = array(
        'user_email'		=> array(
          'required'   	=> true,
          'match'		 	=> (isset($user['user_email']) ? $user['user_email'] : ''),
              ),
        'captcha'   => array(
          'required'    => true,
          'captcha'    => (isset($_POST['captcha']) ? $_SESSION['captcha']['code'] : ''),
        )
      );
      if(empty($_SESSION['captcha'])) unset($validation_rules['captcha']);
      
      $validator = new CUValidator($_POST, $validation_rules);
      if (!$validator->validate()) {
        // Get errors from validator
        $errors = $validator->get_errors();
       
        // Return errors
        return $validator->print_errors();
      }
      else {
        $clean_data = $validator->get_fields();
        $user_pass = CUTable::randomKey(8);
        
        CUTable::updateRecord('CU_users', $user['id'], array('user_pass'=>sha1($user_pass)));
        mail($user['user_email'],'Centralised User account modified','user: '.$user['user_name'].' | pass: '.$user_pass, $user['user_email']);
        
        return '<div class="success">'.i18n_r('CUsers/DETAILS_SENT_TO_EMAIL').'</div>';
      }
    }
    else {
      $_SESSION['captcha'] = ($captcha==true ? captcha() : '');
      $form = '<div class="forgotPass">
                <label>'.i18n_r('CUsers/USER_EMAIL').'</label>
                 <input type="text" name="user_email" />'.($captcha==true ? 
              '<label>'.i18n_r('CUsers/CAPTCHA').'</label>
                <input type="text" name="captcha" />
                <img src="'.$_SESSION['captcha']['image_src'].'" class="captcha" alt="CAPTCHA security code" />' : '').'
              <input type="submit" name="forgotpass" value="'.i18n_r('CUsers/SEND').'" />
              </div>';
      return $form;
    }
  }

}
?>