<?php
// populates the users array
function get_CU_users() {
  global $CU_users;
  $users = DM_query("SELECT * FROM CU_users");
  if(!empty($users)) {
    foreach ($users as $key=>$user) {
      $CU_users[$key]['user_name']       = $user['user_name'];
      $CU_users[$key]['user_display']    = $user['user_display'];
      $CU_users[$key]['user_email']      = $user['user_email'];
      $CU_users[$key]['user_avatar']     = $user['user_avatar'];
      $CU_users[$key]['user_signature']  = $user['user_signature'];
      $CU_users[$key]['user_date']       = date('j F Y', $user['user_date']);
    }
  }
}

// indexes the users
function CUser_search_index() {
  global $CU_users;
  foreach ($CU_users as $id => $user) {
    $date = strtotime($user['user_date']);
    i18n_search_index_item('cuser:'.$id, null, $date, $date, array('cuser', strtolower($user['user_name']), strtolower($user['user_display']), strtolower($user['user_email'])), $user['user_display'], $user['user_signature']);
  }
}

// indexes each item
function CUser_search_item($id, $language, $creDate, $pubDate, $score) {
  if (!class_exists('CUserResultItem')) {
    class CUserResultItem extends I18nSearchResultItem {
      protected $data = null;
      protected function get($name) {
        global $CU_users;
        if (!$this->data) {
          $this->data = $CU_users[substr($this->id,6)];
          if (!$this->data) return null;
        }
        switch ($name) {
          case 'title': return $this->data['user_display'];
          case 'description': return $this->data['user_signature'];
          case 'content': return '<p>' . htmlspecialchars($this->data['user_signature']) . '</p>';
          case 'link': return null; 
          default: return @$this->data[$name]; 
        }
      }
    }
  }
  if (substr($id,0,6) == 'cuser:') return new CUserResultItem($id, $language, $creDate, $pubDate, $score);
  return null;
}

function CUser_search_display($item, $showLanguage, $showDate, $dateFormat, $numWords) {
  return false;
}

// sets up the array
$CU_users = array();
get_CU_users();
?>