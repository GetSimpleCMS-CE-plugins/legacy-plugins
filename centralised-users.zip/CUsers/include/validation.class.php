<?php
class CUValidator { // built using 'http://cipriancociorba.com/php-form-validation-part-2-building-the-validator-class/'
  // constants
  const REGEX_EMAIL         = '/^[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}$/i';
  const REGEX_ALPHA         = '/^[A-Z.]+$/i';
  const REGEX_ALPHA_NUM     = '/^[A-Z0-9._+-]+$/i';
  
  // variables
  public  $img_extensions = array('gif', 'jpg', 'jpeg', 'png');
  private $fields         = array();
  private $rules          = array();
  private $errors         = array();
  private $user           = array();
  
  // construct object
  function __construct($form_data, $rules_data) {
    $this->fields = $this->sanitize($form_data);
    $this->rules = $rules_data;
    $userSpecificForms = array('signin', 'save_profile_changes');
    foreach ($userSpecificForms as $form) {
      if(array_key_exists($form, $this->fields)) {
        $this->user = DM_query("SELECT * FROM CU_users WHERE user_name = '".$this->fields['user_name']."'", "DM_SINGLE");
      }
    }
  }
  
  // sanitize form data
  private function sanitize($form_data) {
    $sanitized_data = filter_var_array($form_data, FILTER_SANITIZE_STRING);
    return $sanitized_data;
  }
    
  // initialise form data property
  public function validate() {
    // validate each form field
    foreach ($this->fields as $field => $value) {
      // if the field value is empty
      if (empty($value)) {
        // If the field is set as required, throw error
        if (isset($this->rules[$field]['required'])) {
          $this->errors[$field][] = i18n_r('CUsers/ERROR_REQUIRED');
        }
      }
      // else, if the field has a value and is declared in rules
      elseif (isset($this->rules[$field])) {

        // remove 'required' from list of callable functions.
        unset($this->rules[$field]['required']);
 
        foreach ($this->rules[$field] as $rule => $rule_value) {
          call_user_func_array(
            array($this, $rule),
            array($field, $value, $rule_value)
          );
        }
      }
    }
    // return result
    if (empty($this->errors)) {
      return TRUE;
    }
    else {
      return FALSE;
    }
  }
  // rules defined below
  
  // email
  private function email($field, $value) {
    if (!preg_match(self::REGEX_EMAIL, $value)) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_EMAIL');
    }
  }
    
  // email match (check it exists)
  private function email_match($field, $value, $match) {
    // $match[0] = id of the user, $match[1] = email
    $user = DM_query("SELECT user_email FROM CU_users");
    $emails = multi_array_map('strtolower', DM_query("SELECT id, user_email FROM CU_users"));
    $i=0;
    foreach ($emails as $user) {
      if (($match[0]==$user['id'] && strtolower($match[1])==$user['user_email'])) $i++;
    }
    if ($i==0 && multi_in_array(strtolower($value), $emails)) $this->errors[$field][] = i18n_r('CUsers/ERROR_EMAIL_EXISTS');
  }
  
  // general matching
  private function match($field, $value, $match) {
    if (!($value===$match)) $this->errors[$field][] = i18n_r('CUsers/ERROR_NO_MATCH');
  }

  // user match (checks user_name and user_display)
  private function user_match($field, $value, $match) {
    // $match[0] = field(s), $match[1] = field value, $match[2] = user id
    if(is_array($match[0])) {
      $field_query = '';
      foreach ($match[0] as $match_field) {
        $field_query .= ', '.$match_field;
      }
      $users = multi_array_map('strtolower', DM_query("SELECT id ".$field_query." FROM CU_users")); 
    }
    else {
      $users = multi_array_map('strtolower', DM_query("SELECT id, ".$match[0]." FROM CU_users"));
    }
    $i=0;
    foreach ($users as $user) {
      if(is_array($match[0])) {
        foreach ($match[0] as $match_field) {
          if (($match[2]==$user['id'] && strtolower($match[1])==$user[$match_field])) $i++;
        }
      }
      else {
        if (($match[2]==$user['id'] && strtolower($match[1])==$user[$match[0]])) $i++;
      }
    }
    if($i==0 && multi_in_array(strtolower($value), $users)) $this->errors[$field][] = i18n_r('CUsers/ERROR_DETAILS_EXISTS');
  }
   
  // alphabetical
  private function alpha($field, $value) {
    if (!preg_match(self::REGEX_ALPHA, $value)) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_ALPHA');
    }
  }
   
  // alphanumeric
  private function alpha_num($field, $value) {
    if (!preg_match(self::REGEX_ALPHA_NUM, $value)) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_ALPHA_NUM');
    }
  }

  // is numeric
  private function numeric($field, $value) {
    if(!is_numeric($value)) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_NUMERIC');
    }
  }
    
  // checks username exists
  private function user($field, $value) {
    if(empty($this->user)) $this->errors[$field][] = i18n_r('CUsers/ERROR_USER_MATCH');
  }
  
  // checks username already exists
  private function user_signup($field, $value, $name) {
    // do a case insensitive search
    $usernames = DM_query("SELECT * FROM CU_users");
    if(!empty($usernames)) {
      // puts all usernames in lowercase
      $usernames = multi_array_map('strtolower', $usernames);
      if(multi_in_array(strtolower(trim($value)), $usernames)) {
        $this->errors[$field][] = i18n_r('CUsers/ERROR_USER_EXISTS');
      }
    }
  }
  
  // password match
  private function pass_match($field, $value, $username) {
    if(empty($this->user) || (isset($this->user['user_pass']) && sha1($value)!=$this->user['user_pass'])) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_PASS_MATCH');
    } 
  }
  
  // min length
  private function min_length($field, $value, $min_length) {
    $length = strlen($value);
 
    // Throw error is field length does not meet minimum
    if ($length < $min_length) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_MIN_LENGTH');
    }
  }
  // max length
  private function max_length($field, $value, $max_length) {
    $length = strlen($value);
 
    // Throw error is field length does not meet minimum
    if ($length > $max_length) {
      $this->errors[$field][] = i18n_r('CUsers/ERROR_MAX_LENGTH');
    }
  }
    
  // url
  private function url($field, $value) {
    if(!filter_var($value, FILTER_VALIDATE_URL)) $this->errors[$field][] = i18n_r('CUsers/ERROR_URL');
  }
    
  // image
  private function img($field, $value) {
    if(strlen($value)>0) {
      $extension = strtolower(end(explode('.', $value)));
      if(!in_array($extension, $this->img_extensions)) {
        $this->errors[$field][] = i18n_r('CUsers/ERROR_IMG');
      }
    }
  }
  
  // captcha
  private function captcha($field, $value, $captcha) {
    if($value === $captcha) {
      // codes match
    }
    else $this->errors[$field][] = i18n_r('CUsers/ERROR_CAPTCHA');
  }
    
  // inbox check (for PMs)
  private function inbox_check($field, $value, $user) {
    $pm_settings = DM_query("SELECT * FROM CU_pms_settings ORDER BY id DESC", "DM_SINGLE");
    $msgs = DM_query("SELECT * FROM CU_pms WHERE pm_to = ".$user." ORDER BY pm_date DESC");
    if (count($msgs)>=$pm_settings['pm_max']) {
      $this->errors[$field][] = i18n_r('CU_pms/INBOX_FULL_VALIDATION');
    }
  }
    
  // return form data
  public function get_fields() {
    if(array_key_exists('signin', $this->fields)) $this->fields['signin'] = $this->user;
    return $this->fields;
    }
  
  // return validation errors  
  public function get_errors() {
    // unset the 'passwords do not match' error is the user_name isn't found
      if(array_key_exists('signin', $this->fields) && array_key_exists('user_name', $this->errors)) unset($this->errors['user_pass']);
    
    // unset the 'email exists' message if the email field is already invalid
      if(array_key_exists('signup', $this->fields) && array_key_exists('user_email', $this->errors) && in_array(i18n_r('CUsers/ERROR_EMAIL'), $this->errors['user_email'])) {
        $key = array_search(i18n_r('CUsers/ERROR_EMAIL_EXISTS'), $this->errors['user_email']);
        if($key) unset($this->errors['user_email'][$key]);
      }
    // return the errors
    return $this->errors;
  }
  
  // print validation errors  
  public function print_errors() {
    global $SITEURL;
    if(!empty($this->errors)) {
      $print_errors = '';
      // if the error array is non-empty, show error page  
      $print_errors .= '<p><img src="'.CUCOMMONIMG.'/error.png">&nbsp; Some fields are not filled in correctly.</p>
                          <ul>'; 
      foreach($this->errors as $field=>$errors) {
        $print_errors .= '  <li>'.i18n_r('CUsers/'.strtoupper($field)).'<ul>';
        foreach ($errors as $error) {
          // uses array to output all of the errors in an unordered list
          $print_errors .= '<li>'.$error.'</li>';
        }
        $print_errors .= '</ul></li>';
      } 
      $print_errors .= '  </ul>';
      return $print_errors;
    }
    else {
      return false;
    }
  }
 
  // return validation errors as json (for AJAX)
  public function get_errors_json() {
    return json_encode($this->errors);
  }
}
?>