<?php
class CUPagination {
	// paginates the content
	public function query($query, $max_records=5, $return) {
		global $_GET;
				
		if(!isset($_GET['page'])) {
			$_GET['page'] = 1; // so if GET isn't set, it still shows the first page's results
		}
		
		switch ($return) {
			case 'pages':
				return ceil(count($query)/$max_records);
				break;
			default:
				return array_slice($query, ($max_records*($_GET['page']-1)), $max_records);		
				break;
		}			
	}
	
	// returns the total number of pages
	
	// gets the navigation links
	public function getNav($url, $key='page', $pages) {
    $getNav = '';
    if (!isset($_GET[$key])) $_GET[$key] = 1;
		if(isset($_GET[$key]) && (is_numeric($_GET[$key]))) { 	
			$current = $_GET[$key];
			$prev = $current-1;
			$next = $current+1;
    }
			
    if($current==1) { $prev=$next=1; }
    
    $getNav .= '<a class="page first" href="'.$url.'&'.$key.'=1">'.i18n_r('CUsers/FIRST').'</a>';
    $getNav .= '<a class="page prev" href="'.$url.'&'.$key.'='.$prev.'">'.i18n_r('CUsers/PREV').'</a>';
    
    if($pages<7) { // 6 or less pages
      $i=1;
      while($i<=$pages) {
        $class = 'pg_'.$i;
        if($_GET[$key]==$i) $class = 'current';
        $getNav .= '<a class="page '.$class.'" href="'.$url.'&'.$key.'='.$i.'">'.$i.'</a>';
        $i++;
      }
    }
    else {
      if($current==1) { // first page
        $i=1;
        while($i<=3) {
          $getNav .= '<a href="page '.$url.'&'.$key.'='.$i.'">'.$i.'</a>';
          $i++;
        }
      }
      
      elseif($current==$pages) { // last page
        $i=$pages-2;
        while($i<=$pages) {
          $getNav .= '<a href="page '.$url.'&'.$key.'='.$i.'">'.$i.'</a>';
          $i++;
        }
        $next = $pages;
      }
      else { // any page between
        $getNav .= '<a class="page prev" href="'.$url.'&'.$key.'='.$prev.'">'.$prev.'</a>';
        $getNav .= '<a class="page current" href="'.$url.'&'.$key.'='.$current.'">'.$current.'</a>';
        $getNav .= '<a class="page next" href="'.$url.'&'.$key.'='.$next.'">'.$next.'</a>';
      }
    }
    
    $getNav .= '<a class="page next" href="'.$url.'&'.$key.'='.$next.'">'.i18n_r('CUsers/NEXT').'</a>';
    $getNav .= '<a class="page last" href="'.$url.'&'.$key.'='.$pages.'">'.i18n_r('CUsers/LAST').'</a>';
  
  return $getNav;
	}
}

// admin panel settings
class CUAdminPanel {
	var $settings;
	
	public function __construct() {
		$this->settings			= DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
		$this->censorList		= $this->settings['censor_list'];
		$this->ban_list			= $this->settings['ban_list'];
	}
	
	public function censorList() {
		return explode("\n", $this->censorList);
	}
	
	public function banList() {
		$form 	= 	new CU_forms();

		if(empty($_POST['ban_list'])) {
			$ban_list = $this->ban_list;
		}
		else {
			$ban_list = $_POST['ban_list'];
		}
		
		$fields	= array(
					'IP'=>array(
						'field'=>'textarea',
						'type'=>'text',
						'name'=>'ban_list',
						'value'=>$ban_list,
						'disabled'=>''
					),
				);
		$btns	= array(
					'Save'=>array(
						'field'=>'input',
						'type'=>'submit',
						'name'=>'save',
						'value'=>'Save changes',
						'disabled'=>''
					),
				);
				
		#var_dump(explode("\n", $ban_list));
		echo '<form method="post" action="">';
				$form->create_form($fields);
		echo '<div class="no_label" style="text-align: right;">';
				$form->create_form($btns);
		echo '</div>
			  </form>';
	}
	
	public function censor() {
		$form 	= 	new CU_forms();

		if(empty($_POST['censorList'])) {
			$censorList = $this->censorList;
		}
		else {
			$censorList = $_POST['censorList'];
		}
		
		$fields	= array(
					'Censor List'=>array(
						'field'=>'textarea',
						'type'=>'text',
						'name'=>'censorList',
						'value'=>$censorList,
						'disabled'=>''
					),
				);
		$btns	= array(
					'Save changes'=>array(
						'field'=>'input',
						'type'=>'submit',
						'name'=>'save',
						'value'=>'Save changes',
						'disabled'=>''
					),
				);
				
		echo '<form method="post" action="">';
				$form->create_form($fields);
		echo '<div class="no_label" style="text-align: right;">';
				$form->create_form($btns);
		echo '</div>
			  </form>';
	}
}

// filters post content (for censors and BBCode)
class CUContentFilter {	
	var $content;
	
	public function censor($string) {
		$list	= new CUAdminPanel();
		$words	= $list->censorList();
		$string = str_replace($list->censorList(), '***', $string);
		return $string;
	}
	
	public function bbcode($string) {
		// code replacements edited from 'http://thesinkfiles.hubpages.com/hub/Regex-for-BBCode-in-PHP'
		
		// bold
		$string = preg_replace('#\[b\](.+)\[\/b\]#iUs', '<strong>$1</strong>', $string);
		
		// italic
		$string = preg_replace('#\[i\](.+)\[\/i\]#iUs', '<span style="font-style: italic;">$1</span>', $string);
		
		// underline
		$string = preg_replace('#\[u\](.+)\[\/u\]#iUs', '<span style="text-decoration: underline;">$1</span>', $string);
		
		// links
		$string = preg_replace('#\[url\=(.+)\](.+)\[\/url\]#iUs', '<a href="$1">$2</a>', $string);
		
		// images
		$string = preg_replace('#\[img\](.+)\[\/img\]#iUs', '<img src="$1" alt="Image" />', $string); 
		
		// lists
		$string = preg_replace('#\[list\]#iUs', '<ul>', $string);
		$string = preg_replace('#\[list\=(.+)\](.+)\[\/list\]#iUs', '<ol start="$1">$2</ol>', $string);
		$string = preg_replace('#\[/list]#iUs', '</ul>', $string);
		$string = preg_replace('#\[\*\]#iUs', '<li>', $string);
		$string = preg_replace('#\[/\*]#iUs', '</li>', $string);
    
    // headings
    $string = preg_replace('#\[heading\=(.+)\](.+)\[\/heading\]#iUs', '<h$1>$2</h$1>', $string); 
    
    // span
    $string = preg_replace('#\[span\](.+)\[\/span\]#iUs', '<span>$1</span>', $string); 
    $string = preg_replace('#\[span\=(.+)\](.+)\[\/span\]#iUs', '<span class="$1">$2</span>', $string); 
		
		// quotes
		$string = preg_replace('#\[quote\=(.+)\]#iUs', '<blockquote class="quote"><strong>$1 said:</strong><br />', $string);
		$string = preg_replace('#\[/quote]#iUs', '</blockquote>', $string);
		
		// font size
		$string = preg_replace('#\[size\=(.+)\](.+)\[\/size\]#iUs', '<span style="font-size:$1%;">$2</span>', $string); 
		
		// codes
		$string = preg_replace('#\[code\](.+)\[\/code\]#iUs', '<div class="code"><span><strong>Code</strong>:</span><pre><code>$1</code></pre></div>', $string); 
		
		// returns
		$string = preg_replace('#(\s*\n)+#iUs', '<br />', $string);

		return $string;
	}
}

// message updates on the site
function CU_msg_update($msg, $success=TRUE, $admin=FALSE) {

  // changes styling depending on whether this is successful or an error
  if($success==TRUE) {
    $show = 'updated';
  }
  else {
    $show = 'error';
  }
  
  // changes the coding depending on whether this is an admin end message
  if($admin==TRUE) {
    // admin end
    echo '	<script type="text/javascript">
          $(function() {
            $("div.bodycontent").before("<div class=\"'.$show.'\" style=\"display:block;\">"+'.json_encode($msg).'+"</div>");
            $(".updated, .error").fadeOut(500).fadeIn(500);
          });
        </script>';
  }
  else {
    // front end
    echo '	<script type="text/javascript">
          $(function() {
            $(".updated, .error").fadeOut(500).fadeIn(500);
          });
        </script>
        <div class="'.$show.'">'.$msg.'</div>';
  }
}

// common call for the filter
function CU_filter($string) {
	$filter = new CUContentFilter();
	$s = $filter->censor($string);
	$s = $filter->bbcode($s);
	return $s;
}
 
?>