<?php
// admin.php

// http://www.bookofzeus.com/articles/convert-simplexml-object-into-php-array/
function xml2array($xml) {
  $arr = array();
  foreach ($xml as $element) {
    $tag = $element->getName();
    $e = get_object_vars($element);
    if (!empty($e)) {
      $arr[$tag] = $element instanceof SimpleXMLElement ? xml2array($element) : $e;
    }
    else {
      $arr[$tag] = trim($element);
    }
  }
  return $arr;
}

// navigation
global $SITEURL;
if(!defined('CUADMINURL')) define('CUADMINURL', $SITEURL.'/admin/load.php?id=CUsers');
end($_GET);
echo '<h3 class="floated">';
  if(!isset($_POST['edit'])) {
    if(key($_GET)=='id') echo 'Centralised Users';
    else echo i18n_r('CUsers/'.strtoupper(key($_GET)));
  }
  else {
    $user = DM_query("SELECT * FROM CU_users WHERE id = ".$_POST['edit'], "DM_SINGLE");
    echo i18n_r('CUsers/EDIT').' '.$user['user_name'];
  }  
echo '</h3>
      <div class="edit-nav">
        <a href="'.CUADMINURL.'&settings">'.i18n_r('CUsers/SETTINGS').'</a>
        <a href="'.CUADMINURL.'&users">'.i18n_r('CUsers/USERS').'</a>
        <a href="'.CUADMINURL.'&setup">'.i18n_r('CUsers/SETUP').'</a>
        <a href="'.CUADMINURL.'">'.i18n_r('CUsers/HOME').'</a>
        <div class="clear"></div>
      </div>
      <div style="clear: both"></div>';
end($_GET);
if(key($_GET)=='id') {
  echo '<table>
          <tbody>
            <tr>
              <th style="width: 100px;"><a href="'.CUADMINURL.'&setup">'.i18n_r('CUsers/SETUP').'</a></th>
              <td>'.i18n_r('CUsers/SETUP_DESCRIPTION').'</td>
            </tr>
            <tr>
              <th><a href="'.CUADMINURL.'&users">'.i18n_r('CUsers/USERS').'</a></th>
              <td>'.i18n_r('CUsers/USERS_DESCRIPTION').'</td>
            </tr>
            <tr>
              <th><a href="'.CUADMINURL.'&settings">'.i18n_r('CUsers/SETTINGS').'</a></th>
              <td>'.i18n_r('CUsers/SETTINGS_DESCRIPTION').'</td>
            </tr>
          </tbody>
        </table>';
}
      
// setup
if(isset($_GET['setup'])) {
  $setupMsgs = array();

  // create the tables
  $query = new CUTable;
  $tables = array(
  'CU_users'=>array(
      'user_name'=>array(
        'name' => 'user_name',
        'type' => 'textlong'
      ),
      'user_pass'=>array(
        'name' => 'user_pass',
        'type' => 'textlong'
      ),
      'user_email'=>array(
        'name' => 'user_email',
        'type' => 'textlong'
      ),
      'user_date'=>array(
        'name' => 'user_date',
        'type' => 'int'
      ),
      'user_level'=>array(
        'name' => 'user_level',
        'type' => 'int'
      ),
      'user_display'=>array(
        'name' => 'user_display',
        'type' => 'textlong'
      ),
      'user_avatar'=>array(
        'name' => 'user_avatar',
        'type' => 'textlong'
      ),
      'user_signature'=>array(
        'name' => 'user_signature',
        'type' => 'textlong'
      ),
      'user_ip'=>array(
        'name' => 'user_ip',
        'type' => 'textlong'
      )
    ),
    'CU_settings'=>array(
      'admin_email'=>array(
        'name' => 'admin_email',
        'type' => 'textlong',
      ),
      'ban_list'=>array(
        'name' => 'ban_list',
        'type' => 'textlong'
      ),
      'censor_list'=>array(
        'name' => 'censor_list',
        'type' => 'textlong'
      ),
    )
  );
  $data = array(
    'CU_users'=>array(
      'user_name'=>'admin',
      'user_pass'=>'d033e22ae348aeb5660fc2140aec35850c4da997',
      'user_email'=>'noreply@yourdomain.com',
      'user_date'=>time(),
      'user_level'=>2,
      'user_avatar'=>'',
      'user_display'=>'admin',
      'user_signature'=>'Your signature goes here.',
      'user_ip'=>'',
    ),
    'CU_settings'=>array(
      'admin_email'=>'noreply@yourdomain.com',
      'censor_list'=>'',
      'ban_list'=>'',
    )
  );
	CUTable::createTable($tables, $data);
  
    // perform queries to see if the tables were successfully created and populated
    foreach ($data as $table=>$fields) {
      $verify = DM_query("SELECT * FROM $table");
      if(!empty($verify)) $setupMsgs['success'][] = '<strong>'.$table.'</strong> '.strtolower(i18n_r('CUsers/TABLE').' '.i18n_r('CUsers/SUCCESSFULLY_CREATED')).'.';
      else                $setupMsgs['error'][]   = '<strong>'.$table.'</strong> '.strtolower(i18n_r('CUsers/TABLE').' '.i18n_r('CUsers/NOT_SUCCESSFULLY_CREATED')).'.';
    }
  
  // creates users from existing userlist of GS installation and emails the user
  if(file_exists(GSUSERSPATH)) {
    foreach(glob(GSUSERSPATH.'*') as $key=>$user) {
      $details = xml2array(simplexml_load_file($user));
      $query = DM_query("SELECT * FROM CU_users WHERE user_name = '".trim($details['USR'])."'", "DM_SINGLE");
      if(empty($query)){
        $user_pass = CUTable::randomKey(8);
        createRecord('CU_users', array(
                'user_name'=>$details['USR'],
                'user_pass'=>sha1($user_pass),
                'user_email'=>$details['EMAIL'],
                'user_date'=>time(),
                'user_level'=>0,
                'user_avatar'=>'',
                'user_display'=>$details['USR'],
                'user_signature'=>'',
                'user_ip'=>'',
                ));
        $setupMsgs['success'][] = '<strong>'.$details['USR'].'</strong> '.strtolower(i18n_r('CUsers/USER').' '.i18n_r('CUsers/SUCCESSFULLY_CREATED'));
        mail($details['EMAIL'],'Centralised User account activated','user: '.$details['USR'].' | pass: '.$user_pass, $details['EMAIL']);
      }
    }
  }
  
  // display results of setup
  echo '<ul>';
  foreach ($setupMsgs as $set=>$msgs) {
    if(!empty($set)) { 
      echo '<li>'.i18n_r('CUsers/'.strtoupper($set)).':<ul>';
        foreach ($msgs as $msg) echo '<li>'.$msg.'</li>';
      echo '</ul></li>';
    }
  }
  echo '</ul>';
  getCUError(i18n_r('CUsers/SETUP_SUCCESS'), 'updated', false);
}

// edit users
if(isset($_GET['users']) && !is_numeric($_GET['users'])) {
  $users = DM_query("SELECT * FROM CU_users ORDER BY user_name ASC");
  $usersDropdown = '<form method="post" action=""><select class="text" style="width:250px;" name="edit"><p>';
  
  foreach ($users as $user) {
    $usersDropdown .= '<option '.(isset($_POST['edit']) && $_POST['edit']==$user['id'] ? 'selected="selected"' : '').' value="'.$user['id'].'">'.$user['user_name'].'</option>';
  }
  $usersDropdown .= '</select>&nbsp;&nbsp;&nbsp;<input type="submit" class="submit" name="get_user" value="'.i18n_r('CUsers/EDIT_USER').'"></p></form>';
  
  if(!isset($_POST['edit'])) echo $usersDropdown;
  
  if(isset($_POST['edit']) && is_numeric($_POST['edit'])) {
    $user = DM_query("SELECT * FROM CU_users WHERE id = ".$_POST['edit'], "DM_SINGLE");
    echo '<form method="post">
            <p id="edit_window">
              <input type="text" class="text title" name="user_display" value="'.$user['user_display'].'">
            </p>
              <input type="hidden" name="id" value="'.$user['id'].'">
              <div id="metadata_window">
                <div class="leftopt">
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_LEVEL').': &nbsp; </label>';
                    echo '<select name="user_level" class="text autowidth">';
                    foreach ($CUserLevels as $key=>$level) echo '<option '.($key==$value? 'selected="selected"': '').' value="'.$key.'">'.$level['title'].'</option>';
                    echo '</select>';
    echo '        </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_DATE').': &nbsp; </label>
                      <input type="datetime-local" name="user_date" value="'.date('Y-m-d\TH:i', $user['user_date']).'"/>
                  </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_IP').': &nbsp; </label>
                      <input type="text" disabled="disabled" name="user_ip" value="'.$user['user_ip'].'"/>
                  </p>';
    echo '      </div>';
      
      
    echo '      <div class="rightopt">
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_NAME').': &nbsp; </label>
                      <input type="text" name="user_name" value="'.$user['user_name'].'"/>
                  </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_EMAIL').': &nbsp; </label>
                      <input type="text" name="user_email" value="'.$user['user_email'].'"/>
                  </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_AVATAR').': &nbsp; </label>
                      <input type="text" name="user_avatar" value="'.$user['user_avatar'].'"/>
                  </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/USER_SIGNATURE').': &nbsp; </label>
                      <textarea name="user_signature">'.$user['user_signature'].'</textarea>
                  </p>
                  
                </div>
                <div class="clear"></div>
                
              </div>
              <input type="submit" class="submit" name="save_profile_changes" value="'.i18n_r('CUsers/SAVE').'"/>
          </form>';
  }
  if(isset($_POST['save_profile_changes'])) {
    unset($_POST['save_profile_changes']);
    if(empty($_POST['user_pass'])) unset($_POST['user_pass']);
    else $_POST['user_pass'] = sha1($_POST['user_pass']);
    $_POST['user_date'] = strtotime($_POST['user_date']); // fixes the date
    CUTable::updateRecord('CU_users', $_POST['id'], $_POST);
    getCUError(i18n_r('CUsers/UPDATE_SUCCESS'), 'updated', false);
  }
}
// settings
if(isset($_GET['settings'])) {
  $CU_settings = DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
  if(!empty($CU_settings)) {
    // updates form 
    if(isset($_POST['save_settings'])) {
      unset($_POST['save_settings']);
      CUTable::updateRecord('CU_settings', $_POST['id'], $_POST);
      $CU_settings = DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
      echo 'Changes saved'; // need to fix
    }
  
    // form
    echo '<form method="post">
            <div id="metadata_window">
                <div class="leftopt">
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/BAN_LIST').': &nbsp; </label>
                      <textarea name="ban_list">'.$CU_settings['ban_list'].'</textarea>
                  </p>
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/CENSOR_LIST').': &nbsp; </label>
                      <textarea name="censor_list">'.$CU_settings['censor_list'].'</textarea>
                  </p>
                </div>
                <div class="rightopt">
                  <p class="inline clearfix">
                    <label>'.i18n_r('CUsers/ADMIN_EMAIL').': &nbsp; </label>
                      <input type="text" name="admin_email" value="'.$CU_settings['admin_email'].'" />
                  </p>
                </div>
                <div class="clear"></div>
            </div>
            <input type="submit" class="submit" name="save_settings" value="'.i18n_r('CUsers/SAVE').'">
          </form>';
  }
  else {
    echo i18n_r('CUsers/GOTO_SETUP');
  }
}
 
?>