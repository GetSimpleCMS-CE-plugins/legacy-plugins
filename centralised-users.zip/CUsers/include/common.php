<?php
// page redirection
function CU_redirect($url, $time) {
  echo '	<script type="text/javascript">
        function myRedirect() {
          setTimeout(function(){window.location = "'.$url.'"},'.$time.');
        }
        myRedirect();
      </script>';
}

// return version of the previous function
function return_CU_redirect($url, $time) {
  return '	<script type="text/javascript">
        function myRedirect() {
          setTimeout(function(){window.location = "'.$url.'"},'.$time.');
        }
        myRedirect();
      </script>';
}

// IP ban detection
function CU_IPBan($address, $denyIP=array()) {
  $denyIP = array_map('trim', $denyIP);
  if (in_array($address, $denyIP)) {
    return true;
  }
  else return false;
}
	
// show update message
function CU_show_update($msg, $success=true) {
  $show = ($success==true ? 'success' : 'error');
  echo '<script type="text/javascript">
          $(function() {
            $("body").before("<div class=\"'.$show.'\">"+'.json_encode($msg).'+"</div>");
            $(".updated, .error").fadeOut(500).fadeIn(500);
          });
        </script>
        <div class="'.$show.'">'.$msg.'</div>';
}

// random key generator (used for password reset)
function random_key($length) {
  // massive to bob for his beautifully succinct code at http://www.lateralcode.com/creating-a-random-string-with-php/
  $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  return substr(str_shuffle($chars),0,$length);
}

// find values in multidimensional array (http://www.namepros.com/code/711084-php-in_array-for-multidimensional-arrays.html)
function multi_in_array($value, $array) {
	foreach ($array as $item)  { 
		if (!is_array($item)) { 
			if ($item == $value) { 
				return true; 
			} 
			continue; 
		} 
		if (in_array($value, $item)) { 
			return true; 
		} 
		elseif (multi_in_array($value, $item)) { 
			return true; 
		} 
	} 
	return false; 
}

// returns array key on a multidimensional array
function multi_array_search($needle, $array) {
	$new_array = array();
	
	if(is_array($array)) {
		foreach ($array as $key=>$item) {
			if(is_array($item)) {
				multi_array_search($needle, $item);
			}
			else {
				if($needle==$item) {
					return $key;
				}
			}
		}
	}
	else {
		return false;
	}
}

// use array_map on a multidimensional array
function multi_array_map($function, $array) {
	$new_array = array();
	if (function_exists($function) && is_array($array)) {
		foreach ($array as $key=>$item) {
			if(is_array($item)) {
				$new_array[strtolower($key)] = multi_array_map($function, $item);
			}
			else {
				$new_array[strtolower($key)] = call_user_func($function, $item);
			}
		}
		return $new_array;
	}
	else {
		return false;
	}
}

// check signed in status
function CU_signin() { return CUSession::status(); }

// get forms
function get_CU_form($form, $captcha=false) {
  echo '<form method="post">';
  switch($form) {
    case 'signup':        echo CUForms::signUp($captcha); break;
    case 'signin':        echo CUForms::signIn($captcha); break;
    case 'editdetails':   if(CUSession::status()) echo CUForms::editUserDetails($_SESSION['CUser']['user_id']); break;
    case 'forgotpass':    echo CUForms::forgotPass($captcha); break;
  }
  echo '</form>';
}

// show back-end error (used from the GetSimple wiki)
function getCUError($msg, $isSuccess, $canUndo) {
 
  if (isset($msg)) {
    if ($canUndo) $msg .= ' <a href="load.php?id=myplugin&undo">' . i18n_r('UNDO') . '</a>' 
?>
<script type="text/javascript">
  $(function() {
    $('div.bodycontent').before('<div class="<?php echo $isSuccess ? 'updated' : 'error'; ?>" style="display:block;">'+
            <?php echo json_encode($msg); ?>+'</div>');
    $(".updated, .error").fadeOut(500).fadeIn(500);
  });
</script>
<?php 
  } 
}

?>