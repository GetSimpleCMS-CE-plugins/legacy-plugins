<?php
// constants
define('MEMBER', i18n_r('CUsers/MEMBER'));
define('MODERATOR', i18n_r('CUsers/MODERATOR'));
define('ADMINISTRATOR', i18n_r('CUsers/ADMINISTRATOR'));
define('BANNED', i18n_r('CUsers/BANNED'));
define('INACTIVE', i18n_r('CUsers/INACTIVE'));
 
$CUserLevels = array(
                      array('title'=>MEMBER, 'class'=>'user'), 
                      array('title'=>MODERATOR, 'class'=>'mod'), 
                      array('title'=>ADMINISTRATOR, 'class'=>'admin'), 
                      array('title'=>BANNED, 'class'=>'banned'), 
                      array('title'=>INACTIVE, 'class'=>'inactive')
                    );
 
class CUser {
  public static $levels;
  
  public function __construct($id) {
    $this->u = DM_query("SELECT * FROM CU_users WHERE id = $id", "DM_SINGLE");
    $this->levels = array(
                      array('title'=>MEMBER, 'class'=>'user'), 
                      array('title'=>MODERATOR, 'class'=>'mod'), 
                      array('title'=>ADMINISTRATOR, 'class'=>'admin'), 
                      array('title'=>BANNED, 'class'=>'banned'), 
                      array('title'=>INACTIVE, 'class'=>'inactive')
                    );
  }
  public function getName() {
    if(!empty($this->u['user_display'])) return $this->u['user_display'];
    else return $this->u['user_name'];
  }
  public function getUserName() {
    return $this->u['user_name'];
  }
  public function getUserDisplay() {
    return $this->u['user_display'];
  }
  public function getEmail($link=false) {
    switch($link) {
      case true:
        return '<a href="mailto:'.$this->u['user_email'].'">'.$this->u['user_email'].'</a>';
        break;
      default:
        return $this->u['user_email'];
        break;
    }
  }
  public function getLevel($key=true) {
    switch($key) {
      case true:
        return $this->levels[$this->u['user_level']]['title'];
        break;
      default:
        return $this->u['user_level'];
        break;
    }
  }
  public function getAvatar($format=false) {
    switch($format) {
      case true:
        return '<img class="avatar" src="'.$this->u['user_avatar'].'"/>';
        break;
      default:
        return $this->u['user_avatar'];
        break;
    }
  }
  public function getSignature($format=false) {
    switch($format) {
      case true:
        return $this->u['user_signature'];
        break;
      default:
        return $this->u['user_signature'];
        break;
    }
  }
  public function getDate() {
    return $this->u['user_date'];
  }
  public function getIP() {
    return $this->u['user_ip'];
  }
}

class CUSession {
  // gets IP address of the current computer
  function findIP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']))   $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    elseif(isset($_SERVER['HTTP_X_FORWARDED']))       $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    elseif(isset($_SERVER['HTTP_FORWARDED_FOR']))     $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    elseif(isset($_SERVER['HTTP_FORWARDED']))         $ipaddress = $_SERVER['HTTP_FORWARDED'];
    elseif(isset($_SERVER['REMOTE_ADDR']))            $ipaddress = $_SERVER['REMOTE_ADDR'];
    else                                              $ipaddress = 'UNKNOWN';
    return $ipaddress;
  }
  // signs the user in
  public function signIn() {
    $user = DM_query("SELECT * FROM CU_users WHERE user_name = '".$_POST['user_name']."'", "DM_SINGLE");
    // checks to see if the account is banned
    $CU_settings = DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
    $denyIP = array_map('trim', explode("\n", $CU_settings['ban_list']));
    
    if($user['user_level']==3 || $user['user_level']==4) return $user['user_level'];
    elseif (in_array(trim(self::findIP()), $denyIP)) return 3;
    else {
      $_SESSION['CUser']['signed_in']  = true;   
      $_SESSION['CUser']['user_id']    = $user['id'];
      $_SESSION['CUser']['user_name']  = $user['user_name'];
      $_SESSION['CUser']['user_level'] = $user['user_level'];
      CUTable::updateRecord('CU_users', $user['id'], array('user_ip'=>self::findIP()));
      return true;
    }
  }
  // signs the user out
  public function signOut() {
    $_SESSION['CUser'] = null;
  }
  // returns the signed in status of the user
  public function status() {
    if(isset($_SESSION['CUser']['signed_in']) && $_SESSION['CUser']['signed_in']==true) return true; else return false;  
  }
  // returns whether the user is permitted to perform a certain action
  public function getPerm($types=array(0)) {
    if(self::status()) {
      if(in_array($_SESSION['CUser']['user_level'], $types)) return true; else return false;
    }
    else return false;
  }
}
?>