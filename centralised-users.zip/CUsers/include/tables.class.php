<?php
class CUTable {
  public function createTable($tables, $data) { // tables is an array that contains the table name and field details
    if(is_array($tables) && is_array($data)) {
      
      // create the tables
      foreach ($tables as $table=>$fields) {
        if(!tableExists($table)) {
          createSchemaTable($table, $maxrecords=0, array()); // creates empty table with the table name
        }
        
        // create the fields
        foreach ($fields as $field=>$details) {
          // ensures label and description fields are filled
          $details['label'] = $details['desc'] = $details['name'];
          
          // automates last few array details for fields
          $last_field_details = array(
            'cacheindex' => '1', 
            'tableview' => '1', 
            'table' => '100', 
            'row' => 'row', 
            'fieldsize' => '100', 
            'fieldvisibility' => '1'
          );
          $full_field_details = array_merge($details, $last_field_details);
          addSchemaField($table, $full_field_details, $save=true);
        }
      }
      
      // populate the tables
      if(!empty($data)) {
        foreach ($data as $table=>$record) {
          $check_record = DM_query("SELECT * from $table");
          if (empty($check_record)) { // if there is no first record, create one
            createRecord($table, $record);
          }
        }
      }
    }
    else {
      // returns false if either $tables or $data isn't an array
      return false;
    }
  }
  
  // delete tables
  public function deleteTable($tables) {
    if(is_array($tables) && !empty($tables)) {
      foreach ($tables as $table) {
        // first deletes all of the records in the table
        $records = DM_query("SELECT * FROM $table");
        if(!empty($records)) {
          foreach ($records as $record) {
            DM_deleteRecord($table, $record['id']);
          }
        }
        // deletes the table
        DM_deleteTable($table);
      }
    }
    else {
      // returns false if tables isn't an array or empty
      return false;
    }
  }
  
  // updates the record
  public function updateRecord($table, $id, $query) {
    $record = DM_query("SELECT * FROM $table WHERE id = $id", "DM_SINGLE");
    foreach ($record as $field=>$value) {
      if($value===null) {
        $record[$field] = '';
      }
    }
    if(!empty($record)) {
      updateRecord($table, $id, array_merge($record, $query));
    }
    else {
      return false;
    }
  }
  
  // creates random key (useful for passwords)
  public function randomKey($length) {
    // massive to bob for his beautifully succinct code at http://www.lateralcode.com/creating-a-random-string-with-php/
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return substr(str_shuffle($chars),0,$length);
  }
  
  // refreshes the search index
  public function refreshIndex() {
    if(function_exists('delete_i18n_search_index')){
      delete_i18n_search_index();
    }
  }
}
?>