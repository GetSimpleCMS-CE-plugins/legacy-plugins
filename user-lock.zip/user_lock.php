<?php
/*
Name: User Lock
Description: Locks pages being edited, so any used is denied to edit a page while other user is editing.
	     Lock will be controlled by a simple lock file indicating a user is already editing
Version: 1.0
Author: Victor Martin vicmarher@hotmail.com
Author URI: 
*/

# Configuration

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");


# Useful environment values
$ulock_files_folder=('ulock_files');

# register plugin
register_plugin(
        $thisfile,
        'User Lock',
        '1.0',
        'Victor Martin',
        '',
        'Locks pages being edited, so another used is denied to edit a page while other user is editing.',
        '',
        '');

# includes
require_once('user_lock/functions.php');

# language
i18n_merge('user_lock') || i18n_merge('user_lock', 'en_US');
# hooks

#when edit.php is loaded, we must check for the lock, and create it if doesn't exist
add_action('load-edit-page','ulock_check_lock');

#when edit.php page is unload, we must get sure that the lock file has been released.
#so in the onbeforeunload event of edit.php page, we make it to execute the action 'edit-finished'
add_action('unload-edit-page','ulock_delete_lock');



#when user logs out while editing a page, all the possible locks of the user must be removed
add_action('logout','ulock_on_logout');

#in pages.php, in the main menu, add an additional icon if the page is currently locked
#some global variables are needed in order to know current page being treated, and new item to add if needed
$gs_current_menu_id=null;
$gs_extra_menu_status=null;
add_action('menupage_extra_status','ulock_add_lock_status');


#when login, we check if there were other lock files from a previous session, undeleted for example
#due to closing the browser
add_action('successful-login-end','ulock_login');

#the js events for load/unload are added to the edit.php at header scope
add_action('header','ulock_inject_js_edit');


