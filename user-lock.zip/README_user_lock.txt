USER_LOCK PLUGIN FOR GetSimple
==============================

Description: USER_LOCK plugin Locks pages being edited, so any user is denied to edit a page while other user is editing.
	     Lock will be controlled by a simple lock file indicating a user is already editing page.
             The control will be made in  load and unload events of the edit.php GetSimple page.
	     This events will be injected in edit.php by the plugin, and will use ajax to call the lock functions in 
             user_lock.php plugin page.

Current Version 1.0
Author. Víctor Martín Hernández , vicmarher@hotmail.com

* Install
==========


Unzip and copy user_lock.php file and user_lock folder inside plugins folder of your GetSimple structure.


-> IMPORTANT!! : data/other/ulock_files folder is tried to be created by the plugin. Depending of your permissions it won't be possible, and you'll have to do it manually.
   ===========


-> The status of the page can be shown as '[locked]' when 'toggle_status' button in pages.php is clicked. 
   If you want this additional feature to work, you'll need to modify the function 'get_pages_menu' of 'inc/template_functions.php'. 
   In the loop, for each page, it is checked if the page is locked, executing a new action, that stores in a global variable the extra information to add to the <TD> of the page.
   Here are the modified lines you would need to add for it to work:

		if ($page['url'] == 'index' ) { $homepage = ' <sup>['.i18n_r('HOMEPAGE_SUBTITLE').']</sup>'; } else { $homepage = ''; }

  -->new code   //VMH BEGIN :If we want an extra menu flag, not to be treated as status and always visible, this exec_action will allow a plugin to generate it
		//the plugin function must fill the global variable $gs_extra_menu_status (defined for this version in user_lock.php plugin
		$gs_current_menu_id=$page['url'];
                $gs_extra_menu_status=null; //clean it before all plugins update it
                exec_action('menupage_extra_status');
                //now we know that $gs_extra_menu_status is filled with the extra flag the plugin wants to add
                //inside the td, we add the new extra status    
		$menu .= '<td class="pagetitle">'. $dash .'<a title="'.i18n_r('EDITPAGE_TITLE').': '. cl($page['title']) .'" href="edit.php?id='. $page['url'] .'" >'. cl($page['title']) .'</a><span class="showstatus toggle" >'. $homepage . $page['menuStatus'] . $page['private'] . $gs_extra_menu_status  . '</span></td>';
		//VMH REMOvE THIS LINE $menu .= '<td class="pagetitle">'. $dash .'<a title="'.i18n_r('EDITPAGE_TITLE').': '. cl($page['title']) .'" href="edit.php?id='. $page['url'] .'" >'. cl($page['title']) .'</a><span class="showstatus toggle" >'. $homepage . $page['menuStatus'] . $page['private'] .'</span></td>';			
  -->end new code//VMH END

  NOTE!!! that the last line starting $menu .= must be removed and substed by the new one provided.
  My modified function is included in the zip file for you to check it, in the _extra_ folder, with name 'ulock_template_functions.php_modified'.
  

* How it works
==============

  The plugin only needs to know if someone is editing the page when tries to start editing.
  So in the load event of edit.php page, we check if there's a lock file for the page from another user. If not, editing is allowed,
  and the file for this page and this user is created.
  
  The lock files are stored in data/other/ulock_files folder. The folder is created by the plugin if possible. If not, do it yourself! 

  In the unload event, when we leave the page, deletes the lockfile.
  When editing is not allowed, we are redirected to pages.php, showing an error in the header.

  Renaming the url, saving, cloning, deleting, canceling, going to another url.... all this actions fit this behaviour.

  When user logs out, all the locks of the user are released too. Imagine you open several tabs with different pages to edit, and logout. All locks are released,
  and the open tabs, when they try to save/whatever, will be redirected to the login page, so no possible update without lock seems that can happen.

  Just to avoid the case of a crash of the browser or something similar, when the user logs in, all the previous locks of this user are released too.
  
  In case of login expired time, no exec_action has been added. The pages will be locked till next login. It could be easy to add a new action and to the same as
  when we logout.

  

  When this plugin is enabled, 2 new exec_action's are executed:
  -> exec_action('load-edit-page') : when edit.php is loaded
  -> exec_action('unload-edit-page') : when edit.php is unloaded

  This actions are executed via ajax, so no redirect functions can be used. If you want to redirect depending on the result, your client-side js calling ajax must
  treat the response from the ajax call. In this plugin, we do it in the onload and the onunload js events that we inject in the header, using the exec_action('header').

  So:
  ->exec_action('header') is called. We inject js events for load and unload of edit.php
  ->onload -> with ajax we call the plugin user_lock.php page. If page is locked, ajax is returned with the lock information, and the js redirects it to pages.php
  ->onunload -> with ajax we call the plugin user_lock.php to unlock page. 
                If page was locked for another user, it means that we are there but after lock check made in ¡onload', so we must leave, and don't release the lock.
                If page was locked for the same user, means edit has finished, and unlock the page.


  Another functionallity added is notifying in the status of the page that is locked. It only shows when a page is locked by another user.
  As the other status, it's only shown when toggle status button is clicked.
  Update your 'inc/template_functions.php' file as explained in the Install instructions, and enjoy it ;)

  Off course oll the possible situations of lock are not fully controlled by this plugin. For example, if we open several tabs in the browser, logout from one of them,
  and then login, the others tabs will be able to edit without havint a lock-file. Some more complicated behaviour should be implemented, but the purpose of this plugin
  is just to implement a simple user exclusion method, enough for our purposes.

  Any comments will be wellcome!


  


