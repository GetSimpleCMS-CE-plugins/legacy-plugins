<?php
/*
Description: user_lock page to handle load and unload of the edit.php getsimple page
	     This page is accessed via Ajax from the javascript injected by user_lock plugin in the 
	     load and beforeunload events of edit.php

Author: Victor Martin
*/

#require_once('functions.php');



// Setup inclusions
$load['plugin'] = true;

// Include common.php
include('../../admin/inc/common.php');

// Variable settings
login_cookie_check();



if (!isset($_GET['id'])) 
{
  echo "@LOCK_ERROR@". i18n_r('user_lock/MUTEX_GNRL_ERROR'); 
  return;
}

if (!isset($_GET['action'])) 
{
  echo "@LOCK_ERROR@". i18n_r('user_lock/MUTEX_GNRL_ERROR'); 
  return;
}

$idpage =  $_GET['id'];
$action =  $_GET['action'];


echo "El ID vale ". $idpage . " y la accion vale " . $action;

if ($action == 'load')
{
    
    exec_action('load-edit-page');
}

else

if ($action == 'unload')
{
    exec_action('unload-edit-page');
}

?>
