<script type="text/javascript">


/*LOAD EVENT*/
			function doLoad() 
			{
  			  var i=0;
			  var id=null;
                          
                          var tmp=$(location).attr('href');
                          //alert( document.URL );

                          i=tmp.lastIndexOf("id=");
			  
			  
                          
                          if (i!=-1) //If we are creating a new one, no lock action is needed
			  {

  	
				id=tmp.substring(i+3); //the 3 characters of 'id='
		                i=id.indexOf("&"); //search if there are other parameters after id
                                if (i!=-1)				
				   id=id.substring(0,i);

				$.ajax(
		                {
					type: "GET",
					async: false,
					url: "../plugins/user_lock/user_lock.php",
					data: "action=load&id=" + id,
					complete : function(data)
						   {
		                                      //alert("COMPLETE");
		                                   },
					error : function(XMLHttpRequest, textStatus, errorThrown)
		                                {
						   //alert("ERRORRRRRR!!"+textStatus+errorThrown);
						   window.location="pages.php?error="+textStatus;
		                                },
					success : function (data)
						  {
						   //alert("LOAD OK !! " + id+ "<->" + data);
	                                           i=data.indexOf("@LOCK_ERROR@");
						   if (i!=-1)
						   {
							//error found. We get the error string, and redirect it to pages.php
							i=i+"@LOCK_ERROR@".length;
                                                        i2=data.indexOf("@",i); //the next '@'
                                                        errtxt=data.substring(i,i2);
                                                        window.location="pages.php?error="+errtxt;

						   }
						  }//success function
		                        
				});
                          } //if (i!=-1)
			} //function doLoad
			
			if ( window.addEventListener ) 
			{ 
			   window.addEventListener( "load", doLoad, false );
			}
			else 
			if ( window.attachEvent ) 
			{ 
			   window.attachEvent( "onload", doLoad );
			} else 
			if ( window.onLoad ) 
			{
			   window.onload = doLoad;
                        }

                       

			$('#cancel-updates').hide();	

			window.onunload = function () 
                        {

			  var i=0;
			  var id=null;
                       
                          var tmp=$(location).attr('href');

			  
			  i=tmp.indexOf("id=");
			  id=tmp.substring(i+3); //the 3 characters of 'id='
	                
                          i=id.indexOf("&"); //search if there are other parameters after id
                          if (i!=-1)				
			   id=id.substring(0,i);
			  
                          $.ajax(
                          {
				type: "GET",
				async: false,
				url: "../plugins/user_lock/user_lock.php",
				data: "action=unload&id=" + id,
				complete : function(data)
					   {
                                              //alert("UNLOAD COMPLETE");
                                           },
				error : function(XMLHttpRequest, textStatus, errorThrown)
                                        {
					   //alert("UNLOAD ERRORRRRRR!!"+textStatus+errorThrown);
					   window.location="pages.php?error="+textStatus;
                                        },
				success : function (data)
					  {
					   //alert("UNLOAD DONE!!"+data);
					  }
                                
			  });
			} /*END onunload*/
			
</script>

