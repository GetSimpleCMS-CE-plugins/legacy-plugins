<?php
/**
 * English Language File
 * GetSimple plugin user_lock 
 *
 */


$i18n = array(

/*
 * Additions for user_lock plugin
 */

"MUTEX_USER_ERROR" => 'User \'%s\' is editing this page since %s',
"MUTEX_GNRL_ERROR" => 'Error trying to lock page'
);

?>
