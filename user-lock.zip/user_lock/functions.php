<?php
/*
Description: Management Functions for User Lock GetSimple plugin
Author: Victor Martin
*/



/*Gets the full path name of the lock file*/
function getFullPathLockFile($filename)
{
  global $ulock_files_folder;
  return GSDATAOTHERPATH .$ulock_files_folder .'/' .$filename .'-ulock';
}

/*Checks if folder for the lock files exists, and create it if not*/
function check_create_lock_folder($folder)
{
	
  if (file_exists(GSDATAOTHERPATH.$folder)) 
  {
    return ;

  }
  else 
  {
    if (defined('GSCHMOD')) 
    {
      $chmod_value = GSCHMOD;
    } 
    else 
    {
      $chmod_value = 0755;
    }
    mkdir(GSDATAOTHERPATH . $folder, $chmod_value);
  }

}


/*
 Returns if a functions is locked, and if it's the case, information about
 the user that locks and since when the page is locked.
 If the page is locked by the user asking for the lock, page is considered 
 NOT being locked
*/
function _ulock_is_page_locked($idpage,&$usrlock,&$datelock)
{
  global $USR;

  $lockfile=getFullPathLockFile($idpage);

  if (file_exists($lockfile))
  {
     $xml = @file_get_contents($lockfile);
     $v = simplexml_load_string($xml, NULL, LIBXML_NOCDATA);
     $usrlock = $v->username;
     $datelock= $v->date_lock;
     //I cannot lock to myself...
     return $usrlock!=$USR;
  }
  return false;
}

/*
  ulock_load_edit executes just when edit.php is loaded in the browser, 
  in response to the NEW exec_action('load-edit-page'), executed in plugin file user_lock.php,
  after an ajax request from the onload window event in edit.php ... ;)

  IMPORTANT:
  Being executed in ajax request content, no 'redirect' function can be executed.
  This kind of treatment must be done in client-side, evaluating the ajax response.
  That's why this function does 'echo', in order to ajax to know the result.

  Checks if a lock file for this page exists, with another user editing.
  In this case, redirects the page with an error indicating exclusive access issue.
  If not exists, creates the lock with the current user information, avoiding other users to edit it.
  
*/

function ulock_check_lock()
{
  
  global $USR;
  global $ulock_files_folder;
  
  
  if (!isset($_GET['id'])) 
  {
   echo "@LOCK_ERROR@". i18n_r('user_lock/MUTEX_GNRL_ERROR'); 
   return;
  }

  
  $id =  $_GET['id'];

  
  if ($id)
  {
        //user locking acces file
	//check if directory exists. Create it if not
	check_create_lock_folder($ulock_files_folder);

        if (_ulock_is_page_locked($id,$usrlock,$datelock))	
        {
   	   $error=sprintf(i18n_r('user_lock/MUTEX_USER_ERROR'),$usrlock,$datelock);	
           //We cannot redirect here. This function is executed by the trigger inside an ajax request.
           //so we return data to the ajax request, and on client side we'll made the redirect
	   echo "@LOCK_ERROR@" . $error . "@"; //we use '@' to separate, just in case the browser adds some kind of info	   
	   //redirect('pages.php?error='.urlencode($error));
        }
 
	else
        {
		//if it does not exist, we create it. 
		$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
	    	$note = $xml->addChild('username');
		$note->addCData(@$USR);
		
	    	$note = $xml->addChild('date_lock');
		$note->addCData(lngDate(null));
		//Save it
           	$lockfile=getFullPathLockFile($id);
		$xml->asXML($lockfile);
                //We tell the ajax request that everything was ok
		echo "@LOCK_OK@";
	
	}	
  }
//Now we know that file exists and it's an error, or file does not exist and we can continue editing
}//ulock_check_log



/*
 Private Function to delete the given lock file
*/
function _ulock_delete_lockfile($filename)
{
  
  $lockfile=getFullPathLockFile($filename);
  if (file_exists($lockfile))
  {
    unlink($lockfile);
  }
} //_ulock_delete_lockfilr


/*
  ulock_delete_lock is the Plugin function called once a editing page has been unloaded from the browser,
  in response to the exec_action('unload-edit-page'), executed in user_lock.php,
  after an ajax request from the onunload window event inside edit.php ... ;)
  
  IMPORTANT:
  Being executed in ajax request content, no 'redirect' function can be executed.
  This kind of treatment must be done in client-side, evaluating the ajax response.
  That's why this function does 'echo', in order to ajax to know the result.
 
  If we leave the page because we where the lockers, we delete the file
  If we leave the page because this page is locked by another user, we DON'T delete it
*/
function ulock_delete_lock()
{
  global $USR;

  if (!isset($_GET['id'])) 
  {
   echo "@LOCK_ERROR@". i18n_r('user_lock/MUTEX_GNRL_ERROR'); 
   return;
  }

  $idpage =  $_GET['id'];

  if (!_ulock_is_page_locked($idpage,$usrlock,$datelock))  
  {	
	_ulock_delete_lockfile($idpage);

  }
} //ulock_delete_lock







/*
 *If the user logs out while in edit page, this lock must be removed.
 *In order to assure no locks have been left, all the locks with this username are removed
*/

function ulock_on_logout()
{
 
  global $USR; //If the user only logs in, this variable is NULL. It's filled once a page is edited
  global $ulock_files_folder;
  $path = GSDATAOTHERPATH .$ulock_files_folder .'/';
 
  $dir_handle = @opendir($path) or die("Unable to open $path");
  $filenames = array();
  while ($filename = readdir($dir_handle)) {
    $filenames[] = $filename;
  }
  closedir($dir_handle);

  $count = 0;
  if (count($filenames) != 0) 
  {
    foreach ($filenames as $file) 
    {
        if (substr($file, -6) == "-ulock") 
        {
          $data = getXML($path . $file);
          $user = @$data->username;
          if ((string)$user == $USR)
          {
            $idfile=substr($file,0,strlen($file)-6); //the short name of the page 
            _ulock_delete_lockfile($idfile);
          }
        } 
    }
  }
}//ulock_on_logout

/* 
 * this function is plugin functor for exec_action('menupage_extra_status'), added in template_functions.php
 * In ulock_plugin case, if the page is locked, we add '[locked]' to the status
 */

function ulock_add_lock_status()
{
  global $gs_current_menu_id;
  global $gs_extra_menu_status;
  
  if (_ulock_is_page_locked($gs_current_menu_id,$usrlock,$datelock))
  {
  
   //add it, not assign it, not to overwrite status in case other plugin is adding another one
   $gs_extra_menu_status.='[locked]';
  } 
			

}

/*
 *In case login expires, we do the same when in logout
 */
function ulock_login_expired()
{
  ulock_on_logout();
}

/*
 *When we log in, do the same we do in logout, in case a previous session left some lock files for example by closing the browser while editing
*/
function ulock_login()
{
  ulock_on_logout();
}


/*The js code for load and unload events is injected here.
  We use the 'header' exec_action to add it, but we only have to do it in edit.php page
*/

function ulock_inject_js_edit()
{

  if (strpos($_SERVER['PHP_SELF'],"edit.php")!=false)
  {
    //we are in edit page.
    //open the file with the js to inject, and inject it
    readfile('../plugins/user_lock/load_unload_js.js');
  }


}





