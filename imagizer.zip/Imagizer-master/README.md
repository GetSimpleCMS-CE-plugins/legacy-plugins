Imagizer
========

Imagizer plugin for Get-Simple CMS.

After I've installed a few copies of GS to my clients, I've noticed that they upload 3MB photos with resolution about 4000x4000 and place 20 photos on 1 page. So I developed plugin, that would handle each uploaded photo by resizing, cropping or compressing it automatically.

