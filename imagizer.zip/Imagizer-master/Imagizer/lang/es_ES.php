<?php

$i18n = array (
	
    'CONVERT'=>'Convertir imágenes a formato JPEG',
    'WATERMARK'=>'Colocar marca de agua en imágenes (archivo "watermark.png" en carpeta plugins/Imagizer)',
    'COMPRESS'=>'Establecer nivel de compresión de imágenes (0-100; por defecto 80)',
    'EXACT_SIZE'=>'Tamaño exacto',
    'MIN'=>'Mínimo',
    'MAX'=>'Máximo',
    'MIN_SIZE'=>'Tamaño mínimo',
    'MAX_SIZE'=>'Tamaño máximo',
    'WIDTH'=>'Ancho ',
    'HEIGHT'=>'Alto',
    'PRIORITY'=>'Prioridad',
    'ADVANCED'=>'Avanzado',
    'SAVED'=>'Se ha guardado la configuración.',
    'SIZE'=>'Tamaño',
    'EXCLUDE'=>'Excluir carpeta',
    'EXCLUDE_HELP'=>'Deshabilita Imagizer para esta carpeta y sus subcarpetas.',
    'SAVE_SETTINGS'=>'Guardar configuración',
    'VAR_SIZE'=>'Tamaño variable'
    
);

?>
