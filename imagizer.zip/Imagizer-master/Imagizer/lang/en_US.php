<?php

$i18n = array (
	
    'CONVERT'=>'Convert images to JPEG format',
    'WATERMARK'=>'Place watermark on images (file "watermark.png" in plugins/Imagizer folder)',
    'COMPRESS'=>'Compress images to this level 0-100 (default=80)',
    'EXACT_SIZE'=>'Exact size',
    'MIN'=>'Minimum',
    'MAX'=>'Maximum',
    'MIN_SIZE'=>'Minimum size',
    'MAX_SIZE'=>'Maximum size',
    'WIDTH'=>'Width ',
    'HEIGHT'=>'Height',
    'PRIORITY'=>'Priority',
    'ADVANCED'=>'Advanced',
    'SAVED'=>'Configuration saved.',
    'SIZE'=>'Size',
    'EXCLUDE'=>'Exclude folder',
    'EXCLUDE_HELP'=>'Disables Imagizer for this folder and its subfolders.',
    'SAVE_SETTINGS'=>'Save settings',
    'VAR_SIZE'=>'Variable size'
    
//	''=>'',

);



?>