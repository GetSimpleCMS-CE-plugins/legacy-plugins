<?php
/*
Plugin Name: TS Edit in same window
Description: Let you edit a page in the same window as viewing. Often more faster.
Version: 1.0
Author: Lars Flintzak
Author URI: http://www.flintzak.de/gsplugins
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, //Plugin id
	'TS Edit in same window', 	//Plugin name
	'1.0a', 		//Plugin version
	'Lars Flintzak',  //Plugin author
	'http://www.gowep.de/gsplugins', //author website
	'Let you edit a page in the same window as viewing. Often more faster.', //Plugin description
	'pages', //Page type
	''  //main function (administration) - there is no need for it, as there is no administration backend yet
);

//Change hook name to alter the position where the link is being displayed
add_action('footer','do_tss_clearblanks');

# functions

function do_tss_clearblanks()
{
	echo "<script>
	$('a[target=\"_blank\"]').removeAttr('target');
	</script>";
	echo "TS Edit in same window message: target='_blank' removed.";
}
?>