<?php
/*
    SIS-Handball XML Import

*/
function getFileContent($filename, $use_include_path = 0) {
  
  $ret = '';

  if (function_exists('curl_version')) {
    //echo "<br/>curl wird verwendet";
      $ch = curl_init();
      // set URL and other appropriate options
      curl_setopt($ch, CURLOPT_URL, $filename);
      curl_setopt($ch, CURLOPT_HEADER, FALSE);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
      
      // grab URL and 
      $ret = @curl_exec($ch);
      
      // close curl resource, and free up system resources
      curl_close($ch);
      
    //}
  //wenn URL dann pruefen ob allow_url_fopen, ansonsten ist es ein lokales file
  } elseif ((ini_get("allow_url_fopen") == 1) ) {
  //echo "<br/>file_get_contents wird verwendet";
    $ret = @file_get_contents($filename);
  } 
  return $ret;
}

function update_data($strArt="tabelle", $strLiga="unknown")
{

    // SIS - Benutzerdaten auslesen
    $sis_config = sishandball_get_config();
    $server = $sis_config['settings']['sis_server'];
    $login = $sis_config['settings']['sis_login'];
    $pass = $sis_config['settings']['sis_pass'];
    $strVerein = $sis_config['settings']['sis_verein'];
    // Specifies the interval, in minutes (!), that Leaguedata are cached.
    $cache_timeout = $sis_config['settings']['sis_cachetimeout']; 
    // Die SIS - Parameter zuordnen
    switch ($strArt)
    {
        case 'tabelle'                  : $art = 4; $auf = $strLiga; break;
        case 'mini_tabelle'             : $art = 4; $auf = $strLiga; break;
        case 'allespieleliga'           : $art = 1; $auf = $strLiga; break;
        case 'allespieleverein'         : $art = 1; $auf = $strVerein; break;
        case 'heimspieleverein'         : $art = 1; $auf = $strVerein; break;
        case 'spielemannschaft'         : $art = 1; $auf = $strLiga; break;
        case 'naechsten15spieleliga'    : $art = 3; $auf = $strLiga; break;
        case 'naechsten15spieleverein'  : $art = 3; $auf = $strVerein; break;
        case 'naechsten30spieleverein'  : $art= 11; $auf = $strVerein; break;
        case 'naechsten30spieleliga'    : $art= 11; $auf = $strLiga; break;
        case 'letzten15spieleliga'      : $art = 2; $auf = $strLiga; break;
        case 'letzten15spieleverein'    : $art = 2; $auf = $strVerein; break;
        case 'letzten30spieleliga'      : $art = 10; $auf = $strLiga; break;
        case 'letzten30spieleverein'    : $art = 10; $auf = $strVerein; break;
    }

    // Den Dateinamen bestimmen
    $datei = GSDATAOTHERPATH.'sishandball/sis_' . $art .'_' . $auf . '.xml';
    // Url generieren
    $sisUrl = "http://$server/xmlexport/xml_dyn.aspx?art=$art&auf=$auf&user=$login&pass=$pass";
    $filetimestamp = 0;
    //echo $sisUrl;
    if (file_exists($datei))
    {
        $filetimestamp = filemtime($datei);
        /* disable datasync from sis-handball if $cache_timeout <= 0 */
        if ( !($cache_timeout <= 0) && (time() - $filetimestamp) > ($cache_timeout*60))
        {
            // Laden
            $content = getFileContent($sisUrl);
            // Parsen mit Errorhandling
            $doc = new DOMDocument();
            libxml_use_internal_errors(true);
            $doc = simplexml_load_string($content);
            // Nur speichern,wenn xml Content vorhanden
            // Wir wollen ja keine Serverfehlermeldungen speichern ;-)
            // Workaround wenn root != html
            if ($content != '' && $doc->getName() != "html") $doc->saveXML($datei); 
            //else echo "using Cache, Server nicht erreichbar";
            libxml_clear_errors();
        } 
/*        
        else {
            echo " using Cache";
        }
*/       
    } else{
        $content = @file_get_contents($sisUrl);
        // Parsen
        $doc = simplexml_load_string($content);
        if ($content != '' && $doc->getName() != "html") {
            $doc->saveXML($datei);  
        }
    }
    return $datei;
}

function sishandball($view=null,$league_id=null) 
{
    $tpl = 'index';
    $sis_content=null;
    if (!is_null($view) && !is_null($league_id) ) {
        $xmlFile = update_data($view,$league_id);
        switch ($view)
        {
            case 'tabelle'                  : $tpl = 'sis_tabelle'; break;
            case 'mini_tabelle'             : $tpl = 'sis_mini_tabelle'; break;
            case 'allespieleliga'           : $tpl = 'sis_naechstenspiele'; break;
            case 'allespieleverein'         : $tpl = 'sis_naechstenspiele'; break;
            case 'heimspieleverein'         : $tpl = 'sis_heimspiele'; break;
            case 'spielemannschaft'         : $tpl = 'sis_spielemannschaft'; break;
            case 'naechsten15spieleliga'    : $tpl = 'sis_naechstenspiele'; break;
            case 'naechsten15spieleverein'  : $tpl = 'sis_naechstenspiele'; break;
            case 'naechsten30spieleverein'  : $tpl = 'sis_gesamtspielplan'; break;
            case 'naechsten30spieleliga'    : $tpl = 'sis_naechstenspiele'; break;
            case 'letzten15spieleliga'      : $tpl = 'sis_letztenspiele'; break;
            case 'letzten15spieleverein'    : $tpl = 'sis_letztenspiele'; break;
            case 'letzten30spieleliga'      : $tpl = 'sis_letztenspiele'; break;
            case 'letzten30spieleverein'    : $tpl = 'sis_letztenspiele'; break;
        }
        
        $sis_view_path = GSPLUGINPATH.'SISHandball/views/'.$tpl.'.php';
        // Load .xml File
        if (file_exists($xmlFile))
        {
            $xml = simplexml_load_file($xmlFile);
            ob_start();
            include($sis_view_path);
            $sis_content = ob_get_clean();       
        } 
        else $sis_content = "FEHLER: Der SISHANDBALL View <b>$view</b> ist nicht definiert! Bitte Aufruf �berpr�fen.";
    }
    else {
        $sis_content = "FEHLER: Der SISHANDBALL View und/oder LigaID sind nicht definiert! Bitte Aufruf �berpr�fen.";
    }
    return "<div class=\"sishandball\">".$sis_content."</div>";   
}

/**
 * Returns HTML image code for a small team icon
 *
 * @param        string     $team       Long name of the team
 * @param        string     $alternative_text      If image not found return this instead
 * @return       string     HTML image-Code for the small team icon
 */
function sishandball_getSmallImage($team,$alternative_text='',$htmlAttributes="border='0'") {
	$subFolder = "img/teams/small/";
	$imgHTML = sis_handball_findImage($team,$subFolder,".png",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage($team,$subFolder,".gif",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage($team,$subFolder,".jpg",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage("handball_noimg",$subFolder,".gif",$alternative_text,$htmlAttributes);
	
	return $imgHTML;
}

/**
 * Returns HTML image code for a big team icon
 *
 * @param        string     $team       Long name of the team
 * @param        string     $alternative_text      If image not found return this instead
 * @return       string     HTML image-Code for the big team icon
 */
function sishandball_getBigImage($team,$alternative_text='',$htmlAttributes="border='0'") {
	$subFolder = "img/teams/big/";
	$imgHTML = sis_handball_findImage($team,$subFolder,".png",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage($team,$subFolder,".gif",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage($team,$subFolder,".jpg",$alternative_text,$htmlAttributes);
	if ($imgHTML == $alternative_text)
		$imgHTML = sis_handball_findImage("handball_noimg",$subFolder,".gif",$alternative_text,$htmlAttributes);
	return $imgHTML;
}

/**
 * searched for a image in the upload folder and returns HTML <img> tag
 */

function sis_handball_findImage ($key,$path,$imgType = ".png",$alternative_text='',$htmlAttributes='') {
  if( is_dir ( GSDATAUPLOADPATH.$path ) ) {
    $siteUrl = get_site_url(false); // return as string, no echo
    $key=strtolower($key);
    $oKey = $key;
    $key = str_replace("/","",$key);
    if (!file_exists(GSDATAUPLOADPATH.$path.$key.$imgType)) {
    $key=preg_replace("/[^a-zA-Z0-9]/",'',$key);
    }
    else {
    $imgdata=getimagesize(GSDATAUPLOADPATH.$path.$key.$imgType);
    return ("<img src='".$siteUrl."data/uploads/".$path.rawurlencode($key)."$imgType' {$imgdata[3]} $htmlAttributes alt=''/>");
    }
    //  Mannschaftsnummern entfernen 
    if (!file_exists(GSDATAUPLOADPATH.$path.$key.$imgType)) {
    //    $key=preg_replace("/[0-9]+$/",'',$key);
    $key=preg_replace("/\s+([ivxm]+$|[0-9]$)/i",'',$oKey);
    $key=preg_replace("/[^a-zA-Z0-9]/",'',$key);
    }
    else {
    $imgdata=getimagesize(GSDATAUPLOADPATH.$path.$key.$imgType);
    return ("<img src='".$siteUrl."data/uploads/".$path.rawurlencode($key)."$imgType' {$imgdata[3]} $htmlAttributes alt=''/>");
    }

    if (!file_exists(GSDATAUPLOADPATH.$path.$key.$imgType)) {
    return $alternative_text;
    } 
    else {
    $imgdata=getimagesize(GSDATAUPLOADPATH.$path.$key.$imgType);
    return ("<img src='".$siteUrl."data/uploads/".$path.rawurlencode($key)."$imgType' {$imgdata[3]} $htmlAttributes alt=''/>");
    }
  }
  // There is no img/teams/ Directory in the uploadfolder, so do not show any teamlogos
  else return ('<!-- SIS-Handball Plugin:PATH doesn\'t exists:'.$path.' -->');
}

?>