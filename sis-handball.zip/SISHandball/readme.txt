tabelle,               
mini_tabelle,          
allespieleliga,         

letzten15spieleliga,
naechsten15spieleliga, 
letzten30spieleliga,
naechsten30spieleliga, 

letzten15spieleverein,
letzten30spieleverein,

naechsten15spieleverein,
naechsten30spieleverein,
allespieleverein,       
heimspieleverein,       
spielemannschaft,      


<h2>Letzten 15 Spiele der Liga</h2>
(%sishandball:letzten15spieleliga,001513000000000000000000000000000001000%)
<h2>N�chsten 15 Spiele der Liga</h2>
(%sishandball:naechsten15spieleliga,001513000000000000000000000000000001000%)
<h2>Letzten 30 Spiele der Liga</h2>
(%sishandball:letzten30spieleliga,001513000000000000000000000000000001000%)
<h2>N�chsten 30 Spiele der Liga</h2>
(%sishandball:naechsten30spieleliga,001513000000000000000000000000000001000%)
