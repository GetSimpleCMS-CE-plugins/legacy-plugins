<?php
$counter = 0;
$leaguename = $xml->Spielklasse[0]->Name;
?>
<table class="tabelle" width="100%">
    <thead>
    <tr>
        <th class="center">Platz</th>
        <th width="40px">&nbsp;</th>
        <th class="left">Verein</th>
        <th>Sp.</th>
        <th>G</th>
        <th>U</th>
        <th>V</th>
        <th>Tore</th>
        <th>+/-</th>
        <th class="left">Pkt</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($xml->Platzierung as $platzierung): ?>
    <tr class="<?php echo ($counter % 2 == 0) ? "even" : "odd"; ?>">
        <td class="center"><?php echo $platzierung->Nr; ?>.</td>
        <td class="center"><?php echo sishandball_getSmallImage($platzierung->Name,"nicht gefunden","style='vertical-align:middle,align=center'");?></td>
        <td><?php echo $platzierung->Name; ?></td>
        <td class="center"><?php echo $platzierung->Spiele; ?></td>
        <td class="center"><?php echo $platzierung->Gewonnen; ?></td>
        <td class="center"><?php echo $platzierung->Unentschieden; ?></td>
        <td class="center"><?php echo $platzierung->Verloren; ?></td>
        <td class="center"><?php echo $platzierung->TorePlus . ":" . $platzierung->ToreMinus; ?></td>
        <td class="center"><?php echo $platzierung->D; ?></td>
        <td class="left"><?php echo $platzierung->PunktePlus . ":" . $platzierung->PunkteMinus; ?></td>
    </tr>
    <?php $counter++; ?>
    <?php endforeach; ?>
    </tbody>
</table>