<?php
$counter = 0;
if (count($xml->Spiel) >= 1) : ?>
<table>
    <thead>
    <tr>
        <th class="left">Datum</th>
        <th class="left">Heim</th>
        <th class="left">Gast</th>
        <th>Endstand</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($xml->Spiel as $spiel): ?>
    <tr class="<?php echo ($counter % 2 == 0) ? "even" : "odd"; ?>">
        <td class="left"><?php echo date('d.m.y', strtotime($spiel->SpielVon)); ?></td>
        <td class="left"><?php echo $spiel->Heim; ?></td>
        <td class="left"><?php echo $spiel->Gast; ?></td>
        <td class="left"><?php echo $spiel->Tore1 . ":" . $spiel->Tore2 . " (" . $spiel->Tore01 . ":" . $spiel->Tore02 . ")"; ?></td>
    </tr>
    <?php $counter++; ?>
    <?php endforeach; ?>
    </tbody>
</table>
<?php else : ?>
<p>Aktuell keine Daten vorhanden.</p>
<?php endif; ?>