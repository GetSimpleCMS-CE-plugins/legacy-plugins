<?php
echo "<p>SIS Handball Plugin: no template found</p>";
?>