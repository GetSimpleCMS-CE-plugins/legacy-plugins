<?php
$counter = 0;
?>
<table class="sidebar_tabelle">
    <thead>
    <tr>    
        <th class="right">#&nbsp;</th>    
        <th>Verein</th>
        <th>Punkte</th>
        <th>Sp.</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($xml->Platzierung as $platzierung): ?>
    <tr class="<?php echo ($counter % 2 == 0) ? "even" : "odd"; ?>">
        <td class="right"><?php echo $platzierung->Nr; ?>.</td>
        <td class="left"><?php echo $platzierung->Name; ?></td>
        <td class="left"><?php echo $platzierung->PunktePlus . ":" . $platzierung->PunkteMinus; ?></td>
        <td class="center"><?php echo $platzierung->Spiele; ?></td>
    </tr>
    <?php $counter++; ?>
    <?php endforeach; ?>
    </tbody>
</table>