<?php
/****************************************************
*
* @File: 		de_DE.php
* @Package:		GetSimple SIS-Handball Plugin
* @Subject:		Deutsche Sprachdatei
* @Date:		1 apr 2012
* @Version:		sishandball 1.0 beta / GetSimple 3.1+
* @Autor:		Timme
* @Autor URI: 	
*
*****************************************************/



$i18n = array(
	"TITLE"					=> "SIS-Handball  Einstellungen",
	"DESCRIP"				=> "Dieses Plugin bindet Ihre SIS-Handball Ligen auf Ihrer Webseite ein.",
	"HOW"					=> "<b>Hilfe</b>",								
	"HOW1"					=> "Tragen Sie die notwendigen Angaben ein: <b>SIS Login, SIS Passwort, SIS Vereinsnummer</b>.",
    "HOW2"					=> "Wechseln Sie zum \"Seiten-Tab\" und tragen Sie in der Seite, auf der Sie die SIS-Daten anzeigen möchten, ohne Leerzeichen (!), folgendes ein: <b>(%sishandball:<i>Ansicht</i>,<i>Liganummer bzw. Vereinsnummer</i>%)</b>",
	"HOW3"					=> "Das wär's schon. Der Eintrag wird beim Laden der Webseite durch die Ligadaten ersetzt.",
	"HOW4"					=> 
    
"Folgende Views/Ansichten stehen zur Verfügung:  
<h4><b>Ligainformationen</b> (2.Parameter ist die Liganummer)</h4>
<ul>
<li>tabelle (die aktuelle Ligatabelle)</li>
<li>mini_tabelle (die aktuelle Ligatabelle in kompakter Form für die Sidebar)</li>
<li>letzten15spieleliga (die letzten 15 Partien der Liga)</li>
<li>naechsten15spieleliga (die kommenden 15 Partien der Liga)</li>
<li>letzten30spieleliga (die letzten 30 Partien der Liga)</li>
<li>naechsten30spieleliga (die kommenden 30 Partien der Liga)</li>
<li>allespieleliga (Gesamtspielplan der Liga)</li>
</ul>
Beispiel Tabellenansicht: <pre><b>(%sishandball:<i>tabelle</i>,<i>liganummer</i>%)</b></pre><br/>
<h4><b>Vereinsinformationen</b> (2.Parameter ist Ihre Vereinsnummer)</h4>
<ul>
<li>allespieleverein (alle Spiele ihres Vereins)</li>
<li>heimspieleverein (alle Heimspiele ihres Vereins)</li>
<li>letzten15spieleverein (die letzten 15 Partien ihres Vereins)</li>
<li>naechsten15spieleverein (die kommenden 15 Partien ihres Vereins)</li>
<li>letzten30spieleverein (die letzten 30 Partien ihres Vereins)</li>
<li>naechsten30spieleliga (die kommenden 30 Partien ihres Vereins)</li>
</ul> 
Beispiel Heimspiele des Vereins : <pre><b>(%sishandball:<i>heimspieleverein</i>,<i>Vereinsnummer</i>%)</b></pre>",   
    
    "SIS_LOGIN"             => "SIS Login",
    "SIS_PASS"              => "SIS Passwort",
    "SIS_VEREIN"             => "SIS Vereinsnummer",
    "SIS_SERVER"             => "SIS Server Domäne (sis-handball.de oder sis-handball.at)",
    "CREATECACHEFOLDER_ERROR" => "Cache Ordner 'sishandball' unter /data/other/ nicht erstellbar! Bitte per FTP erstellen",
    "SIS_CACHETIMEOUT"      => "Cachetimeout (SIS-Daten nach x Minuten synchronisieren). 15 Minuten reichen in der Regel völlig aus.<br/>Setzen Sie den Wert auf 0 oder kleiner, um den Abgleich komplett zu deaktivieren. (z.B. nach Saisonende)",
    "SIS_TAG_ERROR"         => "SIS Funktion nicht erkannt",
    "SIS_SYNC_DISABLED"     => "Der Serverabgleich ist zur Zeit deaktiviert!",
    );
?>