<?php
/****************************************************
*
* @File: 		de_DE.php
* @Package:		GetSimple SIS-Handball Plugin
* @Subject:		English
* @Date:		1 apr 2012
* @Version:		sishandball 1.0 beta / GetSimple 3.1+
* @Autor:		Timme
* @Autor URI: 	
*
*****************************************************/



$i18n = array(
	"TITLE"					=> "SIS-Handball  Settings",
	"DESCRIP"				=> "Dieses Plugin bindet Ihre SIS-Handball Ligen auf Ihrer Webseite ein.",
	"HOW"					=> "<b>Help</b>",								
	"HOW1"					=> "Enter all the necessary information: <b>SIS Login, SIS Password, SIS Teamid</b>.",
    "HOW2"					=> "Navigate to the \"Pages tab \" and fill in the page on which you want to view the SIS data, with no spaces, as follows (!): <b> Sishandball (%: <i> View </ i > <i> League or Club ID </ i>%) </ b>",
	"HOW3"					=> "That's it. The entry will be replaced by the league information during the runtime.",
	"HOW4"					=> 
    
"Folgende Views/Ansichten stehen zur Verfügung:  
<h4><b>Ligainformationen</b> (2.Parameter ist die Liganummer)</h4>
<ul>
<li>tabelle (die aktuelle Ligatabelle)</li>
<li>mini_tabelle (die aktuelle Ligatabelle in kompakter Form für die Sidebar)</li>
<li>letzten15spieleliga (die letzten 15 Partien der Liga)</li>
<li>naechsten15spieleliga (die kommenden 15 Partien der Liga)</li>
<li>letzten30spieleliga (die letzten 30 Partien der Liga)</li>
<li>naechsten30spieleliga (die kommenden 30 Partien der Liga)</li>
<li>allespieleliga (Gesamtspielplan der Liga)</li>
</ul>
Beispiel Tabellenansicht: <pre><b>(%sishandball:<i>tabelle</i>,<i>liganummer</i>%)</b></pre><br/>
<h4><b>Vereinsinformationen</b> (2.Parameter ist Ihre Vereinsnummer)</h4>
<ul>
<li>allespieleverein (alle Spiele ihres Vereins)</li>
<li>heimspieleverein (alle Heimspiele ihres Vereins)</li>
<li>letzten15spieleverein (die letzten 15 Partien ihres Vereins)</li>
<li>naechsten15spieleverein (die kommenden 15 Partien ihres Vereins)</li>
<li>letzten30spieleverein (die letzten 30 Partien ihres Vereins)</li>
<li>naechsten30spieleliga (die kommenden 30 Partien ihres Vereins)</li>
</ul> 
Beispiel Heimspiele des Vereins : <pre><b>(%sishandball:<i>heimspieleverein</i>,<i>Vereinsnummer</i>%)</b></pre>",   
    
    "SIS_LOGIN"             => "SIS Login",
    "SIS_PASS"              => "SIS Password",
    "SIS_VEREIN"             => "SIS Clubnummer",
    "SIS_SERVER"             => "SIS Server Domain (sis-handball.de or sis-handball.at)",
    "CREATECACHEFOLDER_ERROR" => "Can't Cache Folder 'sishandball' in /data/other/ !",
    "SIS_CACHETIMEOUT"      => "Cachetimeout. 15 Min. are quite nice<br/>Set to 0 or less, for disabling the sync.",
    "SIS_TAG_ERROR"         => "SIS Function not detected",
    "SIS_SYNC_DISABLED"     => "The Server Synchronization is disabled!",
    );
?>