<?php
/****************************************************
* @Plugin Name: SISHandball
* @Description: Connect Your Team Website with the SIS-Handball XML-Dataservice. 
*               Requires a SIS-Handball Registration.
*               Dieses Plugin ermöglicht die Darstellung von Ergebissen und Tabellen über 
*               den XML Dienst von SIS-Handball. Erfordert eine SIS Lizenz.
* @File: 		SISHandball.php
* @Package:		GetSimple SIS-Handball Plugin v1
* @Date:		2013/02/25
* @Version:		SISHandball 1.0 beta / GetSimple 3.1+
* @Autor:		Tim Schumacher
* @Autor URI: 	
*
*****************************************************/

# get correct id for plugin
$sishandball_thisfile=basename(__FILE__, ".php");
$sishandball_configfile = GSDATAOTHERPATH.$sishandball_thisfile.'.xml';

# add in this plugin's language file
i18n_merge($sishandball_thisfile);// || i18n_merge($sishandball_thisfile, 'en_US');

# register plugin
register_plugin(
    $sishandball_thisfile, //Plugin id
    'SIS-Handball',     //Plugin name
    '1.0 beta',         //Plugin version
    'Tim Schumacher',  //Plugin author
    '', //author website
    'Connect Your Team Website with the SIS-Handball XML-Dataservice. Requires a SIS-Handball Registration.<br>Dieses Plugin ermöglicht die Darstellung von Ergebissen und Tabellen über den XML Dienst von SIS-Handball. Erfordert eine SIS Lizenz.',
    'plugins', //page type - on which admin tab to display
    'sishandball_show_config'  //main function (administration)
);

/*
function check_version() {
    $my_plugin_id = 001; // replace this with yours
    
    $apiback = file_get_contents('http://get-simple.info/api/extend/?id='.$my_plugin_id);
    $response = json_decode($apiback);
    if ($response->status == 'successful') {
        // Successful api response sent back. 
        $facebookevents_current_ver = $response->version;
            return $facebookevents_current_ver;
    }
}*/

# activate filter
add_filter('content','sishandball_show'); 
add_filter('theme-sidebar','sishandball_show'); 

# add a link in the admin tab 'theme'
add_action('plugins-sidebar','createSideMenu',array($sishandball_thisfile,'SIS-Handball'));

# register Frontend Styles
register_style('SISHandball_CSS', $SITEURL . 'plugins/SISHandball/css/style.css', '1.0', 'screen');
queue_style('SISHandball_CSS', GSFRONT);


/* __________________________________________________________________________________
 * Replace tag %sishandball% by LeagueData
 * Supports multi SIS-tag per Side !!!!
 */
 function sishandball_show($contents){ 
  
    global $sishandball_config,$sishandball_thisfile;
    $tmpContent = $contents;
    
    $result = null;
    $sis_tags = null;
    $find = '/\(%sishandball:(.*?)%\)/i';
    preg_match_all($find, $tmpContent, $sis_tags);
    if (isset($sis_tags[0][0]) && count($sis_tags[0][0]) > 0 ){
        
        for ($x=0;$x < count($sis_tags[1]);$x++) {           
            $sis_view = null;
            $sis_id = null;
            $sisContent = null;
            $sisFunctionCallArray = explode(",",$sis_tags[1][$x]);
            $sisFunctionCallArray = array_map('trim', $sisFunctionCallArray);
            // SIS View
            if(isset($sisFunctionCallArray[0]) ) {
                $sis_view = $sisFunctionCallArray[0];
                $sis_view = trim($sis_view);
            }
            // SIS Liga / Verein
            if(isset($sisFunctionCallArray[1]) ) {
                $sis_id = $sisFunctionCallArray[1];
                $sis_id = trim($sis_id);
            }
            
            if (!is_null($sis_view) && !is_null($sis_id) ) {
                $sisContent = sishandball($sis_view,$sis_id);
            }
            
            else { //i18n($sishandball_thisfile.'/SIS_TAG_ERROR')
                $sisContent = '<p><strong>Fehler:</strong> sishandball Aufruf No.'.($x+1).' nicht korrekt!<br/><code>'.$sis_tags[1][$x].'</code></p>';
            }
            //$tag = $sis_tags[1][$x];
            $find_sisTag = "/\(%sishandball:".$sis_tags[1][$x]."%\)/i";
            //echo "SEARCH=".$findSIS_tag;
            $tmpContent = preg_replace($find_sisTag,$sisContent,$tmpContent);
            
        }
    }    
    return $tmpContent;
};

function sishandball_get_config() {
    global $sishandball_configfile, $error;
    // SIS - Config set default values     
    $sis_config = array();        
    $sis_config['settings']['sis_server'] = 'sis-handball.de';
    $sis_config['settings']['sis_login'] = 'sis-login';
    $sis_config['settings']['sis_pass'] = 'sis-password';
    $sis_config['settings']['sis_verein'] = 'sis-vereinsnummer';
    $sis_config['settings']['sis_cachetimeout'] = '15'; // cachetimeout in minutes
 
    if (file_exists($sishandball_configfile)) {
    
        if(!$x = @getXML($sishandball_configfile)){
            $x=0; $error = i18n_r('CHMOD_ERROR');
            return false;
        }
        
        if(isset($x->sis_server))
            $sis_config['settings']['sis_server'] = $x->sis_server;
        if(isset($x->sis_login))
            $sis_config['settings']['sis_login'] = $x->sis_login;
        if(isset($x->sis_pass))
            $sis_config['settings']['sis_pass'] = $x->sis_pass;
        if(isset($x->sis_verein))
            $sis_config['settings']['sis_verein'] = $x->sis_verein;
        if(isset($x->sis_cachetimeout))
            $sis_config['settings']['sis_cachetimeout'] = $x->sis_cachetimeout;
    
    } 
    /*
    else {
        // SIS - Benutzerdaten Default      
        $sis_config['settings']['sis_server'] = 'sis-handball.de';
        $sis_config['settings']['sis_cachetimeout'] = '5'; // cachetimeout in minutes
        $sis_config['settings']['sis_login'] = 'sis-login';
        $sis_config['settings']['sis_pass'] = 'sis-password';
        $sis_config['settings']['sis_verein'] = 'sis-vereinsnummer';
    }
    */
    return $sis_config;
}

function sishandball_show_config() 
{
    global $sishandball_config,$sishandball_configfile, $sishandball_thisfile, $success, $error, $LANG;

    i18n_merge('sishandball') || i18n_merge('sishandball','en_US');

    // submitted form
    if (isset($_POST['submit'])) {
    
        $sishandball_config = array();
    
        $xml = new SimpleXMLExtended('<?xml version="1.0" encoding="ISO-8859-15"?><settings></settings>');

        // RECORD SETTINGS
        $sishandball_config['settings']['sis_login'] = sis_clevar($_POST['sis_login']);
        $sishandball_config['settings']['sis_pass'] = sis_clevar($_POST['sis_pass']);
        $sishandball_config['settings']['sis_verein'] = sis_clevar($_POST['sis_verein']);
        $sishandball_config['settings']['sis_server'] = sis_clevar($_POST['sis_server']);
        $sishandball_config['settings']['sis_cachetimeout'] = sis_clevar($_POST['sis_cachetimeout']);

        
        // CREATE XML
        //$item = $xml->addChild('map');
        $xml->addChild('sis_login')    ->addCData(htmlspecialchars(stripslashes($sishandball_config['settings']['sis_login']),     ENT_QUOTES));
        $xml->addChild('sis_pass')    ->addCData(htmlspecialchars(stripslashes($sishandball_config['settings']['sis_pass']),     ENT_QUOTES));
        $xml->addChild('sis_verein')    ->addCData(htmlspecialchars(stripslashes($sishandball_config['settings']['sis_verein']),     ENT_QUOTES));
        $xml->addChild('sis_server')    ->addCData(htmlspecialchars(stripslashes($sishandball_config['settings']['sis_server']),     ENT_QUOTES));
        $xml->addChild('sis_cachetimeout')    ->addCData(htmlspecialchars(stripslashes($sishandball_config['settings']['sis_cachetimeout']),     ENT_QUOTES));
        
        // Create cachefolder
        if (!file_exists(GSDATAOTHERPATH.'sishandball')){ 
            if (!mkdir(GSDATAOTHERPATH.'sishandball', 0755)) {
                $error = i18n_r($sishandball_thisfile.'/CREATECACHEFOLDER_ERROR');               
            }
        }

        // Save
        if(!XMLsave($xml, $sishandball_configfile)){
            $error = i18n_r('CHMOD_ERROR');
        }else{
            $success = i18n_r('SETTINGS_UPDATED');
        };
        
    }else{
        $sishandball_config = sishandball_get_config();
    };


    // Show success
    if($success) { 
        echo '<br/><div class="updated"><b>'. $success .'</b></div>';
    };
    if($error) { 
        echo '<br/><div class="error"><b>'. $error .'</b></div>';
    };
    ?>
    <div id="sisHandballPlugin">
    <script type="text/javascript">
    // EXPAND/COLLAPSE options
    $(".edit-nav a.ops").live("click", function($e) {
    $e.preventDefault();
    name = $(this).attr('name');
    $($(this).parent().parent().find('#'+name)).slideToggle('fast');
    $(this).toggleClass('current');
    });         
    </script>
    <ul id="event-log" />
        <form method="post" name="formmap" action="<?php echo $_SERVER ['REQUEST_URI'];?>">  
        
        <h3 class="floated"><?php i18n($sishandball_thisfile.'/TITLE');?></h3>

        <div class="edit-nav clearfix">
            <a href="#" class="ops" name="sishandball_how"><?php i18n($sishandball_thisfile.'/HOW');?></a>        
        </div>
        
         <div class="clear"/></div>
        
        
        <div id="sishandball_how">
             
            <fieldset style="font-weight:normal;">
                <legend><?php i18n($sishandball_thisfile.'/HOW');?></legend>
                <ul>
                    <li><?php i18n($sishandball_thisfile.'/HOW1');?></li>
                    <li><?php i18n($sishandball_thisfile.'/HOW2');?></li>
                    <li><?php i18n($sishandball_thisfile.'/HOW3');?></li>
                    <li><?php i18n($sishandball_thisfile.'/HOW4');?></li>
                </ul>
            </fieldset>    
        </div>
        <p class="clear"></p>
        <div class="basic">
            <p style="margin:0 15px 0 0;">
                <label for="sishandball_id"><?php i18n($sishandball_thisfile.'/SIS_SERVER');?></label>
                http://<input  name="sis_server" type="text" class="text medium idmap" value="<?php echo $sishandball_config['settings']['sis_server']; ?>"/>
            </p>
            <p style="margin:0 15px 0 0;">
                <label for="sishandball_id"><?php i18n($sishandball_thisfile.'/SIS_LOGIN');?></label>
                <input  name="sis_login" type="text" class="text medium idmap" value="<?php echo $sishandball_config['settings']['sis_login']; ?>"/>
            </p>
            <p style="margin:0 15px 0 0;">
                <label for="sishandball_id"><?php i18n($sishandball_thisfile.'/SIS_PASS');?></label>
                <input  name="sis_pass" type="text" class="text medium idmap" value="<?php echo $sishandball_config['settings']['sis_pass']; ?>"/>
            </p>
            <p style="margin:0 15px 0 0;">
                <label for="sishandball_id"><?php i18n($sishandball_thisfile.'/SIS_VEREIN');?></label>
                <input  name="sis_verein" type="text" class="text medium idmap" value="<?php echo $sishandball_config['settings']['sis_verein']; ?>"/>
            </p>
            <p style="margin:0 15px 0 0;">
                <label for="sishandball_id"><?php i18n($sishandball_thisfile.'/SIS_CACHETIMEOUT');?></label>
                <input  name="sis_cachetimeout" type="text" class="text medium idmap" value="<?php echo $sishandball_config['settings']['sis_cachetimeout']; ?>"/>
            </p>
            <?php
            if ($sishandball_config['settings']['sis_cachetimeout']<=0) {
                echo'<p><div class="error"><b>'. i18n_r($sishandball_thisfile.'/SIS_SYNC_DISABLED') .'</b></div></p>';
            }
            ?>
            
            
        </div>
             
            <p>&nbsp;</p>
            <p class="submit"><input type="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" /></p>
            
            <!--    Anchor template    -->
            <?php draw_anchor(array("TEMP",false,false,false,false,false,false,false)); ?>
            <!-- --------------------- -->
            
        </form>

    </div>

<?php
}; // End function sishandball_show_config()

function sis_clevar($val = false){
    if(!isset($val)){ $val = ''; };
    return $val;
};

include('SISHandball/include.php');


?>