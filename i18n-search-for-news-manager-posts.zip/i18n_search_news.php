<?php

$thisfile = basename(__FILE__, ".php");

register_plugin(
  $thisfile,
  'I18N Search for News Manager Posts',
  '0.3',
  'SebastianBatko.com',
  'http://SebastianBatko.com/get-simple/',
  'Plugin to index and search News Manager Posts with the I18N Search plugin',
  'plugins', //page type - on which admin tab to display
  'nmi_admin'  //main function (administration)
);

define('NMI_CONFIG_XML', GSDATAOTHERPATH .'nmi_config.xml');

// Plugin based on original i18n_search_dummy.php by mvlecek
// Some parts get from Matrix Blog by Angryboy and News Manager (updated)
// Thanks for suggestions to Carlos and Mvlcek

// The action called for indexing News Manager pages.
add_action('search-index', 'i18n_search_news_index');
add_action('plugins-sidebar','createSideMenu',array($thisfile,'News Manager Search Settings'));
// The filter called for returning the data of the found item.
add_filter('search-item', 'i18n_search_news_item');
// The filter called for displaying the found item.
// It is not neaded, if the item has fields title and content like a regular page.
// Implemented but not used, show how to custom-format search result
add_filter('search-display', 'i18n_search_news_display');
// Hook to check indexes dates
add_action('admin-pre-header', 'i18n_search_news_check', array(false)); 

# includes
require_once(GSROOTPATH.'plugins/news_manager/inc/common.php');
require_once(GSROOTPATH.'plugins/i18n_search/indexer.class.php');
require_once(GSROOTPATH.'plugins/i18n_search.php');

function nmi_read_config() {
    $config = array();
    if (file_exists(NMI_CONFIG_XML)) {
        $x = getXML(NMI_CONFIG_XML);
        $config['lang'] = strval($x->lang);
        //$config['feedburner_id'] = strval($x->feedburner_id);
    } else {
        # Default config options
        $config['lang'] = 'pl';
        //$config['feedburner_id'] = '';
    }
    return $config;
}

function nmi_write_config($config) {
    $xml = @new SimpleXMLElement('<item></item>');
    $xml->addChild('lang', $config['lang']);
    //$xml->addChild('feedburner_id', $config['feedburner_id']);

    return $xml->asXML(NMI_CONFIG_XML);
}


function i18n_search_news_index() {
  global $i18n_news_items;
  global $is_arr_empty;
  if ($is_arr_empty) {
    //error_log("N_index need load\n", 3, "err.txt"); 
    load_news();
  }
  // for each item call i18n_search_index_item($id, $language, $creDate, $pubDate, $tags, $title, $content)
  foreach ($i18n_news_items as $id => $item) {
    // only index the page if we have selected to
    if (!strval($item['private'])=='Y') {
            
      // language for individual page, default is en
      $config = nmi_read_config();
      $lang = $config['lang'];

      // format date correctly (the two stages MUST be done - you cannot just use the raw UNIX stamp as-is
      $item['credate'] = is_numeric($item['date']) ? $item['date'] : strtotime($item['date']);
      $item['pubdate'] = is_numeric($item['date']) ? $item['date'] : strtotime($item['date']);
      
      $creDate = date('j F Y', $item['credate']);
      $creDate = strtotime($creDate);
      $pubDate = date('j F Y', $item['pubdate']);
      $pubDate = strtotime($pubDate);
      
      // explode tags list and add default tags to the array
      //$tags   = explode(',', strval($item['tags']));
      $tags   = $item['tags'];
      //$tags   = array_merge($this->config['tags'], $tags);
      
      // virtual tags for credate and pubdate and ensuring our item is in MatrixBlog
      $tags[] = '_cre_'.date('Y',  $item['credate']);
      $tags[] = '_cre_'.date('Ym', $item['credate']);
      $tags[] = '_pub_'.date('Y',  $item['pubdate']);
      $tags[] = '_pub_'.date('Ym', $item['pubdate']);
      $tags[] = '_newsmanager';
      
      // content
      //$content = array($item['description']); // add the fields that you want to be indexed
      //$content = implode(' ', $content);
      $content = html_entity_decode(strip_tags(stripslashes(htmlspecialchars_decode($item['description']))), ENT_QUOTES, 'UTF-8');
      $title = html_entity_decode(stripslashes(htmlspecialchars_decode(strip_tags($item['title']))), ENT_QUOTES, 'UTF-8');

      // finally index the item
      i18n_search_index_item('nmi:'.trim($id), $lang, $creDate, $pubDate, $tags, $title, $content);
      //error_log("N_Added to index:$id/$creDate/".implode (':', $item['tags'])."/".$item['title']."\n", 3, "err.txt"); 
    }
  }
}
  

function i18n_search_news_item($id, $language, $creDate, $pubDate, $score) {

  //error_log("Searched:$id\n", 3, "err.txt");
  global $is_arr_empty;
  if ($is_arr_empty) load_news();

  if (!class_exists('I18nSearchNewsResultItem')) {

    // a class for returning all properties of an item of this plugin
    class I18nSearchNewsResultItem extends I18nSearchResultItem {
      protected $data = null;
      // this is the only function you need to implement
      protected function get($name) {
        global $i18n_news_items;
        global $is_arr_empty;
        global $NMPAGEURL;
        if (!$this->data) {
          // lazy loading data of the item - normally this would involve reading a file
          
          if ($is_arr_empty) load_news();
          $this->data = $i18n_news_items[substr($this->id,4)];
          if (!$this->data) {
            //error_log("SearchNotFound:".$this->id."\n", 3, "err.txt");
            //var_dump($i18n_news_items);
            return null;
          }
        }
        switch ($name) {
          case 'title': return $this->data['title'];
          case 'tags': return $this->data['tags'];
          case 'description': return $this->data['description'];
          case 'content': return '<p>' . htmlspecialchars($this->data['description']) . '</p>';
          case 'link': return get_site_url(false).$NMPAGEURL.'/post/'.substr($this->id,4);// 
          default: return @$this->data[$name]; 
        }
      }
    }

  }
   
  if (substr($id,0,4) == 'nmi:') {
    // return the result item, if it is an item of our plugin
    //error_log("SearchFoundNmi:".substr($id,4)."\n", 3, "err.txt");
    return new I18nSearchNewsResultItem($id, $language, $creDate, $pubDate, $score);
  }
  // item is not from our plugin - maybe from another plugin
  return null;
}

function i18n_search_news_display($item, $showLanguage, $showDate, $dateFormat, $numWords) {
  // uncomment the following line to see the default rendering
  return false;
  
  global $NMPAGEURL;
  if (substr($item->id,0,4) == 'nmi:') {
?>
    <h3><a href="<?php echo get_site_url(false).$NMPAGEURL.'/post/'.substr($item->id,4) ?>"><?php echo $item->title ?></a></h3>
    <p><?php echo $item->description ?></p>
<?php
    //error_log("Displayed:".$item->id."\n", 3, "err.txt");
    return true;
  }
  // item is not from our plugin - maybe from another plugin
  //error_log("NotDisplayed:".$item->id."\n", 3, "err.txt");
  return false;
}


//sjb

function nm_get_post_content($slug) {
  $file = NMPOSTPATH . "$slug.xml";
  if (dirname(realpath($file)) == realpath(NMPOSTPATH)) // no path traversal
    $post = @getXML($file);
  if (!empty($post) && $post->private != 'Y') {
    //$url     = nm_get_url('post') . $slug;
    //$title   = stripslashes($post->title);
    //$date    = nm_get_date(i18n_r('news_manager/DATE_FORMAT'), strtotime($post->date));
    $content = strip_decode($post->content);
    //if ($excerpt) $content = nm_create_excerpt($content);
    # print post data
    return $content;
  } else {
    return '';
  }
}

function load_news() {
  global $i18n_news_items;
  global $is_arr_empty;
  $lista = nm_get_posts(true);    
  foreach ($lista as $id => $item) {
    $content = nm_get_post_content($item->slug);
    $content = preg_replace('/\(%.*?%\)/', '', $content); // remove (% ... %)
    $content = preg_replace('/\{%.*?%\}/', '', $content); // remove {% ... %}
    $content = strip_tags($content); 
    $key = strval($item->slug);
    $tags = explode(",", $item->tags);
    $data = array('title' => strval($item->title), 'description' => $content, 'tags' => $tags, 'date' => strval($item->date), 'private' => strval($item->private));
    $i18n_news_items[$key] = $data;
    error_log("ArrayBuilded:".$key."\n", 3, "err.txt");
  }
  $is_arr_empty = false;
}

function nmi_admin() {
    $config = nmi_read_config();
    $error = "";
    $success = "";

  if (isset($_POST['submit'])) {

        $config['lang'] = $_POST['lang'];
        //$config['feedburner_id'] = $_POST['feedburner_id'];
    
    if ($error == "") {
      if (! nmi_write_config($config)) {
        $error = i18n_r('CHMOD_ERROR');
      } else {
          $config = nmi_read_config();
          $success = i18n_r('SETTINGS_UPDATED');
          //bad: i18n_search_news_index();
          //good: this works
          delete_i18n_search_index();
      }
    }
  }
  ?>
  <h3>I18N Search for News Manager Settings</h3>
  
  <?php 
  if($success) { 
    echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
  } 
  if($error) { 
    echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
  }
  ?>
  
  <form method="post" action="<?php echo $_SERVER ['REQUEST_URI']?>">
        <p>
            <label for="lang">Language code for I18N Search Index</label>
            <input id="lang" name="lang" class="text" value="<?php echo $config['lang']; ?>" />
        </p>
    <p><input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" /></p>
  </form>
  
  <?php
}

function i18n_search_news_check($parameters) {
  //debugLog('In i18n_search_news_check');
  if (basename($_SERVER['PHP_SELF']) == 'load.php' && @$_GET['id'] == 'news_manager' ) { //&& /* additional conditions to check for save or delete parameters */
    if ((isset($_POST['post']) || isset($_POST['settings']) || isset($_GET['delete']) || isset($_GET['restore']))) {
      //debugLog('In News_Manager add/edit/delete/settings/restore');
      delete_i18n_search_index();
    }
    
    // $i18nfile=GSDATAOTHERPATH.'i18n_word_index.txt';
    // $nmixfile=GSDATAOTHERPATH.'news_manager/posts.xml';
    // if (file_exists($i18nfile) && file_exists($nmixfile)) {
    //   $snm = stat($nmixfile);
    //   $si18n = stat($i18nfile);
    //   if ($snm[9]>$si18n[9]) {
    //     debugLog('News_Manager newer than i18n');
    //   } else {
    //     debugLog('News_Manager not newer than i18n');
    //   }
    // } else {
    //   debugLog('Some index files not exists');
    // }
  
  }
}


$i18n_news_items = array();
$is_arr_empty = true;

