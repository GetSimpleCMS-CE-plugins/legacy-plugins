<?php
  
defined('IN_GS') or die('Cannot load this file directly.');
  
require_once('settings.class.php');

$settings = new FilesWardenSettings();
$message = '';
$message_class = 'updated';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $notificationEnabled = isset($_POST['notification-enabled']);
  $notificationEmail = '';
  $notificationEmailSubject = '';
  $notificationEmailMessage = '';
  if (isset($_POST['notification-email'])) $notificationEmail = trim($_POST['notification-email']);
  if (isset($_POST['notification-subject'])) $notificationEmailSubject = trim($_POST['notification-subject']);
  if (isset($_POST['notification-message'])) $notificationEmailMessage = trim($_POST['notification-message']);
  //
  if ($message === ''){
    if ($notificationEnabled && ($notificationEmail === '')){
      $message = 'Email not specified';
    }
  }
  if ($message === ''){
    if ($notificationEnabled && ($notificationEmailSubject === '')){
      $message = 'Email Subject not specified';
    }
  }
  if ($message === ''){
    if ($notificationEnabled && ($notificationEmailMessage === '')){
      $message = 'Email Message not specified';
    }
  }
  if ($message === ''){
    if ($notificationEmail !== ''){
      if (!filter_var($notificationEmail, FILTER_VALIDATE_EMAIL)){
        $message = 'Wrong email format';
      }
    }
  }
  //
  //
  if ($message !== ''){
    $message_class = 'error';
  }else{
    $settings->NotificationEnabled = $notificationEnabled;
    $settings->NotificationEmail = $notificationEmail;
    $settings->NotificationEmailSubject = $notificationEmailSubject;
    $settings->NotificationEmailMessage = $notificationEmailMessage;
    //
    $settings->Save();
    $message = 'Settings saved.';
  }
}else{
  $settings->Load();
  $notificationEnabled = $settings->NotificationEnabled;
  $notificationEmail = $settings->NotificationEmail;
  $notificationEmailSubject = $settings->NotificationEmailSubject;
  $notificationEmailMessage = $settings->NotificationEmailMessage;
}

?>  

<?php if ($message !== '') { ?>
<div class="<?php echo $message_class; ?>"><p><?php echo $message; ?></p></div>
<?php } ?>

<h3 class="floated">Site Files Warden</h3>
    
    <div class="edit-nav clearfix">
      <a class="current" href="load.php?id=files-warden&amp;settings">Settings</a>
      <a href="load.php?id=files-warden">Main</a>
    </div>
    
    <form method="post" action="">
      
      <p class="inline">
        <input name="notification-enabled" id="notification-enabled" type="checkbox" <?php if ($notificationEnabled) echo 'checked'; ?> />&nbsp;
        <label for="notification-enabled">Send email notification when plugins/files-warden/check.php found the changes.</label>
      </p>

      <p>
        <label for="notification-email">Email:</label>
        <input class="text" type="text" name="notification-email" id="notification-email" value="<?php echo $notificationEmail; ?>" placeholder="mail@example.com" />
      </p>
      
      <p>
        <label for="notification-subject">Email Subject:</label>
        <input class="text" type="text" name="notification-subject" id="notification-subject" value="<?php echo $notificationEmailSubject; ?>" placeholder="Files Warden found changes" />
      </p>
      
      <p>
        <label for="notification-message">Email Message:</label>
        <input class="text" type="text" name="notification-message" id="notification-message" value="<?php echo $notificationEmailMessage; ?>" placeholder="Files Warden found changes on the website." />
      </p>
      
      <p>
        <input class="submit" type="submit" name="settings" value="Save settings" />
        &nbsp;
        <a href="load.php?id=files-warden" class="cancel">Cancel</a>
      </p>
    </form>
