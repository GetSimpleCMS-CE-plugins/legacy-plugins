<?php

defined('IN_GS') or die('Cannot load this file directly.');

class CheckState {

  public $NotificationSent = false;
  
  private $fileName; 
  
  function __construct(){
    $this->fileName = GSDATAOTHERPATH . '/files-warden/check-state.json'; 
  }
    
  public function Load(){
    $this->NotificationSent = false;
    if (!file_exists($this->fileName)) return;
    //
    $contents = file_get_contents($this->fileName);
    $obj = json_decode($contents);
    $this->NotificationSent = $obj->NotificationSent;
  }

  public function Save(){
    $contents = json_encode($this);
    file_put_contents($this->fileName, $contents);
  }

}

?>