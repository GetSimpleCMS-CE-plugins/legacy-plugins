<?php
  defined('IN_GS') or die('Cannot load this file directly.');
?>

<?php
  if (isset($_GET['settings'])){
    require_once('gs-admin-settings.php');
  }else{
    require_once('gs-admin-main.php');
  } 
?>
    
