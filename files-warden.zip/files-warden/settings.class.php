<?php 

  defined('IN_GS') or die('Cannot load this file directly.');
        
  class FilesWardenSettings {
  
    public $NotificationEnabled = false;
    public $NotificationEmail = '';
    public $NotificationEmailSubject = '';
    public $NotificationEmailMessage = '';
    
    private $fileName = null;
    
    function __construct(){
      $this->fileName = GSDATAOTHERPATH . '/files-warden/settings.xml'; 
    }
    
    public function Load(){
      if (file_exists($this->fileName)){
        $xml = simplexml_load_file($this->fileName);
        $this->NotificationEnabled = $this->string2bool($xml->NotificationEnabled);
        $this->NotificationEmail = $xml->NotificationEmail;
        $this->NotificationEmailSubject = $xml->NotificationEmailSubject;
        $this->NotificationEmailMessage = $xml->NotificationEmailMessage;
      }else{
        $this->NotificationEnabled = false;
        $this->NotificationEmailSubject = 'Files Warden found changes';
        $this->NotificationEmailMessage = 'Files Warden found changes on the website.';
        //
        global $USR;
        $file	= _id($USR) .'.xml';
        $data = getXML(GSUSERSPATH . $file);
        $this->NotificationEmail = $data->EMAIL;
      }
    }
    
    public function Save(){
      $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><settings></settings>');
      //
      $xml->addChild('NotificationEnabled', $this->bool2string($this->NotificationEnabled));
      $xml->addChild('NotificationEmail', $this->NotificationEmail);
      $xml->addChild('NotificationEmailSubject', $this->NotificationEmailSubject);
      $xml->addChild('NotificationEmailMessage', $this->NotificationEmailMessage);
      //      
      $xml->asXml($this->fileName);
    }
    
    private function bool2string($value){
      return $value ? 'true' : 'false';
    }
    
    private function string2bool($value){
      return ($value == 'true');
    }
    
  }

?>