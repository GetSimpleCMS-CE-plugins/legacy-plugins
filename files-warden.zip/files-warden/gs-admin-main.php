<?php

  defined('IN_GS') or die('Cannot load this file directly.');

  //error_reporting(E_ALL | E_STRICT);
  //error_reporting(0);
  require_once('files-warden.classes.php');
  require_once('check-state.class.php');
  
  $filesWarden = new FilesWarden("..");
  $filesWarden->DataPath = GSDATAOTHERPATH . '/files-warden'; 
  if (!$filesWarden->DataPathExists()){
    // first time run
    $filesWarden->CreateDataPath();
    $filesWarden->SaveExclusions(array(
      'data/other/files-warden/state.json',
      'data/other/files-warden/new-state.json',
      'data/other/files-warden/check-state.json'
    ));
  }else{
    if (!file_exists(GSDATAOTHERPATH . '/files-warden/check-state.json')){
      // upgrade from 1.0 to 1.1
      $exclusionsFileName = GSDATAOTHERPATH . '/files-warden/exclusions.txt';
      $exclusions = file_get_contents($exclusionsFileName);
      if (stripos($exclusions, 'data/other/files-warden/check-state.json') === false){
        $old = 'data/other/files-warden/state.json' . PHP_EOL . 'data/other/files-warden/new-state.json';
        $new = $old . PHP_EOL . 'data/other/files-warden/check-state.json';
        $exclusions = str_replace($old, $new, $exclusions);
        file_put_contents($exclusionsFileName, $exclusions);
      }
    }
  }
  $filesWarden->LoadExclusions();
  
  
  $operation = 'refresh';
  if (($_SERVER['REQUEST_METHOD'] === 'POST') && isset($_POST['op'])){
    $operation = $_POST['op'];
  }
  
?>

  <style>

    @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");
  
    /* ---------------------- */
    /*        reset           */
    /* ---------------------- */

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    /* ---------------------- */
    /*         page           */
    /* ---------------------- */
  
    /*.page {
      padding: 20px;
      font-family: Geneva, Arial, Helvetica, sans-serif;
    }*/
  
    .demo-explanation {
      background: #eee;
      padding: 20px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
    }
  
    h1,h2 {
      margin-bottom: 10px;
    }
    
    form {
      margin-top: 20px;
      margin-bottom: 20px;
    }
    
    input {
      padding: 5px;
    }
    
    .additional-notes {
      color: #777;
    }
  
    /* ---------------------- */
    /*         diff           */
    /* ---------------------- */

    .wrapper #maincontent .diff ul {
      margin: 0; /* 0 20px 30px;   */
    }
    .bodycontent .diff ul p {
      margin: 0;
    }
    
    .diff {
      overflow: auto;
    }   
    .diff p {
      margin: 0;
      padding: 2px 50px 2px 5px;
    }
    .diff > ul {
      display: inline-block;
      border: 1px solid #ccc;
      padding: 10px 20px 10px 10px;
    }
    .diff > ul {
      margin: 0;
    }
    .diff ul {
      list-style: none;
      padding-left: 20px;
    }

    .fa.roll {
      font-size: 15px;
      margin-right: 7px;
      cursor: pointer;
    }       
    .fa.change {
      background-color: #fff;
      padding: 4px 3px 2px 3px;
      border-radius: 9px;
      font-size: 15px;
      margin-right: 5px;    
      cursor: pointer;
    }   
    .fa-minus {
      color: blue;
    }
    .fa-plus {
      color: red;
    }
    .fa-asterisk {
      color: #777;
    }
    
    /*
    
    .diff .fa.roll {
      font-size: 15px;
      margin-right: 7px;
      cursor: pointer;
    }   
    
    .diff .fa.change {
      background-color: #fff;
      padding: 4px 3px 2px 3px;
      border-radius: 9px;
      font-size: 15px;
      margin-right: 5px;    
      cursor: pointer;
    }   
    .diff .fa-minus {
      color: blue;
    }
    .diff .fa-plus {
      color: red;
    }
    .diff .fa-asterisk {
      color: #777;
    }
    
    */
    
    .edited > .name{
      background-color: #00ff00;
    }    
    .inserted .name {
      background-color: #ff88c8;
    }
    .deleted .name {
      background-color: #0088ff;
    }
    
    /* ------------------------------ */
    /*            details             */
    /* ------------------------------ */
    
     /* The Modal (background) */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

    /* Modal Content/Box */
    .modal-content {
        background-color: #fefefe;
        margin: 15% auto; /* 15% from the top and centered */
        /*padding: 20px;*/
        border: 1px solid #888;
        width: 80%; /* Could be more or less, depending on screen size */
    }

    /* The Close Button */
    .close {
        color: #888;
        float: right;
        font-size: 28px;
        font-weight: bold;
        margin-right: 5px;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
    } 
    
    .modal h4 {
      background: #ccc;
      padding: 10px;
    }
    .info {
      margin: 10px;
    }
    .info h5 {
      display: inline-block;
    }
    .info p {
      display: inline-block;
      margin: 0;
    }
    
  </style>
 
    <h3 class="floated">Site Files Warden</h3>
    
    <div class="edit-nav clearfix">
      <a href="load.php?id=files-warden&amp;settings">Settings</a>
      <a class="current" href="load.php?id=files-warden">Main</a>
    </div>
    
    
    <?php
    
    if ($operation === 'accept'){
      $message = "State saved";
      if (!$filesWarden->SaveCurrentAsNorm()){
        $message = "File rename error.";
      }else{
        $state = new CheckState();
        $state->NotificationSent = false;
        $state->Save();
      }
    
      ?>
      
      <p><?php echo $message; ?></p>   
      <form method="post" action="">
        <input type="hidden" name="op" value="refresh" />
        <input class="submit" type="submit" value="Check again" />
      </form>    
    
    <?php }else{ 

      if ($filesWarden->CheckDiff()){
        $prevDateTime = $filesWarden->GetPrevDateTime();
        if ($prevDateTime === null){
          echo "<h2>First time check: all files looks like added.</h2>";
        }else{
          $prevDateTimeText = date('Y-m-d H:i:s P', $prevDateTime);
          echo "<h2>Changes found <small>(since $prevDateTimeText):</small></h2>";
        }
        //
        $filesWarden->PrintDiffHtml();
      }
      //
      $acceptChangesDisabled = '';
      if ($filesWarden->GetDiffItemsCount() === 0) $acceptChangesDisabled = "disabled=\"disabled\"";
      
    ?>
    
    
    <form method="post" action="">
      <input type="hidden" name="op" value="refresh" />
      <input class="submit" type="submit" value="Refresh" />
    </form>    
    
    <form method="post" action="">
      <input type="hidden" name="op" value="accept" />
      <input class="submit" type="submit" value="Accept changes" <?php echo $acceptChangesDisabled; ?> />
      <span>
        &nbsp;Current state will be saved as a norm. Next time a new state will be compared with this one.
      </span>
    </form>
    <p class="additional-notes">
      This tool does not change anything except own state and settings files inside the "data/other/files-warden/" directory. "Accept changes" only means update the state files.
    </p>
  
  <div id="details" class="modal">
    <div class="modal-content">
      <span id="details-close" class="close">&times;</span>
      <h4 id="details-title" >dir/dir/dir/dir/dir/dir/dir/dir/dir/dir/dir/dir/dir/dir/</h4>
      <div class="info">
        <strong>Was: </strong>
        <p id="details-prev" >Nothing</p>
      </div>
      <div class="info">
        <strong>Now: </strong>
        <p id="details-curr">File, 100500 bytes, 2005-08-15 15:52:01</p>
      </div>
      <div class="info">
        <strong>Change: </strong>
        <p id="details-change">File inserted</p>
      </div>
    </div>
  </div>
  
  
  <script>
    $(document).ready(function () {
    
      $(".diff i.roll").click(function(){
        $fa = $(this);
        $name = $fa.parent();
        if ($fa.hasClass("fa-minus-square-o")){
          $fa.removeClass("fa-minus-square-o");
          $fa.addClass("fa-plus-square-o");
          $name.next().hide();
        }else{
          $fa.removeClass("fa-plus-square-o");
          $fa.addClass("fa-minus-square-o");
          $name.next().show();
        }
      });
    
      $(".diff i.change").click(function(){
        $fa = $(this);
        var path = '';
        $fa.parents(".diffitem").each(function(index, element){
          if (path !== '') path = '\\' + path;
          $li = $(this);
          $p = $li.children("p.name");
          path = $p.text() + path;
        });
        //
        $parent = $fa.parent().parent();
        dataPrev = $parent.attr('data-prev');
        dataCurr = $parent.attr('data-curr');
        //
        $("#details-title").text(path);
        $("#details-prev").text(calcStateText(dataPrev));
        $("#details-curr").text(calcStateText(dataCurr));
        $("#details-change").text(calcChangeText(dataPrev, dataCurr));
        //
        $("#details").show();
      });
      
      $(".modal").click(function(event){
        if (event.target === $(".modal")[0]){
          $("#details").hide();
        }
      });
      $("#details-close").click(function(){
        $("#details").hide();
      });
      
      function calcStateText(state){
        if (state === '') return 'Nothing';
        if (state === 'dir') return 'Directory';
        var parts = state.split('|');
        return 'File, ' + parts[1] + ' bytes, ' + parts[2];
      }
      
      function calcChangeText(prevState, currState){
        switch(prevState){
          case '': switch(currState){
            case '': return '???';
            case 'dir': return 'Directory created.';
            default: return 'File added.';
          }
          case 'dir': switch(currState){
            case '': return 'Directory deleted.';
            case 'dir': return '';
            default: return 'Directory converted to file (directory deleted, file added).';
          }
          default: switch(currState){
            case '': return 'File deleted.';
            case 'dir': return 'File converted to directory (file deleted, directory created).';
            default: return 'File edited.';
          }
        }
      }
          
    });
  </script>
  
<?php } ?>  
