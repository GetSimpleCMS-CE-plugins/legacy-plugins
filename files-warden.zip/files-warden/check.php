<?php

//error_reporting(E_ALL | E_STRICT);
error_reporting(0);

define('IN_GS', 0);
define('GSDATAOTHERPATH', '../../data/other');

require_once('settings.class.php');
require_once('check-state.class.php');

ExecuteCheck();
echo 'Done';

function ExecuteCheck(){
  //
  $settings = new FilesWardenSettings();
  $settings->Load();
  if (!$settings->NotificationEnabled) return;
  //
  $state = new CheckState();
  $state->Load();
  if ($state->NotificationSent) return;
  //
  require_once('files-warden.classes.php');
  //
  $filesWarden = new FilesWarden("../..");
  $filesWarden->DataPath = GSDATAOTHERPATH . '/files-warden'; 
  if (!$filesWarden->DataPathExists()) return;
  $filesWarden->LoadExclusions();
  //
  $hasChanges = false;
  if ($filesWarden->CheckDiff()){
    $hasChanges = $filesWarden->CalcHasChanges();
  }
  if (!$hasChanges) return;
  //
  $sent = mail($settings->NotificationEmail, $settings->NotificationEmailSubject, $settings->NotificationEmailMessage);
  if (!$sent) return;
  //
  $state->NotificationSent = true;
  $state->Save();
}


?>