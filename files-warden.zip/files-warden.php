<?php
/*
Plugin Name: Files Warden
Description: Determines the changed files and directories.
Version: 1.1
Author: Sergey Zyryanov
Author URI: http://ypwm.ru/about-eng
*/
 
defined('IN_GS') or die('Cannot load plugin directly.');
 
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
 
# register plugin
register_plugin(
	$thisfile, //Plugin id
	'Files Warden', 	//Plugin name
	'1.1', 		//Plugin version
	'Sergey Zyryanov',  //Plugin author
	'http://ypwm.ru/about-eng', //author website
	'Determines the changed files and directories', //Plugin description
	'plugins', //page type - on which admin tab to display
	'files_warden_admin'  //main function (administration)
);
 
# add a link in the admin tab 'plugins'
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Files Warden'));
  
function files_warden_admin() {
  include 'files-warden/gs-admin.php';   
}

?>