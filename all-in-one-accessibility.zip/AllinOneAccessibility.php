<?php

# get correct id for plugin
$AllinOneAccessibility=basename(__FILE__, ".php");

$AllinOneAccessibility_data = GSDATAOTHERPATH . 'AllinOneAccessibility-settings.xml';
$site_url = $SITEURL;
$plugin_folder = basename(GSPLUGINPATH);
$plugin_url = $site_url.$plugin_folder;

# add in this plugin's language file
i18n_merge($AllinOneAccessibility) || i18n_merge($AllinOneAccessibility, 'en_US');

# register plugin
register_plugin(
	$AllinOneAccessibility,								# ID of plugin, should be filename minus php
	i18n_r($AllinOneAccessibility.'/lang_Menu_Title'), 	# Title of plugin
	'1.4',										# Version of plugin
	'Rajesh Bhimani',										# Author of plugin
	'https://www.skynettechnologies.com',				# Author URL
	i18n_r($AllinOneAccessibility.'/lang_Description'), # Plugin Description
	'plugins',										# Page type of plugin
	'allinoneaccessibility_settings'							# Function that displays content
);

# Front-End Hooks
add_action('theme-footer','allinoneaccessibility_js');

# Back-End Hooks
add_action('plugins-sidebar','createSideMenu', array($AllinOneAccessibility, i18n_r($AllinOneAccessibility.'/lang_Menu_Title')));

# ===== # ===== # ===== # =====

# ===== functions Footer =====

function allinoneaccessibility_js() {
	    echo '<script id="aioa-adawidget" src="https://www.skynettechnologies.com/accessibility/js/all-in-one-accessibility-js-widget-minify.js?aioa_reg_req=true&colorcode=&token=&position=bottom_right"></script>';
}

# ===== # ===== # ===== # =====

# ===== functions Admin =====

function allinoneaccessibility_settings() {

    $current_domain_name = $_SERVER['HTTP_HOST'];
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://ada.skynettechnologies.us/check-website',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array('domain' => $current_domain_name) //'xoopsdemo.com', 'skynettechnologies.com'
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $settingURLObject = json_decode($response);
    try{
        if(isset($settingURLObject->status) && $settingURLObject->status == 3)
        { ?>
            <div class="aioa-expire-plan-wrapper">
                <h3 style="color: #aa1111">It appears that you have already registered! Please click on the "Manage Subscription" button to renew your subscription.<br> Once your plan is renewed, please refresh the page.</h3>
                <div style="text-align: left; width:100%; padding-bottom: 10px;"><a target="_blank" class="aioa-cancel-button"  href="<?php echo $settingURLObject->settinglink;?>">Manage Subscription</a></div>
            </div>
        <?php }
        else if(isset($settingURLObject->status) && $settingURLObject->status > 0 && $settingURLObject->status < 3)
        {
            ?>
            <div class="aioa-heading-wrapper">
                <h2>Widget Preferences:</h2>
                <div style="width:100%; padding-bottom: 10px;">
                    <a target="_blank" class="aioa-cancel-button" href="<?php echo $settingURLObject->manage_domain;?>">Manage Subscription</a>
                </div>
            </div>
            <iframe id="aioamyIframe" width="100%" style=" height: calc(100vh - 150px); max-width: 1920px;" height="2900px"  src="<?php echo $settingURLObject->settinglink; ?>"></iframe>
            <?php
        }
        else{
            ?>
            <div class="aioa-new-user-wrapper">
                <iframe src="https://ada.skynettechnologies.us/trial-subscription?isframe=true&website=<?php echo $current_domain_name;?>&developer_mode=true" height="600px;" width="100%" style="    height: calc(100vh - 100px); border: none;"></iframe>
            </div>
            <?php
        }
    } catch(Exception $e){}
?>
<!-- end plugin admin -->
<?php
}?>
