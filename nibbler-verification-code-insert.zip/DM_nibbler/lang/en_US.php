<?php
/**
 * English Language File for Nibbler Verification Plugin
 *
 *
 */
 
$i18n = array (
	"NIBBLER_TITLE"=>  "Nibbler Authentication Code",
	"NIBBLER_DESC" =>  "Please enter your Nibbler Verification Code",
	"NIBBLER_SUCCESS" =>  "Settings Updated",
	"NIBBLER_ERROR" =>  "Unable to update Settings",
	"NIBBLER_SAVE" =>  "Save Settings"
);