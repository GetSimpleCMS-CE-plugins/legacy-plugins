<?php
  global $SITEURL;
?>
  <script type="text/javascript" src="<?php echo $SITEURL; ?>plugins/hitcount/js/jquery-ui-1.8.16.custom.min.js"></script>
  <script type="text/javascript" src="<?php echo $SITEURL; ?>plugins/hitcount/js/jquery.jqplot.min.js"></script>
  <script type="text/javascript" src="<?php echo $SITEURL; ?>plugins/hitcount/js/jqplot.dateAxisRenderer.min.js"></script>
  <script type="text/javascript" src="<?php echo $SITEURL; ?>plugins/hitcount/js/jqplot.highlighter.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo $SITEURL; ?>plugins/hitcount/css/jquery-ui-1.8.16.custom.css"></link>
  <link rel="stylesheet" type="text/css" href="<?php echo $SITEURL; ?>plugins/hitcount/css/jquery.jqplot.min.css"></link>
  <style type="text/css">
    .wrapper #chart table { width:auto; }
    .wrapper #chart table tr { border: 0 none; }
    .wrapper #chart table td { border: 0 none; line-height: auto; padding:1px 4px; vertical-align:middle; }
    #ui-datepicker-div { z-index:10 !important; }
  </style>
  