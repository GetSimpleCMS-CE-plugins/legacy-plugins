<?php

    /*
      Plugin Name: TIDEengine News/Blog Manager
      Description: News/Blog Management System.
      Version: 2.0
      Author: Goran Bogdanovic
      Author URI: http://tidengine.info
     */


#get correct id for plugin
    $thisfile = basename(__FILE__, '.php');

#register plugin
    register_plugin(
        $thisfile, 'TIDEngine News/Blog Manager', '2.0', 'Goran Bogdanovic', 'http://tidengine.info', 'News/Blog Management System.', $thisfile, 'tide_news_router'
    );

#include helper functions
    include_once(GSPLUGINPATH . 'TIDEGetSimple/tide_news_helper.php');

#Set internationalzation
    tide_international_set('tide_news', 'en_US');

# hooks
#Create Main navigation item  
    ob_start();
    add_action('nav-tab', 'createNavTab', array('tide_news', 'tide_news', i18n_r('tide_news/TAB_TITLE'), ''));
    ob_flush();
 //add_action('nav-tab', 'tide_init_navigation', array('N', 'tide_news', i18n_r('tide_news/TAB_TITLE')));
#Add scripts 
    add_action('theme-header', 'tide_theme_header_scripts');
    add_action('header', 'tide_admin_header_scripts');
    add_action('theme-footer', 'tide_theme_footer_scripts');
    add_action('footer', 'tide_admin_footer_scripts');

#add plugin links  MENU_RSS
    $navigation_list = array(
        'tide_create_news' => array('menu_text' => i18n_r('tide_news/MENU_CREATE')),
        'tide_news_overview' => array('menu_text' => i18n_r('tide_news/MENU_OVERVIEW'),
            'children' => array('tide_edit_news')
        ),
        'tide_category' => array('menu_text' => i18n_r('tide_news/MENU_CREATE_CAT'),
            'children' => array('tide_create_category', 'tide_category_list', 'tide_category_edit')
        ),
        'tide_rss_management' => array('menu_text' => i18n_r('tide_news/MENU_RSS'),
            'children' => array('tide_rss_manual_create')
        ),
        'tide_template_editor' => array('menu_text' => i18n_r('tide_news/MENU_EDITOR')),
        'tide_news_settings' => array('menu_text' => i18n_r('tide_news/MENU_SETTINGS'),
            'children' => array('tidenews_general', 'tidenews_news_menu', 'tidenews_tags', 'tidenews_rss_feed', 'tidenews_ckeditor', 'tidenews_share')
        ),
        'tide_help' => array('menu_text' => i18n_r('tide_news/MENU_HELP')),
    );

    #Add Modified Slidebar Menu
    add_action($thisfile . '-sidebar', 'tide_admin_menu', array($thisfile, $navigation_list));

    #Example Tags Menu for Tags settings
    if (isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_tags') {
        add_action($thisfile . '-sidebar', 'tide_tags_example', array(''));
    }


#definitions 
    $constants = array(
        'PLUGIN_PATH' => GSPLUGINPATH . 'tide_news/',
        'NEWS_DIR' => GSDATAPATH . 'tide_news/',
        'NEWS_RSS_DIR' => GSDATAOTHERPATH . 'tide_news_feed/',
        'TIDE_MASTER_DIR' => GSPLUGINPATH . 'TIDEGetSimple/',
        'TIDE_NEWS_TEMPLATES' => GSPLUGINPATH . 'tide_news/templates/',
        'NEWS_RSS_LINK' => GSDATAOTHERPATH . 'news_feed/feed.xml',
        'GENERAL_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/general_settings.xml',
        'TAGS_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/tags_settings.xml',
        'MENU_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/news_menu_settings.xml',
        'CKE_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/cke_settings.xml',
        'RSS_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/rss_settings.xml',
        'SHARE_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/share_settings.xml',
        'STORAGE_SETTINGS' => GSPLUGINPATH . 'tide_news/settings/storage.xml',
        'SITE_URL' => $SITEURL,
        'PRETTY_URLS' => $PRETTYURLS,
        'SITE_NAME' => $SITENAME
    );

#Chesk existance and define if not exists 
    check_constants($constants);

#Global Settings
    $general_settings = xml_content_array(GENERAL_SETTINGS, false);
    $tags_settings = xml_content_array(TAGS_SETTINGS, false);
    $menu_settings = xml_content_array(MENU_SETTINGS, false);
    $rss_settings = xml_content_array(RSS_SETTINGS, false);
    $share_settings = xml_content_array(SHARE_SETTINGS, false);
    $storage = xml_content_array(STORAGE_SETTINGS, false);
    $cfk_settings = xml_content_array(CKE_SETTINGS, false);

    if ($storage[0] !== 'undefined') {
        add_action('index-pretemplate', 'tide_set_headers');
    }

    #activate filter
    if (!function_exists('eval_php_in_content')) {
        add_filter('content', 'tide_evaluate_php');
    }

    add_filter('page-content', 'tide_shortcodes');

############################ JAVASCRIPT CSS INCLUDE FUNCTIONS #######################################################################################
#Include External scripts: Admin-header/footer, Theme-header/footer
#-------------------------------- DONE------------------------------------

    function tide_admin_header_scripts() {

        $script = '';
        if (isset($_GET['id']) && $_GET['id'] == 'tide_news') {
            $js_paths = array();
            $css_paths = array();

            if (!empty($_GET['tide_news_overview']) || (!empty($_GET['subpage']) && $_GET['subpage'] == 'tide_category_list')) {
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_news_delete.js';
            }

            if (isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_rss_feed') {
                $js_paths[] = 'template/js/uploadify/jquery.uploadify.js?v=3.0';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_news_rss.js';
            }

            if ((isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_general') || (isset($_GET['tide_news_settings']) && !isset($_GET['subpage']))) {

                $css_paths[] = SITE_URL . 'plugins/tide_news/css/keyboardstyle.css';

                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery.keypad.min.js';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/date_keyboard.js';
            }
            if (isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_share') {
                $js_paths[] = SITE_URL . 'plugins/tide_news/js//tide_share.js';
            }

            if (isset($_GET['tide_rss_management']) && isset($_GET['category'])) {
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery-ui-1.8.21.custom.min.js';
                $css_paths[] = SITE_URL . 'plugins/tide_news/css/jquery-ui-1.8.21.custom.css';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_rss.js';
            }
            if (isset($_GET['tide_help'])) {
                $js_paths[] = SITE_URL . 'plugins/tide_news/highlight/scripts/shCore.js';
                $js_paths[] = SITE_URL . 'plugins/tide_news/highlight/scripts/shAutoloader.js';

                $css_paths[] = SITE_URL . 'plugins/tide_news/highlight/styles/shCore.css';
                $css_paths[] = SITE_URL . 'plugins/tide_news/highlight/styles/shCoreDefault.css';
            }
            if (isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_tags') {
                global $tags_settings;
                $js_paths[] = SITE_URL . 'plugins/TIDEGetSimple/fontpicker/js/jquery.fontselect.min.js';
                $js_paths[] = SITE_URL . 'plugins/TIDEGetSimple/colorpicker/js/colorpicker.js';
                $js_paths[] = SITE_URL . 'plugins/TIDEGetSimple/fontresize/js/jquery.jfontsize-1.0.js';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_news_tags.js';
                $css_paths[] = SITE_URL . 'plugins/TIDEGetSimple/colorpicker/css/colorpicker.css';
                $css_paths[] = SITE_URL . 'plugins/TIDEGetSimple/fontpicker/css/fontselect.css';
                $css_paths[] = SITE_URL . 'plugins/TIDEGetSimple/fontresize/css/jfontsize.css';
                $css_paths[] = 'http://fonts.googleapis.com/css?family=' . $tags_settings['tags_font'] . '';
            }
            if (isset($_GET['subpage']) && $_GET['subpage'] == 'tidenews_ckeditor') {
                $css_paths[] = SITE_URL . 'plugins/tide_news/css/jquery-ui-1.8.21.custom.css';
                $css_paths[] = SITE_URL . 'admin/template/js/codemirror/lib/codemirror.css?v=screen';
                $css_paths[] = SITE_URL . 'admin/template/js/codemirror/theme/default.css?v=screen';

                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery-ui-1.8.21.custom.min.js';
                $js_paths[] = SITE_URL . 'admin/template/js/codemirror/lib/codemirror-compressed.js?v=0.2.0';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tidenews_ckeditor.js';
            }

            if (isset($_GET['tide_template_editor'])) {
                $path_file = urlencode(PLUGIN_PATH);
                $css_paths[] = SITE_URL . 'admin/template/js/codemirror/lib/codemirror.css?v=screen';
                $css_paths[] = SITE_URL . 'admin/template/js/codemirror/theme/default.css?v=screen';
                $css_paths[] = SITE_URL . 'plugins/tide_news/css/jquery-ui-1.8.21.custom.css';

                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery-ui-1.8.21.custom.min.js';
                $js_paths[] = SITE_URL . 'admin/template/js/codemirror/lib/codemirror-compressed.js?v=0.2.0';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_editor.js';

                echo '<script type="text/javascript">                   
jQuery(document).ready(function() {
    $(".submit").click(function(event) {
        event.preventDefault();
         getClicked = $(this).attr("id");
        if(getClicked == "edit_file"){    
            inputs = $("select#tide_files").val(); 
            inputs = "' . $path_file . '" + inputs;
            if(inputs == $("#edited_file_path").val()){
                alert("' . i18n_r('tide_news/FILE_DOUBLE') . '");
                    return false;
            }
            action_type = "open";
            fileContent = $("#editor_textarea").val();
        }else if(getClicked == "save_file"){
                if( !$(".CodeMirror").length){
                alert("' . i18n_r('tide_news/FILE_EMPTY') . '");
                return false;
            }
              fileContent = editor.getValue();
              action_type = "save";
        }          
       
       var edited_file = $("#edited_file_path").val();        
        $.getJSON("../plugins/tide_news/templates/editor_req.php",  { 
            file_path: inputs, 
            action: action_type, 
            fileData: fileContent, 
            editedFile: edited_file},
       function(data){tideData(data);});
     });
});  
</script>';
            }

            if (isset($_GET['tide_create_news']) || isset($_GET['tide_edit_news'])) {
                $js_paths[] = SITE_URL . 'plugins/TIDEGetSimple/ckeditor/ckeditor.js';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery-ui-1.8.21.custom.min.js';
                $js_paths[] = SITE_URL . 'plugins/tide_news/js/jquery-ui-timepicker-addon.js';
                $css_paths[] = SITE_URL . 'plugins/tide_news/css/jquery-ui-1.8.21.custom.css';
                $css_paths[] = SITE_URL . 'plugins/TIDEGetSimple/tags/css/tagit-dark-grey.css';
                $js_paths[] = SITE_URL . 'plugins/TIDEGetSimple/tags/js/tagit.js';

                $d_format = tide_date_format();
                $t_format = tide_time_format();
                $script = '<script type="text/javascript">                   
jQuery(document).ready(function() {
$( "#date" ).datepicker({ dateFormat: "' . $d_format . '"});
$("#time").timepicker({ timeFormat: "' . $t_format . '", showSecond: true });  

});
jQuery(document).ready(function() {
 $("#tags").tagit({select:true, sortable:true});
})
</script>';
            }

            $js_paths[] = SITE_URL . 'plugins/tide_news/js/tide_master.js';
            $css_paths[] = SITE_URL . 'plugins/tide_news/css/tide_news_admin.css';

            echo init_scripts($css_paths, 'css');
            echo init_scripts($js_paths, 'js');
            echo $script;
        }
    }

#-------------------------------- DONE------------------------------------

    function tide_admin_footer_scripts() {
        if ($_GET['id'] == 'tide_news') {
            if (isset($_GET['tide_help'])) {
                echo "<script type='text/javascript'>
    var baseSyntaxHighlighterScriptsPath = '" . SITE_URL . "plugins/tide_news/highlight/scripts/'    
    function getSyntaxHighlighterScriptPath(name){
        return name.replace('@', baseSyntaxHighlighterScriptsPath); 
    }
    SyntaxHighlighter.autoloader(
        [ 'applescript', getSyntaxHighlighterScriptPath('@shBrushAppleScript.js') ],
        [ 'actionscript3', 'as3', getSyntaxHighlighterScriptPath('@shBrushAS3.js') ],
        [ 'bash', 'shell', getSyntaxHighlighterScriptPath('@shBrushBash.js') ],
        [ 'coldfusion', 'cf', getSyntaxHighlighterScriptPath('@shBrushColdFusion.js') ],
        [ 'cpp', 'c', getSyntaxHighlighterScriptPath('@shBrushCpp.js') ],
        [ 'c#', 'c-sharp', 'csharp', getSyntaxHighlighterScriptPath('@shBrushCSharp.js') ],
        [ 'css', getSyntaxHighlighterScriptPath('@shBrushCss.js') ],
        [ 'diff', 'patch', 'pas', getSyntaxHighlighterScriptPath('@shBrushDiff.js') ],
        [ 'erl', 'erlang', getSyntaxHighlighterScriptPath('@shBrushErlang.js') ],
        [ 'groovy', getSyntaxHighlighterScriptPath('@shBrushGroovy.js') ],
        [ 'java', getSyntaxHighlighterScriptPath('@shBrushJava.js') ],
        [ 'jfx', 'javafx', getSyntaxHighlighterScriptPath('@shBrushJavaFX.js') ],
        [ 'js', 'javascript', 'jscript', getSyntaxHighlighterScriptPath('@shBrushJScript.js') ],
        [ 'perl', 'pl', getSyntaxHighlighterScriptPath('@shBrushPerl.js') ],
        [ 'php', getSyntaxHighlighterScriptPath('@shBrushPhp.js') ],
        [ 'text', 'plain', getSyntaxHighlighterScriptPath('@shBrushPlain.js') ],
        [ 'py', 'python', getSyntaxHighlighterScriptPath('@shBrushPython.js') ],
        [ 'ruby', 'rails', 'ror', 'rb', getSyntaxHighlighterScriptPath('@shBrushRuby.js') ],
        [ 'sass', 'scss', getSyntaxHighlighterScriptPath('@shBrushSass.js') ],
        [ 'scala', getSyntaxHighlighterScriptPath('@shBrushScala.js') ],
        [ 'sql', getSyntaxHighlighterScriptPath('@shBrushSql.js') ],
        [ 'vb', 'vbnet', getSyntaxHighlighterScriptPath('@shBrushVb.js') ],
        [ 'xml', 'xslt', 'html', 'htm', getSyntaxHighlighterScriptPath('@shBrushXml.js') ]
    );
    SyntaxHighlighter.all();
</script>";
            }
        }
    }

#-------------------------------- DONE------------------------------------

    function tide_theme_header_scripts() {

        global $cfk_settings;
        global $tags_settings;

        $js_paths = array();
        $css_paths = array();

        $css_paths[] = SITE_URL . 'plugins/tide_news/css/tide_news.css';
        if ($tags_settings['tags_menu_status'] == 'checked' && !empty($tags_settings['tags_font'])) {
            $css_paths[] = 'http://fonts.googleapis.com/css?family=' . $tags_settings['tags_font'] . '';
        }
        if ($cfk_settings['highlight_styles'] !== 'not') {
            $js_paths[] = SITE_URL . 'plugins/tide_news/highlight/scripts/shCore.js';
            $js_paths[] = SITE_URL . 'plugins/tide_news/highlight/scripts/shAutoloader.js';

            $css_paths[] = SITE_URL . 'plugins/tide_news/highlight/styles/shCore.css';
            $css_paths[] = SITE_URL . 'plugins/tide_news/highlight/styles/' . $cfk_settings["highlight_styles"] . '.css';
        }

        echo init_scripts($css_paths, 'css');
        echo init_scripts($js_paths, 'js');
    }

#-------------------------------- DONE------------------------------------

    function tide_theme_footer_scripts() {
        global $general_settings;
        global $share_settings;
        global $cfk_settings;
        if ($share_settings['use_share_this'] = 'checked') {
            echo '<script type="text/javascript">var switchTo5x=true;</script>
                   <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
                   <script type="text/javascript">stLight.options({publisher: "' . $share_settings['sharethis_key'] . '"}); </script>';
        }
        if ($share_settings['use_addthis'] = 'checked') {///addthis_bar>addthis_key
            if ($share_settings['addthis_bar'] = 'checked') {
                echo '<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>';
            }
            echo '<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=' . $share_settings['addthis_key'] . '"></script>';
        }
        if ($cfk_settings['highlight_styles'] !== 'not') {
            echo "<script type='text/javascript'>
    var baseSyntaxHighlighterScriptsPath = '" . SITE_URL . "plugins/tide_news/highlight/scripts/'    
    function getSyntaxHighlighterScriptPath(name){
        return name.replace('@', baseSyntaxHighlighterScriptsPath); 
    }
    SyntaxHighlighter.autoloader(
        [ 'applescript', getSyntaxHighlighterScriptPath('@shBrushAppleScript.js') ],
        [ 'actionscript3', 'as3', getSyntaxHighlighterScriptPath('@shBrushAS3.js') ],
        [ 'bash', 'shell', getSyntaxHighlighterScriptPath('@shBrushBash.js') ],
        [ 'coldfusion', 'cf', getSyntaxHighlighterScriptPath('@shBrushColdFusion.js') ],
        [ 'cpp', 'c', getSyntaxHighlighterScriptPath('@shBrushCpp.js') ],
        [ 'c#', 'c-sharp', 'csharp', getSyntaxHighlighterScriptPath('@shBrushCSharp.js') ],
        [ 'css', getSyntaxHighlighterScriptPath('@shBrushCss.js') ],
        [ 'diff', 'patch', 'pas', getSyntaxHighlighterScriptPath('@shBrushDiff.js') ],
        [ 'erl', 'erlang', getSyntaxHighlighterScriptPath('@shBrushErlang.js') ],
        [ 'groovy', getSyntaxHighlighterScriptPath('@shBrushGroovy.js') ],
        [ 'java', getSyntaxHighlighterScriptPath('@shBrushJava.js') ],
        [ 'jfx', 'javafx', getSyntaxHighlighterScriptPath('@shBrushJavaFX.js') ],
        [ 'js', 'javascript', 'jscript', getSyntaxHighlighterScriptPath('@shBrushJScript.js') ],
        [ 'perl', 'pl', getSyntaxHighlighterScriptPath('@shBrushPerl.js') ],
        [ 'php', getSyntaxHighlighterScriptPath('@shBrushPhp.js') ],
        [ 'text', 'plain', getSyntaxHighlighterScriptPath('@shBrushPlain.js') ],
        [ 'py', 'python', getSyntaxHighlighterScriptPath('@shBrushPython.js') ],
        [ 'ruby', 'rails', 'ror', 'rb', getSyntaxHighlighterScriptPath('@shBrushRuby.js') ],
        [ 'sass', 'scss', getSyntaxHighlighterScriptPath('@shBrushSass.js') ],
        [ 'scala', getSyntaxHighlighterScriptPath('@shBrushScala.js') ],
        [ 'sql', getSyntaxHighlighterScriptPath('@shBrushSql.js') ],
        [ 'vb', 'vbnet', getSyntaxHighlighterScriptPath('@shBrushVb.js') ],
        [ 'xml', 'xslt', 'html', 'htm', getSyntaxHighlighterScriptPath('@shBrushXml.js') ]
    );
    SyntaxHighlighter.all();
</script>";
        }
    }

############################ JAVASCRIPT CSS INCLUDE FUNCTIONS END #######################################################################################
#-------------------------------- DONE ------------------------------------      
#Plugin Home Page
#-------------------------------- DONE ------------------------------------  

    function tide_get_data() {
        $category_index = NEWS_DIR . 'category_index.xml';
        $category = xml_content_array($category_index);

        $data = '<div class="tide_category_info">';

        if ($category['nodes'] > 0) {

            $category_data = category_array($category);
            $data .= '<div class="tide_category_info_item">
                    <div class="tide_category_info_category_t">' . i18n_r('tide_news/INFO_CATEGORY') . '</div>
                    <div class="tide_category_info_number_t">' . i18n_r('tide_news/INFO_CATEGORY_NEWS') . '</div>
                    </div>
                    <div class="clearfix borders"></div>';
            foreach ($category_data as $slug => $title) {

                $n_path = NEWS_DIR . 'category/' . $slug . '.xml';
                $nodes = tide_count_nodes($n_path, 'item');

                $data .= '<div class="tide_category_info_item">
                    <div class="tide_category_info_category">' . $title . '</div>
                    <div class="tide_category_info_number">' . $nodes . '</div>
                    </div><div class="clearfix borders"></div>';
            }
        } else {
            $data .= '<div class="tide_category_info_item"><h2>' . i18n_r('tide_news/INFO_NO_CATEGORIES') . '</h2></div>';
        }
        $data .= '</div>';
        return $data;
    }

#-------------------------------- CHECK------------------------------------      
#Plugin Installation
#-------------------------------- CHECK------------------------------------    

    function tide_news() {
        set_time_limit(0);
        global $storage;

        $messages = array();
        $template = '';

        if (!isset($_POST['storage_type'])) {

            $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_start.tpl');

            if ($storage[0] == 'undefined') {
                $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_form.tpl');
            } else {
                $data['info'] = tide_get_data();
                $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_finish_success.tpl', $data);
            }
        } else {

            $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_start.tpl');

            $rest['news_dir'] = tide_check_file(NEWS_DIR);
            $rest['rss_dir'] = tide_check_file(NEWS_RSS_DIR);
            $backup_date = date("d-M-Y-H-i-s", time());
            ob_implicit_flush(true);

            if ($rest['news_dir']) {
                $res[] = create_directory(NEWS_DIR, 'deny');
                $res[] = create_directory(NEWS_DIR . 'archives/', 'deny');
                $res[] = create_directory(NEWS_DIR . 'category/', 'deny');
                $res[] = create_directory(NEWS_DIR . 'news/', 'deny');
                $res[] = create_directory(NEWS_DIR . 'tags/', 'deny');

                $blog_data['item'] = array('category_title' => 'Blog', 'category_slug' => 'blog', 'keywords' => 'Site Blog', 'pages' => 'blog', 'category_visibility' => 'N', 'metad' => 'Site Blog');
                $res[] = tide_xml_file($blog_data, NEWS_DIR . 'category_index.xml', 'create', array('id' => 'blog'), false, false);


                $res[] = tide_xml_file('', NEWS_DIR . 'news/news_index.xml', 'create');
                $r[] = $create_news = tide_check($res);

                echo get_messages($create_news, i18n_r('tide_news/PLUGINCREATE_SUCC'), i18n_r('tide_news/PLUGINCREATE_FAULT'));
            } else {
                echo get_messages(false, '', i18n_r('tide_news/PLUGINCREATE_EXIST'));
            }
            ob_end_flush();
            sleep(1);

            if ($rest['rss_dir']) {
                $r[] = $res['create_rss'] = create_directory(NEWS_RSS_DIR, 'deny');
                echo get_messages($res['create_rss'], i18n_r('tide_news/RSSCREATE_SUCC'), i18n_r('tide_news/RSSCREATE_FAULT'));
            } else {
                echo get_messages(false, '', i18n_r('tide_news/RSSCREATE_EXIST'));
            }

            sleep(1);

            $htaccess_file_path = GSROOTPATH . '.htaccess';
            $file_contents = file_get_contents($htaccess_file_path);

            $r[] = $res['backup_htaccess'] = file_put_contents(GSROOTPATH . 'bak.htaccess-' . $backup_date, $file_contents);

            echo get_messages($res['backup_htaccess'], i18n_r('tide_news/HTTACESS_BACKUP_SUCCESS'), i18n_r('tide_news/HTTACESS_BACKUP_FAULT'));

            sleep(1);

            $rewrite_add = "
                
#######################################################################################################               
#TIDEngine News Plugin
#######################################################################################################

#TIDEngine RSS Feed
RewriteRule ^rss/(.*)$ ^index.php?id=rss&page=$1 [L]

#TIDEngine Tags
RewriteRule ^tags/([a-zA-Z0-9_-]+)$ ^index.php?id=tags&tide_tags=$1 [L]
RewriteRule ^tags/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)$ ^index.php?id=tags&tide_tags=$1&category=$2 [L]
                                
#TIDEngine Archive
RewriteRule ^archive/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)$ ^index.php?id=archive&tide_archive=$1&category=$2 [L]

#TIDEngine News
RewriteRule ^news/([a-zA-Z0-9_-]+)/page/([a-zA-Z0-9_-]+) ^index.php?id=$1&tide_show_news&page_number=$2 [L]
RewriteRule ^news/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)$ ^index.php?id=$1&tide_show_news&category=$2&news_current=$3 [L]
RewriteRule ^news/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)$ ^index.php?id=$1&tide_show_news&category=$3&news_current=$4&page_number=$2 [L]

#######################################################################################################
#TIDEngine News Plugin
#######################################################################################################

";

            preg_match('/#TIDEngine News Plugin/us', $file_contents, $matches);

            if (!$matches) {

                $lines = array();
                foreach (file($htaccess_file_path) as $line) {
                    if (preg_match('/RewriteBase \//', $line)) {
                        $line = $line . $rewrite_add;
                    }
                    array_push($lines, $line);
                }
                $r[] = $res['modify_htaccess'] = file_put_contents($htaccess_file_path, $lines);
                echo get_messages($res['modify_htaccess'], i18n_r('tide_news/HTTACESS_SUCCESS'), i18n_r('tide_news/HTTACESS_FAULT'));
            } else {
                echo get_messages(false, '', i18n_r('tide_news/HTTACESS_EXISTS'));
            }
             sleep(1);
            
            $r[] = $ind[] = rename(GSROOTPATH . 'index.php',  GSROOTPATH . 'index.php.bak');
            $r[] = $ind[] = smartCopy(PLUGIN_PATH  . 'files/index.php', GSROOTPATH);
            $index = tide_check($ind);
            echo get_messages($index, i18n_r('tide_news/INDEX_SUCCESS'), i18n_r('tide_news/INDEX_FAULT'));
            
            sleep(1);

            $pages['rss'] = array('pubDate' => date('r'),
                'title' => 'RSS',
                'url' => 'rss',
                'meta' => '',
                'metad' => '',
                'menu' => 'RSS',
                'menuOrder' => '0',
                'menuStatus' => '',
                'template' => 'rss.php',
                'parent' => '',
                'content' => '',
                'private' => '',
                'author' => 'TIDEngine');

            $pages['archive'] = array('pubDate' => date('r'),
                'title' => 'Archive',
                'url' => 'archive',
                'meta' => 'Archive',
                'metad' => 'Archive data',
                'menu' => 'archive',
                'menuOrder' => '1',
                'menuStatus' => 'Y',
                'template' => 'template.php',
                'parent' => '',
                'content' => '&lt;?php tide_archive($_GET); ?&gt;',
                'private' => '',
                'author' => 'TIDEngine');

            $pages['tags'] = array('pubDate' => date('r'),
                'title' => 'Tags',
                'url' => 'tags',
                'meta' => 'Tags',
                'metad' => 'Tags',
                'menu' => 'tags',
                'menuOrder' => '2',
                'menuStatus' => 'Y',
                'template' => 'template.php',
                'parent' => '',
                'content' => '&lt;?php tide_tags($_GET); ?&gt;',
                'private' => '',
                'author' => 'TIDEngine');


            $pages['latest-news'] = array('pubDate' => date('r'),
                'title' => 'Latest News',
                'url' => 'latest-news',
                'meta' => 'Latest News',
                'metad' => 'Latest News',
                'menu' => 'latest news',
                'menuOrder' => '3',
                'menuStatus' => 'Y',
                'template' => 'template.php',
                'parent' => '',
                'content' => '&lt;?php tide_show_news("master"); ?&gt;',
                'private' => '',
                'author' => 'TIDEngine');


            foreach ($pages as $key => $val) {
                $path = GSDATAPAGESPATH . $key . '.xml';
                if (file_exists($path)) {
                    $create[] = rename($path, $path . '.' . $backup_date);
                }
                $create[] = tide_xml_file($val, $path, 'create', false, false, 'item', true, true);
            }

            $r[] = $backup_pages = tide_check($create);
            echo get_messages($backup_pages, i18n_r('tide_news/PAGES_BACKUP_SUCCESS'), i18n_r('tide_news/PAGES_BACKUP_FAULT'));

            sleep(1);

            $r[] = $create_pages = tide_check($create);

            echo get_messages($create_pages, i18n_r('tide_news/PAGES_CREATE_SUCC'), i18n_r('tide_news/PAGES_CREATE_FAIL'));

            sleep(1);
            $rss_template = '<?php 
if(!defined("IN_GS")){ die("you cannot load this page directly."); }

	header("Content-Type: application/rss+xml");
	header("Content-Type: application/xhtml+xml");
	header("Content-Type: application/rss+xml");
	header("Content-Type: text/xml"); 
	tide_rss_feed($_GET["page"]);';

            $themes = find_themes();

            foreach ($themes as $key => $value) {

                if (file_exists($value . '/rss.php')) {
                    $rest[] = rename($value . '/rss.php', $value . '/rss.php.' . $backup_date);
                }

                $rest[] = file_put_contents($value . '/rss.php', $rss_template);
            }

            $r[] = $create_rss_page = tide_check($rest);

            echo get_messages($create_rss_page, i18n_r('tide_news/PLUGIN_THEME_SUCC'), i18n_r('tide_news/PLUGIN_THEME_FAIL'));

            $final = tide_check($r);

            if ($final) {
                $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_finish_success.tpl');
                $template .= '<div style="float: right; margin: 20px;"><a id="tide_admin_install_finish_btn" href="load.php?id=tide_news&tide_news_settings&subpage=tidenews_general">' . i18n_r('tide_news/PLUGIN_INSTALL_BTN_START') . ' ' . i18n_r('tide_news/SETTINGS') . '</a></div>';
            } else {
                $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_finish_fail.tpl');
            }

            $last_check = tide_check($r);

            if ($last_check) {
                $data['item'] = 'installed';
                $res['storage'] = tide_xml_file($data, STORAGE_SETTINGS, 'create');

                echo get_messages($res['storage'], i18n_r('tide_news/STORAGE_UPDATE_SUCC'), i18n_r('tide_news/STORAGE_UPDATE_FAULT'));
            }
        }


        $template .= load_template(TIDE_NEWS_TEMPLATES . 'backend/install_end.tpl');

        echo $template;
    }

#-------------------------------- DONE------------------------------------
#Plugin routing 
#-------------------------------- DONE------------------------------------

    function tide_news_router() {

        if (isset($_GET['tide_edit_news'])) {
            tide_edit_news();
        } elseif (isset($_GET['tide_delete_news'])) {
            tide_delete_news();
        } elseif (isset($_GET['tide_create_news'])) {
            tide_create_news();
        } elseif (isset($_GET['tide_news_settings'])) {
            tide_news_settings();
        } elseif (isset($_GET['tide_settings_save'])) {
            tide_settings_save();
        } elseif (isset($_GET['tide_news_overview'])) {
            tide_news_overview();
        } elseif (isset($_GET['tide_gsconfig'])) {
            tide_gsconfig();
        } elseif (isset($_GET['tide_rss_management'])) {
            tide_rss_management();
        } elseif (isset($_GET['tide_rss_manual'])) {
            tide_rss_manual();
        } elseif (isset($_GET['tide_news_help'])) {
            tide_news_help();
        } elseif (isset($_GET['tide_template_editor'])) {
            tide_template_editor();
        } elseif (isset($_GET['tide_category'])) {
            tide_category();
        } elseif (isset($_GET['tide_archive'])) {
            tide_archive();
        } elseif (isset($_GET['tide_tags'])) {
            tide_tags();
        } elseif (isset($_GET['tide_help'])) {
            tide_help();
        } else {
            tide_news();
        }
    }

############################ NEWS FUNCTIONS #######################################################################################
#-------------------------------- DONE------------------------------------
#Show existing pages and news  
#-------------------------------- DONE------------------------------------

    function tide_news_overview() {

        $category_index = NEWS_DIR . 'category_index.xml';
        $categorys = xml_content_array($category_index);
        if ($categorys['nodes'] == 0) {
            $category_data = 0;
        } else {
            $category_data = category_array($categorys);
        }

        if (empty($_GET['tide_news_overview'])) {
            //@TODO - dodati navigaciju kada ma vise od 20 kategorija
            $text = '<div class="tide_logo_admin"><img src="' . SITE_URL . 'plugins/TIDEGetSimple/images/TIDEngine.ico" /></div>
                <h3 class="tide_title_admin">' . i18n_r('tide_news/NEWS_OVERVIEW') . '</h3>           
                <table class="highlight" id="category_list">
                    <tr style="background-color: #ccc">
                        <th style="width: 80%">' . i18n_r('tide_news/NEWS_CATEGORY') . '</th>
                        <th style="text-align: right; width: 200px;">' . i18n_r('tide_news/NEWS_P_NEWS') . '</th>
                    </tr><tr>
                        <td colspan="2"></td></tr>';
            $ra = 0;
            if ($category_data > 0) {

                $category_data = category_array($categorys);

                foreach ($category_data as $slug => $title) {

                    $n_path = NEWS_DIR . 'category/' . $slug . '.xml';

                    $nodes = tide_count_nodes($n_path, 'item');

                    if ($nodes > 0) {
                        $text .= '<tr>  
                            <td class="pagetitle" ><a href="load.php?id=tide_news&amp;tide_news_overview=' . $slug . '&amp;c_title=' . urlencode($title) . '">' . $title . '</a></td>
                            <td class="delete"  style="text-align:center">' . $nodes . '</td>
                        </tr>';
                        $ra++;
                    }
                }
            }
            if ($ra == 0) {

                $text .= '<tr><td colspan="2"><h2>' . i18n_r('tide_news/NO_NEWS') . '</h2></td></tr>';
            }
            $text .= '</table>';
        } else {
            if (isset($_GET['update'])) {
                echo get_messages(true, i18n_r('tide_news/NEWS_UPDATE_SUCC'), '');
            }
            global $general_settings;

            $news = NEWS_DIR . 'category/' . $_GET['tide_news_overview'] . '.xml';
            $news_items = xml_content_array($news, true);
            $news_number = $news_items['nodes'];
            $data = $news_items['data'];

            $category = $_GET['tide_news_overview'];

            $text = '<div class="tide_logo_admin"><img src="' . SITE_URL . 'plugins/TIDEGetSimple/images/TIDEngine.ico" /></div>
                <h3 class="tide_title_admin">' . i18n_r('tide_news/NEWS_MANAGEMENT') . ' <i style="color: #999">' . urldecode($_GET['c_title']) . ' </i> </h3>
            <form method="post" name="multi_delete"  id="multi_delete" >
                <table class="highlight" id="news_list">
                    <tr style="background-color: #ccc">
                        <th>' . i18n_r('tide_news/NEWS_TABLE_TITLE') . '</th>
                        <th style="width: 150px;">' . i18n_r('tide_news/NEWS_TABLE_DATE') . '</th>
                        <th>' . i18n_r('tide_news/NEWS_PREV') . '</th>
                        <th>' . i18n_r('tide_news/NEWS_DEL') . '</th>
                        <th>   <input type="checkbox" id="selectall"/></th>
                    </tr><tr>
                        <td colspan="5"></td></tr>';

            if ($news_number > 0) {

                $start = 0;
                $times_loop = 20;
                $show_per_page = 20;

                if (!empty($_GET['page_number'])) {

                    if ($_GET['page_number'] > 1) {
                        $start = ($_GET['page_number'] - 1) * $show_per_page;
                    }

                    $times_loop = $times_loop + $start;

                    if ($times_loop > $news_number) {
                        $times_loop = $news_number;
                    }
                    $current_page = $_GET['page_number'];
                } else {
                    if ($news_number <= $times_loop) {
                        $times_loop = $news_number;
                    }
                    $current_page = 1;
                }

                for ($i = $start; $i < $times_loop; $i++) {

                    $reformat = date_format_convert($general_settings['date_format'], true);
                    $patern = '/[^F M m Y y]/iu';
                    $archive_date = trim(preg_replace($patern, '', "'.$reformat.'"));
                    $archive_date = str_replace(' ', '-', $archive_date);
                    $archive_date = date($archive_date, strtotime($data[$i]['date']));

                    if (strlen($data[$i]['title']) > 60) {
                        $data[$i]['title'] = substr($data[$i]['title'], 0, 60);
                    }

                    $category_index = NEWS_DIR . 'category_index.xml';
                    $cat = tide_xml_search_value($category_index, 'category_slug', $category);
                    $cat = tide_xml_decode($cat);
                    $preview_link = url_builder($cat['pages'], $category, $data[$i]['@attributes']['id']);

                    // $preview_link = SITE_URL . 'index.php?id=' . $cat['pages'] . '&amp;tide_show_news&amp;category=' . $category . '&amp;news_current=' . $data[$i]['@attributes']['id'] . '';

                    $text .= '                    
                        <tr>
                        <td class="pagetitle" style="width: 60%">
                            <a href="load.php?id=tide_news&amp;tide_edit_news=' . $data[$i]['@attributes']['id'] . '&amp;category=' . $category . '&amp;c_title=' . urlencode($_GET['c_title']) . '" title="' . i18n_r('tide_news/NEWS_EDIT') . ' ' . $data[$i]['title'] . '">
                                ' . $data[$i]['title'] . '
                            </a>
                        </td>
                        <td style="width: 150px;">
                            <span>' . $data[$i]['date'] . '</span>
                        </td>
                        <td class="secondarylink"><a href="' . $preview_link . '" target="_blank" title="View Page:  ' . $data[$i]['title'] . '">#</a></td> 
                            
                        <td class="delete">
                            <a href="load.php?id=tide_news&amp;tide_delete_news=' . $data[$i]['@attributes']['id'] . '&amp;category=' . $_GET['tide_news_overview'] . '&amp;date=' . $archive_date . '" class="tidelete" title="' . i18n_r('tide_news/NEWS_DELETE') . $data[$i]['title'] . '?">&#215;</a>
                        </td>
                        <td><input type="checkbox" name="multiple_delete[]" class="delete_checkboxes" value="' . $data[$i]['@attributes']['id'] . '" /></td>
                </tr>';
                }

                $text .= '</table>
                        <input type="hidden" name="page" value="' . $_GET['tide_news_overview'] . '" />
                        <p id="submit_line">
                            <input class="submit tidelete" type="submit" value="' . i18n_r('tide_news/NEWS_DEL_MULT') . '" name="tide_delete_news"    title="Do you want to delete multiple news?">&nbsp;&nbsp;or&nbsp;&nbsp;
                            <a class="cancel" title="Cancel" href="load.php?id=tide_news&amp;tide_news_overview">Cancel</a>
                        </p>          
            </form>';
            }

            $last = round($news_number / $show_per_page);


            if ($show_per_page < $news_number) {
                $pages_array = nav_drop_down($category, range(0, $last));
                $data = nav_old_new($last, $current_page, $category, 'nav_news_admin');

                $text .= load_template(TIDE_NEWS_TEMPLATES . 'backend/nav_default.tpl', $data);
                $text .= '<br /><br />';
            }
        }
        echo $text;
    }

#News delete
#-------------------------------- DONE------------------------------------

    function tide_delete_news() {

        $news_file = NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['tide_delete_news'] . '.xml';
        $news_content = xml_content_array($news_file, false);
        $news_content['tags'] = $news_content['tags']['data'];
        $data = create_news_paths($news_content, true, $_GET['date']);

        unlink($news_file);
        $r[] = tide_check_file($news_file);

        $t_num = count($data['category_tags']);
        $unique_key = md5($_GET['category'] . $_GET['tide_delete_news']);
        if (!empty($data['category_tags']) && !empty($data['master_tags'])) {

            for ($i = 0; $i < $t_num; $i++) {
                $r[] = tide_xml_node_remove($data['category_tags'][$i], 'item', 'id', $_GET['tide_delete_news'], true);
                $r[] = tide_xml_node_remove($data['master_tags'][$i], 'item', 'unique', $unique_key, true);
            }
        }

        $r[] = tide_xml_node_remove($data['master_archive'], 'item', 'unique', $unique_key, true);
        $r[] = tide_xml_node_remove($data['category_archive'], 'item', 'id', $_GET['tide_delete_news'], true);
        $r[] = tide_xml_node_remove($data['category_news'], 'item', 'id', $_GET['tide_delete_news']);
        $r[] = tide_xml_node_remove($data['news_index'], 'item', 'id', $unique_key);

        $res = tide_check($r);

        echo get_messages($res, i18n_r('tide_news/NEWS_DELETE_SUCC'), i18n_r('tide_news/NEWS_DELETE_ERROR'));
    }

#-------------------------------- DONE------------------------------------
#Create news
#-------------------------------- DONE------------------------------------

    function tide_create_news() {

        global $general_settings;

        $data['summary'] = '';
        $data['title'] = '';
        $data['content'] = '';
        $data['slug'] = '';
        $data['keywords'] = '';
        $data['tags'] = '';
        $data['metad'] = '';
        $data['news_visibility'] = 'N';
        $data['permanent_link'] = 'checked';
        $data['date_show'] = 'checked';
        $data['click_title'] = 'checked';
        $data['tags'] = '';
        $data['date'] = date_convert($general_settings['date_format']);
        $data['time'] = date_convert($general_settings['time_format']);
        $data['category'] = '';
        if (isset($_POST['tide_create_news'])) {
            unset($_POST['tide_create_news']);

            $_POST['date_show'] = (isset($_POST['date_show']) ? 'checked' : '');
            $_POST['permanent_link'] = (isset($_POST['permanent_link']) ? 'checked' : '');
            $_POST['click_title'] = (isset($_POST['click_title']) ? 'checked' : '');
            $_POST['tags'] = (isset($_POST['tags']) ? $_POST['tags'] : '');

            $test = tide_save_news($_POST);
            if ($test) {
                $data = $test;
                $data['tags'] = '';
                if (!empty($test['tags'])) {
                    foreach ($test['tags'] as $key => $value) {
                        $data['tags'] .= '<li>' . $value . '</li>';
                    }
                }
            }
        }

        if ($general_settings['news_summary'] == 'textarea') {
            $data['rich_editor_content'] = init_editor('content', "tide_news", 'advanced', 'tidengine', '400');
            $data['rich_editor_summary'] = init_editor('summary', "tide_news", 'basic', 'tidengine', '150');
            $data['textarea'] = '<div style="height: auto;margin: 5px 0" class="tide_admin_label">
            <label style="height: 25px;" for="tide_news_textarea">' . i18n_r('tide_news/NEWS_SUMMARY') . ':</label>
                
    <div class="edit-nav" style="margin-top: -15px;font-style: normal">
        <a href="" id="summary_btn" accesskey="s">' . i18n_r('tide_news/NEWS_SUMMARY') . '
            <b style="font-size: 16px;font-weight: bold; vertical-align: middle">+</b></a>
        <div class="clear" ></div>
    </div>

</div><p id="news_summary" style="display: none"><textarea class="tide_news_textarea" name="summary" >' . $data['content'] . '</textarea>
             ' . $data['rich_editor_summary'] . '</p>';
        } else {

            $data['rich_editor_content'] = init_editor('content', "tide_news", 'advanced', 'tidengine', '400');
            $data['textarea'] = '';
        }

        $category_index = NEWS_DIR . 'category_index.xml';

        $category_data = xml_content_array($category_index);
        if ($category_data['nodes'] > 0) {
            $category_data = category_array($category_data);

            $data['category'] = construct_dropdown('category', 'text autowidth', $category_data, $data['category'], '', true);
            $news_visibility = array('Y' => i18n_r('tide_news/NEWS_VISIBILITY_PRIVATE'), 'N' => i18n_r('tide_news/NEWS_VISIBILITY_PUBLIC'));
            $data['news_visibility'] = construct_dropdown('news_visibility', 'text autowidth', $news_visibility, $data['news_visibility'], '', true);

            echo load_template(TIDE_NEWS_TEMPLATES . 'backend/create_news.tpl', $data);
        } else {
            echo load_template(TIDE_NEWS_TEMPLATES . 'backend/no_categories.tpl', $data);
        }
    }

#-------------------------------- DONE------------------------------------
    #News save
#-------------------------------- DONE------------------------------------

    function tide_save_news($data) {

        $message = array();

        if (empty($data['title'])) {
            echo get_messages(false, '', i18n_r('tide_news/NEWS_TITLE_ERROR'));
            $result = $data;
        } else {

            global $general_settings;
            $data = tide_html_ent($data);
            $r = array();

            $data['slug'] = slug_sanitize($data['slug'], $data['title']);

            $news_file = os_separator(NEWS_DIR . 'news/' . $data['category'] . '/' . $data['slug'] . '.xml');

            $c = true;
            if (file_exists($news_file)) {
                if ($general_settings['duplicate_name'] !== 'checked') {
                    echo get_messages(false, '', i18n_r('tide_news/NEWS_SAVE_DUPLICATE'));
                    $result = $data;
                    $c = false;
                } else {
                    $data['slug'] = $data['slug'] . '_1';
                    $news_file = os_separator(NEWS_DIR . 'news/' . $data['category'] . '/' . $data['slug'] . '.xml');
                    $c = true;
                }
            }

            if ($c) {

                if ($general_settings['news_summary'] == 'pagebreak') {
                    $data['summary'] = pagebreak_process($data['content']);
                } else {
                    if (empty($data['summary'])) {
                        $data['summary'] = pagebreak_process($data['content']);
                    }
                }

                if (!empty($data['tags'])) {
                    $data['tags'] = tide_tag_sanitize($data['tags']);
                }
                $r[] = create_news_paths($data);
                $r[] = tide_xml_file($data, $news_file, 'create', false, false, false, true, true);

                if ($r) {
                    global $rss_settings;

                    if ($rss_settings['feed_enable'] == 'checked' && $rss_settings['feed_auto'] == 'checked') {
                        $r[] = create_rss('general');
                        $r[] = create_rss($data['category']);
                    }
                }

                if (in_array(false, $r)) {
                    $result = $data;
                    $re = false;
                } else {
                    $result = false;
                    $re = true;
                }

                echo get_messages($re, i18n_r('tide_news/NEWS_SAVE_SUCC'), i18n_r('tide_news/NEWS_SAVE_ERROR'));
            }
        }

        return $result;
    }

#-------------------------------- DONE------------------------------------
#Edit news
#-------------------------------- DONE------------------------------------

    function tide_edit_news() {
        global $general_settings;

        if (isset($_POST['tide_update_news'])) {
            unset($_POST['tide_update_news']);

            $_POST['date_show'] = (isset($_POST['date_show']) ? 'checked' : '');
            $_POST['permanent_link'] = (isset($_POST['permanent_link']) ? 'checked' : '');
            $_POST['click_title'] = (isset($_POST['click_title']) ? 'checked' : '');
            $_POST['modified'] = (isset($_POST['modified']) ? 'checked' : '');

            $kat = $_POST['category'];

            $test = tide_save_edited_news($_POST);
  
            unset($_POST);

            if ($test) {
                $data = $test;
                $category = $data['category'];
                $data['tags']['data'] = $data['tags'];
                echo get_messages(false, '', i18n_r('tide_news/NEWS_UPDATE_ERROR'));
            } else {
     

                header('Location: load.php?id=tide_news&tide_news_overview=' . $kat . '&c_title=' . urlencode($kat) . '&update');
               
            }
        } else {
            $file = NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['tide_edit_news'] . '.xml';
            $data = xml_content_array($file, false);
            $data['modified'] = '';
            $category = $_GET['category'];
        }

        $data['old_category'] = $data['category'];
        $data['c_title'] = urlencode($_GET['c_title']);

        $category_index = NEWS_DIR . 'category_index.xml';
        $category_data = xml_content_array($category_index);
        $category_data = category_array($category_data);

        $data['category'] = construct_dropdown('category', 'text autowidth', $category_data, $data['category'], '', true);

        $news_visibility = array('Y' => i18n_r('tide_news/NEWS_VISIBILITY_PRIVATE'), 'N' => i18n_r('tide_news/NEWS_VISIBILITY_PUBLIC'));
        $data['news_visibility'] = construct_dropdown('news_visibility', 'text autowidth', $news_visibility, $data['news_visibility'], '', true);

        if ($general_settings['news_summary'] == 'textarea') {
            $data['rich_editor_content'] = init_editor('content', "tide_news", 'advanced', 'tidengine', '400');
            $data['rich_editor_summary'] = init_editor('summary', "tide_news", 'basic', 'tidengine', '150');
            $data['textarea'] = '<div style="height: auto;margin: 5px 0" class="tide_admin_label">
            <label style="height: 25px;" for="tide_news_textarea">' . i18n_r('tide_news/NEWS_SUMMARY') . ':</label>
                
    <div class="edit-nav" style="margin-top: -15px; font-style: normal">
        <a href="" id="summary_btn" accesskey="s">' . i18n_r('tide_news/NEWS_SUMMARY') . '
            <b style="font-size: 16px;font-weight: bold; vertical-align: middle">+</b></a>
        <div class="clear" ></div>
    </div>
</div><p id="news_summary" style="display: none"><textarea class="tide_news_textarea" name="summary" >' . $data['content'] . '</textarea>
             ' . $data['rich_editor_summary'] . '</p>';
        } else {
            $data['rich_editor_content'] = init_editor('content', "tide_news", 'advanced', 'tidengine', '400');
            $data['textarea'] = '';
            $data['content'] = $data['content'];
        }

        $data['c_tags'] = '';

        if (!empty($data['tags']['data'])) {
            if (!is_array($data['tags']['data'])) {
                $tags[0] = $data['tags']['data'];
            } else {
                $tags = $data['tags']['data'];
            }

            foreach ($tags as $key => $val) {
                $data['c_tags'] .= '<li>' . $val . '</li>';
            }
        } else {
            $data['tags']['data'] = '';
        }

        $old_data = array('title' => $data['title'], 'slug' => $data['slug'], 'date' => $data['date'], 'category' => $category, 'tags' => $data['tags']['data']);

        $data['old_data'] = json_encode($old_data);

        unset($data['tags']);
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/edit_news.tpl', $data);
    }

#-------------------------------- DONE------------------------------------
    #Save Edited News
#-------------------------------- DONE------------------------------------

    function tide_save_edited_news($data) {

        if (empty($data['title'])) {
            echo get_messages(false, '', i18n_r('tide_news/NEWS_TITLE_ERROR'));
            $result = $data;
        } else {

            global $general_settings;

            $data = tide_html_ent($data);
            $r = array();

            $data['title'] = trim($data['title']);
            $data['slug'] = slug_sanitize($data['slug'], $data['title']);

            $old_data = json_decode(html_entity_decode($data['old_data']), true);
            $old_data_val = $data['old_data'];
            unset($data['old_data']);

            $old_data['tags'] = tide_tag_sanitize($old_data['tags']);
            $data['tags'] = tide_tag_sanitize($data['tags']);

            $old_paths = create_news_paths($old_data, true);
            $new_paths = create_news_paths($data, true);

            $old_unique = md5($old_data['category'] . $old_data['slug']);
            $new_unique = md5($data['category'] . $data['slug']);
            $new_ids = array('id' => $data['slug'], 'category' => $data['category'], 'unique' => $new_unique);

            if ($general_settings['news_summary'] == 'pagebreak') {
                $data['summary'] = pagebreak_process($data['content']);
            } else {
                if (empty($data['summary'])) {
                    $data['summary'] = pagebreak_process($data['content']);
                }
            }

            if ($old_data['category'] !== $data['category']) {

                $created_changed_news = tide_save_news($data);

                if (!$created_changed_news) {

                    $r[] = tide_xml_node_remove($old_paths['category_archive'], 'item', 'id', $old_data['slug'], true);
                    $r[] = tide_xml_node_remove($old_paths['category_news'], 'item', 'id', $old_data['slug']);
                    $r[] = tide_xml_node_remove($new_paths['news_index'], 'item', 'id', $old_unique);

                    foreach ($old_paths['category_tags'] as $key => $val) {
                        $r1[] = tide_xml_node_remove($val, 'item', 'id', $old_data['slug'], true);
                    }
                    $r[] = tide_check($r1);

                    foreach ($old_paths['master_tags'] as $key => $val) {
                        $r2[] = tide_xml_node_remove($val, 'item', 'unique', $old_unique, true);
                    }
                    $r[] = tide_check($r2);

                    $r[] = tide_xml_node_remove($old_paths['master_archive'], 'item', 'unique', $old_unique, true);

                    unlink($old_paths['news_file']);
                    $r[] = tide_check_file($old_paths['news_file']);
                } else {
                    $data['old_data'] = $old_data_val;
                    $result = $data;
                }
            } else {

                $cat['title'] = $data['title'];
                $cat['file'] = $new_paths['news_file'];
                $cat['date'] = $data['date'];

                $r[] = tide_xml_node_update($old_paths['category_news'], $cat, 'item', 'id', $old_data['slug'], $data['slug']);

                if ($data['modified'] == 'checked') {
                    $data['modified_date'] = date_convert(strftime($general_settings['date_format'], time()));
                    $data['modified_time'] = date_convert(strftime($general_settings['time_format'], time()));
                }
                unset($data['modified']);
         
                $r[] = tide_xml_file($data, $new_paths['news_file'], 'create');

                if ($old_data['slug'] !== $data['slug']) {
                    unlink($old_paths['news_file']);
                    $r[] = tide_check_file($old_paths['news_file']);
                }

                global $menu_settings;
                $new['summary'] = tide_reduce_text($data['summary'], $menu_settings['menu_content_lenght']);
                $link = url_builder($general_settings['all_news_page'], $data['category'], $data['slug'], 'tide_show_news', false, false);

                $news_index = array('title' => $data['title'], 'date' => $old_data['date'], 'category' => $data['category'], 'summary' => $new['summary'], 'link' => $link, 'file' => $new_paths['news_file']);

                $r[] = tide_xml_node_update($new_paths['news_index'], $news_index, 'item', 'id', $old_unique, $new_unique);

                if ($old_paths['master_archive'] !== $new_paths['master_archive']) {
                    $r[] = news_items($new_paths['news_file'], $new_paths['master_archive'], $new_ids, true);
                    $r[] = tide_xml_node_remove($old_paths['master_archive'], 'item', 'unique', $old_unique, true);
                } else {
                    $r[] = tide_xml_node_update($old_paths['master_archive'], $new_paths['news_file'], 'item', 'unique', $old_unique, $new_ids);
                }

                if ($old_paths['category_archive'] !== $new_paths['category_archive']) {
                    $r[] = news_items($new_paths['news_file'], $new_paths['category_archive'], $data['slug'], true);
                    $r[] = tide_xml_node_remove($old_paths['category_archive'], 'item', 'id', $old_data['slug'], true);
                } else {
                    $r[] = tide_xml_node_update($old_paths['category_archive'], $new_paths['news_file'], 'item', 'id', $old_data['slug'], $data['slug']);
                }

                $r[] = check_tags($old_paths['category_tags'], $new_paths['category_tags'], $new_paths['news_file'], $old_data['slug'], $data['slug']);
                $r[] = check_tags($old_paths['master_tags'], $new_paths['master_tags'], $new_paths['news_file'], $old_data['slug'], $new_ids);
            }


            if (in_array(false, $r)) {
                $data['old_data'] = $old_data_val;
                $result = $data;
            } else {
                global $rss_settings;

                if ($rss_settings['feed_enable'] == 'checked' && $rss_settings['feed_auto'] == 'checked') {
                    $s[] = create_rss('general');
                    $s[] = create_rss($data['category']);
                }
                if (in_array(false, $s)) {
                    $data['old_data'] = $old_data_val;
                    $result = $data;
                } else {
                    $result = false;
                }
            }
        }

        return $result;
    }

############################ CATEGORY FUNCTIONS #######################################################################################
#-------------------------------- DONE------------------------------------
#Create category
#-------------------------------- DONE------------------------------------

    function tide_create_category() {

        global $general_settings;
        $data['category_title'] = '';
        $data['category_slug'] = '';
        $data['keywords'] = '';
        $data['metad'] = '';
        $data['category_visibility'] = 'N';
        $data['pages'] = 'blog_category';

        if (isset($_POST['tide_category_save'])) {
            unset($_POST['tide_category_save']);

            $test = tide_save_category($_POST, 'create');
            unset($_POST);
            if ($test) {
                $data = $test;
            }
        }
        $ch_pages = tide_pages_category();

        $data['pages'] = construct_dropdown('pages', 'text', $ch_pages, $data['pages'], '', true);
        $category_visibility = array('Y' => i18n_r('tide_news/CATEGORY_VISIBILITY_PRIVATE'), 'N' => i18n_r('tide_news/CATEGORY_VISIBILITY_PUBLIC'));
        $data['category_visibility'] = construct_dropdown('category_visibility', 'text autowidth', $category_visibility, $data['category_visibility'], '', true);
        $data['c_title'] = i18n_r('tide_news/CATEGORY_CREATE');
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/category_start.tpl', $data);
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/create_category.tpl', $data);
    }

#-------------------------------- DONE------------------------------------
#Category Edit
#-------------------------------- DONE------------------------------------

    function tide_category_edit() {
        global $general_settings;

        $category_index = NEWS_DIR . 'category_index.xml';

        if (isset($_POST['tide_category_update'])) {
            unset($_POST['tide_category_update']);

            $_POST['replace_page_category'] = (isset($_POST['replace_page_category']) ? true : false);

            $test = tide_save_category($_POST, 'update');

            unset($_POST);
            if ($test) {
                $data = $test;
            } else {
                header('Location: load.php?id=tide_news&tide_category&subpage=tide_category_list&updated');
            }
        } else {
            $data = tide_get_xml_node($category_index, 'item', 'id', $_GET['category']);
        }

        $data['old_slug'] = $data['category_slug'];
        $data['old_page'] = $data['pages'];
        $pages = get_pages(GSDATAOTHERPATH . 'pages.xml', true);
        $ch_pages = tide_pages_category($data['category_slug']);

        $data['pages'] = construct_dropdown('pages', 'text', $ch_pages, $data['pages'], '', true);
        $category_visibility = array('Y' => i18n_r('tide_news/CATEGORY_VISIBILITY_PRIVATE'), 'N' => i18n_r('tide_news/CATEGORY_VISIBILITY_PUBLIC'));
        $data['category_visibility'] = construct_dropdown('category_visibility', 'text autowidth', $category_visibility, $data['category_visibility'], '', true);
        $data['c_title'] = i18n_r('tide_news/CATEGORY_EDIT');
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/category_start.tpl', $data);
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/edit_category.tpl', $data);
    }

#-------------------------------- DONE------------------------------------
#Category Save/ Update 
#-------------------------------- DONE ------------------------------------

    function tide_save_category($data, $action, $old_data = false) {
        if ($data['pages'] !== 'blog_category') {
            tide_save_news_category($data, $action, $old_data);
        } else {
            tide_save_blog_category($data, $action, $old_data);
        }
    }

#-------------------------------- DONE------------------------------------
#Save edited News Category
#-------------------------------- DONE ------------------------------------

    function tide_save_news_category($data, $action, $old_data = false) {
        global $general_settings;

        $message = array();
        $data = tide_html_ent($data);

        if ($action == 'create') {
            if (!empty($data['category_title'])) {
                $data['category_slug'] = slug_sanitize($data['category_slug'], $data['category_title']);


                $re = true;
//                if ($data['pages'] !== 'blog_category') {
                $re = tide_update_page(GSDATAPAGESPATH . $data['pages'] . '.xml', $data['category_slug']);
//                }

                if ($re) {

                    $news_dir = os_separator(NEWS_DIR . 'news/' . $data['category_slug']);
                    $category_archives = os_separator(NEWS_DIR . 'archives/' . $data['category_slug']);
                    $category_tags = os_separator(NEWS_DIR . 'tags/' . $data['category_slug']);

                    if (!file_exists($news_dir) && !file_exists($category_archives) && !file_exists($category_archives)) {

                        $news_dir_create = create_directory($news_dir, 'alow');
                        if ($news_dir_create) {
                            $category_archives_create = create_directory($category_archives, 'alow');
                            if ($category_archives_create) {

                                $category_tags_create = create_directory($category_tags, 'alow');
                                if ($category_tags_create) {

                                    $category_index = NEWS_DIR . 'category_index.xml';
                                    $cat_res = tide_xml_file($data, $category_index, 'update', $data['category_slug']);
                                    if ($cat_res) {

                                        $category_file = NEWS_DIR . 'category/' . $data['category_slug'] . '.xml';
                                        $result = tide_xml_file(false, $category_file, 'create');

                                        $message[] = get_messages($result, i18n_r('tide_news/CATEGORY_CREATED_SUCC'), i18n_r('tide_news/CATEGORY_CREATED_ERROR'));

                                        if (!$result) {
                                            $result = $data;
                                        } else {
                                            $result = false;
                                        }
                                    } else {
                                        unlink($news_dir);
                                        unlink($category_archives);
                                        unlink($category_tags);
                                        $message[] = get_messages($cat_res, i18n_r('tide_news/CATEGORY_INDEX_UPDATED'), i18n_r('tide_news/CATEGORY_INDEX_UPDATE_FAIL'));
                                        $result = $data;
                                    }
                                } else {
                                    unlink($news_dir);
                                    unlink($category_archives);
                                    $message[] = get_messages($category_tags_create, i18n_r('tide_news/CATEGORY_TAGS_SUCC'), i18n_r('tide_news/CATEGORY_TAGS_ERROR'));
                                    $result = $data;
                                }
                            } else {
                                unlink($news_dir);
                                $message[] = get_messages($category_archives_create, i18n_r('tide_news/CATEGORY_ARCH_SUCC'), i18n_r('tide_news/CATEGORY_ARCH_ERROR'));
                                $result = $data;
                            }
                        } else {
                            $message[] = get_messages($news_dir_create, i18n_r('tide_news/CATEGORY_NEWS_SUCC'), i18n_r('tide_news/CATEGORY_NEWS_ERROR'));
                            $result = $data;
                        }
                    } else {

                        $message[] = get_messages(false, '', i18n_r('tide_news/CATEGORY_SAVE_DUPLICATE'));
                        $result = $data;
                    }
                } else {
                    $message[] = get_messages($re, i18n_r('tide_news/CATEGORY_PAGE_UPDATE_SUCC'), i18n_r('tide_news/CATEGORY_PAGE_UPDATE_ERROR'));
                    $result = $data;
                }
            } else {
                $message[] = get_messages(false, '', i18n_r('tide_news/CATEGORY_TITLE_ERROR'));
                $result = $data;
            }
        } else if ($action == 'update') {
            if (strtolower($data['category_title']) !== 'category title' || !empty($data['category_title'])) {
                $data['category_slug'] = slug_sanitize($data['category_slug'], $data['category_title']);

                $news_dir_rename = true;
                $category_archives_rename = true;
                $category_tags_rename = true;
                $category_file_rename = true;

                if ($data['old_slug'] !== $data['category_slug']) {

                    $news_dir = os_separator(NEWS_DIR . 'news/' . $data['category_slug']);

                    $news_dir_old = os_separator(NEWS_DIR . 'news/' . $data['old_slug']);
                    $news_dir_rename = rename($news_dir_old, $news_dir);

                    $category_archives = NEWS_DIR . 'archives/' . $data['category_slug'];
                    $category_archives_old = NEWS_DIR . 'archives/' . $data['old_slug'];
                    $category_archives = os_separator($category_archives);
                    $category_archives_old = os_separator($category_archives_old);
                    $category_archives_rename = rename($category_archives_old, $category_archives);

                    $category_tags = NEWS_DIR . 'tags/' . $data['category_slug'];
                    $category_tags_old = NEWS_DIR . 'tags/' . $data['old_slug'];
                    $category_tags = os_separator($category_tags);
                    $category_tags_old = os_separator($category_tags_old);
                    $category_tags_rename = rename($category_tags_old, $category_tags);

                    $category_file = NEWS_DIR . 'category/' . $data['category_slug'] . '.xml';
                    $category_file_old = NEWS_DIR . 'category/' . $data['old_slug'] . '.xml';
                    $category_file_rename = rename($category_file_old, $category_file);
                }

                if ($news_dir_rename && $category_archives_rename && $category_tags_rename && $category_file_rename) {

                    $res = true;
                    $old_re = true;

                    if ($data['old_page'] !== $data['pages'] && $data['old_slug'] !== $data['category_slug']) {

                        //   if ($data['pages'] !== 'blog_category') {

                        $res = tide_update_page(GSDATAPAGESPATH . $data['pages'] . '.xml', $data['category_slug']);
                        //    }
                        // if ($data['old_page'] !== 'blog_category') {
                        $old_re = tide_remove_code(GSDATAPAGESPATH . $data['old_page'] . '.xml');
                        // }
                    }

                    if ($data['old_page'] !== $data['pages'] && $data['old_slug'] == $data['category_slug']) {

                        // if ($data['pages'] !== 'blog_category') {

                        $res = tide_update_page(GSDATAPAGESPATH . $data['pages'] . '.xml', $data['category_slug']);
                        // }
                        // if ($data['old_page'] !== 'blog_category') {
                        $old_re = tide_remove_code(GSDATAPAGESPATH . $data['old_page'] . '.xml');
                        // }
                    }

                    if ($data['old_page'] == $data['pages'] && $data['old_slug'] !== $data['category_slug']) {

                        //  if ($data['pages'] !== 'blog_category') {
                        $res = tide_update_page(GSDATAPAGESPATH . $data['pages'] . '.xml', $data['category_slug']);
                        //  }
                    }

                    if (!$res) {
                        $message[] = get_messages($res, i18n_r('tide_news/CATEGORY_PAGE_UPDATE_SUCC'), i18n_r('tide_news/CATEGORY_PAGE_UPDATE_ERROR'));
                    }

                    if (!$old_re) {
                        $message[] = get_messages($old_re, i18n_r('tide_news/CATEGORY_PAGE_CODE_REMOVE_SUCC'), i18n_r('tide_news/CATEGORY_PAGE_CODE_REMOVE_ERROR'));
                    }
                } else {
                    $message[] = get_messages(false, '', i18n_r('tide_news/CATEGORY_RENAME_ERROR'));
                    $result = $data;
                }


                $category_index = NEWS_DIR . 'category_index.xml';
                unset($data['old_page']);
                unset($data['replace_page_category']);
                $data['slug'] = $data['category_slug'];
                $update = update_xml($category_index, $data);

                if (!$update) {
                    $message[] = get_messages($update, i18n_r('tide_news/CATEGORY_UPDATED'), i18n_r('tide_news/CATEGORY_UPDATE_FAIL'));
                    $result = $data;
                } else {
                    $result = false;
                }
            } else {
                $message[] = get_messages(false, '', i18n_r('tide_news/CATEGORY_TITLE_ERROR'));
                $result = $data;
            }
        }
//        if (!$result) {
//            global $rss_settings;
//
//            if ($rss_settings['feed_enable'] == 'checked' && $rss_settings['feed_auto'] == 'checked') {
//                create_rss('general');
//                create_rss($data['category']);
//            }
//        }
        $i = 0;
        while ($i < count($message)) {
            echo $message[$i];
            sleep(1);
            $i++;
        }
        return $result;
    }

#-------------------------------- DONE------------------------------------
#Category List Page 
#-------------------------------- DONE------------------------------------

    function tide_category_list() {

        if (isset($_GET['updated'])) {
            echo get_messages(true, i18n_r('tide_news/CATEGORY_UPDATED'), '');
        }

        $category_index = os_separator(NEWS_DIR . 'category_index.xml');
        $category_data = xml_content_array($category_index);
        $category = $category_data['data'];
        $category_number = $category_data['nodes'];

        $start = 0;
        $times_loop = 20;
        $show_per_page = 20;

        $text = '<form method="post" name="multi_delete"  id="multi_delete" >
                <table class="highlight" id="category_list">
                    <tr style="background-color: #ccc">
                        <th>' . i18n_r('tide_news/CATEGORY_TABLE_TITLE') . '</th>
                        <th style="text-align: right">' . i18n_r('tide_news/NEWS_DEL') . '</th>
                    </tr><tr>
                        <td colspan="2"></td></tr>';

        if ($category_number > 0) {

            if (!empty($_GET['page_number'])) {

                if ($_GET['page_number'] > 1) {
                    $start = ($_GET['page_number'] - 1) * $show_per_page;
                }

                $times_loop = $times_loop + $start;

                if ($times_loop > $category_number) {
                    $times_loop = $category_number;
                }
            } else {
                if ($category_number <= $times_loop) {
                    $times_loop = $category_number;
                }
            }

            for ($i = $start; $i < $times_loop; $i++) {
                $c_data = $category[$i]['category_slug'];
                $c_title = $category[$i]['category_title'];
                $c_parent = $category[$i]['pages'];
                $text .= '<tr>  
            <td class="pagetitle" >
                <a href="load.php?id=tide_news&amp;tide_category&amp;subpage=tide_category_edit&amp;category=' . $c_data . '" title="' . i18n_r('tide_news/CATEGORY_EDIT') . $c_data . '">
                    ' . $c_title . '
                </a>
            </td>
            <td class="delete"  style="padding-left: 15px;">
                <a style="width: 15px;" href="load.php?id=tide_news&amp;tide_category&amp;subpage=tide_category_delete&amp;category=' . $c_data . '&amp;parent=' . $c_parent . '" class="tidelete" title="' . i18n_r('tide_news/CATEGORY_DELETE') . ' ' . $c_data . '?">&#215;</a>
            </td>
    </tr>';
            }
        } else {
            $text .= '<tr><td colspan="2"><h2>' . i18n_r('tide_news/CATEGORY_NODATA') . '</h2></td></tr>';
        }
        $text .= '</table>                              
            </form>';

        if (empty($_GET['page_number'])) {
            $current_page = 1;
        } else {
            $current_page = $_GET['page_number'];
        }

        $last = round($category_number / $show_per_page) + 1;
        if ($show_per_page < $category_number) {
            $data = nav_old_new($last, $current_page, '', 'nav_category_admin');

            $text .= load_template(TIDE_NEWS_TEMPLATES . 'backend/nav_default.tpl', $data);
            $text .= '<br /><br />';
        }

        $last = round($category_number / $show_per_page);
        $data['c_title'] = i18n_r('tide_news/CATEGORY_LIST');
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/category_start.tpl', $data);
        echo $text;
    }

#-------------------------------- DONE------------------------------------
#Category Delete
#-------------------------------- DONE------------------------------------

    function tide_category_delete() {

        $category = $_GET['category'];

        #brise iz MASTER ARCHIVES
        $arch_path = os_separator(NEWS_DIR . 'archives');
        $arch = get_files($arch_path, 'xml');

        foreach ($arch as $k => $v) {
            $v = os_separator($v);
            $r[] = tide_xml_node_remove($v, 'item', 'category', $category, true);
        }

        #brise iz CATEGORY ARCHIVES
        $arch_path_c = os_separator(NEWS_DIR . 'archives/' . $category);
        $arch_c = get_files($arch_path_c, 'xml');

        foreach ($arch_c as $k => $v) {
            $v = os_separator($v);
            unlink($v);
            $r[] = tide_check_file($v);
        }
        $h = os_separator($arch_path_c . '/.htaccess');
        unlink($h);
        $r[] = tide_check_file($h);

        $r[] = rmdir($arch_path_c);


        #brise iz MASTER TAGS
        $tags_path = os_separator(NEWS_DIR . 'tags');
        $tags = get_files($tags_path, 'xml');

        foreach ($tags as $k => $v) {
            $v = os_separator($v);
            $r[] = tide_xml_node_remove($v, 'item', 'category', $category, true);
        }


        #brise iz CATEGORY TAGS
        $tags_path_c = os_separator(NEWS_DIR . 'tags/' . $category);
        $tags_c = get_files($tags_path_c, 'xml');

        foreach ($tags_c as $k => $v) {
            $v = os_separator($v);
            unlink($v);
            $r[] = tide_check_file($v);
        }
        $h1 = os_separator($tags_path_c . '/.htaccess');
        unlink($h1);
        $r[] = tide_check_file($h1);

        $r[] = rmdir($tags_path_c);


        #brise iz CATEGORY NEWS
        $news = os_separator(NEWS_DIR . 'news/');
        $news_path_c = $news . $category;
        $news_c = get_files($news_path_c, 'xml');

        foreach ($news_c as $k => $v) {
            $v = os_separator($v);
            unlink($v);
            $r[] = tide_check_file($v);
        }

        $h2 = os_separator($news_path_c . '/.htaccess');
        unlink($h2);

        $r[] = tide_check_file($h2);
        $r[] = rmdir($news_path_c);

        #brise iz NEWS iz NEWS INDEX
        $r[] = tide_xml_node_remove($news . 'news_index.xml', 'item', 'category', $category);

        #brise iz CATEGORY iz CATEGORY INDEX
        $category_index = os_separator(NEWS_DIR . 'category_index.xml');
        $r[] = tide_xml_node_remove($category_index, 'item', 'id', $category);

        #brise CATEGORY FILE
        $c = os_separator(NEWS_DIR . 'category/' . $category . '.xml');
        unlink($c);
        $r[] = tide_check_file($c);

        if ($_GET['parent'] !== 'blog_category') {
            tide_remove_code(GSDATAPAGESPATH . $_GET['parent'] . '.xml');
        }

        $res = tide_check_file($r);

        echo get_messages($res, i18n_r('tide_news/CATEGORY_DELETE_SUCC'), i18n_r('tide_news/CATEGORY_DELETE_ERROR'));
    }

#-------------------------------- DONE------------------------------------ 
#Category Page tab menu
#-------------------------------- DONE------------------------------------

    function tide_category_menu() {
        if (isset($_GET['subpage'])) {
            $selected = $_GET['subpage'];
        } else {
            $selected = 'tide_create_category';
        }

        $subpages = array('tide_category_list' => i18n_r('tide_news/CATEGORY_LIST'), 'tide_create_category' => i18n_r('tide_news/CATEGORY_CREATE'));

        if (isset($_GET['subpage']) && $_GET['subpage'] == 'tide_category_edit') {
            $subpages['tide_category_edit'] = i18n_r('tide_news/CATEGORY_EDIT');
        }

        $menu = '<div class="edit-nav" style="padding-bottom: 25px;">';

        foreach ($subpages as $key => $value) {

            if ($selected == $key) {
                $menu .= '<a class="current" href="load.php?id=tide_news&amp;tide_category&amp;subpage=' . $key . '">' . $value . '</a>';
            } else {
                $menu .= '<a href="load.php?id=tide_news&amp;tide_category&amp;subpage=' . $key . '">' . $value . '</a>';
            }
        }

        $menu .= '</div>';

        return $menu;
    }

#-------------------------------- DONE------------------------------------
    #Category Function Router
#-------------------------------- DONE------------------------------------   

    function tide_category() {
        if (isset($_GET['subpage'])) {
            switch ($_GET['subpage']) {
                case 'tide_create_category':
                    tide_create_category();
                    break;
                case 'tide_category_edit':
                    tide_category_edit();
                    break;
                case 'tide_category_list':
                    tide_category_list();
                    break;
                case 'tide_category_delete':
                    tide_category_delete();
                    break;
            }
        } else {
            tide_create_category();
        }
    }

############################ CATEGORY FUNCTIONS END #######################################################################################
#-------------------------------- DONE------------------------------------
#Category Template Editor
#-------------------------------- DONE------------------------------------   

    function tide_template_editor() {

        if (isset($_GET['saved'])) {
            echo get_messages($_GET['saved'], i18n_r('tide_news/FILE_UPDATE_SUCC'), i18n_r('tide_news/FILE_UPDATE_ERROR'));
        }

        $template_path = 'templates/frontend/';
        $css_path = 'css/tide_news.css';
        $data['tide_files'] = $template_path . 'news.tpl';
        $tide_news_templates = array(
            $template_path . 'nav_default.tpl' => i18n_r('tide_news/FILE_NAV_DEFAULT'),
            $template_path . 'nav_drop_down.tpl' => i18n_r('tide_news/FILE_NAV_DROP'),
            $template_path . 'nav_paginate.tpl' => i18n_r('tide_news/FILE_NAV_PAG'),
            $template_path . 'news.tpl' => i18n_r('tide_news/FILE_NEWS_SUMMARY'),
            $template_path . 'news_extended.tpl' => i18n_r('tide_news/FILE_NEWS_EXTENDED'),
            $template_path . 'no_news.tpl' => i18n_r('tide_news/FILE_NEWS_NONE'),
            $template_path . 'comments.tpl' => i18n_r('tide_news/FILE_COMMENTS'),
            $template_path . 'rss_menu.tpl' => i18n_r('tide_news/FILE_RSS_MENU'),
            $template_path . 'archives.tpl' => i18n_r('tide_news/FILE_ARCHIVE_PAGE'),
            $template_path . 'addthis.tpl' => i18n_r('tide_news/FILE_ADDTHIS'),
            $template_path . 'sharethis.tpl' => i18n_r('tide_news/FILE_SHARETHIS'),
            $css_path => i18n_r('tide_news/FILE_NEWS_CSS'),);


        $data['tide_files'] = construct_dropdown('tide_files', 'text', $tide_news_templates, $data['tide_files'], '', true);
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/editor.tpl', $data);
    }

#-------------------------------- DONE------------------------------------
#Match Shortcodes
#-------------------------------- DONE------------------------------------   

    function tide_shortcodes($content, $echos = true) {

        // $content = $content[0];
        //  file_put_contents(NEWS_DIR . 'test.txt', $content);
//{%{TIDE_TAGS_MENU::GENERAL}%} {%{TIDE_TAGS_MENU::GENERAL}%}
//
//{%{TIDE_ARCHIVE_MENU::CATEGORY}%} {%{TIDE_ARCHIVE_MENU::GENERAL}%}
//
//{%{TIDE_NEWS_MENU::SUMMARY}%} {%{TIDE_NEWS_MENU::GENERAL}%}
//
//{%{TIDE_ARCHIVE}%}
//
//{%{TIDE_RSS_MENU::CATEGORY}%} {%{TIDE_RSS_MENU::GENERAL}%}
//
//{%{TIDE_TAGS}%}
//
//{%{TIDE_BREADCRUMBS}%}
//
//{%{TIDE_SHARETHIS::SHARE_CODE_1}%}
//
//{%{TIDE_ADDTHIS::SHARE_CODE_1}%}

        $f_list = array(
            'TIDE_TAGS_MENU' => 'tide_tags_menu',
            'TIDE_NEWS' => 'tide_show_news',
            'TIDE_ARCHIVE_MENU' => 'tide_archive_menu',
            'TIDE_NEWS_MENU' => 'tide_news_menu',
            'TIDE_ARCHIVE' => 'tide_archive',
            'TIDE_RSS_MENU' => 'tide_rss_feed_menu',
            'TIDE_TAGS' => 'tide_tags',
            'TIDE_BREADCRUMBS' => 'tide_news_breadcrumbs',
            'TIDE_SHARETHIS' => 'tide_share_sharethis',
            'TIDE_ADDTHIS' => 'tide_share_addthis',
        );

        preg_match_all('/{%{([A-Z0-9_:-]+)}%}/usm', $content, $matches);
        for ($index = 0; $index < count($matches[1]); $index++) {

            list($function, $args) = explode('::', $matches[1][$index]) + Array(null, $_GET);
            $tt = in_array($f_list[$function], $f_list);
            if ($tt) {
                if (!is_array($args)) {
                    $args = strtolower($args);
                }
                $data = call_user_func($f_list[$function], $args);
                $content = str_replace($matches[0][$index], $data, $content);
            } else {
                $content = str_replace($matches[0][$index], '', $content);
            }
        }
        if ($echos) {
            echo $content;
        } else {
            return $content;
        }
    }

#-------------------------------- DONE------------------------------------
#In calse that eval_php_in_content plugin is not installed
#-------------------------------- DONE------------------------------------   

    function tide_evaluate_php($c) {
        $c = eval("?>" . stripslashes(htmlspecialchars_decode($c, ENT_QUOTES)) . "<?php ");
        return $c;
    }

############################ SETTINGS FUNCTIONS #######################################################################################
#-------------------------------- DONE------------------------------------   
#Settings Navigation Menu
#-------------------------------- DONE------------------------------------   

    function tide_settings_menu() {
        if (isset($_GET['subpage'])) {
            $selected = $_GET['subpage'];
        } else {
            $selected = 'tidenews_general';
        }
        $subpages = array('tidenews_share' => i18n_r('tide_news/S_MENU_SHARETHIS'),
            'tidenews_ckeditor' => i18n_r('tide_news/S_MENU_CKE'),
            'tidenews_rss_feed' => i18n_r('tide_news/S_MENU_RSS'),
            'tidenews_tags' => i18n_r('tide_news/S_MENU_TAGS'),
            'tidenews_news_menu' => i18n_r('tide_news/S_MENU_M_NEWS'),
            'tidenews_general' => i18n_r('tide_news/S_MENU_GENERAL')
        );
        $menu = '<div class="edit-nav" style="padding-bottom: 25px;">';

        foreach ($subpages as $key => $value) {

            if ($selected == $key) {
                $menu .= '<a class="current" href="load.php?id=tide_news&amp;tide_news_settings&amp;subpage=' . $key . '">' . $value . '</a>';
            } else {
                $menu .= '<a href="load.php?id=tide_news&amp;tide_news_settings&amp;subpage=' . $key . '">' . $value . '</a>';
            }
        }
        $menu .= '</div>';
        return $menu;
    }

#-------------------------------- DONE------------------------------------   
#Settings Functions Router
#-------------------------------- DONE------------------------------------   

    function tide_news_settings() {

        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_start.tpl');

        if (isset($_GET['subpage'])) {

            switch ($_GET['subpage']) {
                case 'tidenews_general':
                    tidenews_general_settings();
                    break;
                case 'tidenews_news_menu':
                    tidenews_news_menu_settings();
                    break;
                case 'tidenews_tags':
                    tidenews_tags_settings();
                    break;
                case 'tidenews_rss_feed':
                    tidenews_rss_feed_settings();
                    break;
                case 'tidenews_share':
                    tidenews_share_settings();
                    break;
                case 'tidenews_ckeditor':
                    tidenews_ckeditor_settings();
                    break;
            }
        } else {
            tidenews_general_settings();
        }
    }

#-------------------------------- DONE------------------------------------   
#CKEditor settings
#-------------------------------- DONE------------------------------------   

    function tidenews_ckeditor_settings() {

        global $cfk_settings;
        global $cke_languages;

        $data = $cfk_settings;

        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);

            $result = file_put_contents(TIDE_MASTER_DIR . 'ckeditor/config.js', $_POST['cke_config']);
            echo get_messages($result, i18n_r('tide_news/CKE_CONFIG_UPDATE_SUCC'), i18n_r('tide_news/CKE_CONFIG_UPDATE_ERROR'));

            unset($_POST['cke_config']);

            $data = $_POST;
            tide_settings_save(CKE_SETTINGS, $data);
        }

        $data['images'] = '';
        $img_path = SITE_URL . 'plugins/TIDEGetSimple/images/';

        for ($i = 1; $i < 9; $i++) {
            $data['images'] .= '<img src="' . $img_path . $i . '.jpg" alt="" /><br />';
        }

        $data['cke_config'] = file_get_contents(TIDE_MASTER_DIR . 'ckeditor/config.js');

        $data['cke_config'] = htmlentities($data['cke_config'], ENT_QUOTES, 'UTF-8');

        $ckeditor_skin = array('getsimple', 'kama', 'office2003', 'v2', 'tidengine');
        $data['ckeditor_skin'] = construct_dropdown('ckeditor_skin', 'text', $ckeditor_skin, $data['ckeditor_skin']);

        $data['cke_languages'] = construct_dropdown('cke_languages', 'text', $cke_languages, $data['cke_languages']);

        $highlight_styles = array('not' => 'Do not use Highlighter', 'shThemeDefault' => 'Default Style', 'shThemeDjango' => 'Django Style', 'shThemeEclipse' => 'Eclipse Style', 'shThemeEmacs' => 'Emacs Style', 'shThemeFadeToGrey' => 'FadeToGrey Style', 'shThemeMDUltra' => 'MDUltra Style', 'shThemeMidnight' => 'Midnight Style', 'shThemeRDark' => 'RDark Style');

        $data['highlight_styles'] = construct_dropdown('highlight_styles', 'text', $highlight_styles, $data['highlight_styles'], '', true);

        $data['ckeditor_type'] = 'basic';
        $ckeditor_type = array('basic' => i18n_r('tide_news/CKE_BASIC'), 'advanced' => i18n_r('tide_news/CKE_ADV'), 'custom' => i18n_r('tide_news/CKE_CUSTOM'));
        $data['ckeditor_type'] = construct_dropdown('ckeditor_type', 'text', $ckeditor_type, $data['ckeditor_type'], '', true);

        $data['cke_toolbar'] = '';

        $buttons_base_path = SITE_URL . 'plugins/TIDEGetSimple/images/buttons/';
        global $buttons;
        foreach ($buttons as $key => $value) {
            $data['cke_toolbar'] .= '<div class="cke_buttons" id="' . $value . '"><img class="cke_button" src="' . $buttons_base_path . $value . '.png" title="' . $value . '" /></div>';
        }

        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_cke.tpl', $data);
    }

#-------------------------------- DONE------------------------------------   
#Tags settings
#-------------------------------- DONE------------------------------------   

    function tidenews_tags_settings() {

        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);
            $_POST['tags_menu_status'] = (isset($_POST['tags_menu_status']) ? 'checked' : '');

            $data = $_POST;
            tide_settings_save(TAGS_SETTINGS, $data);
        } else {
            global $tags_settings;
            $data = $tags_settings;
        }
        $tags_min_length = range(1, 20);
        $data['tags_min_length'] = construct_dropdown('tags_min_length', 'text', $tags_min_length, $data['tags_min_length']);


        $tags_size = array('random' => 'Random Size', 'proportional' => 'Proportional Size');
        $data['tags_size'] = construct_dropdown('tags_size', 'text', $tags_size, $data['tags_size'], '', true);
        $tags_occurence = range(0, 30);
        $data['tags_occurence'] = construct_dropdown('tags_occurence', 'text', $tags_occurence, $data['tags_occurence'], '', true);
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_tags.tpl', $data);
    }

#ShareThis Settings
#-------------------------------- DONE------------------------------------   

    function tidenews_share_settings() {
        $sharethis_path = PLUGIN_PATH . 'data/sharethis.xml';
        if (isset($_POST['tide_settings_save'])) {

            if (isset($_POST['share_code'])) {
                $sh_d['item'] = $_POST['share_code'];
                tide_xml_file($sh_d, $sharethis_path, 'create', false, false, false, true, true);
                $sharethis['data'][0] = $_POST['share_code'];
                $nodes = count($_POST['share_code']);
                unset($_POST['share_code']);
            } else {
                $sharethis = xml_content_array($sharethis_path, true);
                $nodes = 0;
                $c_node = tide_count_nodes($sharethis_path, 'item', true);
                if ($c_node > 0) {
                    tide_xml_file('', $sharethis_path, 'create');
                }
            }
            unset($_POST['tide_settings_save']);

            $_POST['use_share_this'] = (isset($_POST['use_share_this']) ? 'checked' : '');
            $_POST['use_addthis'] = (isset($_POST['use_addthis']) ? 'checked' : '');
            $_POST['addthis_bar'] = (isset($_POST['addthis_bar']) ? 'checked' : '');
            $data = $_POST;
            tide_settings_save(SHARE_SETTINGS, $data);
        } else {
            global $share_settings;
            $data = $share_settings;
            $sharethis = xml_content_array($sharethis_path, true);
            $nodes = tide_count_nodes($sharethis_path, 'item', true);
        }

        $data['sharethis_code'] = '';
        if ($nodes > 0) {
            $data['sharethis_code'] .= '<p class="tide_admin_label tide_share_holder" id="share_code">';
            foreach ($sharethis['data'][0] as $key => $val) {
                $id = str_replace('share_code_', '', $key);

                $data['sharethis_code'] .= '<label id="' . $id . '" class="clearfix" for="' . $key . '">
Use ID\'s
<br>
<span class="tide_admin_info_small">' . $key . '/ ' . strtoupper($key) . '</span>
<br>
<textarea id="share_code[' . $key . ']" class="text short" name="share_code[' . $key . ']">' . $val . '</textarea>
<a class="remove" href="">remove</a>
</label>';
            }
            $data['sharethis_code'] .= '</p>';
        } else {
            $data['sharethis_code'] .= '<p class="tide_admin_label tide_share_holder" id="share_code" style="display: none;"></p>';
        }


        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_share.tpl', $data);
    }

#-------------------------------- DONE------------------------------------ 
#ShareThis Menu
#-------------------------------- DONE------------------------------------  

    function tide_share_addthis($code_id) {
        $addthis = xml_content_array(PLUGIN_PATH . 'data/addthis.xml', false);

        $data['addthis'] = $addthis[$code_id];
        $data['addthis_elemet_class'] = 'tide_addthis_' . $code_id;
        $txt = load_template(TIDE_NEWS_TEMPLATES . 'frontend/addthis.tpl', $data);

        $r = debug_backtrace();
        if ($r[1]['function'] == 'call_user_func') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE------------------------------------ 
#AddThis Menu
#-------------------------------- DONE------------------------------------  

    function tide_share_sharethis($code_id) {
        $sharethis = xml_content_array(PLUGIN_PATH . 'data/sharethis.xml', false);

        $data['sharethis'] = $sharethis[0][$code_id];
        $data['sharethis_elemet_class'] = 'tide_sharethis_' . $code_id;
        $txt = load_template(TIDE_NEWS_TEMPLATES . 'frontend/sharethis.tpl', $data);

        $r = debug_backtrace();
        if ($r[1]['function'] == 'call_user_func') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE------------------------------------ 
#RSS Feed Settings
#-------------------------------- DONE------------------------------------ 

    function tidenews_rss_feed_settings() {
        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);

            $_POST['feed_enable'] = (isset($_POST['feed_enable']) ? 'checked' : '');
            $_POST['feed_auto'] = (isset($_POST['feed_auto']) ? 'checked' : '');
            $_POST['feed_title'] = (isset($_POST['feed_title']) ? $_POST['feed_title'] : get_site_name(false));
            $_POST['feed_menu_enable'] = (isset($_POST['feed_menu_enable']) ? 'checked' : '');

            $data = $_POST;
            tide_settings_save(RSS_SETTINGS, $data);
        } else {
            global $rss_settings;
            $data = $rss_settings;
        }

        $lang_array = installed_languages();
        $data['feed_lang'] = construct_dropdown('feed_lang', 'text', $lang_array, $data['feed_lang']);

        $feed = array_merge(range(1, 10), range(15, 40, 5));
        $data['feed_num'] = construct_dropdown('feed_num', 'text', $feed, $data['feed_num']);

        $data['icon'] = SITE_URL . 'plugins/tide_news/icons/' . $data['feed_icon'];

        $icons = get_files(PLUGIN_PATH . '/icons', '.png', true);
        $data['feed_icon'] = construct_dropdown('feed_icon', 'text', $icons, $data['feed_icon']);

        $images_list = get_files(GSDATAPATH . '/uploads', '', true);

        if (!$images_list) {
            $data['upload_image'] = upload_image();
            $data['feed_images'] = '';
            $data['image'] = '';
        } else {
            $data['upload_image'] = upload_image();
            $data['feed_images'] = construct_dropdown('feed_image', 'text', $images_list, basename($data['feed_image']));
            $data['image'] = '<img id="feed_im_prew" src="' . SITE_URL . 'data/uploads/' . $data['feed_image'] . '" alt="image" />';
        }

        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_rss.tpl', $data);
    }

#-------------------------------- DONE------------------------------------ 
#News Menu Settings
#-------------------------------- DONE------------------------------------ 

    function tidenews_news_menu_settings() {
        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);
            $_POST['menu_enable'] = (isset($_POST['menu_enable']) ? 'checked' : '');

            $data = $_POST;
            tide_settings_save(MENU_SETTINGS, $data);
        } else {
            global $menu_settings;
            $data = $menu_settings;
        }

        $pages_num = range(1, 10);
        $data['menu_news_number'] = construct_dropdown('menu_news_number', 'text', $pages_num, $data['menu_news_number']);

//        $menu_man = array(i18n_r('tide_news/S_MENU_WARP'), i18n_r('tide_news/S_MENU_CUT'));
//        $data['menu_man'] = construct_dropdown('menu_man', 'text', $menu_man, $data['menu_man']);

        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_news_menu.tpl', $data);
    }

#-------------------------------- DONE------------------------------------ 
#General  Settings 
#-------------------------------- DONE------------------------------------ 

    function tidenews_general_settings() {
        global $general_settings;
        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);
            $_POST['external_comments'] = (isset($_POST['external_comments']) ? 'checked' : '');
            $_POST['duplicate_name'] = (isset($_POST['duplicate_name']) ? 'checked' : '');
            $r = array();
            if ($_POST['old_master_page'] !== $_POST['all_news_page']) {
                $news_index = os_separator(NEWS_DIR . 'news/news_index.xml');

                $index = xml_content_array($news_index, true);
                for ($i = 0; $i < $index['nodes']; $i++) {
                    $link['link'] = str_replace($_POST['old_master_page'], $_POST['all_news_page'], $index['data'][$i]['link']);
                    $r[] = tide_xml_node_update($news_index, $link, 'item', 'id', $index['data'][$i]['@attributes']['id'], false);
                }
                $old_master = GSDATAPATH . 'pages/' . $_POST['old_master_page'] . '.xml';
                $new_master = GSDATAPATH . 'pages/' . $_POST['all_news_page'] . '.xml';

                $r[] = tide_update_page($new_master, 'master');
                $r[] = tide_remove_code($old_master);
            }

            $res = tide_check($r);
            $data = $_POST;
            if ($res) {
                tide_settings_save(GENERAL_SETTINGS, $data);
            } else {
                echo get_messages(false, '', i18n_r('tide_news/S_NEWS_MASTER_ERROR'));
            }
            $general_settings['all_news_page'] = $_POST['all_news_page'];
        } else {

            $data = $general_settings;
        }

        $data['old_master_page'] = $data['all_news_page'];

        if (!function_exists('get_external_comments')) {
            $data['external_exist'] = i18n_r('tide_news/S_EXTERNAL') . '
                <a href="http://get-simple.info/extend/plugin/external-commenting/73/">
                 ' . i18n_r('tide_news/S_NEWS_COMM_INT') . '
                </a>';
        } else {
            $data['external_exist'] = i18n_r('tide_news/S_EXTERNAL_INSTALLED') . '
                <a href="load.php?id=external_comments">
                 ' . i18n_r('tide_news/S_NEWS_COMM_INT') . '
                </a>';
        }
        $data['external_comments'] = '';
        $news_number = array_merge(range(1, 10), range(15, 40, 5));
        $data['news_page_number'] = construct_dropdown('news_page_number', 'text', $news_number, $data['news_page_number']);


        $pages = array_merge(array($general_settings['all_news_page'] => 'Default Page'), tide_pages_category());

        $data['all_news_page'] = construct_dropdown('all_news_page', 'text', $pages, $data['all_news_page'], '', true);

        $news_summary = array('pagebreak' => i18n_r('tide_news/S_NEWS_SUMMARY_BREAK'), 'textarea' => i18n_r('tide_news/S_NEWS_SUMMARY_AREA'));
        $data['news_summary'] = construct_dropdown('news_summary', 'text', $news_summary, $data['news_summary'], '', true);

        $slug_separator = array('-' => 'Hyphen ( - )', '_' => 'Underscore ( _ )');
        $data['slug_separator'] = construct_dropdown('slug_separator', 'text', $slug_separator, $data['slug_separator'], '', true);

        $language = country_language_codes();
        $data['language'] = construct_dropdown('language', 'text', $language, $data['language'], '', true);

        $navigation_type = array(i18n_r('tide_news/S_NEWS_PAG_DEF'), i18n_r('tide_news/S_NEWS_PAG_PAG'), i18n_r('tide_news/S_NEWS_PAG_DROP'));
        $data['navigation_type'] = construct_dropdown('navigation_type', 'text', $navigation_type, $data['navigation_type']);


        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_general.tpl', $data);
    }

#-------------------------------- DONE------------------------------------ 
#Save plugin settings
#-------------------------------- DONE------------------------------------ 

    function tide_settings_save($save_path, $data) {
        $result = tide_xml_file($data, $save_path, 'create', false, false, 'item');
        echo get_messages($result, i18n_r('tide_news/S_SAVE_SUCC'), i18n_r('tide_news/S_SAVE_ERROR'));
    }

############################ SETTINGS FUNCTIONS END #######################################################################################
#-------------------------------- DONE------------------------------------
#Show pages list with number of news and show news list by pahe
#-------------------------------- DONE------------------------------------ 

    function tide_show_news($cat) {

        if (!isset($_GET['news_current'])) {
            if ($cat == 'master') {

                global $general_settings;
                $news_index = NEWS_DIR . 'news/news_index.xml';
                $news_data = xml_content_array($news_index, true);

                if (!empty($news_data)) {
                    $news_items = array_reverse($news_data['data']);


                    foreach ($news_items as $key => $val) {
                        $news_items[$key]['link'] = $val['file'];
                    }
                    $category_data = array('pages' => $general_settings['all_news_page']);


                    $txt = tide_news_page_build($news_data['nodes'], $news_items, $category_data);

                    $r = debug_backtrace();

                    if ($r[1]['function'] !== 'eval') {
                        return $txt;
                    } else {
                        echo $txt;
                    }
                } else {

                    return load_template(TIDE_NEWS_TEMPLATES . 'frontend/no_news.tpl');
                }
            } else {
                $category_index = NEWS_DIR . 'category_index.xml';

                $category_data = tide_get_xml_node($category_index, 'item', 'id', $cat);
                if ($category_data['category_visibility'] == 'N') {
                    if (!empty($category_data)) {

                        $news_path = NEWS_DIR . 'category/' . $category_data['category_slug'] . '.xml';
                        $news_index = xml_content_array($news_path, true);

                        if ($news_index['nodes'] > 0) {
                            $news_items = array_reverse($news_index['data']);
                        } else {
                            $news_items = '';
                        }

                        return tide_news_page_build($news_index['nodes'], $news_items, $category_data);
                    } else {

                        return load_template(TIDE_NEWS_TEMPLATES . 'frontend/no_news.tpl');
                    }
                } else {
                    return load_template(TIDE_NEWS_TEMPLATES . 'frontend/private_category.tpl');
                }
            }
        } else {

            $data_link = NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['news_current'] . '.xml';

            return tide_complete_news_build($data_link);
        }
    }

#-------------------------------- DONE------------------------------------ 
# Set News Headers
#-------------------------------- DONE------------------------------------ 

    function tide_set_headers() {

        global $metad;
        global $metak;
        global $title;


        if (isset($_GET['current_news'])) {
            $news_path = NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['current_news'] . '.xml';
            $data = xml_content_array($news_path, false);
        } else {

            $category_index = NEWS_DIR . 'category_index.xml';

            if (!isset($_GET['id'])) {
                $page = 'index';
            } else {
                $page = $_GET['id'];
            }

            $data = tide_xml_search_value($category_index, 'pages', $page);

            if ($data) {
                $data = tide_xml_decode($data);

                $data['title'] = $data['category_title'];
            } else {
                $data = xml_content_array(GSDATAPAGESPATH . $page . '.xml', false);
                $data = tide_xml_decode($data);

                $p = get_page_clean_title(false);

                if (empty($data['metad'])) {
                    $data['metad'] = $p;
                }
                if (empty($data['meta'])) {
                    $data['keywords'] = $p;
                } else {
                    $data['keywords'] = $data['meta'];
                }
                if (empty($data['title'])) {
                    $data['title'] = $p;
                }
            }
        }

        $metad = preg_replace('/[\s]+/', ' ', $data['metad']);
        $metak = $data['keywords'];
        $title = $data['title'];
    }

#-------------------------------- DONE------------------------------------ 
#Archive Menu
#-------------------------------- DONE------------------------------------ 

    function tide_archive_menu($type) {
        $txt = '';
        if ($type == 'general') {
            $arch_path = os_separator(NEWS_DIR . 'archives/');
            $arch = get_files($arch_path, 'xml', true);

            $txt .= '<div class="tide_archive"><h2>' . i18n_r('tide_news/SITE_ARCHIVE_MENU_TITLE') . '</h2><div class="tide_archive_content">';

            if ($arch) {
                foreach ($arch as $key => $val) {

                    $link = archive_url_builder($val, 'general');
                    $txt .= '<a href="' . $link . '"> ' . $val . '</a><br />';
                }

                $txt .= '</div></div>';
            } else {
                $txt .= '<h4>' . i18n_r('tide_news/ARCHIVE_EMPTY') . '</h4>';
                $txt .= '</div></div>';
            }
        } else if ($type == 'category') {

            if (!isset($_GET['id'])) {
                $page = 'index';
            } else {
                $page = $_GET['id'];
            }

            $category_index = NEWS_DIR . 'category_index.xml';
            $data = tide_xml_search_value($category_index, 'pages', $page);

            if (!empty($data)) {

                $data = tide_xml_decode($data);
                $arch_cat_path = os_separator(NEWS_DIR . 'archives/' . $data['category_slug']);
                $arch_cat = get_files($arch_cat_path, 'xml', true);

                $txt = '<div class="tide_archive"><h2>' . i18n_r('tide_news/CATEGORY_ARCHIVE_MENU_TITLE') . '</h2><div class="tide_archive_content">';
                if ($arch_cat) {
                    foreach ($arch_cat as $key => $val) {
                        $link = archive_url_builder($val, $data['category_slug']);
                        $txt .= '<a href="' . $link . '"> ' . $val . '</a>';
                    }
                    $txt .= '</div></div>';
                } else {
                    $txt .= '<h4>' . i18n_r('tide_news/ARCHIVE_EMPTY') . '</h4>';
                    $txt .= '</div></div>';
                }
            }
        } else if ($type == 'all_category') {
            $category_index = os_separator(NEWS_DIR . 'category_index.xml');
            $cat_data = xml_content_array($category_index, true);

            $txt = '<div class="tide_archive"><h2>' . i18n_r('tide_news/CATEGORY_ARCHIVE_MENU_TITLE') . '</h2><div class="tide_archive_content">';
            if (!empty($cat_data)) {
                foreach ($cat_data['data'] as $key => $val) {
                    $txt .= '<div class="tide_archive_category_title">' . i18n_r('tide_news/CATEGORY_ARCHIVE_SUBMENU') . ' ' . $val['category_title'] . '</div>';

                    $arch_cat_path = NEWS_DIR . 'archives/' . $val['category_slug'];
                    $arch_cat = get_files($arch_cat_path, 'xml', true);
                    $c = count($arch_cat);
                    if ($c > 0) {
                        for ($i = 0; $i < $c; $i++) {
                            $txt .= '<a href="' . SITE_URL . 'index.php?id=archive&amp;tide_archive=' . $arch_cat[$i] . '&amp;category=' . $val['category_slug'] . '"> ' . $arch_cat[$i] . '</a><br />';
                        }
                    } else {
                        $txt .= '<h4>' . i18n_r('tide_news/ARCHIVE_EMPTY') . '</h4>';
                    }
                    $txt .= '</div></div>';
                }
            } else {
                $txt .= '<h4>' . i18n_r('tide_news/ARCHIVE_EMPTY') . '</h4></div></div>';
            }
        }
        $r = debug_backtrace();

        if ($r[1]['function'] == 'call_user_func' || $r[1]['function'] == 'tide_archive') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE------------------------------------
#Archive Page
#-------------------------------- DONE------------------------------------

    function tide_archive($data) {

        if (!isset($data['category'])) {

            $data['site'] = tide_archive_menu('all_category');
            $data['general'] = tide_archive_menu('general');
            $txt = load_template(TIDE_NEWS_TEMPLATES . 'frontend/archives.tpl', $data);
            $r = debug_backtrace();

            if ($r[1]['function'] !== 'eval') {
                return $txt;
            } else {
                echo $txt;
            }
        } else {

            if (!isset($_GET['news_current'])) {

                if ($data['category'] == 'general') {
                    $arch_path = os_separator(NEWS_DIR . 'archives/' . $data['tide_archive'] . '.xml');
                } else {
                    $arch_path = os_separator(NEWS_DIR . 'archives/' . $data['category'] . '/' . $data['tide_archive'] . '.xml');
                }

                $news_index = xml_content_array($arch_path, true);

                foreach ($news_index['data'] as $key => $val) {
                    $news_items[$key]['file'] = $val;
                }

                $news_items = array_reverse($news_items);
                $category_data = array('pages' => 'archive');

                return tide_news_page_build($news_index['nodes'], $news_items, $category_data, 'tide_archive=' . $data['tide_archive'] . '');
            } else {

                $data_link = os_separator(NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['news_current'] . '.xml');
                return tide_complete_news_build($data_link);
            }
        }
    }

#-------------------------------- DONE------------------------------------
#Rss Management Subnavigation
#-------------------------------- DONE------------------------------------

    function tide_rss_management_nav() {

        if (isset($_GET['subpage'])) {
            $selected = $_GET['subpage'];
        } else {
            $selected = 'tide_rss_management';
        }

        $subpages = array('tide_rss_management' => 'RSS Feed List');

        if (isset($_GET['subpage']) && $_GET['subpage'] == 'tide_rss_manual_create') {
            $subpages['tide_rss_manual_create'] = 'Generate RSS Feed';
        }

        $menu = '<div class="edit-nav" style="padding-bottom: 25px;">';

        foreach ($subpages as $key => $value) {

            if ($selected == $key) {
                $menu .= '<a class="current" >' . $value . '</a>';
            } else {
                $menu .= '<a href="load.php?id=tide_news&amp;tide_rss_management&amp;subpage=' . $key . '">' . $value . '</a>';
            }
        }

        $menu .= '</div>';

        echo $menu;
    }

#-------------------------------- DONE------------------------------------
#Generate RSS feed - direct access and generation every time you create or edir some news
#-------------------------------- DONE------------------------------------

    function tide_rss_management() {

        if (isset($_POST['tide_generate_rss'])) {

            $order = explode(',', $_POST['order']);
            unset($_POST['tide_generate_rss']);
            $category = $_POST['category'];
            $category_title = $_POST['category_title'];
            unset($_POST['category']);
            unset($_POST['category_title']);

            if (count($_POST) > 0) {

                foreach ($order as $key => $val) {
                    $data[] = $_POST['id_' . $val];
                }

                $result = create_rss($category, $data, $category_title);

                echo get_messages($result, $category . ' ' . i18n_r('tide_news/RSS_UPDATE_SUCC'), i18n_r('tide_news/RSS_UPDATE_ERROR_S') . '  ' . $category_title . '  ' . i18n_r('tide_news/RSS_UPDATE_ERROR_E'));
            } else {
                echo get_messages(false, '', i18n_r('tide_news/RSS_UPDATE_EMPTY'));
            }
        }

        if (!isset($_GET['subpage']) || $_GET['subpage'] == 'tide_rss_management') {

            $category_index = os_separator(NEWS_DIR . 'category_index.xml');
            $category_items = xml_content_array($category_index, true);

            echo'<div class="tide_logo_admin"><img src="' . SITE_URL . 'plugins/TIDEGetSimple/images/TIDEngine.ico" /></div>
                    <h3 class="tide_title_admin">' . i18n_r('tide_news/RSS_MANAGEMENT_TITLE') . ' - <i style="color: #999"> Choose RSS Feed </i> </h3>';
            echo tide_rss_management_nav();
            echo '<div class="tide_rss_choose"><a href="load.php?id=tide_news&amp;tide_rss_management&amp;subpage=tide_rss_manual_create&amp;category=general">General RSS Feed</a></div>';

            foreach ($category_items['data'] as $key) {
                echo '<div class="tide_rss_choose"><a href="load.php?id=tide_news&amp;tide_rss_management&amp;subpage=tide_rss_manual_create&amp;category=' . $key['category_slug'] . '&amp;category_title=' . $key['category_title'] . '">' . $key['category_title'] . ' Category RSS Feed</a></div>';
            }
            echo '<div class="clearfix"></div>';
        } else {
            tide_rss_manual_create();
        }
    }

#-------------------------------- DONE------------------------------------
#RSS Feed Creation   
#-------------------------------- DONE------------------------------------

    function tide_rss_manual_create() {
        global $general_settings;
        global $rss_settings;

        if (!isset($_GET['category']) || $_GET['category'] == 'general') {
            $path = os_separator(NEWS_RSS_DIR . 'general.xml');
            $news_index = os_separator(NEWS_DIR . 'news/news_index.xml');
            $type = 'general';
            $category = i18n_r('tide_news/RSS_CATEGORY_GENERAL');
        } else {
            $path = os_separator(NEWS_RSS_DIR . $_GET['category'] . '.xml');
            $news_index = os_separator(NEWS_DIR . 'category/' . $_GET['category'] . '.xml');
            $type = $_GET['category'];
            $category = $_GET['category_title'] . ' ' . i18n_r('tide_news/RSS_CATEGORY_CATEGORY');
        }

        $news_items = xml_content_array($news_index, true);

        $news_number = $news_items['nodes'];
        $data = $news_items['data'];

        if ($news_number > $rss_settings['feed_num']) {
            $data = array_slice($data, 0, $rss_settings['feed_num']);
            $news_number = $rss_settings['feed_num'];
        }

        echo '<div class="tide_logo_admin"><img src="' . SITE_URL . 'plugins/TIDEGetSimple/images/TIDEngine.ico" /></div>
                <h3 class="tide_title_admin">' . i18n_r('tide_news/RSS_MANAGEMENT_TITLE') . ' <i style="color: #999">' . ucfirst($category) . ' </i> </h3>';
        echo tide_rss_management_nav();
        $text = '<form class="largeform" id="rss" action="load.php?id=tide_news&amp;tide_rss_management" method="post" accept-charset="utf-8">
                <table class="highlight" id="rss_list">
                <thead>
                    <tr style="background-color: #ccc">
                        <th>' . i18n_r('tide_news/NEWS_TABLE_TITLE') . '</th>
                        <th  style="width: 150px;">' . i18n_r('tide_news/NEWS_TABLE_DATE') . '</th>
                        <th>' . i18n_r('tide_news/NEWS_DEL') . '</th>
                  </thead>
                  <tbody>
                   ';
        $start = 0;
        $times_loop = 10000;
        $show_per_page = 10000;

        if ($news_number > 0) {

            if (!empty($_GET['page'])) {

                if ($_GET['page'] > 1) {
                    $start = ($_GET['page'] - 1) * $show_per_page;
                }

                $times_loop = $times_loop + $start;

                if ($times_loop > $news_number) {
                    $times_loop = $news_number;
                }
            } else {
                if ($news_number <= $times_loop) {
                    $times_loop = $news_number;
                }
                $current_page = 1;
            }

            for ($i = $start; $i < $times_loop; $i++) {

                if (strlen($data[$i]['title']) > 60) {
                    $data[$i]['title'] = substr($data[$i]['title'], 0, 60);
                }

                $file[] = "<input type='hidden'  name='id_" . $i . "' id='id_" . $i . "' value='" . $data[$i]['file'] . "' />";

                $text .= '                    
                        <tr style="cursor: pointer" id="' . $i . '">
                        <td class="pagetitle" style="width: 60%">' . $data[$i]['title'] . '</td>
                        <td  style="width: 150px;">
                            <span>' . $data[$i]['date'] . '</span>
                        </td>
                        <td class="delete">
                            <a href="' . $i . '">&#215;</a>
                        </td>
                </tr>';
            }

            $text .= '</tbody></table>                     
                    <p id="submit_line">
                            <input class="submit" type="submit" value="' . i18n_r('tide_news/RSS_GENERATE') . '" name="tide_generate_rss"   title="' . i18n_r('tide_news/RSS_GENERATE') . '">
                            <a href="load.php?id=tide_news&amp;tide_rss_management&amp;subpage=tide_rss_management" class="cancel" id="cancel_edit" title="Cancel">Cancel</a>
                    </p>';
            $text .= "<input type='hidden' name='category' id='category' value='" . $type . "' />";
            $text .= "<input type='hidden' name='category_title' id='category_title' value='" . $type . "' />";

            $text .= "<input type='hidden' name='order' id='order' value='' />";
            foreach ($file as $key => $val) {
                $text .= $val;
            }
            $text .= '</form>';
        } else {
            $text .= '<tr><td colspan="4"><h2>' . i18n_r('tide_news/NO_NEWS') . '</h2></td></tr>';
            $text .= '</table>                    
                        
            </form>';
        }
        $last = ceil($news_number / $show_per_page);

        if (empty($_GET['page_number'])) {
            $current_page = 1;
        } else {
            $current_page = $_GET['page_number'];
        }
        $type = '&category=' . $type . '&category_title=' . $category;
        if ($show_per_page < $news_number) {
            $pages_array = nav_drop_down($category, range(0, $last));
            $data = nav_old_new($last, $current_page, $type, 'nav_rss_admin');

            $text .= load_template(TIDE_NEWS_TEMPLATES . 'backend/nav_default.tpl', $data);
            $text .= '<br /><br />';
        }

        echo $text;
    }

#-------------------------------- DONE------------------------------------
#Show RSS Feed you must have page named RSS and use rss.php as template
#-------------------------------- DONE------------------------------------

    function tide_rss_feed($page) {

        $rss = file_get_contents(NEWS_RSS_DIR . $page . '.xml');

        echo $rss;
    }

#-------------------------------- DONE------------------------------------
#Add RSS Feed menu add code 
#-------------------------------- DONE------------------------------------

    function tide_rss_feed_menu($page) {

        global $rss_settings;
        if ($rss_settings['feed_menu_enable'] == 'checked') {

            $settings['feed_icon'] = SITE_URL . 'plugins/tide_news/icons/' . $rss_settings['feed_icon'];

            if ($page !== 'general') {

                if (!empty($rss_settings['category_feed_title'])) {
                    $settings['feed_title'] = $rss_settings['category_feed_title'];
                } else {
                    $settings['feed_title'] = i18n_r('tide_news/RSS_CATEGORY_CATEGORY');
                }

                if (!isset($_GET['id'])) {
                    $page = 'index';
                } else {
                    $page = $_GET['id'];
                }

                $category_index = NEWS_DIR . 'category_index.xml';
                $data = tide_xml_search_value($category_index, 'pages', $page);

                if (!empty($data)) {
                    $data = tide_xml_decode($data);

                    $page = $data['category_slug'];

                    $settings['feed_description'] = $data['metad'];
                    $link = rss_buider($page);
                    $settings['link'] = '<a href="' . $link . '"><img src="' . $settings['feed_icon'] . '" alt="rss_feed" /></a>';
                } else {
                    $settings['feed_description'] = 'NO RSS CREATED';
                    $settings['link'] = '<img src="' . $settings['feed_icon'] . '" alt="rss_feed" />';
                }
            } else {

                if (!empty($rss_settings['feed_menu_title'])) {
                    $settings['feed_title'] = $rss_settings['feed_menu_title'];
                } else {
                    $settings['feed_title'] = i18n_r('tide_news/RSS_CATEGORY_GENERAL');
                }

                if (file_exists(GSDATAOTHERPATH . 'tide_news_feed/general.xml')) {
                    if (!empty($rss_settings['feed_description'])) {
                        $settings['feed_description'] = $rss_settings['feed_description'];
                    } else {
                        $settings['feed_description'] = $rss_settings['feed_description'];
                    }
                    $link = rss_buider($page);
                    $settings['link'] = '<a href="' . $link . '"><img src="' . $settings['feed_icon'] . '" alt="rss_feed" /></a>';
                } else {
                    $settings['feed_description'] = 'NO RSS CREATED';
                    $settings['link'] = '<img src="' . $settings['feed_icon'] . '" alt="rss_feed" />';
                }
            }
        } else {

            $settings['link'] = '<img src="' . $settings['feed_icon'] . '" alt="rss_feed" />';
            $settings['feed_description'] = i18n_r('tide_news/S_RSS_DISABLED');
        }

        $txt = load_template(TIDE_NEWS_TEMPLATES . 'frontend/rss_menu.tpl', '', $settings);

        $r = debug_backtrace();
        if ($r[1]['function'] == 'call_user_func') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE ------------------------------------ 
#latest news menu for pages add code 
#-------------------------------- DONE ------------------------------------ 

    function tide_news_menu($type) {
        global $general_settings;
        global $menu_settings;

        if ($menu_settings['menu_enable'] == 'checked') {
            $news_index = NEWS_DIR . 'news/news_index.xml';
            $news_data = xml_content_array($news_index, true);

            $txt = '<div class="tide_news_menu"><h2>' . $menu_settings['menu_title'] . '</h2><div class="tide_news_menu_content">';

            if (!empty($news_data['data'])) {
                $news_data['data'] = array_reverse($news_data['data']);
                $news_data['data'] = array_slice($news_data['data'], 0, $menu_settings['menu_news_number']);
                foreach ($news_data['data'] as $key => $val) {
                    if (strlen($val['title']) > $menu_settings['menu_title_lenght']) {
                        $val['title'] = substr($val['title'], 0, $menu_settings['menu_title_lenght']) . '...';
                    }
                    if (PRETTY_URLS == '1') {
                        $val['link'] = convert_url($val['link']);
                    }

                    $txt .= '<div class="tide_news_menu_item"><div class="tide_news_menu_item_title"><a href="' . htmlspecialchars($val['link']) . '"> ' . $val['title'] . '</a><span class="tide_news_menu_category">' . i18n_r('tide_news/INFO_CATEGORY') . ': ' . $val['category'] . '</span></div>';

                    if ($type == 'menu') {
                        if (!empty($val['summary'])) {
                            $val['summary'] = tide_reduce_text($val['summary'], $menu_settings['menu_content_lenght']);
                        } else {
                            $val['summary'] = '';
                        }
                        $txt .= ' <div class="tide_news_menu_summary">' . $val['summary'] . '...</div>
                        <div class="tide_news_menu_posted"> ' . i18n_r('tide_news/NEWS_DATE') . ' ' . $val['date'] . '</div>  
                        </div>';
                    } else if ($type == 'summary') {
                        $txt .= ' <div class="tide_news_menu_summary">' . $val['summary'] . '
                        </div>
                        <div class="tide_news_menu_posted"> ' . i18n_r('tide_news/NEWS_DATE') . ' ' . $val['date'] . '</div>  
                        </div>';
                    }
                }

                if (PRETTY_URLS == '1') {
                    $latest_news_page = SITE_URL . $general_settings['all_news_page'];
                } else {
                    $latest_news_page = SITE_URL . 'index.php?id=' . $general_settings['all_news_page'];
                }

                $txt .= '<div class="tide_news_menu_all"><a href="' . $latest_news_page . '">' . i18n_r('tide_news/NEWS_SEE_ALL') . '</a></div>
                    <div class="clearfix"></div>';
            } else {
                $txt .= '<h4>' . i18n_r('tide_news/NEWS_EMPTY') . '</h4>';
            }
        } else {
            $txt .= '<div class="tide_news_menu"><h2>' . i18n_r('tide_news/S_NEWS_DISABLED') . '</h2></div>';
        }
        $txt .= '</div></div>';
        $r = debug_backtrace();
        if ($r[1]['function'] == 'call_user_func') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE ------------------------------------ 
# Tags Menu
#-------------------------------- DONE ------------------------------------ 

    function tide_tags_menu($tag) {
        global $tags_settings;
        $category = '';
        $control = true;
        $tags = '';

        if ($tag == 'general') {
            $tags_dir = NEWS_DIR . 'tags';
            $tags = get_files($tags_dir, 'xml', true, true);
            if (!empty($tags_settings['tags_title'])) {
                $menu_title = $tags_settings['tags_title'];
            } else {
                $menu_title = i18n_r('tide_news/TAGS_MENU_GENERAL');
            }
        } else {
            if ($tag == 'category') {
                if (!isset($_GET['id'])) {
                    $page = 'index';
                } else {
                    $page = $_GET['id'];
                }

                if ($page !== 'tags' && $page !== 'archive') {
                    $category_index = NEWS_DIR . 'category_index.xml';
                    $data = tide_xml_search_value($category_index, 'pages', $page);

                    if (!empty($data)) {
                        $data = tide_xml_decode($data);
                        $category = $data['category_slug'];
                    } else {
                        $control = false;
                    }
                } else {
                    $control = false;
                }
            } else {
                $category = $tag;
            }

            if (!empty($data)) {
                if (!empty($tags_settings['tags_title_category'])) {
                    $menu_title = $tags_settings['tags_title_category'];
                } else {
                    $menu_title = $data['category_title'] . ' ' . i18n_r('tide_news/TAGS_MENU_CATEGORY');
                }

                $cat_tags_path = NEWS_DIR . 'tags/' . $category;
                $tags = get_files($cat_tags_path, 'xml', true, true);
            }
        }

        $tags_num = count($tags);


        if ($control) {
            $txt = '<div class="tide_tags_menu_holder"><h2>' . $menu_title . '</h2><div class="tagcloud" style="font-family: ' . $tags_settings['tags_font'] . ';">';

            if ($tags_num > 0) {
                foreach ($tags as $key => $val) {
                    $tags_size[$key] = tide_count_nodes($val, 'item');
                }

                $tags_sum = array_sum($tags_size);

                foreach ($tags_size as $key => $val) {
                    if ($val > $tags_settings['tags_occurence']) {
                        if ($tags_settings['tags_size'] == 'proportional') {
                            $tags_size[$key] = floor(($val / $tags_sum) * 100);
                        } else if ($tags_settings['tags_size'] == 'random') {
                            $tags_size[$key] = rand(1, 100);
                        }

                        $link = tags_url_builder($key, true, $category);

                        $color = get_tag_color($tags_size[$key], '#' . $tags_settings['tags_menu_start_color'] . '', '#' . $tags_settings['tags_menu_end_color'] . '');
                        $font = floor((($tags_settings['tags_font_size_max'] - $tags_settings['tags_font_size_min']) * $tags_size[$key]) / 100) + $tags_settings['tags_font_size_min'];
                        $txt .= '<span class="tide_tag_item" ><a href="' . $link . '" style="color: #' . $color . '; font-size: ' . $font . 'px;">' . $key . '</a></span>';
                    }
                }
            } else {
                $txt .= '<span class="tide_tag_item" style="margin-top:30px;"><p style="color: #FF0000; font-size: 25px;line-height: 30px;">' . i18n_r('tide_news/S_TAGS_NO') . '</p></span>';
            }
            $txt .= '<div class="clearfix"></div></div>';
            $txt .= '</div>';
            $r = debug_backtrace();

            if ($r[1]['function'] == 'call_user_func' || $r[1]['function'] == 'tide_tags') {
                return $txt;
            } else {
                echo $txt;
            }
        }
    }

#-------------------------------- DONE ------------------------------------ 
# Tags Page
#-------------------------------- DONE ------------------------------------ 

    function tide_tags($tags) {
        if (!empty($tags)) {
            $tags['tide_tags'] = $_GET['tide_tags'];
        }
        if (isset($tags['tide_tags'])) {
            if (!isset($_GET['news_current'])) {
                if (isset($tags['category'])) {
                    $tags_path = NEWS_DIR . 'tags/' . $tags['category'] . '/' . $tags['tide_tags'] . '.xml';
                    $c = $tags['category'];
                } else {
                    $tags_path = NEWS_DIR . 'tags/' . $tags['tide_tags'] . '.xml';
                    $c = 'general';
                }

                $tags_index = xml_content_array($tags_path, true);

                foreach ($tags_index['data'] as $key => $val) {
                    $tags_items[$key]['file'] = $val;
                }
                $category_data = array('pages' => 'tags');

                $txt = tide_news_page_build($tags_index['nodes'], $tags_items, $category_data, 'tide_tags=' . $tags['tide_tags'] . '&amp;type=' . $c . '');
            } else {
                $data_link = NEWS_DIR . 'news/' . $_GET['category'] . '/' . $_GET['news_current'] . '.xml';
                $txt = tide_complete_news_build($data_link);
            }
        } else {
            $txt = tide_tags_menu('general');
        }
        $r = debug_backtrace();

        if ($r[1]['function'] == 'call_user_func' || $r[1]['function'] == 'tide_tags') {
            return $txt;
        } else {
            echo $txt;
        }
    }

#-------------------------------- DONE ------------------------------------ 
# Tags Menu Example for settings selection
#-------------------------------- DONE ------------------------------------ 

    function tide_tags_example() {
        $tags_settings = xml_content_array(TAGS_SETTINGS, false);
        $data = $tags_settings;
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/tags_example_menu.tpl', $data);
    }

#-------------------------------- DONE ------------------------------------ 
# News Breadcrumbs
#-------------------------------- DONE ------------------------------------ 

    function tide_news_breadcrumbs() {

        if (!isset($_GET['id'])) {
            $_GET['id'] = 'index';
        }

        $start_page = '<div class="tide_breadcrumbs_holder" ><div class="tide_breadcrumbs" ><a href="' . SITE_URL . '">Home</a></div>';

        if (isset($_GET['id']) && $_GET['id'] !== 'index') {

            $page_data = xml_content_array(GSDATAPAGESPATH . $_GET['id'] . '.xml', false);


            if (!empty($page_data['parent'])) {
                $page_data_parent = xml_content_array(GSDATAPAGESPATH . $page_data['parent'] . '.xml', false);

                if ($page_data_parent['parent']) {
                    $page_data_parent_1 = get_settings(GSDATAPAGESPATH . $page_data_parent['parent'] . '.xml');

                    if ($page_data_parent_1['parent']) {
                        $page_data_parent_2 = get_settings(GSDATAPAGESPATH . $page_data_parent['parent'] . '.xml');
                        if ($page_data_parent_2['parent'] !== 'index') {
                            $start_page .= '&nbsp;&bull;&nbsp; <a href="' . find_url($page_data_parent_2['url'], '') . '">' . $page_data_parent_2['title'] . '</a></div>';
                        }
                    }
                    if ($page_data_parent_1['parent'] !== 'index') {
                        $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;<a href="' . find_url($page_data_parent_1['url'], '') . '">' . $page_data_parent_1['title'] . '</a></div>';
                    }
                }
                if ($page_data['parent'] !== 'index') {
                    $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;<a href="' . find_url($page_data_parent['url'], '') . '">' . $page_data_parent['title'] . '</a></div>';
                }
            }

            $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;<a href="' . find_url($_GET['id'], '') . '">' . $page_data['title'] . '</a></div>';
        }


        if (isset($_GET['page_number'])) {

            $num = $_GET['page_number'];

            $url = nav_drop_down($_GET['id'], array($num));
            if (empty($_GET['news_current'])) {
                $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;' . $num . '</div>';
            } else {
                $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;<a href="' . $url[0] . '">' . $num . '</a></div>';
            }
        } else {

            global $general_settings;

            $category_index = NEWS_DIR . 'category_index.xml';

            if (!isset($_GET['id'])) {
                $page = 'index';
            } else {
                $page = $_GET['id'];
            }

            $cat = tide_xml_search_value($category_index, 'pages', $page);

            if ($cat) {
                $cat = tide_xml_decode($cat);

                $news_cat_data = NEWS_DIR . 'category/' . $cat['category_slug'] . '.xml';

                $news_number = tide_count_nodes($news_cat_data, 'item');
                $news_page_num = ceil($news_number / $general_settings['news_page_number']);

                global $general_settings;
                if ($news_page_num > 0) {
                    if ($general_settings['news_page_number'] < $news_number) {
                        $url = nav_drop_down($_GET['id'], array(0));
                        if (empty($_GET['news_current'])) {
                            $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;1</div>';
                        } else {
                            $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;<a href="' . $url[0] . '">1</a></div>';
                        }
                    }
                }
            }
        }
        if (isset($_GET['tide_archive'])) {
            if ($_GET['category'] == 'general') {
                $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;Site Archive&nbsp;&bull;&nbsp;' . $_GET['tide_archive'] . '</div>';
            } else {
                $category_index = NEWS_DIR . 'category_index.xml';
                $cat = tide_xml_search_value($category_index, 'category_slug', $_GET['category']);
                $cat = tide_xml_decode($cat);

                $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;' . $cat['category_title'] . '&nbsp;&bull;&nbsp;' . $_GET['tide_archive'] . '</div>';
            }
        }
        if (isset($_GET['tide_tags'])) {
            $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&bull;&nbsp;' . $_GET['tide_tags'] . '</div>';
        }

        if (isset($_GET['news_current'])) {
            $_GET['news_current'] = str_replace('/', '', $_GET['news_current']);
            $start_page .= '<div class="tide_breadcrumbs" >&nbsp;&nbsp;&bull;&nbsp;&nbsp;' . $_GET['news_current'] . '</div>';
        }
        $start_page .= '</div>';

        return $start_page;
    }

#-------------------------------- DONE ------------------------------------ 
# Plugin Help
#-------------------------------- DONE ------------------------------------ 

    function tide_help() {
        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/tide_help.tpl', '');
    }

    function country_language_codes() {
        $os = PHP_OS;

        $country_language = array(
            'prs_AF' => 'Afghanistan - Dari',
            'ps_AF' => 'Afghanistan - Pashto',
            'sq_AL' => 'Albania - Albanian',
            'ar_DZ' => 'Algeria - Arabic',
            'tzm_DZ' => 'Algeria - Tamazight (Latin)',
            'es_AR' => 'Argentina - Spanish',
            'hy_AM' => 'Armenia - Armenian',
            'en_AU' => 'Australia - English',
            'de_AT' => 'Austria - German',
            'az_AZ' => 'Azerbaijan - Azeri (Latin)',
            'ar_BH' => 'Bahrain - Arabic',
            'bn_BD' => 'Bangladesh - Bengali',
            'be_BY' => 'Belarus - Belarusian',
            'nl_BE' => 'Belgium - Dutch',
            'fr_BE' => 'Belgium - French',
            'en_BZ' => 'Belize - English',
            'es_VE' => 'Bolivarian Republic of Venezuela - Spanish',
            'quz_BO' => 'Bolivia - Quechua',
            'es_BO' => 'Bolivia - Spanish',
            'bs_BA' => 'Bosnia and Herzegovina - Bosnian (Latin)',
            'hr_BA' => 'Bosnia and Herzegovina - Croatian',
            'sr_BA' => 'Bosnia and Herzegovina - Serbian (Latin)',
            'pt_BR' => 'Brazil - Portuguese',
            'ms_BN' => 'Brunei Darussalam - Malay',
            'bg_BG' => 'Bulgaria - Bulgarian',
            'km_KH' => 'Cambodia - Khmer',
            'en_CA' => 'Canada - English',
            'fr_CA' => 'Canada - French',
            'iu_CA' => 'Canada - Inuktitut (Syllabics)',
            'moh_CA' => 'Canada - Mohawk',
            'en-029' => 'Caribbean - English',
            'arn_CL' => 'Chile - Mapudungun',
            'es_CL' => 'Chile - Spanish',
            'es_CO' => 'Colombia - Spanish',
            'es_CR' => 'Costa Rica - Spanish',
            'hr_HR' => 'Croatia - Croatian',
            'cs_CZ' => 'Czech Republic - Czech',
            'da_DK' => 'Denmark - Danish',
            'es_DO' => 'Dominican Republic - Spanish',
            'quz_EC' => 'Ecuador - Quechua',
            'es_EC' => 'Ecuador - Spanish',
            'ar_EG' => 'Egypt - Arabic',
            'es_SV' => 'El Salvador - Spanish',
            'et_EE' => 'Estonia - Estonian',
            'am_ET' => 'Ethiopia - Amharic',
            'fo_FO' => 'Faroe Islands - Faroese',
            'fi_FI' => 'Finland - Finnish',
            'smn_FI' => 'Finland - Sami (Inari)',
            'se_FI' => 'Finland - Sami (Northern)',
            'sms_FI' => 'Finland - Sami (Skolt)',
            'sv_FI' => 'Finland - Swedish',
            'gsw_FR' => 'France - Alsatian',
            'br_FR' => 'France - Breton',
            'co_FR' => 'France - Corsican',
            'fr_FR' => 'France - French',
            'oc_FR' => 'France - Occitan',
            'ka_GE' => 'Georgia - Georgian',
            'de_DE' => 'Germany - German',
            'dsb_DE' => 'Germany - Lower Sorbian',
            'hsb_DE' => 'Germany - Upper Sorbian',
            'el_GR' => 'Greece - Greek',
            'kl_GL' => 'Greenland - Greenlandic',
            'qut_GT' => 'Guatemala - K\'iche',
            'es_GT' => 'Guatemala - Spanish',
            'es_HN' => 'Honduras - Spanish',
            'zh_HK' => 'Hong Kong S.A.R. - Chinese (Traditional)',
            'hu_HU' => 'Hungary - Hungarian',
            'is_IS' => 'Iceland - Icelandic',
            'as_IN' => 'India - Assamese',
            'bn_IN' => 'India - Bengali',
            'en_IN' => 'India - English',
            'gu_IN' => 'India - Gujarati',
            'hi_IN' => 'India - Hindi',
            'kn_IN' => 'India - Kannada',
            'kok_IN' => 'India - Konkani',
            'ml_IN' => 'India - Malayalam',
            'mr_IN' => 'India - Marathi',
            'or_IN' => 'India - Oriya',
            'pa_IN' => 'India - Punjabi',
            'sa_IN' => 'India - Sanskrit',
            'ta_IN' => 'India - Tamil',
            'te_IN' => 'India - Telugu',
            'id_ID' => 'Indonesia - Indonesian',
            'fa_IR' => 'Iran - Persian',
            'ar_IQ' => 'Iraq - Arabic',
            'en_IE' => 'Ireland - English',
            'ga_IE' => 'Ireland - Irish',
            'ur_PK' => 'Islamic Republic of Pakistan - Urdu',
            'he_IL' => 'Israel - Hebrew',
            'it_IT' => 'Italy - Italian',
            'en_JM' => 'Jamaica - English',
            'ja_JP' => 'Japan - Japanese',
            'ar_JO' => 'Jordan - Arabic',
            'kk_KZ' => 'Kazakhstan - Kazakh',
            'sw_KE' => 'Kenya - Kiswahili',
            'ko_KR' => 'Korea - Korean',
            'ar_KW' => 'Kuwait - Arabic',
            'ky_KG' => 'Kyrgyzstan - Kyrgyz',
            'lo_LA' => 'Lao P.D.R. - Lao',
            'lv_LV' => 'Latvia - Latvian',
            'ar_LB' => 'Lebanon - Arabic',
            'ar_LY' => 'Libya - Arabic',
            'de_LI' => 'Liechtenstein - German',
            'lt_LT' => 'Lithuania - Lithuanian',
            'fr_LU' => 'Luxembourg - French',
            'de_LU' => 'Luxembourg - German',
            'lb_LU' => 'Luxembourg - Luxembourgish',
            'zh_MO' => 'Macao S.A.R. - Chinese (Traditional)',
            'mk_MK' => 'Macedonia (FYROM) - Macedonian (FYROM)',
            'en_MY' => 'Malaysia - English',
            'ms_MY' => 'Malaysia - Malay',
            'dv_MV' => 'Maldives - Divehi',
            'mt_MT' => 'Malta - Maltese',
            'es_MX' => 'Mexico - Spanish',
            'mn_MN' => 'Mongolia - Mongolian (Cyrillic)',
            'sr_ME' => 'Montenegro - Serbian (Latin)',
            'ar_MA' => 'Morocco - Arabic',
            'ne_NP' => 'Nepal - Nepali',
            'nl_NL' => 'Netherlands - Dutch',
            'fy_NL' => 'Netherlands - Frisian',
            'en_NZ' => 'New Zealand - English',
            'mi_NZ' => 'New Zealand - Maori',
            'es_NI' => 'Nicaragua - Spanish',
            'ha_NG' => 'Nigeria - Hausa (Latin)',
            'ig_NG' => 'Nigeria - Igbo',
            'yo_NG' => 'Nigeria - Yoruba',
            'nb_NO' => 'Norway - Norwegian (Bokmal)',
            'nn_NO' => 'Norway - Norwegian (Nynorsk)',
            'smj_NO' => 'Norway - Sami (Lule)',
            'se_NO' => 'Norway - Sami (Northern)',
            'sma_NO' => 'Norway - Sami (Southern)',
            'ar_OM' => 'Oman - Arabic',
            'es_PA' => 'Panama - Spanish',
            'es_PY' => 'Paraguay - Spanish',
            'zh_CN' => 'People\'s Republic of China - Chinese (Simplified)',
            'mn_CN' => 'People\'s Republic of China - Mongolian (Traditional)',
            'bo_CN' => 'People\'s Republic of China - Tibetan',
            'ug_CN' => 'People\'s Republic of China - Uyghur',
            'ii_CN' => 'People\'s Republic of China - Yi',
            'quz_PE' => 'Peru - Quechua',
            'es_PE' => 'Peru - Spanish',
            'fil_PH' => 'Philippines - Filipino',
            'pl_PL' => 'Poland - Polish',
            'pt_PT' => 'Portugal - Portuguese',
            'fr_MC' => 'Principality of Monaco - French',
            'es_PR' => 'Puerto Rico - Spanish',
            'ar_QA' => 'Qatar - Arabic',
            'en_PH' => 'Republic of the Philippines - English',
            'ro_RO' => 'Romania - Romanian',
            'ba_RU' => 'Russia - Bashkir',
            'ru_RU' => 'Russia - Russian',
            'tt_RU' => 'Russia - Tatar',
            'sah_RU' => 'Russia - Yakut',
            'rw_RW' => 'Rwanda - Kinyarwanda',
            'ar_SA' => 'Saudi Arabia - Arabic',
            'wo_SN' => 'Senegal - Wolof',
            'sr_RS' => 'Serbia - Serbian (Latin)',
            'sr_CS' => 'Serbia and Montenegro (Former) - Serbian (Latin)',
            'zh_SG' => 'Singapore - Chinese (Simplified)',
            'en_SG' => 'Singapore - English',
            'sk_SK' => 'Slovakia - Slovak',
            'sl_SI' => 'Slovenia - Slovenian',
            'af_ZA' => 'South Africa - Afrikaans',
            'en_ZA' => 'South Africa - English',
            'xh_ZA' => 'South Africa - isiXhosa',
            'zu_ZA' => 'South Africa - isiZulu',
            'nso_ZA' => 'South Africa - Sesotho sa Leboa',
            'tn_ZA' => 'South Africa - Setswana',
            'eu_ES' => 'Spain - Basque',
            'ca_ES' => 'Spain - Catalan',
            'gl_ES' => 'Spain - Galician',
            'es_ES' => 'Spain - Spanish',
            'si_LK' => 'Sri Lanka - Sinhala',
            'smj_SE' => 'Sweden - Sami (Lule)',
            'se_SE' => 'Sweden - Sami (Northern)',
            'sma_SE' => 'Sweden - Sami (Southern)',
            'sv_SE' => 'Sweden - Swedish',
            'fr_CH' => 'Switzerland - French',
            'de_CH' => 'Switzerland - German',
            'it_CH' => 'Switzerland - Italian',
            'rm_CH' => 'Switzerland - Romansh',
            'ar_SY' => 'Syria - Arabic',
            'syr_SY' => 'Syria - Syriac',
            'zh_TW' => 'Taiwan - Chinese (Traditional)',
            'tg_TJ' => 'Tajikistan - Tajik (Cyrillic)',
            'th_TH' => 'Thailand - Thai',
            'en_TT' => 'Trinidad and Tobago - English',
            'ar_TN' => 'Tunisia - Arabic',
            'tr_TR' => 'Turkey - Turkish',
            'tk_TM' => 'Turkmenistan - Turkmen',
            'ar_AE' => 'U.A.E. - Arabic',
            'uk_UA' => 'Ukraine - Ukrainian',
            'en_GB' => 'United Kingdom - English',
            'gd_GB' => 'United Kingdom - Scottish Gaelic',
            'cy_GB' => 'United Kingdom - Welsh',
            'en_US' => 'United States - English',
            'es_US' => 'United States - Spanish',
            'es_UY' => 'Uruguay - Spanish',
            'uz_UZ' => 'Uzbekistan - Uzbek (Latin)',
            'vi_VN' => 'Vietnam - Vietnamese',
            'ar_YE' => 'Yemen - Arabic',
            'en_ZW' => 'Zimbabwe - English'
        );

        $language_code_win = array(
            'chinese' => 'Chinese',
            'chinese-simplified' => 'Chinese (simplified)',
            'chinese-traditional' => 'Chinese (traditional)',
            'czech' => 'Czech',
            'danish' => 'Danish',
            'dutch' => 'Dutch (default)',
            'belgian' => 'Dutch (Belgium)',
            'english' => 'English (default)',
            'australian' => 'English (Australia)',
            'canadian' => 'English (Canada)',
            'english-nz' => 'English (New Zealand)',
            'english-uk' => 'English (United Kingdom)',
            'english-american' => 'English (United States)',
            'french' => 'French (default)',
            'french-belgian' => 'French (Belgium)',
            'french-canadian' => 'French (Canada)',
            'french-swiss' => 'French (Switzerland)',
            'german' => 'German (default)',
            'german-austrian' => 'German (Austria)',
            'german-swiss' => 'German (Switzerland)',
            'greek' => 'Greek',
            'hungarian' => 'Hungarian',
            'icelandic' => 'Icelandic',
            'italian' => 'Italian (default)',
            'italian-swiss' => 'Italian (Switzerland)',
            'japanese' => 'Japanese',
            'korean' => 'Korean',
            'norwegian' => 'Norwegian (default)',
            'norwegian-bokmal' => 'Norwegian (Bokmal)',
            'norwegian-nynorsk' => 'Norwegian (Nynorsk)',
            'polish' => 'Polish',
            'portuguese' => 'Portuguese (default)',
            'portuguese-brazilian' => 'Portuguese (Brazil)',
            'russian' => 'Russian (default)',
            'slovak' => 'Slovak',
            'spanish' => 'Spanish (default)',
            'spanish-mexican' => 'Spanish (Mexico)',
            'spanish-modern' => 'Spanish (Modern)',
            'swedish' => 'Swedish',
            'turkish' => 'Turkish',
        );

        $win = array("WINNT", "WIN32", "Windows");
        if (in_array($os, $win)) {
            return $language_code_win;
        } else {
            return $country_language;
        }
    }

    function tide_gsconfig() {

        global $gsconfig_settings;
        global $cke_languages;
        $data = array();
        $data = $gsconfig_settings;

        if (isset($_POST['tide_settings_save'])) {
            unset($_POST['tide_settings_save']);

            if (isset($_POST['highlighter'])) {
                if ($_POST['highlighter'] == 'yes') {
                    cke_files_copy();
                }
            } else {
                $_POST['highlighter'] = 'yes';
                $_POST['installed'] = 'yes';
            }

            //$_POST['cke_in_use'] = (isset($_POST['cke_in_use']) ? 'checked' : '');

            if ($_POST['cke_in_use'] == 'gs') {

                cke_update_cnfg($_POST['ckeditor_type'], $_POST['cke_data'], $_POST['cke_languages'], $_POST['cke_height']);
            }
//            if($_POST['ckeditor_type'] == 'custom'){
//                // DODATI PROVERU SINTAKSE
//                $_POST['ckeditor_type'] = $_POST['cke_data'];
//            } 
            $data = $_POST;
            tide_settings_save(CKE_SETTINGS, $data);
        }

        $data['images'] = '';
        $img_path = SITE_URL . 'plugins/TIDEGetSimple/images/';

        for ($i = 1; $i < 9; $i++) {
            $data['images'] .= '<img src="' . $img_path . $i . '.jpg" alt="" /><br />';
        }
        $extra = '';
        if ($data['installed'] == 'yes' || $data['highlighter'] == 'yes') {
            $extra = 'disabled="disabled"';
            $highlighter = array('installed' => i18n_r('tide_news/CKE_INSTALLED'));
            $selected = 'installed';
        } else {

            $highlighter = array('yes' => i18n_r('tide_news/CKE_INSTALL'), 'no' => i18n_r('tide_news/CKE_INSTALL_NO'));
            $selected = $settings['highlighter'];
        }
        $cke_in_use = array('gs' => i18n_r('tide_news/CKE_SETTINGS_GS'), 'tide' => i18n_r('tide_news/CKE_SETTINGS_TIDE'));
        $data['cke_in_use'] = construct_dropdown('cke_in_use', 'text', $cke_in_use, $data['cke_in_use'], '', true);

        $data['cke_languages'] = construct_dropdown('cke_languages', 'text', $cke_languages, $data['cke_languages']);

        $data['highlighter'] = construct_dropdown('highlighter', 'text', $highlighter, $selected, $extra, true);
        $highlight_styles = array('shThemeDefault' => 'Default Style', 'shThemeDjango' => 'Django Style', 'shThemeEclipse' => 'Eclipse Style', 'shThemeEmacs' => 'Emacs Style', 'shThemeFadeToGrey' => 'FadeToGrey Style', 'shThemeMDUltra' => 'MDUltra Style', 'shThemeMidnight' => 'Midnight Style', 'shThemeRDark' => 'RDark Style');

        $data['highlight_styles'] = construct_dropdown('highlight_styles', 'text', $highlight_styles, $data['highlight_styles'], '', true);

        $ckeditor_type = array('basic' => i18n_r('tide_news/CKE_BASIC'), 'advanced' => i18n_r('tide_news/CKE_ADV'), 'custom' => i18n_r('tide_news/CKE_CUSTOM'));
        $data['ckeditor_type'] = construct_dropdown('ckeditor_type', 'text', $ckeditor_type, $data['ckeditor_type'], '', true);

        $data['cke_toolbar'] = '';

        $buttons_base_path = SITE_URL . 'plugins/TIDEGetSimple/images/buttons/';
        global $buttons;
        foreach ($buttons as $key => $value) {
            $data['cke_toolbar'] .= '<div class="cke_buttons" id="' . $value . '"><img class="cke_button" src="' . $buttons_base_path . $value . '.png" title="' . $value . '" /></div>';
        }

        echo load_template(TIDE_NEWS_TEMPLATES . 'backend/settings_gsconfig.tpl', $data);
    }

    $buttons = array(
        "removeFormat",
        "redo",
        "readmoreButton",
        "replace",
        "rightJustify",
        "selectAll",
        "save",
        "radioButton",
        "print",
        "pageBreakPrinting",
        "numberedList",
        "newPage",
        "paste",
        "pastePlainText",
        "preview",
        "pasteWord",
        "selectionField",
        "showBlocks",
        "textField",
        "textColor",
        "templates",
        "textarea",
        "underline",
        "unlink",
        "undo",
        "table",
        "superscript",
        "spacer",
        "source",
        "smiley",
        "specialCharacter",
        "strike",
        "subscript",
        "styles",
        "maximize",
        "link",
        "checkbox",
        "checkSpelling",
        "centerJustify",
        "copy",
        "createDivContainer",
        "decreaseIndent",
        "cut",
        "button",
        "bulletedList",
        "bidiLeft",
        "backgroundColor",
        "anchor",
        "bidiRight",
        "blockJustify",
        "bold",
        "blockQuote",
        "drupalbreak",
        "drupalpagebreak",
        "image",
        "iframe",
        "icon",
        "imageButton",
        "increaseIndent",
        "leftJustify",
        "italic",
        "horizontalLine",
        "hiddenField",
        "font",
        "flash",
        "find",
        "fontSize",
        "form",
        "group",
        "format",
        "about",
        "WPMore",
        "syntaxhighlight"
    );
    $cke_languages = array("af", "ar", "bg", "bn", "bs", "ca", "cs", "cy", "da", "de", "el", "en-au", "en-ca", "en-gb", "eo", "es", "et", "eu", "fa", "fi", "fo", "fr-ca", "fr", "gl", "gu", "he", "hi", "hr", "hu", "is", "it", "ja", "ka", "km", "ko", "lt", "lv", "mk", "mn", "ms", "nb", "nl", "no", "pl", "pt-br", "pt", "ro", "ru", "sk", "sl", "sr-latn", "sr", "sv", "th", "tr", "ug", "uk", "vi", "zh-cn", "zh");