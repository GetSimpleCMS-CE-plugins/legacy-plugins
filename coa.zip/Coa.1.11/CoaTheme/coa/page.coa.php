## Page Template

menu
  wrap = <nav><ul> | </ul></nav>
  act = <li class="active"> | </li>

content
  wrap = <main><h2>$title</h2> | </main>

content
  get = sidebar
  wrap = <aside> | </aside>

place
  file = coa/footer.coa.php

## End