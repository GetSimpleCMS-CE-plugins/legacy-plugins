## Footer Template

script
  js = http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js
  
text
  value = <script>window.jQuery || document.write('<script src="theme/$theme/js/jquery-1.10.2.min.js"><\/script>');</script>
  
script
  js = js/main.js
  
## End