## Constant Template

config
  bodyTag = basic
  protMail = 2

main
  title = $siteName: $title
  #language = de
  
meta
  viewport = width=device-width,initial-scale=1.0
  
css
  all = css/crack.min.css

script
  js = js/respondjs+html5shiv.js
  wrap = <!--[if lt IE 9]> | <![endif]-->
  
## End