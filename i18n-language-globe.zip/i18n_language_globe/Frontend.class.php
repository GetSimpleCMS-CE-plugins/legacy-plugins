<?php

class I18nLanguageGlobe {
	static $plugin_id = false;
	static $count = 0;


static function return_language_globe ($text_color, $background_color, $border_color) {
	if (!function_exists('return_i18n_lang_url')) return '';
	self::$count ++;
	$rnd = self::$count;
	$html = self::make_html($rnd);
	$html .= self::make_js($rnd);
	$html .= self::make_css($rnd, $text_color, $background_color, $border_color);
	return $html;
}


private static function i18n_setlang_url($lang) {
	$u = return_i18n_lang_url($lang);
	$u .= (strpos($u,'?') !== false ? '&' : '?') . I18N_SET_LANGUAGE_PARAM . '=' . $lang;
	return $u;
}


private static function make_html($rnd) {
	// param: left, right, dropup, dropdown?
	// maxsize, scroll wenn zuviele?
	if (array_key_exists('language', $GLOBALS)  && !empty($GLOBALS['language'])) {
		$current_language = $GLOBALS['language'];
	} else {
		$current_language = get_default_language();
	}
	$slug = return_page_slug();
	$html = '';

	$html.= '<div class="i18n-language-globe" id="i18n_language_globe_'.$rnd.'" onclick="toggle_i18n_language_globe_'.$rnd.'();">

';
	$html .= '<nav class="i18n-language-globe-nav" id="i18n_language_globe_'.$rnd.'_nav"
	><ul class="i18n-language-globe-list">
	';
	$pagelangs_arr=return_i18n_available_languages($slug);
	sort($pagelangs_arr, SORT_STRING);

	foreach($pagelangs_arr as $lang){
		$langname = self::get_languagename($lang);
		$html .= '<li class="i18n-language-globe-item"'.(($lang==$current_language)?' class="current_language"':'').'><a href="'.htmlspecialchars(self::i18n_setlang_url($lang)).'" class="i18n-language-globe-url">'.$langname.'</a></li>
		';
	} 

	$html .= '</ul></nav>
	<div class="i18n-language-globe-globe"></div><div class="i18n-language-globe-name" >&nbsp;'.self::get_languagename($current_language).'</div>
</div>
';
	$html .= '<div class="i18n-language-globe-area" id="i18n_language_globe_'.$rnd.'_area"
	onclick="hide_i18n_language_globe_'.$rnd.'();"
	onresize="hide_i18n_language_globe_'.$rnd.'();">
</div>
';
	return $html;
}

// js

private static function make_js($rnd) {

$script = '
<script>
function hide_i18n_language_globe_'.$rnd.'() {
	document.getElementById("i18n_language_globe_'.$rnd.'_nav").style.display="none";
	document.getElementById("i18n_language_globe_'.$rnd.'_area").style.display="none";
	return true;
}

function toggle_i18n_language_globe_'.$rnd.'() {
   var a = document.getElementById("i18n_language_globe_'.$rnd.'_area");
   if (a.style.display == "block") a.style.display = "none"; else a.style.display = "block";
   var n = document.getElementById("i18n_language_globe_'.$rnd.'_nav");
   if (n.style.display == "block") n.style.display = "none"; else n.style.display = "block";
   var d = document.getElementById("i18n_language_globe_'.$rnd.'");
   var top = Math.round(d.getBoundingClientRect().top);
   var halfheight = Math.round(window.innerHeight/2);
   if (top > halfheight) {
	   n.style.top = "initial";
	   n.style.bottom = "100%";
  } else {
	   n.style.top = "100%";
	   n.style.bottom = "initial";
   }
   var left = Math.round(d.getBoundingClientRect().left+(d.getBoundingClientRect().width/2));
   var halfwidth = Math.round(window.innerWidth/2);
   if (left > halfwidth) {
	   n.style.left = "initial";
	   n.style.right = "0";
  } else {
	   n.style.left = "0";
	   n.style.right = "initial";
   }
  // window.alert(window.innerWidth+":"+window.innerHeight);
}

</script>
';
return $script;
}

private static function make_css(int $rnd, $text_color, $background_color, $border_color) {
	$css = '<style>
';
	$css .= 'div#i18n_language_globe_'.$rnd.' {
		';
	if (!empty($text_color)) {
		$css .= 'color: '.$text_color.';
		';
	} else {
		$css .= 'color: inherit;
		';
	}
	if (!empty($background_color)) {
		$css .= 'background-color: '.$background_color.';
		';
	} else {
		$css .= 'background-color: inherit;
		';
	}
	$css .= '}
';
	if (!empty($border_color)) {
		$css .= 'nav#i18n_language_globe_'.$rnd.'_nav {
			border-width: 1px; 
			border-style: solid; 
			border-color: '.$border_color.'; 
}
';
	}
	
	$css .= '</style>
';
	return $css;
}

private static function get_languagename($lang) {
	include GSPLUGINPATH.'i18n_language_globe/languages_array.php';

	$lang = strtolower($lang);
	if (!empty($iso_languages_array[$lang])) {
		return $iso_languages_array[$lang];
	}
	return $lang;
}



} // end class

