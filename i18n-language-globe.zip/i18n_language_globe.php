<?php
/*
Plugin Name: I18N Language Globe
Description: For i18n multilanguage sites, a language navigation dropdown with globe
displays each language name in its own language
slug/names display is based on the ISO 639-1 two-letter language codes
Version: 1.0.0
*/
 
# get correct id for plugin
$plugin_id = basename(__FILE__, ".php");


register_plugin(
	$plugin_id,                      //Plugin id
	'I18N Language Globe',           //Plugin name
	'1.0.0', 		                 //Plugin version
	'Astrid Hanssen',                //Plugin author
	'https://astrid-hanssen.de',     //author website
	'Globe with language navigation dropdown',  //Plugin description
	'',                              // nothing to admin, no admin page
	''                               // main function (administration)
);


register_style('i18n-language-globe', '/plugins/i18n_language_globe/css/style.css', '1.0.0', 'screen');
queue_style('i18n-language-globe',GSFRONT);


function return_i18n_language_globe($text_color = null, $background_color = null, $border_color = null) {
	require_once(GSPLUGINPATH.'i18n_language_globe/Frontend.class.php');
	return I18nLanguageGlobe::return_language_globe($text_color, $background_color, $border_color);
}
function get_i18n_language_globe($text_color = null, $background_color = null, $border_color = null) {
	require_once(GSPLUGINPATH.'i18n_language_globe/Frontend.class.php');
	echo I18nLanguageGlobe::return_language_globe($text_color, $background_color, $border_color);
}
