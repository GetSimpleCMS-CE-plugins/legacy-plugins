<?php
/*
Plugin Name: BSG Admin header background
Description: displays a logo in the admin
Version: 1.1
Author: Bertrand Saint-Guillain
Author URI: http://www.bertrandtarot.com/getsimple/
License : GNU GPL v3 http://www.gnu.org/licenses/gpl-3.0.txt
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
$bsg_ahbg_file=GSDATAOTHERPATH .'bsg_ahbg.xml';


# register plugin
register_plugin(
	$thisfile, //Plugin id
	'BSG Admin Header Background', 	//Plugin name
	'1.1', 		//Plugin version
	'Bertrand Saint-Guillain',  //Plugin author
	'http://www.bertrandtarot.com/getsimple/', //author website
	'Set a custom background image for the GetSimple admin pages.', //Plugin description
	'plugins', //page type - on which admin tab to display
	'bsg_ahbg_show'  //main function (administration)
);

# activate filter 
add_action('footer','bsg_styleadminheader'); 
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Admin header background')); 

# get XML data
if (file_exists($bsg_ahbg_file)) {
	$x = getXML($bsg_ahbg_file);
	$bsg_ahbg_image = stripslashes(htmlspecialchars_decode($x->image, ENT_QUOTES));
} else {
	$bsg_ahbg_image='';
}

# functions
function bsg_styleadminheader() {
	global $bsg_ahbg_image;
	if (strlen($bsg_ahbg_image)>0) {
		echo '<style type="text/css" >.header {
			background-image:url('.$bsg_ahbg_image.');
		}</style><a href="http://www.bertrandtarot.com/gs">custom admin header</a> |';
	}
}

function bsg_ahbg_show() {
	global $bsg_ahbg_image;
	global $bsg_ahbg_file;
	global $i18n;
	// submitted form
	if (isset($_POST['submit'])) {
		$bsg_ahbg_image = htmlentities($_POST['bsg_ahbg_image'], ENT_QUOTES, 'UTF-8');
		
		$xml = @new SimpleXMLElement('<item></item>');
		$xml->addChild('image', $bsg_ahbg_image);
		
		if (! $xml->asXML($bsg_ahbg_file)) {
			$error = $i18n['CHMOD_ERROR'];
		} else {
			$x = getXML($bsg_ahbg_file);
			$bsg_ahbg_image = stripslashes(htmlspecialchars_decode($x->image, ENT_QUOTES));
		}
	}
	?>
	<h3>BSG Admin Header Background</h3>
	<p>replace the nice default gradient with any image pattern (leave blank for default gradient). Useful to quickly identify a website if you use many different installations of getsimple !</p>
	<form method="post" action="<?php	echo $_SERVER ['REQUEST_URI']?>">
		<p><b>image uri (http://etc...) or base64 encoded image</b>:<br /><textarea style="height:70px;" name="bsg_ahbg_image" class="shorttext" id="bsg_ahbg_field" ><?php echo @$bsg_ahbg_image; ?></textarea><br />
		<p><input type="submit" id="submit" class="submit" value="Set Admin Header Image" name="submit" /></p>
	</form><p><button id="bsg_ahbg_preview" >preview</button><button  id="bsg_ahbg_clear" >clear</button></p>
		<script>
			$("#bsg_ahbg_preview").click(function () {
				$(".header").css("background-image","url('"+$("#bsg_ahbg_field").val()+"')");
				 function complete() {
					$(this).fadeIn(300,"swing");
				 }
				 $(this).fadeOut(300,"swing",complete);
			});
			$("#bsg_ahbg_clear").click(function () {
				 $("#bsg_ahbg_field").html("");
				 function complete() {
					$(this).fadeIn(300,"swing");
				 }
				 $(this).fadeOut(300,"swing",complete);
			});
		</script>
		<span class="hint">you can also try clicking some of the samples below or create your own at <a href="http://www.patternify.com/">patternify</a>.</span></p>
		<?php
		$samples = array(
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAYAAABWKLW/AAAAGklEQVQImWNgMrH4D8MMTCYW/xk9fBEcGAYA8AEM/nCZV6oAAAAASUVORK5CYII=", // dark water
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAYAAABWKLW/AAAAGklEQVQImWOwtdL4D8MMtlYa/2NC9RAcGAYAFzYOz7Gf0bcAAAAASUVORK5CYII=", // dotted earth
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAADCAYAAABbNsX4AAAAHElEQVQImWNo6V3xPzmz9j8yzYAukJxZCxFExwCJcSRpZL9G5gAAAABJRU5ErkJggg==", // violet waves
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAAECAYAAACk7+45AAAALElEQVQImQXBMQEAMAwCMD5uVOACgRUwDdVRYyzBkN2kOKnPLjbpkMWze1I/CXEPAfpuf3UAAAAASUVORK5CYII=", // red fabric
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAGklEQVQImWPQ1bX4r6tr8Z9BV9fiv4WF038AM9UGZcajQekAAAAASUVORK5CYII=", // grey blue
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAGklEQVQImQXBAQEAAACCoK76yb8GA1KbGtABVIEJu9GNxt0AAAAASUVORK5CYII=", // fuzzy grey
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAGklEQVQImWPQ9LX679qQ+J/BtSHxv6av1X8AQHwHqQvDf+MAAAAASUVORK5CYII=", // green fabric
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFUlEQVQImWNgYGD4D8UM/wX45P8DAB6cBDr2erUvAAAAAElFTkSuQmCC",
	"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAbUlEQVQYlX2QMQ4AIQgE/be1P/ALVMbSSGdtZekDfAhXLeGCdwWBsBM2S6DSBBVTlpiyUGnSx5Q+pmrBQhDXPloOpMoOsnCw16w15l9w7fMNUmW1AuCsAWMJ+7WPJnepb0EcSJVf/f4eA+Oy1R554DKn0oV5BgAAAABJRU5ErkJggg==", // skulls
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAJElEQVQImWPQ0bf4n5xZ+x+ZZoAxWnpXwCUYkAVgNG6V6GYCAA7HMYuW7rY4AAAAAElFTkSuQmCC", // vichy grey
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAbElEQVQYlWNwC87+TwxmQOao69v+Z2BggGN1fVtMhTBFmw7chGNkxQzoikpbF8IxsmIGt+BsFEUMDAwoNEwxXCGySegYQyEDA8P/njk7/pe2LvzfM2cHijiKG+GCUAzjw92IrhjZShRfExOOAOeEv4GIy2ooAAAAAElFTkSuQmCC", // smilies
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAhUlEQVQYlWOwd9L4b++k8V/dzAErhskz2Psa/Nexdf+vY+v+397XAAUjizMgc2BsbGIMZt7h/4OS7f+beYf/h7HR+Wbe4f8ZHCLT/rctTP8Po+fuqvy/+/YEFDGHyDRUE2GmIZsKNxHdLdg8omPrToJndMwU4WGmY6aIgpHFGdAF0TFMHgDkJLF5l7zqRAAAAABJRU5ErkJggg==", // psychedot green
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAgklEQVQYlWNwsmX672TL9N9WUhArhskzhPgy/w9SFP8fpCj+P8SXGQUjizMgc2BsbGIMDSaq/0uzWP83mKj+h7HR+Q0mqv8Zjvtb/e9vZP8Po5dN4fj/+KwKithxfytUE2GmIZsKNxHdLdg8EqQoToJnkMMQFmboYetkywRRSEyAAwCG3aYrN5q3twAAAABJRU5ErkJggg==", // psyche dot yellow
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAWElEQVQYlWMwCC/4TwxmMAgv+K/r6PtfUlnzv6Sy5n9dR1/cCiWVNf/reYT/h7HxKkQWxGYDiokwSWw2YLgRZgqyYrhCbBhmA4rV6BhmHUwxToU4PUMMBgAylrUH8uu8cwAAAABJRU5ErkJggg==", // GS
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAQElEQVQYlWNIZGP7n8jG9n8KBwdezABTREgxA+1MxKYBWZwBWRe6IhQT0a1ANxlmKgMuk9DFGLC5B10MRSEhDAAII51y1TEoXgAAAABJRU5ErkJggg==", // BSG
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAVElEQVQYlWM4M4fh/+PNSv/PzGH435OJis/MYfjPcGYOhIFNwd4+hv8Me/sgklMKmDEUTClg/s+ALgAzDaaBAd1OdDcxoNuJ7iYMK9DdxIBuJ7oGAOciiIXlbJuWAAAAAElFTkSuQmCC", // yellow bubbles
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAWCAYAAAC2ew6NAAAEZUlEQVR42oWX12ogMQxFhzTSe4f03ntPSCP1JY2E/P+PaDmCA2Z2s3kQnrElX+lalmaqlpaWQGZnZ2NpaSnW19djdXXVMWVzczP6+vpiZGQkSn2E597e3lhbW4udnZ0ct7e3Y2NjI/fo6OiIpqammJmZCfW1X1xcRA+MtNna2krZ29v7C68CBOFlbm6OzTFiBDjHlZWVmJ6eTsCenh71dTLXDWx3dzftlpeXERxKZ9Uv8RYWFgwI3ZKkDKzEq2RmeHg4Dg8PMdRRmGSDdGR/fz8GBgZicnKyZCb1Tk5OGBEYSV3ZPTo6StDm5ubUr+MhpaNiYzc4OCheMppHcHl5ySIARKXDCHPJ1OnpabKADceCzvn5eZydnck8wTEPMI6yzt7smc6Jpx362IqJjY6CNz8/n6xWn5+f8fDwwIK5wqIRMrIZzmbu3N/fx8fHR7y8vMTT0xNzbA6T6BtYinMHBwdxd3cXX19f8fr6Ch5Mso4++yMEmnY6fHx8HDc3N/H9/R0VE0bEkTGW4DIFo7zDBjrlMakHmBcS/TLPsfOiGQTinJfJk2QekiSqYlLaZdJ3jQHnWSM2Yd0biw4jLOGEzpS3H+FZFrVlP94hg5EAJY93SNNRI85xamoqk7i1tTVlaGiIhM6NdKhkUkcmJiaw85KRj+Qz+jqpLuASAh6XNLHa29ujv7/f6iNBKVV5W3Gos7MzGhoaMObCZIno6upiU4+REce9NNxqEj5tGxsbsUnbsbExwGRRlnSeNUpXHY991IHNfK7MBYBHR0dhA2PLSTrQ3d0d4+PjBoTAFnY8AwAYIOhigy17wLTOcawEZ05j9yMevhgYAVVl4re1tVkr6x0IVr10lhSFNZgETP16B8LG/Db3f8VDR2YrjO0kLMJKrYMgRF8vPToOI4hMlvbM/av0MP6Kh09UIi8TjDLBcWpYZ8aS5THaNpkjR9mYsc4MlcQqwqiYoz/iUXvNa2w5eqNkkdwgR0pmOBoCwVDBxnwjUI6Qo5cZWbEt6yxi6vwXj7bs6aWjHqFl4+LiAkc4MiSBbm9vMbQpyIiAOXd1dcWJeMnIS1ogHQ8d6yq6BsiaeDiLkzgPXq6ZLnn0gNou7bHPz89Ba0UeHx9xEtasoSkGiK1BXl9fx/v7e7y9vdHfZQU7bcsgCQbHbMvg8ZxzBidG5bHrqB0IKT4wZMEW+U+HfS4dK2+7TcMuJK52YsO67VVnq9IJj1LnTHiD8AbCLgwK4Gg71U4QA2Rf9RxtmTLoXVDX9lrRBWh33Fgd0kkDMD3QoU1aoPkKJycB+OGbwXcuG5eFkkRbpk3++s2AHb6BV1EeEDYCVGetmTqJEQlPB6K4WzuZ45b6C4GtHQgmcAgycJICX8fDDhxZLUseQYnnPxNgMiGbjH7a0UIBBAQ22QjhmRJjXnpRzHHWAKNUJUaJh6Pq+qFNsJBUx/OfyWMpCzOGbISzfNkQmWWkrHscZXmjS4H1ZNJeXsfzyw1Hy89DbEq8P07aJTElh3R1AAAAAElFTkSuQmCC", // crible
		"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAiCAMAAADiW5DOAAAAaVBMVEUjIyMlJSUhISEaGhoZGRkcHBwREREHBwcMDAwODg4PDw8NDQ0LCwsICAgQEBAYGBgbGxsiIiIkJCQUFBQKCgoVFRUJCQkSEhITExMdHR0XFxcFBQUGBgYfHx8WFhYeHh4gICAEBAQmJiYtaDO6AAAC4UlEQVR42iVTi5arIAykl4cSMNAFeah1t/v/H3knXT3VyoQkMxmUUo8Hfv+0NtYtq6cQvI8bW53y8wsIbmAmy2VyCXElZscUatiNBpRtTlklqw0+EtL45r3rozjmtbK22Rid9TRqpozwiW/L1XMvY++uh3XIPiuZkkpG4lEPyTggS9nHcIFzxkpG9iOrel7Xspyr0eZ1e8TsexmO9m9j73pd57ks6ty2pbWz7drM3LkPhHRXtDV5LEuttZ2qtjVGkI1aJ3tIot7Z6W+T7/WKYFpXFSl48iFUhw5sD647Tzd4T2rN0wpMeSLX2YdaE6o9H0/R9CcbXVao5bhzUEIXilCsA0H5OyfQsVpbXwMxSg9SHiEDbH0teuojHeBrRPu+hi5SlK7wkst5D7WgmDnw0BAYarkBcOzKiWr7IJ+m1iK3aIdHmrdngfqtPrKhofHK4N7O7Trf55om5O88gPWhGFMcnbpshjm2Zavt2gYSvg5gaIcV0+hMvNusU2qtxRWaLsEk1NwJPiCnfpTY7OuF6em+Re+hFdUmiezr+fhV6qmmMSJIBqej1uAgqOPQ1iOLecSBVh1iwTtlaxNfyD1AmMg3B9QksdBEnoQNaMYmt0F6kYSYas9a1oHCq3hrKY6b2JVyQzYXKItQny4OeGy5zuusyaAauYGYUZiOqS3M8T6X81TbVdvW3sttjf52kqigoTExMwePAVxUrTFAkdrEY5k9PFZ8twafcQNRQCquwcNisXbpHFUcdRoZffSt+uA5eBXQqGNC0GHM/Pd4/H6p58/U6Y4tABnEij7zcrRuu3gLXBE6UYoatpcOTIkNZXCh7UeC/TA3vGAijqiwg0FXPIr8Ye+1zYhIH+n+TiTjIB2j/MXAq5TQg0nSuKig0zxIPHZ/YvZdTi9PUTq+r+u9vSN013NQH/dAreBQsXPPsszL1XAt8NjHKzR2VFAlgHt3xWI2d9wgGY5m88eE/QcLefcf4Go/mGyl89EAAAAASUVORK5CYII%3D" // hexagons
		);
		$cc = count($samples);
		for($i=0;$i<$cc;$i++) {
			echo '<div class="bsg_ahbg_sample" style="float:left;height:1px dotted #888; background-image:url(\''.$samples[$i].'\');width:30px;height:30px;">
				<div style="display:none;">'.$samples[$i].'</div></div>'."\n";
		}
		?>
		<script>
		$(".bsg_ahbg_sample").hover(
			function () {
				$(this).css('cursor','pointer');
			},
			function () {
				$(this).css('cursor','auto');
			}
		);
		$(".bsg_ahbg_sample").click(function() {
			 $("#bsg_ahbg_field").html($(this).find("div").html());
			 $(".header").css("background-image","url('"+$(this).find("div").html()+"')");
			 function complete() {
				$(this).fadeIn(300,"swing");
			 }
			 $(this).fadeOut(300,"swing",complete);
		});
		</script>
		<hr style="border:none;clear:both;" />
		<p><a href="http://www.bertrandtarot.com/getsimple/">Plugin by Bertrand Saint-Guillain</a></p>
		<p style="font-size:10px;">featuring patterns <a href="http://subtlepatterns.com/?p=1112">BO play</a> and <a href="http://subtlepatterns.com/?p=1022">HIXS evolution</a> courtesy of subtlepatterns.com</p>
	<?php
}
?>