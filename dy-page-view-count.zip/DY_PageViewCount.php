<?php
/*
Plugin Name: DY Page View Count
Description: Store and show page view count data
Version: 1.1
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");
define('DY_PAGEVIEWCOUNT', $thisfile);

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY Page View Count',                   # Title of plugin
  '1.1',                              # Version of plugin
  'Dmitry Yakovlev',                  # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  'Store and show page view count data',   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_action('index-posttemplate', 'dyPageViewCount');
add_action('pagecache-aftersave', 'dySyncPageViewCountData');

function dyPageViewCount() {
  $slug = (string)get_page_slug(false);
  $data = dyGetPageViewCountData();
  if (array_key_exists($slug, $data) && is_int($data[$slug])) {
    $data[$slug] = (int)$data[$slug] + 1;
  } else {
    $data[$slug] = 1;
  }
  return dySavePageViewCountData($data);
}

function dyGetPageViewCount($slug, $offset = 0, $echo = false) {
  $slug = (string)$slug;
  $data = dyGetPageViewCountData();
  $count = (array_key_exists($slug, $data) && !empty($data[$slug])) ? $data[$slug] + $offset : $offset;
  if ($count < 0) $count = 0;
  if ($echo) {
    echo $count;
  } else {
    return $count;
  }
}
  
function dySyncPageViewCountData() {
  global $pagesArray;
  $data = dyGetPageViewCountData();
  foreach (array_diff_key($data, $pagesArray) as $key => $value)
    unset($data[$key]);
  foreach (array_diff_key($pagesArray, $data) as $key => $value)
    $data[$key] = 0;
  return dySavePageViewCountData($data);
}

function dyInitPageViewCountData() {
  global $pagesArray;
  $data = array();
  foreach ($pagesArray as $page) $data[$page['url']] = 0;
  return $data;
}
  
function dyGetPageViewCountData() {
  $dir = GSDATAOTHERPATH . DY_PAGEVIEWCOUNT . DIRECTORY_SEPARATOR;
  $file = $dir . 'data.json';
  if (is_file($file)) {
    return json_decode(file_get_contents($file), true);
  } else {
    return dyInitPageViewCountData(true);
  }
}

function dySavePageViewCountData(Array $data) {
  $dir = GSDATAOTHERPATH . DY_PAGEVIEWCOUNT . DIRECTORY_SEPARATOR;
  $file = $dir . 'data.json';
  if (!is_dir($dir)) mkdir($dir);
  return file_put_contents($file, json_encode($data)) ? true : false;
}

function dySetPageViewCount($slug, $count = 0) {
  $slug = (string)$slug;
  if ($slug) {
    $data = dyGetPageViewCountData();
    $data[$slug] = $count;
    return dySavePageViewCountData($data);
  }
}

function dyResetPageViewCountData() {
  global $pagesArray;
  $data = array();
  foreach ($pagesArray as $key => $value) $data[$key] = 0;
  return dySavePageViewCountData($data);
}

#Since 1.1
function dyGetWebsiteViewCount($offset = 0, $offsetForAllPages = false, $echo = false) {
  $offset = (int)$offset;
  $data = dyGetPageViewCountData();
  $count = $offsetForAllPages ? $offset * count($data) : $offset;
  if (is_array($data)) {
    $sum = array_sum(array_values($data));
  } else {
    $sum = 0;
  }
  if ($offsetForAllPages) $offset = $offset * count($data);
  $count = $sum + $offset;
  if ($count < 0) $count = 0;
  if ($echo) {
    echo $count;
  } else {
    return $count;
  }
}
?>