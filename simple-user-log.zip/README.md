
#Simple User Log Plugin
See who is currently logged in to GetSimple

The idea for the plugin came from requiring to see how many users login using the same username and password from an organisation. (Many colleagues in a business or works departments may share one login user name and password) 

eg: accounts, hospitality, marketing, sales, manufacturing

This would provide a clearer indication of which departments are logged in and how many people are using a specific account.


INSTALLATION
-------------
Unzip and place file in the plugin folder of getsimple.

Then activate the plugin

A tab will appear, click on the tab to initialise the plugin. A message will appear stating that a file has been created. The file created will store the details of who is logged in.

Once created, log out of the cms and then log back in again. (You only have to do this once).

Log back in and click new tab, you will be presented with a list of those users who have logged in from then on and how many times. Just refresh the list by clicking the tab when required.

*eg: Jack - 1 *

*Note: * If a user has never logged in then their name will never appear. 
Once is user name is recorded on the list, the value will dynamically chance depending if they are logged in or not.


