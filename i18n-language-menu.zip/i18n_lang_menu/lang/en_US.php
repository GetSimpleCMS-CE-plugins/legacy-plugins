<?php

$i18n = array (
	
    'TITLE'=>'Language menu management',
    'LANG_CODE'=>'Language code',
    'LANG_TEXT'=>'Language caption',
    'LI_CLASS_LABEL'=>'Current language&#39;s &lt;li&gt; class',
    'MENU_TEXT'=>'Edit language menu'
    
//	''=>'',

);



?>