<?php
/**
 * English Language File for Last Hashtag Plugin
 *
 * Date:				14 05 2012
 * Revision:		
 * Version:			GetSimple 3.0
 * Traductors: 	Francesco OpenCode Apruzzese
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	
	"LAST_HASHTAG_TITLE"=>  "Configurazione Last Hashtag",
	"LAST_HASHTAG_DESC" =>  "Plugin che mostra gli utlimi tweet in base ad un hashtag",
	"LAST_HASHTAG_ERROR"	=>	"Hashtag non valido",
	"HASHTAG"		=>	"Hashtag",
	"TWEET_LIMIT"		=>	"Numero Massimo di Tweet"

);
