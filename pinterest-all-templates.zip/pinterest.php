<?php
/*
Plugin Name: Pinterest
Description: Allows page to be pinned
Version: 1.0
Author: David Shaner
Author URI: http://www.shaner.us/
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Pinterest', 	
	'1.1', 		
	'David Shaner',
	'http://www.shaner.us/', 
	'Allows page to be pinned to Pinterest board',
	'content',
	'pinterest_button'  
);

register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
queue_script('jquery',GSFRONT);

# activate filter
add_action('content-top','pinterest_opening_div');
add_action('content-bottom','pinterest_closing_div');
add_action('content-top','pinterest_button');

function pinterest_button(){
    $site_url = get_site_url('',TRUE);
    echo '<span id="pinterest_site_url" style="display:none;">'.$site_url.'</span>'."\n";
    
    register_script('pinterest',$site_url.'plugins/pinterest/js/pinterest.js', '0.1', TRUE);
    queue_script('pinterest',GSFRONT);
}

function pinterest_opening_div(){
    echo '<div id="pinterest_content">'."\n";
}

function pinterest_closing_div(){
    echo "</div>\n";
}
?>