/**
 * Pinterst Plugin Javascript
 * page_url The URL of the page to pin
 * pin_media The first photo of the article/content is used. If there is no photo the default.png is used
 * pin_description The first paragraph of the article/content
 */

$(document).ready(function(){
    get_pinterest_items();
});

/**
 * Get Pinterest Items
 */
function get_pinterest_items(){
    var page_url = window.location.protocol+'//'+window.location.host+window.location.pathname+'/';
        page_url = escape(page_url);
    
    var site_url = $('#pinterest_site_url').text();
    /*  
    var site_url = window.location.protocol+'//'+window.location.host;
    var site_root = window.location.pathname;
        site_root = site_root.split('/');
        site_root = '/'+site_root[1]+'/';
        
        site_url = escape(site_url+site_root);
    */
    
    if($('#pinterest_content img').length != 0){
        var pin_media = $('#pinterest_content img').eq(0).attr('src');
            pin_media = escape(pin_media);
    }else{
        var pin_media = escape('/plugins/pinterest/images/default.png');
            pin_media = site_url+pin_media;   
    }
    
    var pin_description = $('#pinterest_content p').eq(0).text();
        pin_description = $.trim(pin_description);
        pin_description = escape(pin_description);
        
    var pin_button = '<div style="margin-bottom:10px;"><a href="http://pinterest.com/pin/create/button/?url='+page_url+'&media='+pin_media+'&description='+pin_description+'" class="pin-it-button" count-layout="horizontal">Pin It</a></div>';
    
    $(pin_button).prependTo('#pinterest_content');
}



/**
 * Initialize Pinterest
 */
(function() {
    window.PinIt = window.PinIt || { loaded:false };
    if (window.PinIt.loaded) return;
    window.PinIt.loaded = true;
    function async_load(){
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.async = true;
        if (window.location.protocol == "https:")
            s.src = "https://assets.pinterest.com/js/pinit.js";
        else
            s.src = "http://assets.pinterest.com/js/pinit.js";
        var x = document.getElementsByTagName("script")[0];
        x.parentNode.insertBefore(s, x);
    }
    if (window.attachEvent)
        window.attachEvent("onload", async_load);
    else
        window.addEventListener("load", async_load, false);
})();