<?php
$i18n = array(
  "PLUGIN_DESCRIPTION" => "Correct Fancy URLs in GetSimple CMS",
	"PRETTYURLS_OFF" => "Fancy URLs if off. <b>URL Corrector</b> plugin can't work!"
);
