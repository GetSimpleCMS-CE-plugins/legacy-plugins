<?php
$i18n = array(
  "PLUGIN_DESCRIPTION" => "Корректирует неправильные URL.",
	"PRETTYURLS_OFF" => "ЧПУ отклчены. <b>URL Corrector</b> не работает!"
);
