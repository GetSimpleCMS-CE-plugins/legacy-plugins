<?php
/*
Plugin Name: KCFinder FileManager for GetSimple
Description: KCFinder FileManager Integrated for Getsimple
Version: 2.0
Author: Mike Swan
Author URI: http://www.digimute.com/
*/

/* 
 This version uses a slightly modified KCFinder core to function correctly in GetSimple.
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 										# ID of plugin, should be filename minus php
	'KCFinder File Manager', 						# Title of plugin
	'2.2', 											# Version of plugin
	'Mike Swan',									# Author of plugin
	'http://www.digimute.com/', 					# Author URL
	'Replacement File Manager for GetSimple', 	    # Plugin Description
	'files', 										# Page type of plugin
	'kcfinder_show'  								# Function that displays content
);

# activate hooks
add_action('files-sidebar','createSideMenu',array($thisfile,'KCFinder File Manager')); 	// Add the sidebar 

function kcfinder_show() {
	global $plugin_info;
	global $plugins;
	global $LANG;
	

	echo '
	<h3 class="floated" style="float:left">KCFinder File Manager</h3>
	<div class="edit-nav">
        <p>
          <a href="javascript:void();" onclick=\'window.open ("../plugins/kcfinder/browse.php?lang='.substr($LANG,0,2).'", "KCFinder File Manager","status=1,toolbar=1,width=600, height=500");\' class="current">Open In Window</a>
        </p>
        <div class="clear"></div>
    </div>
	<div id="kcfinder"> 
		<div id="kcbrowser">
			<iframe name="kcfinder" id="kcframe" src="" frameborder="0" width="100%" height="500px" marginwidth="0" marginheight="0" scrolling="yes" >
			</iframe>
		</div>
		<script type="text/javascript"> 
		window.KCFinder = {
		    change: function() {
		        var lang = "en";
		        var type = "files";
		        document.getElementById("kcframe").src = "../plugins/kcfinder/browse.php?lang='.substr($LANG,0,2).'";
		    }
		}
		window.onload = function() {
		    window.KCFinder.change();
		}
		</script>
	</div> ';
}