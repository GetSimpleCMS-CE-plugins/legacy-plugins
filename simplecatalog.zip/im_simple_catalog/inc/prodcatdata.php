<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

// Default product category fields
$fields = array(
	'cat' => $realCategory->id,

	'cf_0_key'   => 'slug',
	'cf_0_label' => 'Item Slug',
	'cf_0_type'  => 'slug',
	'cf_0_options' => '',
	'cf_0_value' => '',

	'cf_1_key'   => 'summary',
	'cf_1_label' => 'Summary',
	'cf_1_type'  => 'editor',
	'cf_1_options' => '',
	'cf_1_value' => '',

	'cf_2_key'   => 'description',
	'cf_2_label' => 'Description',
	'cf_2_type'  => 'editor',
	'cf_2_options' => '',
	'cf_2_value' => '',

	'cf_3_key'   => 'image',
	'cf_3_label' => 'Images',
	'cf_3_type'  => 'fileupload',
	'cf_3_options' => '',
	'cf_3_value' => '',

	'cf_4_key'   => 'tags',
	'cf_4_label' => 'Tags',
	'cf_4_type'  => 'text',
	'cf_4_options' => '',
	'cf_4_value' => '',

	'cf_5_key'   => 'metatitle',
	'cf_5_label' => 'Meta title',
	'cf_5_type'  => 'text',
	'cf_5_options' => '',
	'cf_5_value' => '',

	'cf_6_key'   => 'metadescription',
	'cf_6_label' => 'Meta description',
	'cf_6_type'  => 'text',
	'cf_6_options' => '',
	'cf_6_value' => ''
);

// Default product category field data
$fieldsdata = array(
	array(
		'field' => 1,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
	array(
		'field' => 2,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
	array(
		'field' => 3,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
	array(
		'field' => 4,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => '',
		'custom-accept_types' => 'gif|jpe?g|png'
	),
	array(
		'field' => 5,
		'default' => '',
		'info' => 'When adding multiple tags, separate the tags by using commas',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
	array(
		'field' => 6,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
	array(
		'field' => 7,
		'default' => '',
		'info' => '',
		'required' => 0,
		'min_field_input' => 0,
		'max_field_input' => 0,
		'areaclass' => '',
		'labelclass' => '',
		'fieldclass' => ''
	),
);