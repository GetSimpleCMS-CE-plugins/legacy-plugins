<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
if(defined('IN_GS') && !empty($_GET['id']) && $_GET['id'] == $thisfileid) { define('IS_ADMIN_PANEL', true); }

include_once(__DIR__.'/_Util.php');
include_once(dirname(__DIR__).'/lib/config.php');
include_once(dirname(__DIR__).'/lib/router.php');
include_once(dirname(__DIR__).'/lib/factory.php');
include_once(dirname(__DIR__).'/lib/controller.php');
include_once(dirname(__DIR__).'/lib/processor.php');
include_once(dirname(__DIR__).'/lib/trigger.php');

// language
i18n_merge($thisfileid) || i18n_merge($thisfileid, 'en_US');

function imCatalogBuilder()
{
	$controller = new \ImCatalog\Controller();
	\ImCatalog\Factory::buildCatalog($controller);
	if(function_exists('exec_action')) exec_action('imcatalog');
	$catalog = \ImCatalog\Factory::getCatalog();

	return $catalog;
}