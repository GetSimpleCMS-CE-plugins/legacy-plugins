<?php namespace ImCatalog\Slider;

if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * NOTE: DO NOT DELETE OR CHANGE VARIABLES IN THIS FILE!
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *
 * If you want to change the Slider settings you should create your own config
 * file 'custom.config.php' in the same directory. To do so, simply copy the config.php
 * complete file and rename it to 'custom.config.php'. SimpleCatalog will load it at
 * runtime and read it's content, the entries in config.php will be overwritten by your
 * custom.config.php settings.
 */
$config->animation = 'fade';

$config->autoplay = true;

$config->interval = 30000;

$config->item_directory = 'images/';

$config->infotext = array(

	'titles' => array(

		'This is just the dummy text',

		'Who can use SimpleCatalog?',

		'And what can I do with SimpleCatalog?'
	),

	'texts' => array(

		'<p>Please feel free to change or complete the given text within the slider.</p>  
		<p>SimpeCatalog is an object-oriented plugin based on <a href="http://get-simple.info/extend/plugin/itemmanager/936/"
		>ItemManager</a>, ItemManager is a file-based PHP framework for GetSimple-CMS. Note, SimpleCatalog 
		is not a shop, it\'s just a simple fully customizable end user friendly product catalog.</p>   
		',

		'<p>You must not be a professional developer, to discover the new SimpleCatalog plugin.
		SimpleCatalog kept very simple, it does not force you to use PHP and is optimized for the end user.</p>
		<p>If you have any comments or questions relating to SimpleCatalog, please do not hesitate to contact me in forum</p>
		',

		'<p>SimpleCatalog is a GetSimple plugin which provides various ways for the generation of tiny to small presentations, 
		portfolios and product catalogs.</p>
		'
	),
);







