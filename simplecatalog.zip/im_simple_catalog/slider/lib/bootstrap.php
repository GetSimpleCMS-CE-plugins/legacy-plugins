<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
include(dirname(__DIR__).'/lib/slider.php');
$config = new \ImCatalog\Slider\Config();
include(dirname(__DIR__).'/conf/config.php');
!file_exists(dirname(__DIR__).'/conf/custom.config.php')
or include(dirname(__DIR__).'/conf/custom.config.php');
$slider = new \ImCatalog\Slider\Slider($config);