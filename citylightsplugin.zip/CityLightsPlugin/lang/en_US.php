<?php
/**
 * English Language File for CityLights Theme Plugin
 *
 * Date:       16 Aug 2016
 * Revision:   1
 * Version:    GetSimple 3.0
 * Traductors: Owen Tosh
 *
 * @package GetSimple
 * @subpackage Language
 */

$i18n = array (

	"CL_TITLE"         => "CityLights Theme Settings",
	"CL_DESC"          => "Settings for the CityLights GetSimple theme",
	"CL_SUB_BRANDING"  => "Site Branding",
	"CL_SUB_CALENDAR"  => "Calendar Widget",
	"CL_SUB_SOCIAL"    => "Social Media Buttons",
	"LOGO_ERROR"       => "Logo image URL is not valid.",
	"BACKGROUND_ERROR" => "Background image URL is not valid.",
	"CALENDAR_ERROR"   => "Calendar address is not valid.",
	"FACEBOOK_ERROR"   => "Facebook URL is not valid.",
	"GOOGLEPLUS_ERROR" => "Goolge Plus URL is not valid.",
	"TWITTER_ERROR"    => "Twitter URL is not valid.",
	"LINKEDIN_ERROR"   => "LinkedIn URL is not valid.",
	"PINTEREST_ERROR"  => "Pinterest URL is not valid.",
	"YOUTUBE_ERROR"    => "Youtube URL is not valid.",
	"VIMEO_ERROR"      => "Vimeo URL is not valid.",
	"LOGO_URL"         => "Logo image URL",
	"BACKGROUND_URL"   => "Background image URL",
	"CALENDAR_TITLE"   => "Calendar heading text",
	"CALENDAR_ADDR"    => "Google Calendar address",
	"FACEBOOK_URL"     => "Facebook URL",
	"GOOGLEPLUS_URL"   => "Google Plus URL",
	"TWITTER_URL"      => "Twitter URL",
	"LINKEDIN_URL"     => "LinkedIn URL",
	"PINTEREST_URL"    => "Pinterest URL",
	"YOUTUBE_URL"      => "Youtube URL",
	"VIMEO_URL"        => "Vimeo URL"

);
