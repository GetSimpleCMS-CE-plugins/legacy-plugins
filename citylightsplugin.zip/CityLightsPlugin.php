<?php
/*
Plugin Name: CityLights Theme Settings
Description: Settings for the CityLights GetSimple theme.  Based on Innovation theme plugin by Chris Cagle.
Version: 1.0
Author: Owen Tosh
Author URI: http://42.servehttp.com
*/

# get correct id for plugin
$cl_this_file=basename(__FILE__, ".php");
$cl_settings_file=GSDATAOTHERPATH .'CityLightsSettings.xml';

# add in this plugin's language file
i18n_merge($cl_this_file) || i18n_merge($cl_this_file, 'en_US');

# register plugin
register_plugin(
	$cl_this_file,					  # ID of plugin, should be filename minus php
	i18n_r($cl_this_file.'/CL_TITLE'),  # Title of plugin
	'1.0',							  # Version of plugin
	'Owen Tosh',						# Author of plugin
	'http://42.servehttp.com',		  # Author URL
	i18n_r($cl_this_file.'/CL_DESC'),   # Plugin Description
	'theme',							# Page type of plugin
	'cl_show_settings'				  # Function that displays content
);

$hidemenu = true;

# hooks
# enable side menu if theme is CityLights or on theme page and enabling CityLights, handle plugin exec before global is set
if( !$hidemenu ||
	( ( ($TEMPLATE == "CityLights") ||
		( (get_filename_id() == 'theme') &&
		isset($_POST['template']) &&
		($_POST['template'] == 'CityLights') ) ) &&
	  !( ($TEMPLATE == "CityLights") &&
		 (get_filename_id() == 'theme') &&
		 isset($_POST['template']) &&
		 ($_POST['template'] != 'CityLights') ) ) ) {
	add_action(
		'theme-sidebar',
		'createSideMenu',
		array($cl_this_file, i18n_r($cl_this_file.'/CL_TITLE'))
	);
}

$soc_services = array(
	'facebook',
	'googleplus',
	'twitter',
	'linkedin',
	'pinterest',
	'youtube',
	'vimeo'
);

# get XML data
if (file_exists($cl_settings_file)) {
	$cl_data = getXML($cl_settings_file);
}

function cl_show_settings() {
	global $soc_services, $cl_settings_file, $cl_data, $cl_this_file;
	$success=$error=null;
	
	# submitted form
	if (isset($_POST['submit'])) {
		# check for errors and parse data
		if ($_POST['logo'] != '') {
			if (validate_url($_POST['logo'])) {
				$resp['logo'] = $_POST['logo'];
			} else {
				$error .= i18n_r($cl_this_file.'/LOGO_ERROR').' ';
			}
		}
		if ($_POST['background'] != '') {
			if (validate_url($_POST['background'])) {
				$resp['background'] = $_POST['background'];
			} else {
				$error .= i18n_r($cl_this_file.'/BACKGROUND_ERROR').' ';
			}
		}
		if ($_POST['calendar_title'] != '') {
			$resp['calendar_title'] = $_POST['calendar_title'];
		}
		if ($_POST['calendar'] != '') {
			if (filter_var($_POST['calendar'], FILTER_VALIDATE_EMAIL)) {
				$resp['calendar'] = $_POST['calendar'];
			} else {
				$error .= i18n_r($cl_this_file.'/CALENDAR_ERROR').' ';
			}
		}
		foreach($soc_services as $var){
			if ($_POST[$var] != '') {
				if (validate_url($_POST[$var])) {
					$resp[$var] = $_POST[$var];
				} else {
					$error .= i18n_r($cl_this_file.'/'.strtoupper($var).'_ERROR').' ';
				}
			}
		}
		
		# if there are no errors, save data
		if (!$error) {
			$xml = @new SimpleXMLElement('<item></item>');
			if(isset($resp['logo'])) $xml->addChild('logo', htmlspecialchars($resp['logo']));
			if(isset($resp['background'])) $xml->addChild('background', htmlspecialchars($resp['background']));
			if(isset($resp['calendar_title'])) $xml->addChild('calendar_title', htmlspecialchars($resp['calendar_title']));
			if(isset($resp['calendar'])) $xml->addChild('calendar', htmlspecialchars($resp['calendar']));
			foreach($soc_services as $var){
				if(isset($resp[$var])) $xml->addChild($var, htmlspecialchars($resp[$var]));
			}
			
			if (! $xml->asXML($cl_settings_file)) {
				$error = i18n_r('CHMOD_ERROR');
			} else {
				$cl_data = getXML($cl_settings_file);
				$success = i18n_r('SETTINGS_UPDATED');
			}
		}
	}
	
	if($success) { 
		echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
	} 
	if($error) { 
		echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
	}
	?>
	
	<form method="post" action="<?php echo $_SERVER ['REQUEST_URI']; ?>">
		
		
		<h3><?php i18n($cl_this_file.'/CL_SUB_BRANDING'); ?></h3>
		<?php
			$value = '';
			if(isset($cl_data->logo)) $value = $cl_data->logo;
		?>
		<p><label for="cl_logo" ><?php i18n($cl_this_file.'/LOGO_URL'); ?></label><input id="cl_logo" name="logo" class="text" value="<?php echo $value; ?>" type="url" /></p>
		<?php
			$value = '';
			if(isset($cl_data->background)) $value = $cl_data->background;
		?>
		<p><label for="cl_background" ><?php i18n($cl_this_file.'/BACKGROUND_URL'); ?></label><input id="cl_background" name="background" class="text" value="<?php echo $value; ?>" type="url" /></p>
		
		
		<h3><?php i18n($cl_this_file.'/CL_SUB_CALENDAR'); ?></h3>
		<?php
			$value = '';
			if(isset($cl_data->calendar_title)) $value = $cl_data->calendar_title;
		?>
		<p><label for="cl_calendar_title" ><?php i18n($cl_this_file.'/CALENDAR_TITLE'); ?></label><input id="cl_calendar_title" name="calendar_title" class="text" value="<?php echo $value; ?>" type="text" /></p>
		<?php
			$value = '';
			if(isset($cl_data->calendar)) $value = $cl_data->calendar;
		?>
		<p><label for="cl_calendar" ><?php i18n($cl_this_file.'/CALENDAR_ADDR'); ?></label><input id="cl_calendar" name="calendar" class="text" value="<?php echo $value; ?>" type="email" /></p>
		
		
		<h3><?php i18n($cl_this_file.'/CL_SUB_SOCIAL'); ?></h3>
		<?php 
			foreach($soc_services as $var){
				$value = '';
				if(isset($cl_data->$var)) $value = $cl_data->$var;
		?>
		<p><label for="cl_<?php echo $var; ?>" ><?php i18n($cl_this_file.'/'.strtoupper($var).'_URL'); ?></label><input id="cl_<?php echo $var; ?>" name="<?php echo $var; ?>" class="text" value="<?php echo $value; ?>" type="url" /></p>
		<?php
			}
		?>
		
		<p><input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" /></p>
		
	</form>
	
	<p style="font-size: 0.8em;">Default background image by <a href="http://www.freeimages.com/photo/jacksonville-skyline-ii-1447833">Mike Gieson</a>.</p>
	
	<?php
}
?>
