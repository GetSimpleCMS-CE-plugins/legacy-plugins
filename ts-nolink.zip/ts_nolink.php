<?php
/*
Plugin Name: TS_NOLINK
Description: Set menulinks to "#"
Version: 0.1
Author: Lars Flintzak
Author URI: 
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'TS NoLink', 	# Title of plugin
	'0.1', 		# Version of plugin
	'Lars Flintzak',	# Author of plugin
	'http://www.gowep.de/gsplugins', 	# Author URL
	'Set menulinks to "#". Enter <i>xnolinkx</i> after the slug.', 	# Plugin Description
	'pages', 	# Page type of plugin
	''  	# Function that displays content
);

# activate filter
add_filter( 'menuitems', 'ts_nolink' );

function ts_nolink($m)
{
	$ss="xnolinkx";
	$m = preg_replace('#href=".*?'.$ss.'/?"#', 'href="#"', $m);
	$m = str_replace($ss, "", $m);
	return $m;
}
?>
