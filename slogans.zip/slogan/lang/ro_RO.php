<?php
/**
 * English Language File slogan Plugin
 *
 * Date:				26 April 2013
 * Revision:		
 * Version:			GetSimple 3.0
 * Traductors: 	Flavius Calin Tofan 
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	
	"SLOGANS_TITLE" => "Elemente:",
	"ADD_SLOGAN"=>  "... sau Adauga element nou",
	"SAVE" =>  		"Salveaza Elemente",
	"SLOGANS_BUTTON_NAME"	=>	"Editeaza Elemente din pagini",
	"ENTER_NEW_SLOGAN_NAME"		=>	"Introduceti numele noului element",
	"NAME"	=>		"Nume",
);