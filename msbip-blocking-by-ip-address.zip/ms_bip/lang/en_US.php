<?php
$i18n = array(

	# Общее
	
    'MODULNAME' 		=> "Blocking by IP address", 
	'MODULAUTOR' 		=> "MUST-STYLE design studio",
	'MODULVERSION' 		=> "1.1",
	'MODULDESCRIPTION' 	=> "Blocking user access to the site by the IP address. Requires installed plug MSadmin",
	
	# Заголовки
	
	'COUNTERTXT' 		=> "Found",
	'IPEXIST' 			=> "The IP address is already blocked!",	
	'IPADDRESS' 		=> "IP address",	
	'REASON' 			=> "The reason for the lock", 
	
	# Формы
	
    'FORMIP' 			=> "Enter the IP address", 
	'FORMREASON' 		=> "Enter reason for blocking", 
	'FORMDATE' 			=> "DD.MM.YY",
	'FORMRESET' 		=> "- full list -",
	'TITLESEARSH' 		=> "Find the IP address",
	'TITLEADD' 			=> "Add new IP address",
	'TITLEDELETE' 		=> "Delete an IP address",
	
	/* Шаблон */
	
    'LISTREASON' 		=> "for violation of rules for use of the resource", 
	'LISTDATENONE' 		=> "- none -",
	'DELCONFIRM' 		=> "Delete Session #",
	'TMPLHEADER' 		=> "Oops, access to the site is closed!",
	'TMPLDESCRIPTION' 	=> "Access to this computer from the Web site blocked",
	'TMPLDATEPRE' 		=> " until ",
	'PAGERTXT1'		=> "Display on page",
	'PAGERTXT2'		=> "",
	'PAGERTXT3'		=> "all"
);