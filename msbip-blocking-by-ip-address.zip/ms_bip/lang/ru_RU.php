<?php
$i18n = array(

	# Общее
	
    'MODULNAME' 		=> "Блокировка по IP адресу", 
	'MODULAUTOR' 		=> "Студия дизайна MUST-STYLE",
	'MODULVERSION' 		=> "1.1",
	'MODULDESCRIPTION' 	=> "Блокировка пользовательского доступа к сайту по IP адресу. Требуется установленный плагин MSadmin",
	
	# Заголовки
	
	'COUNTERTXT' 		=> "Найдено",
	'IPEXIST' 			=> "Данный IP адрес уже заблокирован!",	
	'IPADDRESS' 		=> "IP адрес",	
	'REASON' 			=> "Причина блокировки", 
	
	# Формы
	
    'FORMIP' 			=> "Введите IP адрес", 
	'FORMREASON' 		=> "Укажите причину блокировки", 
	'FORMDATE' 			=> "ДД.ММ.ГГ",
	'FORMRESET' 		=> "- полный список -",
	'TITLESEARSH' 		=> "Найти IP адрес",
	'TITLEADD' 			=> "Добавить новый IP адрес",
	'TITLEDELETE' 		=> "Удалить IP адрес",
	
	/* Шаблон */
	
    'LISTREASON' 		=> "за нарушение правил пользования ресурсом", 
	'LISTDATENONE' 		=> "- нет -",
	'DELCONFIRM' 		=> "Удалить сессию # ",
	'TMPLHEADER' 		=> "Oops, доступ к сайту закрыт!",
	'TMPLDESCRIPTION' 	=> "Доступ к веб-сайту с данного компьютера заблокирован",
	'TMPLDATEPRE' 		=> " до ",
	'PAGERTXT1'		=> "Отображать на странице",
	'PAGERTXT2'		=> "по ",
	'PAGERTXT3'		=> "все"
);