<?php

i18n_merge('ms_bip') || i18n_merge('ms_bip', 'en_US');

$thisfile=basename(__FILE__, ".php");

register_plugin(
	$thisfile, 							//идентификатор плагина
	i18n_r('ms_bip/MODULNAME'), 		//Название плагина
	i18n_r('ms_bip/MODULVERSION'), 		//Версия плагина
	i18n_r('ms_bip/MODULAUTOR'),		//автор плагина
	'http://must-style.ru/', 			//сайт автора
	i18n_r('ms_bip/MODULDESCRIPTION'), 	//краткое описание плагина
	'msadmin', 							//тип страницы – на какой из вкладок административной панели появится плагин
	'bip_function'  					//главная функция плагина (функция администрирования)
);

# Основная функция режима техобслуживания
function bip_function(){
	global $SITEURL;
	$file 			= GSDATAOTHERPATH.'bip-base.xml';
	$xmlfile 		= simplexml_load_file($file);
	$countSessions 	= '0';

	if (!file_exists($file)) {
  		file_put_contents(GSDATAOTHERPATH.'bip-base.xml','<?xml version="1.0" encoding="utf-8"?><sessions></sessions>');
	} else {
		# Добавление сессии
		if( isset( $_POST['sessionADD'] ) ) {
			$sessionIP 		= $_POST["inputIP"];
			$sessionDATES 	= date("d.m.y");
			$sessionDATE 	= $_POST["inputDATE"];
			$sessionMESS 	= $_POST["inputMESS"];
			
			$sessionIPCheck = count($xmlfile->xpath('/sessions/session[@ip="'.$sessionIP.'"]'));
			
			if ($sessionIPCheck < 1) {
				$dom = new DOMDocument; 
				$dom->load($file);
				$xpath = new DOMXPath($dom);
				
				$sessions=$xpath->query('/sessions')->item(0);
				$session = $dom->createElement('session');
				$attribute1 = $dom->createAttribute("ip");
				$attribute2 = $dom->createAttribute("dates");
				$attribute3 = $dom->createAttribute("date");
				$attribute4 = $dom->createAttribute("message");
				$attribute1->value = $sessionIP;
				$session->appendChild($attribute1);
				$attribute2->value = $sessionDATES;
				$session->appendChild($attribute2);
				$attribute3->value = $sessionDATE;
				$session->appendChild($attribute3);
				$attribute4->value = $sessionMESS;
				$session->appendChild($attribute4);
				$sessions->appendChild($session);
				$dom->save($file);
				}
			else
				{
					echo '
					<script>setTimeout("$(\'div.notice\').fadeOut(500);", 5000);</script>
					<div class="notice"><i class="fa fa-info-circle" aria-hidden="true"></i> ' . i18n_r('ms_bip/IPEXIST') . '</div>
					';
				}
		}
		
		# Удаление сессии
		if( isset( $_POST['sessionDEL'] ) ) {
			$dom = new DOMDocument; 
			$dom->load($file);
			$xpath = new DOMXPath($dom); 
			
			$ip = $_POST["sessionDelIP"];

			$sessions = $xpath->query('/sessions/session[@ip="'.$ip.'"]');
			$el = $sessions->item(0);
			$el->parentNode->removeChild($el);
			$dom->save($file); 
		}
		
		# Форма поиска и добавления IP
		if( isset( $_POST['searchIP'] ) ) {
			if( isset( $_POST["inputIP"] ) ) {
				$filterIP 	= $_POST["inputIP"];
			} else {
				$filterIP 	= '';
			}
			$dom = new DOMDocument;
			$dom->load($file);
			$xpath = new DOMXPath($dom);
			$sessions = $xpath->query('/sessions/session[@ip="'.$filterIP.'"]');
			$countSessions 	= count($xmlfile->xpath('/sessions/session[@ip="'.$filterIP.'"]'));
		} else {
			$dom = new DOMDocument;
			$dom->load($file);
			$xpath = new DOMXPath($dom);
			$sessions = $xpath->query('/sessions/session');
			$countSessions 	= count($xmlfile->xpath('/sessions/session'));
		}
		if( isset( $_POST['resetIP'] ) ) {
			$dom = new DOMDocument;
			$dom->load($file);
			$xpath = new DOMXPath($dom);
			$sessions = $xpath->query('/sessions/session');
			$countSessions 	= count($xmlfile->xpath('/sessions/session'));
		}
	}
	echo '
	<link href="'.$SITEURL.'plugins/ms_bip/template/css/bip_style.css" rel="stylesheet" media="all">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<h3>' . i18n_r('ms_bip/MODULNAME') . ' <span style="float:right;">' . i18n_r('ms_bip/COUNTERTXT') . ': ' . $countSessions . '</span></h3>
	<form method="POST" name="formIP">
		<table id="form_add">
			<tr>
				<td width="25%"><input style="width:90%;" type="text" class="text" name="inputIP" placeholder="' . i18n_r('ms_bip/FORMIP') . '" maxlength="15" required></td>
				<td width="50%"><input style="width:95%;" type="text" class="text" name="inputMESS" placeholder="' . i18n_r('ms_bip/FORMREASON') . '" maxlength="110"></td>
				<td width="15%"><input style="width:80%;" type="text" class="text" name="inputDATE" placeholder="' . i18n_r('ms_bip/FORMDATE') . '" maxlength="8"></td>
				<td width="5%"><button style="width:100%;" type="submit" name="searchIP" class="btn" title="' . i18n_r('ms_bip/TITLESEARSH') . '"><i class="fa fa-fw fa-search" aria-hidden="true"></i></button></td>
				<td width="5%"><button style="width:100%;" type="submit" name="sessionADD" class="btn btn-add" title="' . i18n_r('ms_bip/TITLEADD') . '"><i class="fa fa-fw fa-plus" aria-hidden="true"></i></button></td>
			</tr>
		</table>
	</form>';
	
	if (file_exists($file)) {
		# Список сессий
		echo '
		<table id="bip-table" class="table table-hover">
			<thead> 
				<tr>  
					<th width="15%">' . i18n_r('ms_bip/IPADDRESS') . '</th> 
					<th width="60%">' . i18n_r('ms_bip/REASON') . '</th> 
					<th width="10%" style="text-align:center;"><i class="fa fa-lock" aria-hidden="true"></i></th>
					<th width="10%" style="text-align:center;"><i class="fa fa-unlock" aria-hidden="true"></i></th> 
					<th width="5%"></th>
				</tr> 
			</thead> 
			<tbody>';
				foreach ($sessions as $session) {
					$listSessionIp 		= $session->getAttribute('ip');
					$listSessionDateS 	= $session->getAttribute('dates');
					$listSessionDate 	= $session->getAttribute('date');
					$listSessionMess 	= $session->getAttribute('message');
					echo '
					<tr>
						<td>' . $listSessionIp . '</td>
						<td>'; if($listSessionMess != ''){echo $listSessionMess;} else {echo i18n_r('ms_bip/LISTREASON');} echo '</td>
						<td>'; if($listSessionDateS != ''){echo $listSessionDateS;} else {echo i18n_r('ms_bip/LISTDATENONE');} echo '</td>
						<td>'; if($listSessionDate != ''){echo $listSessionDate;} else {echo i18n_r('ms_bip/LISTDATENONE');} echo '</td>
						<td>
							<form method="POST">
								<button class="btn btn-sm btn-link" type="submit" name="sessionDEL" onclick="return confirm(\'' . i18n_r('ms_bip/DELCONFIRM') . $listSessionIp . ' ?\')"><i class="fa fa-fw fa-times" aria-hidden="true"></i></button>
								<input type="text" class="hidden" name="sessionDelIP" value="' . $listSessionIp . '" />
							</form>
						</td>
					</tr>
					';
				}
			echo '
			</tbody>
		</table>';
		if( isset( $_POST['searchIP'] ) ) {
			echo '<button type="submit" onclick="formIP.submit();" name="resetIP" class="btn btn-reset">' . i18n_r('ms_bip/FORMRESET') . '</button>';
		}
		echo '
			<div id="pager" class="pager" style="height:20px;margin:0px 0px 5px;">
				<form method="POST">
					<div style="float:left;text-align:left;padding:0px;">
						<i class="fa fa-fw fa-angle-double-left first" aria-hidden="true"></i>
						<i class="fa fa-fw fa-angle-left prev" aria-hidden="true"></i>
						<!-- the "pagedisplay" can be any element, including an input -->
						<span class="pagedisplay"></span>
						<i class="fa fa-fw fa-angle-right next" aria-hidden="true"></i>
						<i class="fa fa-fw fa-angle-double-right last" aria-hidden="true"></i>
					</div>
					<div style="float:right;text-align:right;padding:0px;">
						<span class="hidden-xs">' . i18n_r('ms_bip/PAGERTXT1') . '</span>
						<select class="pagesize">
							<option value="10" selected>' . i18n_r('ms_bip/PAGERTXT2') . '10</option>
							<option value="20">' . i18n_r('ms_bip/PAGERTXT2') . '20</option>
							<option value="30">' . i18n_r('ms_bip/PAGERTXT2') . '30</option>
							<option value="50">' . i18n_r('ms_bip/PAGERTXT2') . '50</option>
							<option value="all">' . i18n_r('ms_bip/PAGERTXT3') . '</option>
						</select>
					</div>
				</form>
			</div>
		';
		echo '
		<p style="margin-top:20px;">Модуль разработан студией дизайна <a href="http://must-style.ru" target="_blank">MUST-STYLE.ru</a></p>
		<script type="text/javascript" src="'.$SITEURL.'plugins/ms_bip/template/js/jquery.tablesorter.js"></script>
		<script type="text/javascript" src="'.$SITEURL.'plugins/ms_bip/template/js/jquery.tablesorter.pager.js"></script>
		<script type="text/javascript" src="'.$SITEURL.'plugins/ms_bip/template/js/jquery.maskedinput.js"></script>
		<script type="text/javascript" src="'.$SITEURL.'plugins/ms_bip/template/js/bip_fx.js"></script>
		';
	}
}

# Добавляем ссылку на вкладку Темы 
add_action('msadmin-sidebar','createSideMenu',array($thisfile,i18n_r('ms_bip/MODULNAME')));
add_action('settings-sidebar','createSideMenu',array($thisfile,i18n_r('ms_bip/MODULNAME')));
add_action('index-pretemplate','bip_frontend');

# Формирование страницы-заглушки при включении режима техобслуживания
function bip_frontend() {
	global $SITEURL;
	$file 		= GSDATAOTHERPATH.'bip-base.xml';
	
	if (file_exists($file)) {
  		$xmlfile 	= simplexml_load_file($file);
		$sessionIP 		= $_SERVER['REMOTE_ADDR'];
		$userDate 		= date("d.m.y");
		$sessionCheck 	= count($xmlfile->xpath('/sessions/session[@ip="'.$sessionIP.'"]'));

		$dom = new DOMDocument;
		$dom->load($file);
		$xpath = new DOMXPath($dom);
		
		$sessions = $xpath->query('/sessions/session[@ip="'.$sessionIP.'"]');
		foreach ($sessions as $session) {
			$sessionMess 	= $session->getAttribute('message');
			$sessionDate 	= $session->getAttribute('date');
		}
		
		if ($sessionCheck > 0) {
			if( strtotime($userDate) < strtotime($sessionDate) || $sessionDate == '') {
				echo '	<!DOCTYPE>';
				echo '	<html>
							<head>
								<title>';
								get_site_name();
								echo '</title>
								<link href="'.$SITEURL.'plugins/ms_bip/template/css/bip_style_frontend.css" rel="stylesheet" media="all">
								<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
							</head>
							<body> 
								<div class="main_page">
									<div class="main_body_404">
										<div class="img_404"></div>
										<div class="text_404">
											<i>' . i18n_r('ms_bip/TMPLHEADER') . '</i><br/> ' . i18n_r('ms_bip/TMPLDESCRIPTION'); if($sessionDate != ''){echo i18n_r('ms_bip/TMPLDATEPRE') . $sessionDate;} if($sessionMess != ''){echo '<br/>' . $sessionMess;} else {echo '<br/>' . i18n_r('ms_bip/LISTREASON');} echo '<br/>
											<div style="margin-top:15px;"><a href="http://must-style.ru" title="Студия дизайна MUST-STYLE - Создание эффективных сайтов в Санкт-Петербурге и всей России для малого и среднего бизнеса. +7 (812) 981-34-00">создание сайтов</a> | <a href="https://www.ihc.ru/?ref=254807" title="Интернет Хостинг Центр - надежный хостинг сайтов">хостинг</a></div>
										</div>
									</div>
									<div class="clear"></div>
								</div>
							</body>
						</html>';
				die;
			} else {
				$dom = new DOMDocument; 
				$dom->load($file);
				$xpath = new DOMXPath($dom); 
				
				$ip = $_SERVER['REMOTE_ADDR'];

				$sessions = $xpath->query('/sessions/session[@ip="'.$ip.'"]');
				$el = $sessions->item(0);
				$el->parentNode->removeChild($el);
				$dom->save($file); 
			}
		}
	}
}
?>