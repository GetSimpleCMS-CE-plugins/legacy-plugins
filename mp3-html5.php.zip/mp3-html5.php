<?php
/*
==============  ORIGINAL AUTHOR (based on) ====================
Plugin Name: Mp3 Plugin
Description: Replace links to mp3 files with a flash player inside of page contents
Version: 1.0
Author: Michele de Angelis
Author URI: http://www.micheledeangelis.net/
==============  ORIGINAL AUTHOR ====================

============== CHANGED AUTHOR ===================
Plugin Name: Mp3 Plugin Extended
Description: Place mp3 flash player inside of page contents in specific TAGS
Version: 0.1d
Author: Dominion IT
Author URI: http://www.dominion-it.co.za/
============== CHANGED AUTHOR ===================

============== CHANGED AUTHOR ===================
Plugin Name: Mp3 Html5 Plugin
Description: Place mp3 html5 player inside of page contents in specific TAGS
Version: 0.1d
Author: Rolf J. Dietz
Author URI: http://www.rolfjdietz.de/
============== CHANGED AUTHOR ===================
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Mp3 Html5', 	# Title of plugin
	'0.1', 		# Version of plugin
	'Rolf J. Dietz',	# Author of plugin
	'http://www.rolfjdietz.de/', 	# Author URL
	'Place mp3 html5 player inside of page contents in specific TAG <br>(%mp3html5: ... %)', 	# Plugin Description
	'', 	# Page type of plugin
	''  	# Function that displays content
);

# activate filter
add_filter('content','mp3h5tags'); 

function mp3h5tags($contents){
    $tmpContent = $contents;
	preg_match_all('/\(%(.*)mp3html5(.*):(.*)%\)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER); 
    $AlltoReplace = $tmpArr[count($tmpArr)-1];
    $totalToReplace = count($AlltoReplace);
    for ($x = 0;$x < $totalToReplace;$x++) {
       $targetMp3= str_replace('&nbsp;',' ',$AlltoReplace[$x]);
       $targetMp3 = trim($targetMp3);
      $adTeks = player($targetMp3);
      $tmpContent = preg_replace("/\(%(.*)mp3html5(.*):(.*)$targetMp3(.*)%\)/i",$adTeks,$tmpContent);
    }    
  return $tmpContent;
}
function player($targetFile){
        global $SITEURL;
        $site = $SITEURL;
        if (file_exists(GSDATAUPLOADPATH."mp3/$targetFile")) {
          $targetFile = $site."data/uploads/mp3/$targetFile";
        }        
        $player="<audio controls><source src=\"".$targetFile."\" type=\"audio/mpeg\">Your browser does not support the audio element.</audio> <a href=".$targetFile." target=_blank>download</a>";
        return $player;
}


