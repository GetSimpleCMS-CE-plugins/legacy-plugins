<?php
  /*
  Plugin Name: Piwik Integration
  Description: Simple plugin to add Piwik stats code to GetSimple.
  Version: 1.1
  Original-Author: Antonio Villamarin
  Original-Author URI: http://www.antoniovillamarin.com/
  Author: Michael Cramer
  Author-URI: http://www.bigmichi1.de/
  */
  
  $thisfile_piwik = basename(__FILE__, '.php');
  $piwik_config_file = GSDATAOTHERPATH . 'piwik.xml';
  
  register_plugin(
    $thisfile_piwik,                    //Plugin id
    'Piwik Integration Plugin',         //Plugin name
    '1.1',                              //Plugin version
    'Michael Cramer',                   //Plugin author
    'http://www.bigmichi1.de/',         //Author website
    'Simple plugin to add Piwik stats code to GetSimple.',  //Plugin description
    'settings',                         //Page type - on which admin tab to display
    'piwik_plugin'                      //Main function (administration)
  );

  if( file_exists( $piwik_config_file ) ) {
    $piwik = simplexml_load_file( $piwik_config_file );
  } else {
    $piwik = new simpleXMLElement( '<channel></channel>' );
    $piwik->addChild( 'code', '0' );
    $piwik->addChild( 'token', '' );
    $piwik->addChild( 'stats_url', '' );
    $piwik->asXML( $piwik_config_file );
  }

  add_action( 'settings-sidebar','createSideMenu',array( $thisfile_piwik, 'Piwik' ) );

  add_action( 'theme-footer', 'piwik_plugin_code', array() );
  
  function piwik_plugin() {
    global $piwik, $piwik_config_file;
    $msg = '';
    if( $_POST['piwik_plugin'] == 1 ) {
      $_POST['stats_url'] = strtolower( $_POST['stats_url'] );
      if( !preg_match( '/^([\-\.a-z0-9\/]+)$/', $_POST['stats_url'], $m ) ) {
        $msg = '<p class="error">URL must be in correct form: [subdom.]domain.ext *[optional].</p>';
      } else {
        $piwik->code = $_POST['code'];
        $piwik->token = $_POST['token'];
        $piwik->stats_url = $_POST['stats_url'];
        $piwik->asXML( $piwik_config_file );
        $msg = '<p class="updated">ID updated correctly.</p>';
      }
    }
    ?>
      <h3>Piwik code configuration.</h3>
      <p>
        ID code of piwik must be the number assigned in piwik instalation.<br/>
        If ID is "0", piwik code will not added to page (deactive).<br/>
        Token URL format without "http://" like: [subdomain.]domain.com<br/>
        *[subdomain.] is optional
      </p>
      <?php echo( $msg ); ?>
      <p>
        <form method="post">
          <input type="hidden" name="piwik_plugin" value="1" />
          <label for="code">Web ID</label><br/>
          <input type="number" name="code" min="0" value="<?php echo( (int) $piwik->code ); ?>" required /><br/><br/>
          <label for="token">Token code (this show visits graphic in this panel)</label><br/>
          <input type="text" name="token" value="<?php echo( (string) $piwik->token ); ?>" placeholder="Format: ad325f6e341bb8" /><br/><br/>
          <label for="stats_url">Stats URL ([subdomain.]domain.ext)</label><br/>
          <input type="text" name="stats_url" value="<?php echo( (string) $piwik->stats_url ); ?>" placeholder="[subdomain.]domain.ext" required /><br/><br/>
          <input type="submit" value="Update" />
        </form>
      </p>
      <?php
        if( $piwik->code != '0' && $piwik->token != '' ) {
      ?>
          <h3>Visits. Graphic from last 30 days</h3>
          <p>
            <img src="http://<?php echo( (string) $piwik->stats_url ); ?>/index.php?module=API&method=ImageGraph.get&idSite=<?php echo( (int) $piwik->code ); ?>&apiModule=VisitsSummary&apiAction=get&token_auth=<?php echo( (string) $piwik->token ); ?>&graphType=evolution&period=day&date=previous30&width=500&height=250" />
          </p>
      <?php
        }
      ?>
    <?php
    
  }
  
  function piwik_plugin_code() {
    global $piwik;
    $code = (int) $piwik->code;
    $stats_url = (string) $piwik->stats_url;
    if( $code != 0 ) {
      ?>
        <!-- Piwik -->
        <script type="text/javascript">
          var _paq = _paq || [];
          _paq.push(['trackPageView']);
          _paq.push(['enableLinkTracking']);
          (function() {
            var u="//<?php echo( $stats_url ); ?>/";
            _paq.push(['setTrackerUrl', u+'piwik.php']);
            _paq.push(['setSiteId', <?php echo( $code ); ?>]);
            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
          })();
        </script>
        <noscript><p><img src="//<?php echo( $stats_url ); ?>/piwik.php?idsite=<?php echo( $code ); ?>" style="border:0;" alt="" /></p></noscript>
        <!-- End Piwik Code -->
      <?php
    }
  }

?>
