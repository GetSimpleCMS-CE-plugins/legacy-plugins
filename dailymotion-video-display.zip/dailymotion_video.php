<?php
/*
Plugin Name: Dailymotion video display
Description: Insert dailymotion video easily
Version: 1.0
Author: Patrick RANDRIA
Author URI: http://patrick-randria.tk/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

// register plugin
register_plugin(
	$thisfile,	// ID of plugin, should be filename minus php
	'Dailymotion Video Display',	# Title of plugin
	'1.0',	// Version of plugin
	'Patrick RANDRIA',	// Author of plugin
	'patrick-randria.tk',	// Author URL
	'Add a Dailymotion Video on the page from the video url.',	// Plugin Description
	'plugin',	// Page type of plugin
	'daily_video_display'	// Function that displays content
);

# activate filter
add_filter('content','daily_video_display');

/**
 * Parses the content on a page and matches it to a gallery if one exists.
 *
 * @param string $content - Content of Page
 * @return string;
 */
function daily_video_display($content)
{
	$found = preg_match_all('/\{dailymotion_(\w+)\}/', $content, $match);

	for ($i=0; $i<=$found; $i++)
	{
		$sVideo = '';
		if (isset($match[1][$i]))
		{
                    $sVideo = $match[1][$i];
                    $aVideoParams = explode('_', $match[1][$i]);
                    $eVid = $aVideoParams[0];
                    $iWidth = $aVideoParams[1];
                    $iHeight = $aVideoParams[2];
		}
		else
		{
                    return $content;
		}

		$video = daily_video_embed($eVid,$iWidth,$iHeight);

		$content = preg_replace('/\{dailymotion_'.$sVideo.'\}/', $video, $content);
	}

	return $content;
}

function daily_video_embed($id, $w = 320, $h = 260){
    if ($w == '') $w = 320;
    if ($h == '') $h = 260;
    $toInsert = '
        <iframe frameborder="0" width="'.$w.'" height="'.$h.'" 
        src="http://www.dailymotion.com/embed/video/'.$id.'"></iframe>
        <br />
    ';
    return $toInsert;
}

?>