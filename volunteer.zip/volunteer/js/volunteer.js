$(document).ready(function(){
    $("#dpsta").datetimepicker({
        dateFormat: $.datepicker.W3C,
    });
    $("#dpend").datetimepicker({
        dateFormat: $.datepicker.W3C,
    });  
});

function SelectChanged (select) {
   select.form.submit();
}