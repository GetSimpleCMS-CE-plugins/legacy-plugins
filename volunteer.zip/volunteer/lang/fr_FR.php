<?php

/**
 * Volunteer
 * FRANCAIS
 * Philip Wittamore
 */

$i18n = array(
    'you_are_admin' => 'VOUS ETES ADMINISTRATEUR',
    'login' => 'S&lsquo;identifier',
    'password' => 'Mot de passe',
    'disconnect' => 'D&eacute;connecter',
    'change' => 'Changer',
    'connect' => 'Connecter',
    'return' => 'Retour',
    'email' => 'Adresse email',
    'address' => 'Adresse',
    'city' => 'Ville',
    'state' => 'Etat',
    'zip' => 'Code postale',
    'country' => 'Pays',
    'save' => 'Sauvegarder',
    'cancel' => 'Annuler',
    'yes' => 'Oui',
    'no' => 'Non',
    'join' => 'Devenir membre',
    'leave' => 'Quitter',
    'edit' => 'Editer',
    'delete' => 'Supprimer',
    'name' => 'Nom',
    'group' => 'Groupe',
    'details' => 'Details',
    'remove' => 'Effacer',
    'view' => 'Voir',
                        
    'err_001' => 'ERREUR: Addresse email manquant',
    'err_002' => 'ERREUR: Ne peut envoyer message',
    'err_003' => 'ERREUR: Ne peut changer mot de passe, compte inconnu.',
    'err_004' => 'ERREUR: Connexion impossible, compte ou mot de passe erron&eacute;',
    'err_005' => 'ERREUR: Mot de passe inchange.',
    'err_006' => 'ERREUR: Addresse email incorrect.',
    'err_007' => 'ERREUR: Fichier pays introuvable.',

    'genpass_l1' => 'Un nouveau mot de passe � �t� demand� pour votre compte.',
    'genpass_l2' => "Si vous souhaitez le changer, merci d'entrer le mot de passe suivante: ",
    'genpass_l3' => 'Cordialement, Votre administrateur',
    'genpass_subj' => 'Volunteer: Demande de changement de mot de passe',

    'chgpass_title' => 'Changer votre mot de passe',
    'chgpass_l1' => 'Un nouveau mot de passe &agrave; &eacute;t&eacute; envoy&eacute;',
    'chgpass_l2' => 'Entrez votre mot de passe ci-dessus:',
    'chgpass_success' => 'Mot de passe chang&eacute; avec success.',
    'already_exists' => 'existe d&eacute;ja',
    'reset_password' => 'Changer mot de passe',
    
    'reg_subj' => 'Volunteer: Votre enregistrement',
    'reg_success' => 'Enregistr&eacute;!',
    'reg_pw_sentto' =>'Votre mot de passe &agrave; &eacute;t&eacute; envoy&eacute; &agrave;',
    'reg_title' => 'Enregistrer',
    'first_name' => 'Pr&eacute;nom',
    'last_name' => 'Nom de famille',
    'register' => 'Enregistrer',
    
    'profile_title' => 'Mon profile',
    'tel_work' => 'T&eacute;l. Travail',
    'tel_home' => 'T&eacute;l Maison', 
    'mobile_1' => 'Portable 1', 
    'mobile_2' => 'Portable 2',
    'comments' => 'Commentaire',
    'last_access' => 'Derni&egrave;re access',   
    'last_sub' => 'Derni&egrave;re souscription',

    'page_num' => 'Page Num&eacute;ro',
    'delete' => 'Supprimer',
    'really_delete' => 'Voulez-vous effacer de fa&ccedil;on definitif',
    'must_be_admin' => 'Administrateur seulement',
    'volunteer_list_title' => 'Liste des volontaires',
    'my_groups_title' => 'Mes groupes',
    'group_name' => 'Nom de groupe',
    'create_group_title' => 'Cr&eacute;er groupe',
    'group_name' => 'Nom',
    'edit_group_title' => 'Editer groupe',
    'create_new_group' => 'Cr&eacute;er une nouvelle groupe',
    'list_groups_title' => 'Liste des Groupes',
    'connect_first' =>  'Il faut se connecter d&lsquo;abord',

    'edit_event' => 'Editer evenement',
    'start_date' => 'Date de debut',
    'end_date' => 'Date de fin',
    'volunteer' => 'Se porter Volontaire!',
    'volunteers_for_event' => 'Volontaires pour cet evenement',
    'name_missing' => 'Nom manquant dans profile',
    'create_event_title' => 'Cr&eacute;er un evenement',
    'create_group_first' => 'Cr&eacute;er une groupe d&lsqui;abord',
    'view_event_title' => 'Voir evenement',
    'unvolunteer' => 'Desister',
    'join_group_first' => 'Vous devez d&lsquo;abord &ecirc;tre membre d&lsquo;un groupe.',
    'create_new_event' => 'Cr&eacute;er un nouveau evenement',
    'list_events_title' => 'Liste des evenements',                    
    
);


?>