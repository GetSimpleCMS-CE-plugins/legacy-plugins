<?php

/**
 * Volunteer
 * USA
 * Philip Wittamore
 */

$i18n = array(
    'you_are_admin' => 'YOU ARE ADMIN',
    'login' => 'Login',
    'password' => 'Password',
    'disconnect' => 'Disconnect',
    'change' => 'Change',
    'connect' => 'Connect',
    'return' => 'Return',
    'email' => 'Email address',
    'address' => 'Address',
    'city' => 'City',
    'state' => 'State',
    'zip' => 'Zip',
    'country' => 'Country',
    'save' => 'Save',
    'cancel' => 'Cancel',
    'yes' => 'Yes',
    'no' => 'No',
    'join' => 'Join',
    'leave' => 'Leave',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'name' => 'Name',
    'group' => 'Group',
    'details' => 'Details',
    'remove' => 'Remove',
    'view' => 'View',
    
    'err_001' => 'ERROR: Missing email address',
    'err_002' => 'ERROR: Message could not be sent.',
    'err_003' => 'ERROR: Cannot change password, unknown account.',
    'err_004' => 'ERROR: Connection failed: unknown login/password',
    'err_005' => 'ERROR: Check failed. Password unchanged.',
    'err_006' => 'ERROR: Incorrect email address.',    
    'err_007' => 'Error: missing countries file.',
    
    'genpass_l1' => 'A password reset has been requested for your account.',
    'genpass_l2' => 'If you wish to change your password, please enter the password below',
    'genpass_l3' => 'Best regards, Your Volunteer Admin',
    'genpass_subj' => 'Volunteer: Password Reset Request',
    
    'chgpass_title' => 'Change Password',
    'chgpass_l1' => 'A new password has been sent to',
    'chgpass_l2' => 'Please enter it below:',
    'chgpass_success' => 'Password changed successfully.',
    'already_exists' => 'already exists',
    'reset_password' => 'Reset password',
    
    'reg_subj' => 'Volunteer: Your Registration',
    'reg_success' => 'Registration sucessful!',
    'reg_pw_sentto' =>'Your password has been sent to',
    'reg_title' => 'Register',
    'first_name' => 'First name',
    'last_name' => 'Last name',
    'register' => 'Register',
    
    'profile_title' => 'My profile',
    'tel_work' => 'Tel. Work',
    'tel_home' => 'Tel Home',
    'mobile_1' => 'Mobile 1',
    'mobile_2' => 'Mobile 2',
    'comments' => 'Comments',
    'last_access' => 'Last access',
    'last_sub' => 'Last subscription',

    'page_num' => 'Page Number',
    'delete' => 'Delete',
    'really_delete' => 'Do you really want to permanently delete',
    'must_be_admin' => 'You must be admin to view this page',
    'volunteer_list_title' => 'List of Volunteers',
    'my_groups_title' => 'My Groups',
    'group_name' => 'Group name',
    'create_group_title' => 'Create a Group',
    'group_name' => 'Name',
    'edit_group_title' => 'Edit Group',
    'create_new_group' => 'Create a new Group',
    'list_groups_title' => 'List of Groups',
    'connect_first' => 'Please connect first',
    
    'edit_event' => 'Edit event',
    'start_date' => 'Start Date',
    'end_date' => 'End Date',
    'volunteer' => 'Volunteer!',
    'volunteers_for_event' => 'Volunteers for this event',
    'name_missing' => 'Name missing in profile',
    'create_event_title' => 'Create an event',
    'create_group_first' => 'Create a group first',
    'view_event_title' => 'View Event',
    'unvolunteer' => 'Withdraw',
    'join_group_first' => 'You must join a group first',
    'create_new_event' => 'Create a new event',
    'list_events_title' => 'List of events',
    
);

?>