<?php

/*
 * Plugin Name: Volunteer 
 * Description: Manage Event Volunteers
 * Author: Philip Wittamore
 * Author URI: http://www.pawdata.com/
*/

# don't run this script
if(!defined('IN_GS')) die('You cannot load this page directly');

# version
$vl_version = "0.5";

# id
$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
    $thisfile,            // id
    'Volunteer', 	  // name
    $vl_version,          // version
    'Philip Wittamore',   // author
    'http://volunteer.pawdata.com/', // website
    'Volunteer Manager',  // description
    'Pages',              // where to display admin
    'vl_admin'            // admin function 
);

$VL_DEBUG = true;

if ($VL_DEBUG) {
    $VL_RUNTIME = microtime(true);
    ini_set('error_reporting',E_ALL|E_STRICT);
    ini_set('display_errors', '1');
}else{
    ini_set('display_errors', '0');
}

# check volunteer data folder
if(!is_dir(GSDATAOTHERPATH.'volunteer')){
  killsession();
  @mkdir(GSDATAOTHERPATH.'volunteer', 0755);  
}

# retrieve volunteer settings
$vl_settings = GSDATAOTHERPATH.'volunteer/settings.xml';

# volunteer is database agnostic. See newdb() function below.
$vl_database = "sqlite3";  

# include phpmailer
require GSPLUGINPATH.'volunteer/class/PHPMailer/class.phpmailer.php';

if(!file_exists($vl_settings)) {
    $xml = @new SimpleXMLElement('<volunteer></volunteer>');
    $xml->addChild('language', 'en_US');
    $xml->asXML($vl_settings);
}
$item = getXML($vl_settings);
$vl_admin = $item->vl_admin;
$vl_lang = $item->language;

if ($vl_admin == '') {
    $gs_admin_settings = GSDATAPATH.'users/admin.xml';
    if(file_exists($gs_admin_settings)) {
        $item = getXML($gs_admin_settings);
        $default_addr = $item->EMAIL;
        $vl_admin = $default_addr;
    }
}            

# add in this plugin's language file
i18n_merge('volunteer',$vl_lang) || i18n_merge('volunteer','en_US');

# Off we go...

# create and update DB if necessary
vl_dbstart(); 

# pretemplate
add_action('index-pretemplate','vl_pretemplate');

# posttemplate
add_action('index-posttemplate','vl_posttemplate');

# add a link in the admin tab 'pages'
add_action('pages-sidebar','createSideMenu',array($thisfile,'Volunteer Manager'));

# activate filter 
add_filter('content','vl_inject_content');

# add pretemplate
function vl_pretemplate() {

    global $SITEURL, $vl_settings, $vl_database, $vl_admin;

    if (!isset($_SESSION)) {
        @session_start();
    }

    ob_start();
    
    // inactivity check
    $inactive = 1800;
    if( !isset($_SESSION['timeout']) )
    $_SESSION['timeout'] = time() + $inactive; 
    $session_life = time() - $_SESSION['timeout'];
    if($session_life > $inactive) { 
        $pdo = newdb(); 
        $data = array('vu' => $_SESSION['vl_user']);
        $sql = "UPDATE volunteers SET connected = '0' WHERE email = :vu";
        $sth = $pdo->prepare($sql);
        $sth->execute($data);
        killsession();
        $pdo=$sth=null;
        refresh();
    }
    $_SESSION['timeout']=time();

    register_style('volunteer.css',$SITEURL.'plugins/volunteer/css/volunteer.css','1','screen');
    register_style('jquery-ui.css','//ajax.googleapis.com/ajax/libs/jqueryui/1/themes/smoothness/jquery-ui.css','1',FALSE);
    register_style('jquery-ui-timepicker-addon.css',$SITEURL.'plugins/volunteer/css/jquery-ui-timepicker-addon.css','1','screen');
    
    queue_style('jquery-ui.css', GSFRONT);
    queue_style('volunteer.css', GSFRONT);
    queue_style('jquery-ui-timepicker-addon.css', GSFRONT);

    register_script('jquery', '//code.jquery.com/jquery-latest.min.js','1',FALSE);
    register_script('jquery-ui', '//ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js','1',FALSE);
    register_script('jquery-ui-timepicker-addon', $SITEURL.'plugins/volunteer/js/jquery-ui-timepicker-addon.js','1', FALSE);
    register_script('volunteer', $SITEURL.'plugins/volunteer/js/volunteer.js','1', FALSE);

    queue_script('jquery', GSFRONT);
    queue_script('jquery-ui', GSFRONT);
    queue_script('jquery-ui-timepicker-addon', GSFRONT);
    queue_script('volunteer', GSFRONT);
    
}

# add posttemplate
function vl_posttemplate(){
    global $VL_RUNTIME;
    if ($VL_RUNTIME) echo "Time Elapsed: ".(microtime(true) - $VL_RUNTIME)."s";
    ob_end_flush();
}
                
# admin page function
function vl_admin() {

    global $SITEURL, $vl_settings, $vl_database, $vl_lang, $vl_admin;
 
    $error=null;

    echo '<h2>Volunteer Manager</h2>';
    
    // check version
    $version = substr(phpversion(),0,3);
    if ($version < '5.4') echo '<p class="warning">Warning: Volunteer requires PHP 5.4+, Found '.phpversion().' </p>';
    if (!extension_loaded('sqlite3')) echo '<p class="warning">Warning: Volunteer requires the PHP Sqlite3 extension by default.</p>';
    if (!extension_loaded('PDO')) echo '<p class="error">Error: Volunteer requires the PHP PDO extension.</p>';
    
    echo '<h3>Settings</h3>';
    
    if (isset($_POST['admin_submit'])) {
    
        $xml = @new SimpleXMLElement('<volunteer></volunteer>');
        
        $xml->addChild('language', $_POST['language']);
        
        $vl_admin = mailclean($_POST['vl_admin']);
        if ($vl_admin) {
            $xml->addChild('vl_admin', $vl_admin);
        }else{
            $error = "Bad admin email";
        }
        
        if ($error) {
            echo '<p><span class="notify notify_error">'.$error.'</span></p>';
        }else{
            $xml->asXML($vl_settings);
            echo '<p><span class="notify notify_ok">Settings saved</span></p>';
        }
    }

    echo '<form method="post" id="settings_data" action="'.$_SERVER['REQUEST_URI'].'"><table>';
    echo '<tr><td>Admin email address:</td><td><input type="text" name="vl_admin" id="vl_admin" value="'.$vl_admin.'" /></td></tr>';
    echo '<tr><td>Language:</td><td><select class="text" style="width:100px;" name="language">';
    $files = scandir(GSPLUGINPATH.'volunteer/lang');
    foreach($files as $file) {
        $info = pathinfo($file);
        $language =  basename($file,'.'.$info['extension']);
        $s=null;
        if ($language == $vl_lang) $s = 'selected';
            if (($language != '.') && ($language != '.htaccess') && ($info['extension'] != 'php~')) echo '<option '.$s.' >'.$language.'</option>';    
    }
    echo '</select></td></tr>';
    echo '<tr><td><input type="submit" class="submit" value="save" name="admin_submit" /></td></tr></table></form>';

}

function vl_inject_content($content){

    $code=null;
    global $SITEURL, $vl_settings, $vl_database, $vl_admin;
    $pdo = newdb();

    if (isset($_SESSION['vl_user'])) {
        if (file_exists($vl_settings)) {
            $settings_data = getXML($vl_settings);               
            if (($settings_data->vl_admin) == $_SESSION['vl_user']) {
                $_SESSION['USERISADMIN'] = true;
            }
        }
    }

    /**********************
     * Display User
     * 
     */
    
    if (preg_match('#\[vl_user\]#', $content)) {
        if (isset($_SESSION['vl_user'])) {
            $code .= '<h3>'.$_SESSION['vl_user'].'</h3>';
            if (isset($_SESSION['USERISADMIN'])) {
                $code .= '<p><span style="color:red;font-weight:bold;">admin</span></p>';
            }
        }
        $content = preg_replace('#\[vl_user\]#', $code, $content);
        unset($code);
    }
    
    /**********************
    * User login
    *
    */
    
    if (preg_match('#\[vl_connect\]#', $content)) {
        $code=null;
                
        // disconnect
        if (isset($_SESSION['vl_user'])) {
            if (isset($_POST['disconnect_submit'])) {
                $data = array('vu' => $_SESSION['vl_user']);
                $sql = "UPDATE volunteers SET connected = '0' WHERE email = :vu";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                killsession();
                $pdo=$sth=null;
                refresh();
                
            }else{
                $code .= '<div class="vl_form_box">';
                $code .= '<form method="post" id="disconnect": action="'.$_SERVER['REQUEST_URI'].'"><table>';
                $code .= '<tr><td class="vl_col1"><h3>'.i18n_r('volunteer/disconnect').'</h3></td>';
                $code .= '<td><input class="button"type="submit" class="button" value="'.i18n_r('volunteer/disconnect').'" name="disconnect_submit" /></td></tr>';
                $code .= '</table></form></div>';
            }
        }else{
            // connect
            if (isset($_POST['login_submit'])) {

                if (isset($_POST['iforgot_request'])) {
                    if (!isset($_POST['login_email'])) {
                          $_SESSION['connfail'] = i18n_r("volunteer/err_001"); 
                    }else{

                        // send password reset and display form
                        $sql="SELECT COUNT(*) FROM volunteers WHERE email = '".$_POST['login_email']."'";
                        $result = $pdo->query($sql);
                        $row = $result->fetch(PDO::FETCH_NUM);
                        $count = $row[0];
                        if ($count) {
                            // no need to test rcpt addr as already tested at registration
                            $_SESSION['newpass'] = vl_genpassword(8);
                            $message = '';
                            $message .= i18n_r('volunteer/genpass_l1')."\r\n";
                            $message .= i18n_r('volunteer/genpass_l2')."\r\n\r\n";
                            $message .= $_SESSION['newpass']."\r\n\r\n";
                            $message .= i18n_r('volunteer/genpass_l3');
                            
                            $mail = new PHPMailer;
                            $mail->Sender = $vl_admin;
                            $mail->From   = $vl_admin;
                            $mail->FromName = 'Admin';
                            $mail->addAddress($_POST['login_email']);
                            $mail->Subject = i18n_r('volunteer/genpass_subj');
                            $mail->Body    = $message;
                            if(!$mail->send()) {
                                $code .= i18n_r('volunteer/err_002'). $mail->ErrorInfo;
                            }else{
                                $code  = '<div class="vl_form_box"><h3>'.i18n_r('volunteer/chgpass_title').'</h3>';
                                $code .= '<p>'.i18n_r('volunteer/chgpass_l1').':</p>';
                                $code .= '<p><span style="color:blue;">'.$_POST['login_email'].'</span></p>';
                                $code .= '<p>'.i18n_r('volunteer/chgpass_l2').'</p>';
                                $code .= '<form method="post" id="chpw" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                                $code .= '<tr><td class="vl_col1">'.i18n_r('volunteer/password').':</td><td><input type="password" name="iforgot_password" /></td></tr>';
                                $code .= '<tr><td></td><td><input class="button" type="submit" class="button" value="'.i18n_r("volunteer/change").'" name="submit" />';
                                $code .= '</table><input type="hidden" name="iforgot_email" value="'.$_POST['login_email'].'" /></form></div>';
                            }
                        }else{
                            $_SESSION['connfail'] = i18n_r('volunteer/err_003');
                            $pdo=null;
                            refresh();
                            
                        }
                    }
                }else{
                    // log in
                    $sql = "SELECT COUNT(*) FROM volunteers WHERE email = '".$_POST['login_email']."' AND password = '".md5($_POST['login_password'])."'";
                    $result = $pdo->query($sql);
                    $row = $result->fetch(PDO::FETCH_NUM);
                    $count = $row[0];
                    if ($count) {
                        $data = array( 'lm' => $_POST['login_email']);
                        $sql="UPDATE volunteers SET connected = '1',lastaccess = datetime() WHERE email = :lm";
                        $sth = $pdo->prepare($sql);
                        $sth->execute($data);
                        $_SESSION['vl_user'] = $_POST['login_email'];
                    }else{
                        $_SESSION['connfail'] = i18n_r('volunteer/err_004');
                        file_put_contents(GSDATAOTHERPATH.'volunteer/login_fail.log', date('Y-m-d H:i:s').','.
                            $_SERVER['REMOTE_ADDR'].','.$_POST['login_email']."\n", FILE_APPEND);
                    }
                    $pdo=null;
                    refresh();
                }
            }

            if ( isset($_POST['iforgot_password']) && isset($_POST['iforgot_email']) ) {
                // reset password
                if ($_SESSION['newpass'] == $_POST['iforgot_password']) {
                    $data = array('ip' => md5($_POST['iforgot_password']), 'im' => $_POST['iforgot_email']);
                    $sql = "UPDATE volunteers SET password = :ip WHERE email = :im";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $_SESSION['connfail'] = i18n_r('volunteer/chgpass_success');
                }else{
                    $_SESSION['connfail'] = i18n_r('volunteer/err_005');
                }
                unset ($_SESSION['newpass']);
                unset ($_POST['iforgot_password']);
                unset ($_POST['iforgot_email']);
                $pdo=null;
                refresh();
                
            }

            if (!($_SERVER['REQUEST_METHOD'] == "POST")) {
                # display login form
                if (isset($_SESSION['connfail'])) {
                    $code  = '<p><span class="error">'.$_SESSION['connfail'].'</span></p>';
                    unset($_SESSION['connfail']);
                }else{
                    $code=null;
                }

                $code .= '<div class="vl_form_box">';
                $code .= '<form method="post" id="login" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                $code .= '<tr><td class="vl_col1"><h3>'.i18n_r('volunteer/connect').'</h3></td><td></td></tr>';
                $code .= '<tr><td class="vl_col1">'.i18n_r('volunteer/email').':</td><td><input type="text" name="login_email" /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/password').':</td><td><input type="password" name="login_password" /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/reset_password').':</td><td><input type="checkbox" name="iforgot_request" value="1" /></td></tr>';
                $code .= '<tr><td></td><td><input class="button" type="submit" class="button" value="'.i18n_r('volunteer/connect').'" name="login_submit" />';
                $code .= '</td></tr></table></form></div>';
            }
        }
        $content = preg_replace('#\[vl_connect\]#', $code, $content);
        unset($code);
    }


    /**********************
    * register page
    *
    */
    
    if (preg_match('#\[vl_register\]#', $content)) {
      $code=null;
      
      if ( !isset($_SESSION['vl_user']) ) {

        if (isset($_POST['register_submit'])) {

            $email = mailclean($_POST['reg_email']);
            
            if ($email) {
                $password = vl_genpassword(8);
                # check if email exists
                $sql="SELECT COUNT(*) FROM volunteers WHERE email = '".$email."'";
                $result = $pdo->query($sql);   
                $row = $result->fetch(PDO::FETCH_NUM);
                $count = $row[0];
                if ($count) {
                    $code .= '<p>'.$email.' '.i18n_r('volunteer/already_exists').'</p>';
                    $code .= '<p><a href="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input class="button" type="button" name="return" value="'.i18n_r('volunteer/return').'" /></a></p>';
                }else{                            
                    
                    $data = array('em' => $email, 'pa' => md5($password), 'fn' => $_POST['reg_fname'], 'ln' => $_POST['reg_lname']);
                    $sql = "INSERT INTO volunteers (email,password,fname,lname) VALUES (:em,:pa,:fn,:ln)";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);                    
                    $message  = "Thankyou for registering!\r\nYour password is: ". $password;
                    $mail = new PHPMailer;
                    $mail->Sender = $vl_admin;
                    $mail->From   = $vl_admin;
                    $mail->FromName = 'Admin';
                    $mail->addAddress($email);
                    $mail->Subject = i18n_r('volunteer/reg_subj');
                    $mail->Body    = $message;
                    if(!$mail->send()) {
                        $code .= i18n_r('volunteer/err_002'). $mail->ErrorInfo;
                    }else{
                        $code .= '<h3>'.i18n_r('volunteer/reg_success').'</h3><p>'.i18n_r('volunteer/reg_pw_sentto').'</p><p>'.$email.'</p>';
                    }
                    $code .= '<p><a href="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input class="button" type="button" name="return" value="'.i18n_r('volunteer/return').'" /></a></p>';
                    $pdo=null;
                }
                
            }else{
                $code .= '<p><span class="error">'.i18n_r('volunteer/err_006').'</span></p>';
                $code .= '<p><a href="'.$_SERVER['REQUEST_URI'].'">';
                $code .= '<input class="button" type="button" name="return" value="'.i18n_r('volunteer/return').'" /></a></p>';
            }    
        }else{    
            if (!($_SERVER['REQUEST_METHOD'] == "POST")) {
                # define register form
                $code  = '<div class="vl_form_box">'; 
                $code .= '<form method="post" id="register_volunteer" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                $code .= '<tr><td class="vl_col1" colspan="2"><h3>'.i18n_r('volunteer/reg_title').'</h3></td></tr>';
                $code .= '<tr><td class="vl_col1">'.i18n_r('volunteer/email').':</td><td><input type="text" name="reg_email" /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/first_name').':</td><td><input type="text" name="reg_fname" /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/last_name').':</td><td><input type="text" name="reg_lname" /></td></tr>';
                $code .= '<tr><td></td><td>';
                $code .= '<input class="button" type="submit" class="button" value="'.i18n_r('volunteer/register').'" name="register_submit" /></td></tr>';
                $code .= '</table></form></div>';
            }
        }
      }    
        $content = preg_replace('#\[vl_register(.*)\]#', $code, $content); 
        unset($code);
    }


    /**********************
    * Edit user profile
    *
    */
    
    if (preg_match('#\[vl_profile\]#', $content)) {
        $code=null;
        if(isset($_SESSION['vl_user'])) {
            if (isset($_POST['profile_submit'])) {
            
                $fn = htmlentities($_POST['profile_fname'],ENT_QUOTES);
                $ln = htmlentities($_POST['profile_lname'],ENT_QUOTES);
                $ad = htmlentities($_POST['profile_address'],ENT_QUOTES);
                $ct = htmlentities($_POST['profile_city'],ENT_QUOTES);
                $cs = htmlentities($_POST['profile_state'],ENT_QUOTES);
                $zp = htmlentities($_POST['profile_zip'],ENT_QUOTES);
                $co = htmlentities($_POST['profile_country'],ENT_QUOTES);
                $th = htmlentities($_POST['profile_tel_home'],ENT_QUOTES);
                $tw = htmlentities($_POST['profile_tel_work'],ENT_QUOTES);
                $m1 = htmlentities($_POST['profile_mobile1'],ENT_QUOTES);
                $m2 = htmlentities($_POST['profile_mobile2'],ENT_QUOTES);
                $cm = htmlentities($_POST['profile_comments'],ENT_QUOTES);
                
                $data = array('fn' => $fn,'ln' => $ln,'ad' => $ad,'ct' => $ct,
                       'cs' => $cs,'zp' => $zp,'co' => $co,'th' => $th,'tw' => $tw,
                       'm1' => $m1,'m2' => $m2,'cm' => $cm);
                
                $sql = "UPDATE volunteers SET fname = :fn, lname = :ln, ".
                       "address = :ad, city = :ct, state = :cs, zip = :zp, ".
                       "country = :co, tel_home = :th, tel_work = :tw, ".
                       "mobile1 = :m1, mobile2 = :m2, comments = :cm ".
                       "WHERE email = '".$_SESSION['vl_user']."'";                

                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                
                $pdo=$sth=null;
                refresh();
                            
            }
            $sql = "SELECT * FROM volunteers WHERE email = '".$_SESSION['vl_user']."'";
            $result = $pdo->query($sql);
            $row = $result->fetch(PDO::FETCH_ASSOC);

            $code  = '<div class="vl_form_box"><form method="post" id="profile" action="'.$_SERVER['REQUEST_URI'].'"><table>';
            $code .= '<tr><td class="vl_col1"><h3>'.i18n_r('volunteer/profile_title').'</h3></td></tr>';
            $code .= '<tr><td class="vl_col1">'.i18n_r('volunteer/first_name').':</td><td><input class="in2" type="text" name="profile_fname" value="'.$row['fname'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/last_name').':</td><td><input class="in2" type="text" name="profile_lname" value="'.$row['lname'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/address').':</td><td><input class="in2" type="text" name="profile_address" value="'.$row['address'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/city').':</td><td><input class="in2" type="text" name="profile_city" value="'.$row['city'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/state').':</td><td><input class="in2" type="text" name="profile_state" value="'.$row['state'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/zip').':</td><td><input class="in2" type="text" name="profile_zip" value="'.$row['zip'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/country').':</td><td>';
            $code .= '<select class="in2" name="profile_country" >';

            $file = GSPLUGINPATH.'volunteer/countries.xml';
            $error= null;

            if (file_exists($file)) {
                $data = simplexml_load_file($file);
                $num=0;
                foreach($data->item as $item) {
                    $country = $item->country;
                    if ($country == $row['country']) {$s='selected';}else{$s='';};
                    $code .= '<option '.$s.'>'.$country.'</option>';
                    $num++;
                }
            }else{
                $error= '<span class="error">'.i18n_r('volunteer/err_007').'</span>';
            }

            $code .= '</select>'.$error.'</td></tr>';
            
            $code .= '<tr><td>'.i18n_r('volunteer/tel_home').':</td><td><input class="in2" type="text" name="profile_tel_home" value="'.$row['tel_home'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/tel_work').':</td><td><input class="in2" type="text" name="profile_tel_work" value="'.$row['tel_work'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/mobile_1').':</td><td><input class="in2" type="text" name="profile_mobile1" value="'.$row['mobile1'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/mobile_2').':</td><td><input class="in2" type="text" name="profile_mobile2" value="'.$row['mobile2'].'" /></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/comments').':</td><td><textarea class="in2" rows="5" name="profile_comments">'.$row['comments'].'</textarea></td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/last_access').':</td><td>'.$row['lastaccess'].'</td></tr>';
            $code .= '<tr><td>'.i18n_r('volunteer/last_sub').':</td><td>'.$row['lastsubscribe'].'</td></tr>';
            $code .= '<tr><td></td><td><input class="button"type="submit" class="button" value="'.i18n_r('volunteer/save').'" name="profile_submit" /></td></tr>';
            $code .= '</table></form></div>';
        }
        $content = preg_replace('#\[vl_profile\]#', $code, $content);
        unset($code);
    }


    if (preg_match('#\[vl_list_users\]#', $content)) {
        
        if (isset($_SESSION['USERISADMIN'])) {
                            
            $code=null;
            if (empty($_POST) || (isset($_POST['page']))) { 

                $rowsPerPage = 50;                  
                if (isset($_POST['page'])) $pageNum = $_POST['page'];                    
                if (!isset($pageNum)) $pageNum = 1;
                $offset = ($pageNum - 1) * $rowsPerPage;
                
                $sql="SELECT COUNT(*) FROM volunteers";
                $result = $pdo->query($sql);
                $row = $result->fetch(PDO::FETCH_NUM);
                $lastpage = ceil($row[0] / $rowsPerPage);

                $code .= '<h3>'.i18n_r('volunteer/volunteer_list_title').'</h3>';                
                $result = $pdo->query("SELECT * FROM volunteers ORDER BY 'email' ASC LIMIT '".$offset."', '".$rowsPerPage."'");
                if (count($result)) {
                    $code .= '<table><tr id="vl_list_nav_bar"><td id="vl_list_nav_left">';
                    if ($pageNum>1) {
                        $code .= '<form method="post" id="prevpage" action="'.$_SERVER['REQUEST_URI'].'">';
                        $code .= '<input type="hidden" name="page" value="'.($pageNum - 1).'"/>';
                        $code .= '<input type="submit" class="button" value="<" /></form>';
                    }
                        $code .= '</td><td id="vl_list_nav_center">'.i18n_r('volunteer/page_num').' '.$pageNum.'/'.$lastpage.'</td><td id="vl_list_nav_right">';
                    if ($pageNum < $lastpage) {
                        $code .= '<form method="post" id="nextpage" action="'.$_SERVER['REQUEST_URI'].'">';
                        $code .= '<input type="hidden" name="page" value="'.($pageNum + 1).'"/>';
                        $code .= '<input type="submit" class="button" value=">" /></form>';
                    }
                    $code .= '</td></tr></table><table>';
                    foreach($result as $row) {
                        $code .= '<tr><td>'.$row['fname'].' '.$row['lname'].
                             '</td><td><a href="mailto:'.$row['email'].'">'.$row['email'].
                             '</td><td class="vl_vl_delete_col"><form method="post" id="event_list" action="'.$_SERVER['REQUEST_URI'].'">'.
                             '<input type="hidden" name="email" value="'.$row['email'].'" />'.
                             '<input type="submit" class="button" name="vl_vl_delete" value="'.i18n_r('volunteer/delete').'" />'.
                             '</form></td></tr>'.
                             '<tr><td class="vl_list_hr" colspan="3">'.$row['address'];
                             if($row['city']) $code .= ','.$row['city'];
                             if($row['zip'])  $code .= ','.$row['zip'];
                             if($row['country']) $code .= ','.$row['country'].'</td></tr>';
                    }
                    $code .= '</table>';
                }
            } elseif (isset($_POST['vl_yesdeluser'])) {
                // don't delete admin
                if ($_POST['email'] != $vl_admin) {
                    $data = array('em' => $_POST['email']);
                    $sql = "DELETE FROM volunteers WHERE (email = :em)";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $sql = "DELETE FROM groups WHERE (email = :em)";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $sql = "DELETE FROM subscriptions WHERE (email = :em)";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);                                        
                    $pdo=null;
                    refresh();
                }
                $pdo=null;
                refresh();
                
            } elseif (isset($_POST['vl_nodeluser'])) {
                $pdo=null;               
                refresh();
                
            }else{
                $code .= '<p>'.i18n_r('volunteer/really_delete').':</p><p><span style="color:blue;">'.$_POST['email'].'</span></p>';
                $code .= '<form method="post" id="deluser" action="'.$_SERVER['REQUEST_URI'].'">';
                $code .= '<input type="hidden" name="email" value="'.$_POST['email'].'" />';
                $code .= '<input type="submit" class="button" name="vl_nodeluser" value="No" />&nbsp;';
                $code .= '<input type="submit" class="button" name="vl_yesdeluser" value="Yes" />&nbsp;';
                $code .= '</form>';
            }
        }else{
            $code = '<p>'.i18n_r('volunteer/must_be_admin').'.</p>';
        }
        
        $content = preg_replace('#\[vl_list_users\]#', $code, $content);
        unset($code);
    }

    /*********
    * GROUPS
    * 
    */
    
    if (preg_match('#\[vl_groups\]#', $content)) {

        $code = null;
        
    // list my groups 

        if (isset($_SESSION['vl_user'])) {
        
            // admin forms
            
            if (isset($_SESSION['USERISADMIN'])) {

                if (isset($_POST['create_group_form'])) { 
                    $code = null;
                    $code .= '<div class="vl_form_box"><h3>'.i18n_r('volunteer/create_group_title').'</h3>';
                    $code .= '<form method="post" id="create_group" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                    $code .= '<tr><td>'.i18n_r('volunteer/group_name').':</td><td><input class="in3" type="text" size="40" name="group_name" value="" /></td></tr>';
                    $code .= '<tr><td></td><td colspan="2">';
                    $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="cancel" value="'.i18n_r('volunteer/cancel').'" /></a>&nbsp;';
                    $code .= '<input type="submit" class="button" name="create_group_proc" value="'.i18n_r('volunteer/save').'" /><td></td></tr>';
                    $code .= '</table></form></div>';
                }
                
                if (isset($_POST['edit_group_form'])) {
                    $code = null;
                    $ent_group_name = htmlentities($_POST['group_name'],ENT_QUOTES);
                    $sql = "SELECT DISTINCT * FROM groups WHERE group_name = '".$ent_group_name."'";
                    $result = $pdo->query($sql);
                    $row = $result->fetch(PDO::FETCH_NUM);
                    $code .= '<div class="vl_form_box"><h3>'.i18n_r('volunteer/edit_group_title').'</h3>';
                    $code .= '<form method="post" id="edit_group" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                    $code .= '<tr><td>'.i18n_r('volunteer/group_name').':</td><td><input class="in3" type="text" size="40" name="group_name" value="'.$ent_group_name.'" /></td></tr>';
                    $code .= '<tr><td></td><td>';
                    $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="cancel" value="'.i18n_r('volunteer/cancel').'" /></a>&nbsp;';
                    $code .= '<input type="submit" class="button" name="edit_group_proc" value="'.i18n_r('volunteer/save').'" />';
                    $code .= '<input type="hidden" name="old_gname" value="'.$ent_group_name.'" />';
                    $code .= '</td></tr></table></form></div>';
                }

                if (isset($_POST['delete_group_form'])) {
                    $ent_group_name = htmlentities($_POST['group_name'],ENT_QUOTES);                  
                    $code .= '<p>'.i18n_r('volunteer/really_delete').'</p><p><span style="color:blue;">'.$ent_group_name.'</span></p>';
                    $code .= '<form method="post" id="delgroup" action="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input type="hidden" name="group_name" value="'.$ent_group_name.'" />';
                    $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="no_delgroup" value="'.i18n_r('volunteer/no').'" /></a>&nbsp;';
                    $code .= '<input type="submit" class="button" name="yesdelgroup_proc" value="'.i18n_r('volunteer/yes').'" />&nbsp;';
                    $code .= '</form>';
                }
                
            // admin procedures

                if (isset($_POST['yesdelgroup_proc'])) {
                    $data = array('gn' => htmlentities($_POST['group_name'],ENT_QUOTES));
                    $sql = "DELETE FROM groups WHERE group_name = :gn";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=$sth=null;
                    refresh();
                }

                if (isset($_POST['create_group_proc'])) {
                    $data = array('gn' => htmlentities($_POST['group_name'],ENT_QUOTES)); 
                    $sql = "INSERT INTO groups (group_name, email, group_leader) VALUES (:gn, '', '')";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=null;
                    refresh();
                }
                
                if (isset($_POST['edit_group_proc'])) {
                    $data = array('gn' => htmlentities($_POST['group_name'],ENT_QUOTES), 'og' => htmlentities($_POST['old_gname'],ENT_QUOTES)); 
                    $sql = "UPDATE groups SET group_name = :gn WHERE group_name = :og"; 
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=null;
                    refresh();
                }

            } 

            // procedures for all       

            if (isset($_POST['leave_group'])) {
                $data = array('em' => $_SESSION['vl_user'], 'gn' => $_POST['group_name']);
                $sql = "DELETE FROM groups WHERE (group_name = :gn) AND (email = :em)";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                $pdo=$sth=null;
                refresh();
            }

            if (isset($_POST['join_group'])) {
                $data = array('em' => $_SESSION['vl_user'], 'gn' => $_POST['group_name']);
                $sql = "DELETE FROM groups WHERE (group_name = :gn) AND (email = :em)";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                $sql = "INSERT INTO groups (group_name, email, group_leader) VALUES (:gn, :em, '0')";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                $pdo=null;
                refresh();
            }        

            // list groups

            if (empty($_POST) || isset($_POST['page'])) { 
            
                // if we are not showing admin forms show my groups for user & admin

                $code .= '<div class="vl_form_box">';
                $code .= '<table><tr><td class="vl_col1"><h3>'.i18n_r('volunteer/my_groups_title').'</h3></td></tr><tr><td>';
  
                $result = $pdo->query("SELECT DISTINCT * FROM groups WHERE email = '".$_SESSION['vl_user']."' ORDER BY group_name ASC");
 
                if (count($result)) {
                    foreach($result as $row) {
                        $code .= '<span class="groupname">'.str_replace(' ','&nbsp;',$row['group_name']).'</span> ';
                    }        
                }
    
                $code .= '</td></tr></table></div>';        

         
                // create form if admin            
                
                if (isset($_SESSION['USERISADMIN'])) {
                    $code .= '<div class="vl_form_box"><form method="post" id="create_group" action="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input type="submit" class="button" name="create_group_form" value="'.i18n_r('volunteer/create_new_group').'" /></form></div><br />';
                }
                
                $rowsPerPage = 50;                  

                $sql="SELECT COUNT(*) FROM groups";
                $result = $pdo->query($sql);
                $row = $result->fetch(PDO::FETCH_NUM);
                $lastpage = ceil($row[0] / $rowsPerPage);

                if (isset($_POST['page'])) $pageNum = $_POST['page'];
                if (!isset($pageNum)) $pageNum = 1;
                if ($pageNum == 0) $pageNum=1;
                if ($pageNum > $lastpage) $pageNum = $lastpage;
                $offset = ($pageNum-1) * $rowsPerPage;

                $code .= '<div class="vl_list_box"><h3>'.i18n_r('volunteer/list_groups_title').'</h3>';                
                $result = $pdo->query("SELECT DISTINCT group_name FROM groups ORDER BY group_name ASC LIMIT '".$offset."', '".$rowsPerPage."'");
                if (count($result)) {
                    $code .= '<table><tr id="vl_list_nav_bar"><td id="vl_list_nav_left">';
                    if ($pageNum>1) {
                        $code .= '<form method="post" id="prevpage" action="'.$_SERVER['REQUEST_URI'].'">';
                        $code .= '<input type="hidden" name="page" value="'.($pageNum - 1).'"/>';
                        $code .= '<input type="submit" class="button" value="<" /></form>';
                    }
                        $code .= '</td><td id="vl_list_nav_center">'.i18n_r('volunteer/page_num').' '.$pageNum.'/'.$lastpage.'</td><td id="vl_list_nav_right">';
                    if ($pageNum < $lastpage) {
                        $code .= '<form method="post" id="nextpage" action="'.$_SERVER['REQUEST_URI'].'">';
                        $code .= '<input type="hidden" name="page" value="'.($pageNum + 1).'"/>';
                        $code .= '<input type="submit" class="button" value=">" /></form>';
                    }
                    $code .= '</td></tr></table><table>';
                    foreach($result as $row) {
                        $code .= '<tr class="vl_list_hr" >'.
                                 '<td><span style="font-weight:bold;">'.$row['group_name'].'</span><br />';
                                 
                        $code .= '<form style="float:left;" method="post" id="my_group" action="'.$_SERVER['REQUEST_URI'].'">';
                        $code .= '<input type="hidden" name="group_name" value="'.$row['group_name'].'" />';
                        $code .= '<input type="submit" class="button" name="leave_group" value="'.i18n_r('volunteer/leave').'" />&nbsp;';
                        $code .= '<input type="submit" class="button" name="join_group" value="'.i18n_r('volunteer/join').'" />&nbsp;</form>';
                        $code .= '</form>';
                
                                 
                        if ( (isset($vl_admin)) && ($vl_admin == $_SESSION['vl_user']) ) { 
                                              
                        $code .= '<form style="float:left;" method="post" id="del_group" action="'.$_SERVER['REQUEST_URI'].'">'.
                                 '<input type="hidden" name="group_name" value="'.$row['group_name'].'" />'.
                                 '<input type="submit" class="button" name="delete_group_form" value="'.i18n_r('volunteer/delete').'" /></form>';
                                 
                        $code .= '<form style="float:left;" method="post" id="edit_group" action="'.$_SERVER['REQUEST_URI'].'">'.
                                 '<input type="hidden" name="group_name" value="'.$row['group_name'].'" />'.
                                 '&nbsp;<input type="submit" class="button" name="edit_group_form" value="'.i18n_r('volunteer/edit').'" /></form>';
                        }
                        $code .= '</td></tr>';
                    }
                    $code .= '</table></div>';
                }
            }
            
    }else{
        $code .= i18n_r('volunteer/connect_first');
    }
        
        $content = preg_replace('#\[vl_groups\]#', $code, $content);
        unset($code);
    }
                    



    /**********************
    * events
    *
    */

    if (preg_match('#\[vl_events\]#', $content)) {
        $code = null;

        if (isset($_SESSION['vl_user'])) {
            // user tasks

            if (isset($_POST['ev_volunteer'])) {

                $data = array('em' => $_SESSION['vl_user'], 'ev' => $_POST['event_id']);
                $sql = "DELETE FROM subscriptions WHERE (email = :em) AND (event_id = :ev)";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                $sql = "INSERT INTO subscriptions ('email','event_id') VALUES (:em,:ev)"; 
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                $sql = "UPDATE volunteers SET lastsubscribe = datetime() WHERE email = '".$_SESSION['vl_user']."'";
                $sth = $pdo->prepare($sql);
                $sth->execute();
                //refresh();
            }
                                    
            if (isset($_POST['ev_del_vol_user'])) {
            
                $data = array('em' => $_SESSION['vl_user'], 'ev' => $_POST['event_id']);
                $sql = "DELETE FROM subscriptions WHERE (email = :em) AND (event_id = :ev)";
                $sth = $pdo->prepare($sql);
                $sth->execute($data);
                //refresh();
            }
            
            if (isset($_POST['ev_view'])) {

                $sql = "SELECT * from events WHERE event_id = '".$_POST['event_id']."'";
                $result = $pdo->query($sql);
                $row = $result->fetch(PDO::FETCH_ASSOC);
             
                $code = null;
                $code .= '<div class="vl_form_box"><h3>'.i18n_r('volunteer/view_event_title').'</h3>';
                $code .= '<form method="post" id="view_event" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                $code .= '<tr><td>'.i18n_r('volunteer/start_date').':</td><td><input class="in3" type="text" name="ce_start" size="14" value="'.$row['start_date'].'" readonly /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/end_date').':</td><td><input class="in3" type="text" name="ce_end" size="14" value="'.$row['end_date'].'" readonly /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/name').':</td><td><input class="in3" type="text" size="40" name="ce_name" value="'.$row['name'].'" readonly /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/group').':</td><td><input class="in3" type="text" size="40" name="ce_group" value="'.$row['group_name'].'" readonly /></td></tr>';
                $code .= '<tr><td>'.i18n_r('volunteer/details').':</td><td><textarea class="in3" cols="40" rows="5" name="ce_details" readonly >'.$row['details'].'</textarea></td></tr>';
                $code .= '<tr><td></td><td><input type="hidden" name="event_id" value="'.$row['event_id'].'" />';
                $code .= '<input type="hidden" name="ev_view" value="1" />';
                $code .= '<input type="submit" class="button" name="ev_volunteer" value="'.i18n_r('volunteer/volunteer').'" />&nbsp;';
                $code .= '<input type="submit" class="button" name="ev_del_vol_user" value="'.i18n_r('volunteer/unvolunteer').'" />&nbsp;';
                $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="cancel" value="'.i18n_r('volunteer/cancel').'" /></a>&nbsp;';
                $code .= '<td></td><td></td></tr>';
                $code .= '</table></form><p>&nbsp;</p>';
                $code .= '<h3>'.i18n_r('volunteer/volunteers_for_event').'</h3>';
                $result = $pdo->query("SELECT * FROM subscriptions WHERE event_id='".$_POST['event_id']."'");
                if (count($result)) {
                    $code .= '<table>';
                    foreach($result as $row) {
                        $result2= $pdo->query("SELECT * FROM volunteers WHERE email='".$row['email']."'");
                        $row2 = $result2->fetch(PDO::FETCH_ASSOC);
                        $name = $row2['fname'].' '.$row2['lname'];
                        if (($row2['fname']=='') || ($row2['lname']=='')) $name = $row['email'].' <span class="error">('.i18n_r('volunteer/name_missing').')</span>';
                        $code .= '<tr><td>'.$name.'</td></tr>';
                    }
                    $code .= '</table></div>';
                }
                                                                                                
            }

            /*** admin tasks ***/
            if (isset($_SESSION['USERISADMIN'])) {

                if (isset($_POST['ev_delete_form'])) {
                    $code .= '<p>'.i18n_r('volunteer/really_delete').'</p><p><span style="color:blue;">'.$_POST['event_name'].'</span></p>';
                    $code .= '<form method="post" id="delevent" action="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input type="hidden" name="event_id" value="'.$_POST['event_id'].'" />';
                    $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="no_delevent" value="'.i18n_r('volunteer/no').'" /></a>&nbsp;';
                    $code .= '<input type="submit" class="button" name="ev_del_proc" value="'.i18n_r('volunteer/yes').'" />&nbsp;';
                    $code .= '</form>';
                }
                
                if (isset($_POST['ev_del_proc'])) {
                    $data = array ('ev' => $_POST['event_id']);
                    $sql = "DELETE FROM events WHERE event_id = :ev";
                    $sth = $pdo->prepare($sql);   
                    $sth->execute($data);
                    $sql = "DELETE FROM subscriptions WHERE event_id = :ev";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=null;
                    unset($_POST);
                    refresh();
                }
               
                if (isset($_POST['ev_create'])) {
                    $data = array('cn' => htmlentities($_POST['ce_name'],ENT_QUOTES), 
                                  'cs' => $_POST['ce_start'], 
                                  'ce' => $_POST['ce_end'],
                                  'cg' => $_POST['ce_group'], 
                                  'cd' => htmlentities($_POST['ce_details'],ENT_QUOTES));
                    $sql = "INSERT INTO events (name,start_date,end_date,group_name,details) VALUES (:cn,:cs,:ce,:cg,:cd)";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=null;
                    unset($_POST);
                    refresh();
                }

                if (isset($_POST['ev_mod'])) {
                    $data = array('cn' => htmlentities($_POST['ce_name'],ENT_QUOTES),
                                  'cs' => $_POST['ce_start'],
                                  'ce' => $_POST['ce_end'],
                                  'cg' => $_POST['ce_group'],
                                  'cd' => htmlentities($_POST['ce_details'],ENT_QUOTES));
                    $sql = "UPDATE events SET name = :cn, start_date = :cs, end_date = :ce, group_name = :cg, details = :cd WHERE event_id = '".$_POST['event_id']."'";
                    $sth = $pdo->prepare($sql);
                    $sth->execute($data);
                    $pdo=null;
                    unset($_POST);
                    refresh();
                }
                
                if (isset($_POST['ev_del_vol'])) {
                    $data = array('ev' => $_POST['event_id'], 'em' => $_POST['event_vol']);
                    $sql = "DELETE FROM subscriptions WHERE (event_id = :ev) AND (email = :em)";
                    $sth = $pdo->prepare($sql);   
                    $sth->execute($data);
                }
            
               if ( (isset($_POST['ev_edit'])) && (!isset($_POST['ev_delete_form'])) ) {
                   $sql = "SELECT * from events WHERE event_id = '".$_POST['event_id']."'";
                   $result = $pdo->query($sql);
                   $row = $result->fetch(PDO::FETCH_ASSOC);               
                   $code .= '<div class="vl_form_box"><h3>'.i18n_r('volunteer/edit_event').'</h3>';
                   $code .= '<form method="post" id="edit_event" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                   $code .= '<tr><td>'.i18n_r('volunteer/start_date').':</td><td><input class="in3" type="text" id="dpsta" name="ce_start" size="14" value="'.$row['start_date'].'" readonly /></td></tr>';
                   $code .= '<tr><td>'.i18n_r('volunteer/end_date').':</td><td><input class="in3" type="text" id="dpend" name="ce_end" size="14" value="'.$row['end_date'].'" readonly /></td></tr>';
                   $code .= '<tr><td>'.i18n_r('volunteer/name').':</td><td><input class="in3" type="text" size="40" name="ce_name" value="'.$row['name'].'" /></td></tr>';
                   $code .= '<tr><td>'.i18n_r('volunteer/group').':</td><td><select class="in3" name="ce_group">';
                   
                   $result2 = $pdo->query("SELECT DISTINCT group_name FROM groups ORDER BY group_name ASC");
               
                   if (count($result2)) {
                       foreach($result2 as $row2) {
                           $sel = null;
                           if ($row['group_name'] == $row2['group_name']) $sel = 'selected';
                           $code .= '<option '.$sel.' >'.$row2['group_name'].'</option>';
                       }        
                   }
                   
                   $code .= '</select></td></tr>';
                   $code .= '<tr><td>'.i18n_r('volunteer/details').':</td><td><textarea class="in3" cols="40" rows="5" name="ce_details">'.$row['details'].'</textarea></td></tr>';
                   $code .= '<tr><td></td><td colspan="2">';
                   $code .= '<input type="submit" class="button" name="ev_volunteer" value="'.i18n_r('volunteer/volunteer').'" />&nbsp;';
                   $code .= '<input type="submit" class="button" name="ev_delete_form" value="'.i18n_r('volunteer/delete').'" />&nbsp;';
                   $code .= '<input type="submit" class="button" name="ev_mod" value="'.i18n_r('volunteer/save').'" />&nbsp;';
                   $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="cancel" value="'.i18n_r('volunteer/cancel').'" /></a>&nbsp;';
                   $code .= '<td></td></tr></table>';
                   $code .= '<input type="hidden" name="event_id" value="'.$row['event_id'].'" /><input type="hidden" name="ev_edit" value="1" />';
                   $code .= '<input type="hidden" name="event_name" value="'.$row['name'].'" /></form>';
                   $code .= '<p>&nbsp;</p>';
                   $code .= '<h3>'.i18n_r('volunteer/volunteers_for_event').'</h3>';
                   
                   $result = $pdo->query("SELECT * FROM subscriptions WHERE event_id='".$_POST['event_id']."'");
                   if (count($result)) {
                       $code .= '<table>';
                       foreach($result as $row) {
                           $result2= $pdo->query("SELECT * FROM volunteers WHERE email='".$row['email']."'");
                           $row2 = $result2->fetch(PDO::FETCH_ASSOC);
                           $name = $row2['fname'].' '.$row2['lname'];
                           if (($row2['fname']=='') || ($row2['lname']=='')) $name = $row['email'].' <span style="color:red;">('.i18n_r('volunteer/name_missing').')</span>';
                           $code .= '<tr><td>'.$name.'</td><td>';
                           $code .= '<form method="post" id="delete_event_volunteer" action="'.$_SERVER['REQUEST_URI'].'">';
                           $code .= '<input type="hidden" name="event_id" value="'.$_POST['event_id'].'" />';
                           $code .= '<input type="hidden" name="ev_edit" value="1" />';
                           $code .= '<input type="hidden" name="event_vol" value="'.$row['email'].'" />';
                           $code .= '<input type="submit" class="button" name="ev_del_vol" value="'.i18n_r('volunteer/remove').'">';
                           $code .= '</form></td></tr>';
                       }
                       $code .= '</table></div>';
                   }
                }
            
                if (isset($_POST['create_event'])) {
                    $code = null;
                    $sql="SELECT COUNT(*) FROM groups";
                    $result = $pdo->query($sql);
                    $row = $result->fetch(PDO::FETCH_NUM);
                                
                    if ($row[0]>0) {
                
                        $code .= '<div class="vl_form_box"><h3>'.i18n_r('volunteer/create_event_title').'</h3>';
                        $code .= '<form method="post" id="create_event" action="'.$_SERVER['REQUEST_URI'].'"><table>';
                        $code .= '<tr><td>'.i18n_r('volunteer/start_date').':</td><td><input class="in3" type="text" id="dpsta" name="ce_start" size="14" value="" readonly /></td></tr>';
                        $code .= '<tr><td>'.i18n_r('volunteer/end_date').':</td><td><input class="in3" type="text" id="dpend" name="ce_end" size="14" value="" readonly /></td></tr>';
                        $code .= '<tr><td>'.i18n_r('volunteer/name').':</td><td><input class="in3" type="text" size="40" name="ce_name" value="" /></td></tr>';
                        $code .= '<tr><td>'.i18n_r('volunteer/group').':</td><td><select class="in3" name="ce_group">';
                   
                        $result2 = $pdo->query("SELECT DISTINCT group_name FROM groups ORDER BY group_name ASC");
                        foreach($result2 as $row2) {
                            $code .= '<option>'.$row2['group_name'].'</option>';
                        }        
                
                        $code .= '</select></td></tr>';
                        $code .= '<tr><td>'.i18n_r('volunteer/details').':</td><td><textarea class="in3" cols="40" rows="5" name="ce_details"> </textarea></td></tr>';
                        $code .= '<tr><td></td><td colspan="2">';
                        $code .= '<a href="'.$_SERVER['REQUEST_URI'].'"><input class="button" type="button" name="cancel" value="'.i18n_r('volunteer/cancel').'" /></a>&nbsp;';
                        $code .= '<input type="submit" class="button" name="ev_create" value="'.i18n_r('volunteer/save').'" /><td></td></tr>';
                        $code .= '</table></form></div>';
                    }else{
                        $code .= i18n_r('volunteer/create_group_first');
                    }
                }
            }
            
            if ( (empty($_POST)) || (isset($_POST['page'])) || (isset($_POST['selgroup'])) ) { 

                #list events
                if (isset($_SESSION['USERISADMIN'])) {
                    $code .= '<div class="vl_form_box"><form method="post" id="create_event" action="'.$_SERVER['REQUEST_URI'].'">';
                    $code .= '<input type="submit" class="button" name="create_event" value="'.i18n_r('volunteer/create_new_event').'" /></form></div><br />';
                }
                
                $sql="SELECT COUNT(*) FROM groups WHERE email = '".$_SESSION['vl_user']."'";
                $result = $pdo->query($sql);
                $row = $result->fetch(PDO::FETCH_NUM);
                if ($row[0]==0) {
                    $code .= i18n_r('volunteer/join_group_first');
                }else{                                                                                  
                     
                    $rowsPerPage = 50;                      
                    
                    $sql="SELECT COUNT(*) FROM events";
                    $result = $pdo->query($sql);
                    $row = $result->fetch(PDO::FETCH_NUM);   
                    $lastpage = ceil($row[0] / $rowsPerPage);
                    
                    if (isset($_POST['page'])) $pageNum = $_POST['page'];                        
                    if (!isset($pageNum)) $pageNum = 1;
                    if ($pageNum == 0) $pageNum=1;
                    if ($pageNum > $lastpage) $pageNum = $lastpage;
                    $offset = ($pageNum - 1) * $rowsPerPage;
                    
                    $code .= '<h3>'.i18n_r('volunteer/list_events_title').'</h3>';                    
                    $code .= '<form method="post" id="form_selgroup" action="'.$_SERVER['REQUEST_URI'].
                       '"><p>Group:&nbsp;<select id="selgroup" class="in3" name="selgroup" onchange="SelectChanged(this)">';
                    $code .= '</option>';
                       
                    $result = $pdo->query("SELECT DISTINCT group_name FROM groups WHERE email = '".
                        $_SESSION['vl_user']."' ORDER BY group_name ASC");
                    foreach($result as $row) {
                        $s=null;
                        if (!isset($firstgroup)) $firstgroup = $row['group_name'];
                        if (isset($_POST['selgroup']) && ($_POST['selgroup'] == $row['group_name'])) $s=' selected ';
                        $code .= '<option'.$s.'>'.$row['group_name'].'</option>';
                    }        
                    
                    if (isset($_POST['selgroup'])) {
                        $pgroup = $_POST['selgroup'];
                    }else{
                        $pgroup = $firstgroup;
                    }
                    
                    $code .= '</select></p></form>';
                    $result = $pdo->query("SELECT * FROM events WHERE (group_name = '".
                            $pgroup."') ORDER BY start_date DESC LIMIT '".$offset."', '".$rowsPerPage."'");
                    
                    if (count($result)) {
                        $code .= '<table><tr id="vl_list_nav_bar"><td id="vl_list_nav_left">';
                        if ($pageNum > 1) {
                            $code .= '<form method="post" id="prevpage" action="'.$_SERVER['REQUEST_URI'].'">';
                            $code .= '<input type="hidden" name="page" value="'.($pageNum - 1).'"/>';
                            $code .= '<input type="submit" class="button" value="<" /></form>';
                        }
                            $code .= '</td><td id="vl_list_nav_center">Page No.'.$pageNum.'/'.$lastpage.'</td><td id="vl_list_nav_right">';
                        if ($pageNum < $lastpage) {
                            $code .= '<form method="post" id="nextpage" action="'.$_SERVER['REQUEST_URI'].'">';
                            $code .= '<input type="hidden" name="page" value="'.($pageNum + 1).'"/>';
                            $code .= '<input type="submit" class="button" value=">" /></form>';
                        }
                        $code .= '</td></tr></table><table>';
                        foreach($result as $row) {
                            $code .= '<tr class="vl_list_hr" ><td style="width:25%">'.$row['start_date'].
                                 '</td><td>'.$row['name'].
                                 '</td><td style="width:20%;text-align:right;"><form method="post" id="event_list" action="'.$_SERVER['REQUEST_URI'].'">'.
                                 '<input type="hidden" name="event_id" value="'.$row['event_id'].'" />';
                            if ( isset($_SESSION['USERISADMIN']) ) { 
                                $code .= '<input type="submit" class="button" name="ev_edit" value="'.i18n_r('volunteer/edit').'" />';
                            }else{
                            $code .= '<input type="submit" class="button" name="ev_view" value="'.i18n_r('volunteer/view').'" />';
                            }
                            $code .= '</form></td></tr>';
                        }
                        $code .= '</table>';
                    }
                }
            }

        }else{
            $code = '<p>'.i18n_r('volunteer/connect_first').'</p>';
        }
        
        $content = preg_replace('#\[vl_events\]#', $code, $content);
        unset($code);
        
    }

//////////////

    # return the modified content
    $pdo = null;
    return $content;
}



// functions

# display current user
function vl_display_user() {

    if (isset($_SESSION['vl_user'])) {
        echo '<h2>Connected Volunteer</h2><p>'.$_SESSION['vl_user'].'</p>';
    }

}

# display version
function vl_display_version() {
    global $vl_version;
    echo '<p>Volunteer version '.$vl_version.'</p>';
}

# start db. create & update if needed
function vl_dbstart() {
    $pdo = newdb(); 
    try {
        $sql="SELECT * FROM 'volunteers'";
        $pdo->exec($sql);
    }
    catch(PDOException $e) {
        vl_createdb();
    }
    vl_updatedb();
}

# create the db if it doesn't exist
function vl_createdb() {

    try {
        
        $pdo = newdb();;
        
        $sql='CREATE TABLE volunteers ('.
            'email VARCHAR(40),'. 
            'password VARCHAR(40),'.
            'connected BOOLEAN,'.
            'lastaccess DATETIME,'.
            'lastsubscribe DATETIME,'.
            'role VARCHAR(20),'.
            'fname VARCHAR(40),'.
            'lname VARCHAR(40),'.
            'address VARCHAR(255),'.
            'city VARCHAR(40),'.
            'state VARCHAR(20),'.
            'zip VARCHAR(10),'.
            'country VARCHAR(20),'.
            'tel_work VARCHAR(40),'.
            'tel_home VARCHAR(40),'.
            'mobile1 VARCHAR(40),'.
            'mobile2 VARCHAR(40),'.
            'comments TEXT'.
        ')';
        $pdo->exec($sql);
        
        $sql='CREATE UNIQUE INDEX email_index ON volunteers(email)';
        $pdo->exec($sql);
    
        $sql='CREATE TABLE events ('.
            'event_id INTEGER PRIMARY KEY,'.
            'name VARCHAR(40),'.
            'start_date DATETIME,'.
            'end_date DATETIME,'.
            'group_name VARCHAR(40),'.
            'details TEXT'.
        ')';
        $pdo->exec($sql);
    
        $sql='CREATE UNIQUE INDEX event_index ON events(event_id)';
        $pdo->exec($sql);

        $sql='CREATE TABLE subscriptions (email VARCHAR(40), event_id INTEGER)';
        $pdo->exec($sql);
        
        $sql='CREATE TABLE groups (group_name VARCHAR(40), email VARCHAR(40), group_leader INTEGER)';
        $pdo->exec($sql);
        
        $sql='CREATE TABLE roles (email VARCHAR(40), role VARCHAR(40))';
        $pdo->exec($sql);
        
        $pdo->exec('CREATE TABLE dbinfo (dbversion varchar(10))');

    }    

    catch(PDOException $e) {  
        die($e->getMessage());
    }       
    $pdo = null;
}

function vl_updatedb() {
    // here we can correct the db at each upgrade
    // instead of having to delete it
    global $vl_version;
    $pdo = newdb();

    $result = $pdo->query('SELECT * from dbinfo');
    $row = $result->fetch(PDO::FETCH_ASSOC);
    $dbversion = $row['dbversion'];

    if ( $dbversion != $vl_version ) {
        switch($dbversion) {
            case '0.4.7':
                break;
            default:
                break;    
        }
    }
    $pdo = null;
} 

function newdb() {
    global $vl_version, $vl_database;
    // create new PDO db
    try {
        switch ($vl_database) {
            case "sqlite3":
                $pdo = new PDO('sqlite:'.GSDATAOTHERPATH.'volunteer/volunteer.db');
                break;
            case "mysql":
                // $pdo = new PDO('mysql:host=$host;port=$port;dbname=$dbname', $username, $password);    
                break;
            case "postgresql":
                // $pdo = new PDO('pgsql:host=$host;port=$port;dbname=$dbname', $username, $password );
            // add more databases here            
            default:
                $pdo = new PDO('sqlite:'.GSDATAOTHERPATH.'volunteer/volunteer.db');
        }
        $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }

    catch(PDOException $e) {
        file_put_contents(GSDATAOTHERPATH.'volunteer/PDOErrors.log', $e->getMessage()."\n", FILE_APPEND);
        die($e->getMessage());
    }   

    return $pdo;
}

function vl_genpassword($len) {
    $pass = '';
    $lchar = 0;
    $char = 0;
    for($i = 0; $i < $len; $i++) {
        while($char == $lchar) {
            $char = rand(48, 109);
            if($char > 57) $char += 7;
            if($char > 90) $char += 6;
        }
        $pass .= chr($char);
        $lchar = $char;
    }
    return $pass;
}

function mailclean($email) {
    $email = stripslashes(trim($email));
    $email = str_replace('"',"", $email);
    $email = str_replace("'","", $email);
    $email = filter_var($email,FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);

    if ($email) {    
        list($name, $domain) = explode('@',$email);
        if(!checkdnsrr($domain,'MX')) {
            $email = false;  
        }                  
    } 
    return $email;
}                                                                        

function killsession() {
    session_start();
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function refresh() {  
    $url = 'http';
    if ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on')) $url .= 's';
    $url .= '://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
    header('Location: '.$url);
    exit();
}

?>









