The plugin can be translated into other languages. 
See /lang/en.php, ru.php ... 
Make your translation and upload the xx.php file to the directory - /lang/ - then select your language file in the plugin settings.

If commercial use: please donate $2 per domain.

Feel free for donate.
PayPal: netexplorer@yandex.ru
Yandex.Money: https://money.yandex.ru/to/410012986152433