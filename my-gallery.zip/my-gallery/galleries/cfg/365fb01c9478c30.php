<?php
$my_gallery_output_script="BaguetteBox";
$my_gallery_default_thumbnails_size="240"; 
$my_gallery_default_images_size="1024";
$my_gallery_default_slides_per_view="1";
$my_gallery_default_slides_autoplay="";
?>