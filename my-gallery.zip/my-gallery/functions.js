function MyGallery_b64_to_utf8(str) { 
	return decodeURIComponent(escape(window.atob(str))); 
}

function MyGallery_stopVideo(itemSelectors) {
		var itemElements = document.querySelectorAll(itemSelectors);
		if (itemElements != null) {
			for (var i = 0; i < itemElements.length; i++) {
				itemElements[i].src = itemElements[i].src; // causes a reload so it stops playing, music, video, etc.
			}
		}
	}