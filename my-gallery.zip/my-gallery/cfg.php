<?php
$my_gallery_language="en";
$my_gallery_selected_dir="365fb01c9478c30";
$my_gallery_selected_name="Gallery 1";
$my_gallery_default_max_file_size="10";
?>