<?php
/*
Plugin Name: GetSimple Basket
Description: Add cart to GetSimple CMS
Version: 1.2
Author: Makhonin Pavel
Author URI: http://www.vk.com/cupuyc1989
*/

$thisfile=basename(__FILE__, ".php");
$settings_file = realpath(dirname(__FILE__)) .'/basket_plugin/basket_settings.xml';
$settings_file = str_replace('\\','/',$settings_file);
global $discounts_file;
$discounts_file = realpath(dirname(__FILE__)) .'/basket_plugin/basket_discounts.xml';
$discounts_file = str_replace('\\','/',$discounts_file);
global $history_dir;
$history_dir = realpath(dirname(__FILE__)) .'/basket_plugin/history/';
$history_dir = str_replace('\\','/',$history_dir);

if (!file_exists($settings_file)) {
	$settings_data = @new SimpleXMLExtended('<data></data>');
	$settings_data->addChild('language', serialize('en'));
	$settings_data->addChild('admin_mail', serialize('test@test.ru'));
	$settings_data->addChild('price_field_name', serialize('price'));
	$settings_data->addChild('image_show', serialize('Y'));
	$settings_data->addChild('image_field_name', serialize('image'));
	$settings_data->addChild('letter_header', serialize('New order was maked'));
	$settings_data->addChild('ok_text', serialize('Your order was accepted. We will contact you soon'));
	$settings_data->addChild('basket_styles', serialize('position:fixed; top: 0; right: 0; padding: 10px; border: 1px solid silver; background: #fff; z-index: 1000'));
	$settings_data->addChild('currency', serialize('$'));
	$settings_data->addChild('basket_message_positions', serialize('M'));
	$settings_data->addChild('save_history', serialize('Y'));
	$settings_data->addChild('show_delivery', serialize('N'));
	$settings_data->addChild('delivery', serialize('Pickup,By post,Courier'));
	$settings_data->addChild('show_payment', serialize('N'));
	$settings_data->addChild('payment', serialize('Cash when pickup,Cash to courier,By Card when pickup,By Card to courier,Cash(on post)'));
	$settings_data->addChild('ajax', serialize('Y'));
	$settings_data->addChild('jquery_include', serialize('N'));
	$settings_data->addChild('show_history_to_user', serialize('Y'));
	$settings_data->addChild('use_discounts', serialize('Y'));
	$settings_data->addChild('allow_print', serialize('Y'));
	XMLsave($settings_data, $settings_file);
} elseif (!empty($_POST['basket_settings_change'])) {
	unlink($settings_file);
	$settings_data = @new SimpleXMLExtended('<data></data>');
	$settings_data->addChild('language', serialize($_POST['language']));
	$settings_data->addChild('admin_mail', serialize($_POST['admin_mail']));
	$settings_data->addChild('price_field_name', serialize($_POST['price_field_name']));
	$settings_data->addChild('image_show', serialize($_POST['image_show']));
	$settings_data->addChild('image_field_name', serialize($_POST['image_field_name']));
	$settings_data->addChild('letter_header', serialize($_POST['letter_header']));
	$settings_data->addChild('ok_text', serialize($_POST['ok_text']));
	$settings_data->addChild('basket_styles', serialize($_POST['basket_styles']));
	$settings_data->addChild('currency', serialize($_POST['currency']));
	$settings_data->addChild('basket_message', serialize($_POST['basket_message']));
	$settings_data->addChild('basket_message_positions', serialize($_POST['basket_message_positions']));
	$settings_data->addChild('save_history', serialize($_POST['save_history']));
	$settings_data->addChild('show_delivery', serialize($_POST['show_delivery']));
	$settings_data->addChild('delivery', serialize($_POST['delivery']));
	$settings_data->addChild('show_payment', serialize($_POST['show_payment']));
	$settings_data->addChild('payment', serialize($_POST['payment']));
	$settings_data->addChild('ajax', serialize($_POST['ajax']));
	$settings_data->addChild('jquery_include', serialize($_POST['jquery_include']));
	$settings_data->addChild('show_history_to_user', serialize($_POST['show_history_to_user']));
	$settings_data->addChild('use_discounts', serialize($_POST['use_discounts']));
	$settings_data->addChild('allow_print', serialize($_POST['allow_print']));
	XMLsave($settings_data, $settings_file);
} elseif (!empty($_POST['demo_spec_page'])) {
	$spec_page_file = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_basket-items.xml';
	$copy_path = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_basket-items.xml';
	copy(str_replace('\\','/',$spec_page_file), str_replace('\\','/',$copy_path));
	$spec_page_file2 = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_basket-items-with-discounts.xml';
	$copy_path2 = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_basket-items-with-discounts.xml';
	copy(str_replace('\\','/',$spec_page_file2), str_replace('\\','/',$copy_path2));
}

if (file_exists($settings_file)) {
	$xml = getXML($settings_file);
	global $basket_settings;
	$basket_settings['LANGUAGE'] = unserialize($xml->language);
	$basket_settings['ADMIN_MAIL'] = unserialize($xml->admin_mail);
	$basket_settings['PRICE_FIELD_NAME'] = unserialize($xml->price_field_name);
	$basket_settings['IMAGE_SHOW'] = unserialize($xml->image_show);
	$basket_settings['IMAGE_FIELD_NAME'] = unserialize($xml->image_field_name);
	$basket_settings['LETTER_HEADER'] = unserialize($xml->letter_header);
	$basket_settings['OK_TEXT'] = unserialize($xml->ok_text);
	$basket_settings['BASKET_STYLES'] = unserialize($xml->basket_styles);
	$basket_settings['CURRENCY'] = unserialize($xml->currency);
	$basket_settings['BASKET_MESSAGE'] = unserialize($xml->basket_message);
	$basket_settings['BASKET_MESSAGE_POSITION'] = unserialize($xml->basket_message_positions);
	$basket_settings['SAVE_HISTORY'] = unserialize($xml->save_history);
	$basket_settings['SHOW_DELIVERY'] = unserialize($xml->show_delivery);
	$basket_settings['DELIVERY'] = explode(',',unserialize($xml->delivery));
	$basket_settings['SHOW_PAYMENT'] = unserialize($xml->show_payment);
	$basket_settings['PAYMENT'] = explode(',',unserialize($xml->payment));
	$basket_settings['AJAX'] = unserialize($xml->ajax);
	$basket_settings['JQUERY_INCLUDE'] = unserialize($xml->jquery_include);
	$basket_settings['SHOW_HISTORY_TO_USER'] = unserialize($xml->show_history_to_user);
	$basket_settings['USE_DISCOUNTS'] = unserialize($xml->use_discounts);
	$basket_settings['ALLOW_PRINT'] = unserialize($xml->allow_print);
}

// set language
include_once (realpath(dirname(__FILE__)) .'/basket_plugin/lang/'.$basket_settings['LANGUAGE'].'.php');

register_plugin(
	$thisfile,
	$MESS['register_plugin_name'],
	'1.2',
	'Makhonin Pavel',
	'http://www.vk.com/cupuyc1989',
	$MESS['register_plugin_desc'],
	'plugins', 
	'hello_world_show'
);

// add some actions
add_action('plugins-sidebar','createSideMenu',array($thisfile,'> '.$MESS['tab_sidebar_settings_name'].' <', 'settings'));
add_action('index-pretemplate','basket_logic');
add_action('index-posttemplate','basket_small_show');
if (isset($_GET['basket']) && $_GET['basket'] == 'Y') {
	add_action('index-pretemplate','set_basket_title');
	add_action('content-top','basket_big');
}
if ($basket_settings['SAVE_HISTORY'] == 'Y') {
	add_action('admin-pre-header','history_logic');
	add_action('plugins-sidebar','createSideMenu',array($thisfile,'> '.$MESS['tab_sidebar_history_name'].' <', 'history'));
}
if (isset($_GET['history']) && $_GET['history'] == 'Y' && $basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') {
	add_action('index-pretemplate','history_page_title');
	add_action('content-top','history_page');
}
if ($basket_settings['AJAX'] == 'Y') {
	add_action('index-posttemplate','ajax_basket');
}
if ($basket_settings['USE_DISCOUNTS'] == 'Y') {
	add_action('admin-pre-header','discounts_logic');
	add_action('plugins-sidebar','createSideMenu',array($thisfile,'> '.$MESS['tab_sidebar_discounts_name'].' <', 'discounts'));
}

function basket_logic() {
	if (session_id() === "") {
	   session_start();
	}
	global $basket_settings; global $MESS; global $history_dir; global $discounts_file;
	// if form was submitted
	if (!empty($_POST)) {
		// check discount
		if (!empty($_POST['discount_input']) && !empty($_POST['discount_code'])) {
			$arDiscounts = getXML($discounts_file);
			if ($node = $arDiscounts->xpath("//discount[code='".$_POST['discount_code']."']")) {
				if (intVal($node[0]->use) > 0) {
					$_SESSION['BASKET']['DISCOUNT']['CODE'] = $_POST['discount_code'];
					$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] = 'Y';
					$_SESSION['BASKET']['DISCOUNT']['PERCENT'] = (int)$node[0]->value;
					$_SESSION['BASKET']['DISCOUNT']['SUM'] = ceil($_SESSION['BASKET']['SUM'] * ( 100 - (int)$node[0]->value ) / 100);
					$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_accepted'].' '.ceil($_SESSION['BASKET']['SUM'] * ( 100 - (int)$node[0]->value ) / 100).' '.$basket_settings['CURRENCY'].'. '.$MESS['cart_page_discount_persent'].' '.(int)$node[0]->value.'%';
				} else {
					unset($_SESSION['BASKET']['DISCOUNT']);
					$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_was_used'];
				}
			} else {
				unset($_SESSION['BASKET']['DISCOUNT']);
				$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_not_exists'];
			}
		}
		// send a letter
		if (!empty($_POST['order_submit']) && 0 < count($_SESSION['BASKET']['ITEMS'])) {
			// some data
			$encode = 'UTF-8';
			if (!empty($_POST['order_delivery']) || !empty($_POST['order_payment'])) {
				$delivery = ''; $payment = '';
				if (!empty($_POST['order_delivery'])) {
					$delivery = '<p><strong>'.$MESS['in_letter_delivery_label'].'</strong> '.$_POST['order_delivery'].'</p>';
				}
				if (!empty($_POST['order_payment'])) {
					$payment = '<p><strong>'.$MESS['in_letter_payment_label'].'</strong> '.$_POST['order_payment'].'</p>';
				}
			}
			if (@$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] == 'Y') {
				$discount = '<p><strong>'.$_SESSION['BASKET']['DISCOUNT']['MESSAGE'].'</strong></p>';
				$discount .= '<p><strong>'.$MESS['in_letter_discount_was_used'].'</strong> <i>'.$_SESSION['BASKET']['DISCOUNT']['CODE'].'</i></p>';
				$arDiscounts = getXML($discounts_file);
				if ($node = $arDiscounts->xpath("//discount[code='".$_SESSION['BASKET']['DISCOUNT']['CODE']."']")) {
					$use = (int)$node[0]->use - 1;
					unset($node[0]->use);
					$node[0]->addChild('use',$use);
					XMLsave($arDiscounts, $discounts_file);
				}
			}
			// make order items to string
			$orderstring = '';
			foreach ($_SESSION['BASKET']['ITEMS'] as $arItem) {
				$orderstring .= '
					<tr>
						<td><a href="'.$arItem['LINK'].'" target="_blank">'.$arItem['NAME'].'</a></td>
						<td>'.$arItem['PRICE'].' '.$basket_settings['CURRENCY'].'</td>
						<td>'.$arItem['QUANTITY'].'</td>
						<td>'.$arItem['QUANTITY'] * $arItem['PRICE'].' '.$basket_settings['CURRENCY'].'</td>
					</tr>
				';
			}
			// letter message
			$message = '
				<p>'.date("d-m-Y (H:i:s)",time()).' '.$_SERVER['HTTP_HOST'].' '.$MESS['in_letter_order_was_created'].'</p>
				<br />
				<p><strong>'.$MESS['in_letter_user_name'].'</strong> '.$_POST['order_name'].'</p>
				<p><strong>'.$MESS['in_letter_user_phone'].'</strong> '.$_POST['order_phone'].'</p>
				<p><strong>'.$MESS['in_letter_user_email'].'</strong> '.$_POST['order_email'].'</p>
				'.@$delivery.@$payment.@$discount.'
				<p><strong>'.$MESS['in_letter_user_message'].'</strong> '.trim($_POST['order_text']).'</p>
				<br />
				<h2>'.$MESS['in_letter_order_list_title'].'</h2>
				<table border="1" cellspacing="1" cellpadding="5" width="100%">
					<thead>
						<tr>
							<th>'.$MESS['table_name_column'].'</th>
							<th>'.$MESS['table_price_column'].'</th>
							<th>'.$MESS['table_quantity_column'].'</th>
							<th>'.$MESS['table_sum_column'].'</th>
						</tr>
					</thead>
					<tbody>
						'.$orderstring.'
					</tbody>
					<tfoot>
						<tr>
							<td colspan="4" align="right"><strong> '.$_SESSION['BASKET']['SUM'].' '.$basket_settings['CURRENCY'].'</strong></td>
						</tr>
					</tfoot>
				</table>
			';
			// send a letter
			$headers  = "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html  charset=utf-8\r\n";
			$headers .= "Content-Transfer-Encoding: 8bit\r\n";
			$headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
			$headers .= "From: \"".iconv($encode,'KOI8-R',$_POST['order_name'])."\" <".$_POST['order_email'].">\r\n";
			$headers .= "X-Mailer: My Send E-mail\r\n";
			mail($basket_settings['ADMIN_MAIL'],iconv($encode,'KOI8-R',$basket_settings['LETTER_HEADER']),iconv($encode,'KOI8-R',$message),$headers);
			
			// create file to history
			if ($basket_settings['SAVE_HISTORY'] == 'Y') {
				global $history_dir;
				$orderxml = @new SimpleXMLExtended('<data></data>');
				$file = $history_dir.date('d-m-Y_H-i-m',time()).'.xml';
				$orderxml->addChild('date', serialize(date('d-m-Y H:i:m',time())));
				$orderxml->addChild('name', serialize(htmlspecialchars($_POST['order_name'])));
				$orderxml->addChild('phone', serialize(htmlspecialchars($_POST['order_phone'])));
				$orderxml->addChild('email', serialize(htmlspecialchars($_POST['order_email'])));
				$orderxml->addChild('message', serialize(htmlspecialchars($_POST['order_text'])));
				$orderxml->addChild('items', serialize(count($_SESSION['BASKET']['ITEMS'])));
				if (@$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] == 'Y') {
					$orderxml->addChild('sum', serialize('<s>'.$_SESSION['BASKET']['SUM'].'</s><br/>'.$_SESSION['BASKET']['DISCOUNT']['SUM']));
				} else {
					$orderxml->addChild('sum', serialize($_SESSION['BASKET']['SUM']));
				}
				$orderxml->addChild('status', serialize($MESS['history_status_default']));
				$orderxml->addChild('admin_message', serialize(''));
				$orderxml->addChild('order', htmlspecialchars('<table style="margin-bottom:0"><thead><tr><th>'.$MESS['table_name_column'].'</th><th>'.$MESS['table_price_column'].'</th><th>'.$MESS['table_quantity_column'].'</th><th>'.$MESS['table_sum_column'].'</th></tr></thead><tbody>'.$orderstring.'</tbody></table>'.@$delivery.@$payment.@$discount));
				XMLsave($orderxml, $file);
			}
			if ($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') {
				$arFiles = array();
				if ($handle = opendir($history_dir)) {
					while (false !== ($entry = readdir($handle))) {
						if ($entry != "." && $entry != "..") {
							$arFiles[] = array(
								"PATH" => $history_dir.$entry,
								"CREATED" => filectime($history_dir.$entry)
							);
						}
					}
					closedir($handle);
				}
				// clear data and session and make SUCESS TEXT for user
				$_SESSION['BASKET']['OK'] = $basket_settings['OK_TEXT'].'<br>'.$MESS['order_number'].' <strong>'.count($arFiles).'</strong>';
				unset($arFiles);
			} else {
				$_SESSION['BASKET']['OK'] = $basket_settings['OK_TEXT'];
			}
			unset($_SESSION['BASKET']['ITEMS']);
			unset($_SESSION['BASKET']['DISCOUNT']);
		}
		// add item to cart logic
		elseif(!empty($_POST['add_item']) && $_POST['quantity'] !== '0') {
			$_SESSION['BASKET']['ITEMS'][$_POST['id']] = array(
			   "NAME" => $_POST['name'],
			   "PRICE" => intVal($_POST[$basket_settings['PRICE_FIELD_NAME']]),
			   "QUANTITY" => $_POST['quantity'],
			   "LINK" => $_POST['link']
			);
			if ($basket_settings['IMAGE_SHOW'] == 'Y' && !empty($_POST[$basket_settings['IMAGE_FIELD_NAME']])) {
				$_SESSION['BASKET']['ITEMS'][$_POST['id']]['IMAGE'] = $_POST[$basket_settings['IMAGE_FIELD_NAME']];
			}
		} 
		// delete item from cart logic
		elseif (!empty($_POST['delete_item'])) {
			unset($_SESSION['BASKET']['ITEMS'][$_POST['id']]);
		}
		// change item quantity logic
		elseif (!empty($_POST['quantity_change'])) {
			if ($_POST['quantity_change'] > 0) {
				$_SESSION['BASKET']['ITEMS'][$_POST['id']]['QUANTITY'] = $_POST['quantity_change'];
			} else {
				unset($_SESSION['BASKET']['ITEMS'][$_POST['id']]);
			}
		}
		if (isset($_SESSION['BASKET']['ITEMS']) && 0 < count($_SESSION['BASKET']['ITEMS'])) {
			// get orders count and sum
			$_SESSION['BASKET']['SUM'] = 0;
			foreach ($_SESSION['BASKET']['ITEMS'] as $arItem) {
				$_SESSION['BASKET']['SUM'] = $_SESSION['BASKET']['SUM'] + ($arItem['PRICE'] * $arItem['QUANTITY']);
			}
		}
	}
}
function basket_small_show() {
	global $basket_settings; global $MESS;
	echo '<div id="basket" style="'.$basket_settings['BASKET_STYLES'].'">';
		// if cart has items
		if (!empty($_SESSION['BASKET']['ITEMS'])) {
			// show it to user
			echo '<a href="?basket=Y" title="'.$MESS['cart_small_link_title'].'">'.$MESS['cart_small_cart_items_message'].' - '.count($_SESSION['BASKET']['ITEMS']).' '.$MESS['cart_small_cart_items_message_count'].' '.$MESS['cart_small_cart_items_sum'].' '.$_SESSION['BASKET']['SUM'].' '.$basket_settings['CURRENCY'].'</a>';
		}
		// or show "empty" message
		else { 
			echo $MESS['cart_small_empty_basket_message'];
		}
		if ($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') {
			echo '<br><center><a href="?history=Y" title="'.$MESS['show_history_link_text'].'">'.$MESS['show_history_link_text'].'</a></center>';
		}
	echo '</div>';
}
// Set Title and clear page content
function set_basket_title() {
	global $title; global $content; global $MESS;
	$title = $MESS['cart_page_title'];
	$content = '';
}
// show cart page
function basket_big() {
	global $basket_settings; global $MESS; global $discounts_file;
	// If we have SUCESS TEXT - show it to user
	if (isset($_SESSION['BASKET']['OK']) && 5 < strlen($_SESSION['BASKET']['OK'])):
		echo '<p style="color:green; font-weight:bold;">'.$_SESSION['BASKET']['OK'].'</p><hr />';
		unset($_SESSION['BASKET']['OK']);
	// if cart hasn't got items
	elseif (0 == @count($_SESSION['BASKET']['ITEMS'])):
		echo '<p>'.$MESS['cart_page_empty_basket_message'].'</p>';

	// show full cart page
	else:?>
		<?php if (@$basket_settings['ALLOW_PRINT'] == 'Y'):?>
			<script>
				function printBlock() {
				    productDesc = $('#big-basket').html();
				    $('body').addClass('printSelected');
				    $('body').append('<div class="printSelection">' + productDesc + '</div>');
				    window.print();
				    window.setTimeout(pageCleaner, 0);
				    return false;
				}
				function pageCleaner() {
				    $('body').removeClass('printSelected');
				    $('.printSelection').remove();
				}
			</script>
			<style>
				.printSelected {width: 60%; margin: 0 auto; border: 1px solid silver; padding: 20px; background: #fff}
				.printSelected div {display: none }
				.printSelected div.printSelection {display: block; }
				.printSelected div.printSelection div {display: block; }
				a.print {float: right; text-decoration: none; color: silver; padding: 2px; border: 1px solid silver;}
				.printSelected a.print {display: none;}
			</style>
			<a href="javascript:void(0)" class="print" onclick="printBlock()"><?php echo $MESS['print_order']?></a>	
		<?php endif?>
		<div id="big-basket">
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'T'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>
			
			<h2><?php echo $MESS['cart_page_list_title']?></h2>
			<table border="1" cellspacing="1" cellpadding="5" width="100%" class="basket-items-table">
				<thead>
					<tr>
						<?php if($basket_settings['IMAGE_SHOW'] == 'Y'):?>
						<th><?php echo $MESS['table_picture_column']?></th>
						<?php endif?>
						<th><?php echo $MESS['table_name_column']?></th>
						<th><?php echo $MESS['table_price_column']?></th>
						<th><?php echo $MESS['table_quantity_column']?></th>
						<th><?php echo $MESS['table_sum_column']?></th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($_SESSION['BASKET']['ITEMS'] as $key=>$arItem):?>
						<tr>
							<?php if($basket_settings['IMAGE_SHOW'] == 'Y'):?>
								<td align="center">
									<?php if (!empty($arItem['IMAGE'])):?>
										<img src="<?php echo $arItem['IMAGE']?>" style="max-width:100px; max-height:100px" alt="<?php echo $arItem['NAME']?>" />
									<?php else:?>
										<?php echo $MESS['cart_page_no_picture_message']?>
									<?php endif?>
								</td>
							<?php endif?>
							<td><a href="<?php echo $arItem['LINK']?>" target="_blank" title="<?php echo $arItem['NAME']?>"><?php echo $arItem['NAME']?></a></td>
							<td><?php echo $arItem['PRICE']?> <?php echo $basket_settings['CURRENCY']?></a></td>
							<td align="center">
							<form action="<?php echo $_SERVER['REQUEST_URI']?>" name="quantity_change" method="POST" class="change-form">
								<input type="hidden" name="id" value="<?php echo $key?>" />
								<input type="number" size="4" style="text-align: center; width: 50px" name="quantity_change" value="<?php echo $arItem['QUANTITY']?>" />
								<input type="submit" value="<?php echo $MESS['quantity_change_button']?>" />
							</form>
							</td>
							<td><strong><?php echo ($arItem['QUANTITY'] * $arItem['PRICE'])?> <?php echo $basket_settings['CURRENCY']?></strong></td>
							<td>
								<form action="<?php echo $_SERVER['REQUEST_URI']?>" name="delete_item" method="POST" class="delete-form">
									<input type="hidden" name="id" value="<?php echo $key?>" />
									<input type="submit" value="Х" name="delete_item" />
								</form>
							</td>
						</tr>
					<?php endforeach?>
				</tbody>
				<tfoot>
					<tr>
						<td <?php if($basket_settings['IMAGE_SHOW'] == 'Y'):?> colspan="6" <?php else:?> colspan="5" <?php endif?> align="right"><?php echo $MESS['cart_page_order_list_total']?> <strong><?php echo $_SESSION['BASKET']['SUM']?> <?php echo $basket_settings['CURRENCY']?></strong></td>
					</tr>
				</tfoot>
			</table>
			<br />
			
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'M'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>

			<?php if ($basket_settings['USE_DISCOUNTS'] == 'Y') {
				echo '
					<form class="change-form" action="'.$_SERVER['REQUEST_URI'].'" method="post" class="discount-form">
						<table width="100%">
							<tr>
								<td>'.$MESS['cart_page_discount_input_code'].'</td>
								<td><input type="text" name="discount_code" value="'.@$_POST['discount_code'].'"></td>
							</tr>
							<tr>
								<td colspan="2" class="message" align="center"><strong>'.@$_SESSION['BASKET']['DISCOUNT']['MESSAGE'].'</strong></td>
							</tr>
							<tr>
								<td colspan="2" align="center">
									<input type="submit" name="discount_input" value="'.$MESS['cart_page_discount_code_submit'].'">
								</td>
							</tr>
						</table>
					</form>
				';
			}?>
			
			<h3><?php echo $MESS['cart_page_form_title']?></h3>
			<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="POST">
				<table border="1" cellspacing="1" cellpadding="5" width="100%" class="basket-form-table">
					<tbody>
					<tr>
						<td><?php echo $MESS['cart_page_form_field_name']?></td>
						<td><input size="53" type="text" name="order_name" required /></td>
					</tr>
					<tr>
						<td><?php echo $MESS['cart_page_form_field_phone']?></td>
						<td><input size="53" type="text" name="order_phone" required /></td>
					</tr>
					<tr>
						<td><?php echo $MESS['cart_page_form_field_email']?></td>
						<td><input size="53" type="email" name="order_email" required /></td>
					</tr>
					<?php if ($basket_settings['SHOW_DELIVERY'] == 'Y' && !empty($basket_settings['DELIVERY'])):?>
						<tr>
							<td><?php echo $MESS['cart_page_form_field_delivery']?></td>
							<td>
								<select name="order_delivery" required>
									<option value=""><?php echo $MESS['cart_page_form_select_empty_option']?></option>
									<?php foreach ($basket_settings['DELIVERY'] as $delivery):?>
										<option value="<?php echo $delivery?>"><?php echo $delivery?></option>
									<?php endforeach?>
								</select>
							</td>
						</tr>
					<?php endif?>
					<?php if ($basket_settings['SHOW_PAYMENT'] == 'Y' && !empty($basket_settings['PAYMENT'])):?>
						<tr>
							<td><?php echo $MESS['cart_page_form_field_payment']?></td>
							<td>
								<select name="order_payment" required>
									<option value=""><?php echo $MESS['cart_page_form_select_empty_option']?></option>
									<?php foreach ($basket_settings['PAYMENT'] as $payment):?>
										<option value="<?php echo $payment?>"><?php echo $payment?></option>
									<?php endforeach?>
								</select>
							</td>
						</tr>
					<?php endif?>
					<tr>
						<td><?php echo $MESS['cart_page_form_field_message']?> <?php if ($basket_settings['SHOW_DELIVERY'] == 'Y' && !empty($basket_settings['DELIVERY'])) { echo '<br />'.$MESS['cart_page_form_field_message_delivery']; }?></td>
						<td><textarea name="order_text" id="" cols="50" rows="5"></textarea></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="order_submit" value="<?php echo $MESS['cart_page_form_submit_value']?>" /></td>
					</tr>
					</tbody>
				</table>
			</form>
			
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'B'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>
			
		</div>
	<?php endif;
}
function history_logic() {
	// change item status
	if (!empty($_POST['status_change'])) {
		$xml = getXML($_POST['file']);
		unset($xml->status);
		$xml->addChild('status', serialize($_POST['status_change']));
		XMLsave($xml, $_POST['file']);
	}
	// change item admin_message
	if (isset($_POST['admin_message'])) {
		$xml = getXML($_POST['file']);
		unset($xml->admin_message);
		$xml->addChild('admin_message', serialize($_POST['admin_message']));
		XMLsave($xml, $_POST['file']);
	}
}
// Set Title and clear page content
function history_page_title() {
	global $title; global $content; global $MESS;
	$title = $MESS['history_page_title'];
	$content = '';
}
// show histore page
function history_page() {
	global $history_dir; global $MESS; global $basket_settings;
	$arFiles = array(); $str = ''; $i = 1;
	if ($handle = opendir($history_dir)) {
		while (false !== ($entry = readdir($handle))) {
			if ($entry != "." && $entry != "..") {
				$arFiles[] = array(
					"PATH" => $history_dir.$entry
				);
			}
		}
		closedir($handle);
	}
	echo '
		<form action="'.$_SERVER['REQUEST_URI'].'" method="get" class="history-form">
			<input type="hidden" name="history" value="Y">
			<table width="100%">
				<tr>
					<td>'.$MESS['history_page_insert_number'].'</td>
					<td><input type="text" name="order" required value="'.@$_GET['order'].'"></td>
				</tr>
				<tr>
					<td>'.$MESS['history_page_insert_name'].'</td>
					<td><input type="text" name="user" required value="'.@$_GET['user'].'"></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" value="'.$MESS['history_page_get_order_button'].'"></td>
				</tr>
			</table>
		</form>
		<hr>
	';

	if (isset($_GET['order']) && !empty($_GET['order']) && isset($_GET['user']) && !empty($_GET['user'])) {
		@$order_file = $arFiles[intVal($_GET['order'] - 1)]['PATH'];
		if (!file_exists($order_file)) {
			echo $MESS['history_page_wrong_number'];
		} else {
			$xmlOrder = getXML($order_file);
			if ($_GET['user'] !== unserialize($xmlOrder->name)) {
				echo $MESS['history_page_wrong_user'];
			} else {
				echo '
					<p>
						<strong>'.$MESS['order_created'].'</strong> - '.unserialize($xmlOrder->date).' <br/>
						<strong>'.$MESS['history_table_phone_column'].'</strong> - '.unserialize($xmlOrder->phone).' <br/>
						<strong>'.$MESS['history_table_email_column'].'</strong> - '.unserialize($xmlOrder->email).' <br/>
						<strong>'.$MESS['history_table_items_column'].'</strong> - '.unserialize($xmlOrder->items).' <br/>
						<strong>'.$MESS['history_table_sum_column'].'</strong> - '.unserialize($xmlOrder->sum).' '.$basket_settings['CURRENCY'].' <br/>
						<strong>'.$MESS['order_status'].'</strong> - '.unserialize($xmlOrder->status).' <br/>
						<strong>'.$MESS['history_table_message_column'].'</strong> - '.unserialize($xmlOrder->message).' <br/>
					</p>
					<hr>
					<h2>'.$MESS['order_contain'].'</h2>
					'.$xmlOrder->order;
				if (isset($xmlOrder->admin_message) && 2 < strlen(unserialize($xmlOrder->admin_message))) {
					echo '<hr><h3>'.$MESS['history_page_admin_message'].'</h3>'.unserialize($xmlOrder->admin_message);
				}
			}
		}
	}
}
// ajax basket logic
function ajax_basket() {
	global $basket_settings; global $MESS;
	if ($basket_settings['JQUERY_INCLUDE'] == 'Y') {
		echo '<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.1.min.js"></script>';
	}
	echo '<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.form/3.50/jquery.form.min.js"></script>';
	echo '<script type="text/javascript">
		$(document).ready(function() { 
			$(".add-form").ajaxForm({success: ChangeSmallBasket});
			$(".delete-form").ajaxForm({success: ChangeAllBasket});
			$(".change-form").ajaxForm({success: ChangeAllBasket});
		});
		function ChangeSmallBasket(responseText) {
			$("#basket").empty().html($($.parseHTML(responseText)).filter("#basket").html());
		}
		function ChangeAllBasket(responseText) {
			var $result = $(responseText).find("#big-basket").html();
			$("#basket").empty().html($($.parseHTML(responseText)).filter("#basket").html());
			if ($result !== "undefined" && $("#basket").html() !== "'.$MESS['cart_small_empty_basket_message'].'") {
				$("#big-basket").empty().html($(responseText).find("#big-basket").html());
				$(".delete-form").ajaxForm({success: ChangeAllBasket});
				$(".change-form").ajaxForm({success: ChangeAllBasket});
			} else {
				$("#big-basket").empty().html("<p>'.$MESS['cart_page_empty_basket_message'].'</p>");
			}
		}
	</script>';
}

function discounts_logic() {
	global $discounts_file;
	$arDiscounts = getXML($discounts_file);
	if (isset($_POST['delete_discount'])) {
		if ($node = $arDiscounts->xpath("//discount[code='".$_POST['code']."']")) {
		    unset($node[0][0]);
		}
	}
	if (isset($_POST['change_discount'])) {
		if ($node = $arDiscounts->xpath("//discount[code='".$_POST['code']."']")) {
			unset($node[0]->value);
			unset($node[0]->use);
			$node[0]->addChild('value',$_POST['value']);
			$node[0]->addChild('use',$_POST['use']);
		}
	}
	if (isset($_POST['create_discount']) && !empty($_POST['code']) && !empty($_POST['value'])) {
		$discount = $arDiscounts->addChild('discount');
		$discount->addChild('code',$_POST['code']);
		$discount->addChild('desc',$_POST['desc']);
		$discount->addChild('use',$_POST['use']);
		$discount->addChild('value',$_POST['value']);
	}
	if (!empty($_POST)) {
		XMLsave($arDiscounts, $discounts_file);
	}
}

function hello_world_show() {
	global $basket_settings; global $MESS;
	// settings page
	if (isset($_GET['settings'])):?>
	<?php
		if (!empty($_POST['demo_spec_page']))
			echo '<div style="background: maroon; color:#fff; padding:5px; text-align: center; margin-bottom:10px;">'.$MESS['go_to_spec_page_settings'].'</div>';
	?>
	<center><p style="font-size:150%; font-weight:bold;"><?php echo $MESS['settings_page_title']?></p></center>
	<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="POST">
		<table cellpadding="10" cellspacing="0" >
			<tr>
				<td width="300px">Язык/Language/Sprache/Langue:</td>
				<td>
					<label for="language_ru" style="display:block; float: left; margin-right: 10px;">Ru</label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="language_ru" name="language" value="ru" <?php if($basket_settings['LANGUAGE'] == 'ru') echo 'checked';?> />
					<label for="language_en" style="display:block; float: left; margin-right: 10px;">En</label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="language_en" name="language" value="en" <?php if($basket_settings['LANGUAGE'] == 'en') echo 'checked';?> />
					<label for="language_de" style="display:block; float: left; margin-right: 10px;">De</label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="language_de" name="language" value="de" <?php if($basket_settings['LANGUAGE'] == 'de') echo 'checked';?> />
					<!-- <? /*
					<label for="language_fr" style="display:block; float: left; margin-right: 10px;">Fr</label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="language_fr" name="language" value="fr" <?php if($basket_settings['LANGUAGE'] == 'fr') echo 'checked';?> />
					*/ ?> -->
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_use_discounts']?></td>
				<td>
					<label for="use_discounts_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="use_discounts_yes" name="use_discounts" value="Y" <?php if($basket_settings['USE_DISCOUNTS'] == 'Y') echo 'checked';?> />
					<label for="use_discounts_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="use_discounts_no" name="use_discounts" value="N" <?php if($basket_settings['USE_DISCOUNTS'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_save_history']?></td>
				<td>
					<label for="save_history_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="save_history_yes" name="save_history" value="Y" <?php if($basket_settings['SAVE_HISTORY'] == 'Y') echo 'checked';?> />
					<label for="save_history_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="save_history_no" name="save_history" value="N" <?php if($basket_settings['SAVE_HISTORY'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_history_to_user']?></td>
				<td>
					<label for="show_history_to_user_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_history_to_user_yes" name="show_history_to_user" value="Y" <?php if($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') echo 'checked';?> />
					<label for="show_history_to_user_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_history_to_user_no" name="show_history_to_user" value="N" <?php if($basket_settings['SHOW_HISTORY_TO_USER'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_allow_print_order']?></td>
				<td>
					<label for="allow_print_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="allow_print_yes" name="allow_print" value="Y" <?php if($basket_settings['ALLOW_PRINT'] == 'Y') echo 'checked';?> />
					<label for="allow_print_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="allow_print_no" name="allow_print" value="N" <?php if($basket_settings['ALLOW_PRINT'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_admin_email']?></td>
				<td><input style="width:321px; padding: 5px;" type="email" name="admin_mail" value="<?php echo $basket_settings['ADMIN_MAIL']?>" required/></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_price_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="price_field_name" value="<?php echo $basket_settings['PRICE_FIELD_NAME']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_image']?></td>
				<td>
					<label for="show_image_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_image_yes" name="image_show" value="Y" <?php if($basket_settings['IMAGE_SHOW'] == 'Y') echo 'checked';?> />
					<label for="show_image_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_image_no" name="image_show" value="N" <?php if($basket_settings['IMAGE_SHOW'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_image_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="image_field_name" value="<?php echo $basket_settings['IMAGE_FIELD_NAME']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_letter_subject']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="letter_header" value="<?php echo $basket_settings['LETTER_HEADER']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_sucess_text']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="ok_text" value="<?php echo $basket_settings['OK_TEXT']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_smallcart_styles']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="basket_styles" value="<?php echo $basket_settings['BASKET_STYLES']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_currency']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="currency" value="<?php echo $basket_settings['CURRENCY']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_message_position']?></td>
				<td>
					<label for="position_top" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_top']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="position_top" name="basket_message_positions" value="T" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'T') echo 'checked';?> />
					<label for="position_middle" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_middle']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="position_middle" name="basket_message_positions" value="M" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'M') echo 'checked';?> />
					<label for="position_bottom" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_bottom']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="position_bottom" name="basket_message_positions" value="B" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'B') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_message']?></td>
				<td><textarea style="width:321px; padding: 5px; height: 100px;" name="basket_message"><?php echo $basket_settings['BASKET_MESSAGE']?></textarea></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_delivery']?></td>
				<td>
					<label for="show_delivery_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_delivery_yes" name="show_delivery" value="Y" <?php if($basket_settings['SHOW_DELIVERY'] == 'Y') echo 'checked';?> />
					<label for="show_delivery_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_delivery_no" name="show_delivery" value="N" <?php if($basket_settings['SHOW_DELIVERY'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_delivery_options']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="delivery" value="<?php echo implode(',',$basket_settings['DELIVERY'])?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_payment']?></td>
				<td>
					<label for="show_payment_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_payment_yes" name="show_payment" value="Y" <?php if($basket_settings['SHOW_PAYMENT'] == 'Y') echo 'checked';?> />
					<label for="show_payment_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_payment_no" name="show_payment" value="N" <?php if($basket_settings['SHOW_PAYMENT'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_payment_options']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="payment" value="<?php echo implode(',',$basket_settings['PAYMENT'])?>" /></td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_ajax']?></td>
				<td>
					<label for="ajax_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="ajax_yes" name="ajax" value="Y" <?php if($basket_settings['AJAX'] == 'Y') echo 'checked';?> />
					<label for="ajax_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="ajax_no" name="ajax" value="N" <?php if($basket_settings['AJAX'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_jquery_include']?></td>
				<td>
					<label for="jquery_include_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="jquery_include_yes" name="jquery_include" value="Y" <?php if($basket_settings['JQUERY_INCLUDE'] == 'Y') echo 'checked';?> />
					<label for="jquery_include_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="jquery_include_no" name="jquery_include" value="N" <?php if($basket_settings['JQUERY_INCLUDE'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="basket_settings_change" value="<?php echo $MESS['settings_page_save_button']?>" /></td>
			</tr>
		</table>
	</form>
	<hr />
	<p><?php echo $MESS['settings_page_required_plugins']?><br />
		1) I18n Base<br />
		2) I18n Special Pages<br />
		3) I18n Search
	</p>
	<p><i><?php echo $MESS['settings_page_instruction_plugins']?></i></p>
	<p>
		<strong><?php echo $MESS['settings_page_example_text']?></strong>
		<div style="border:1px solid silver; padding:5px 0; font-size:90%; margin-top:-15px">
		<?php highlight_string('<form action="<?php echo $_SERVER[\'REQUEST_URI\']?>" method="POST" class="add-form">
  <span>Quantity:</span>
  <input type="hidden" name="id" value="<?php get_special_field(\'id\',\'\',false)?>" />
  <input type="hidden" name="link" value="<?php get_special_field(\'link\',\'\',false)?>" />
  <input type="hidden" name="name" value="<?php get_special_field(\'title\',\'\',false)?>" />
  <input type="hidden" name="price" value="<?php get_special_field(\'price\',\'\',false)?>" />
  <input type="hidden" name="image" value="<?php get_special_field(\'image\',\'\',false)?>" />
  <input type="text" size="3" value="1" name="quantity" />
  <input type="submit" name="add_item" value="Buy" />
</form>')?>
		</div>
		<strong style="color:red; font-size:80%"><?php echo $MESS['settings_page_danger_text']?></strong>
	</p>
	<hr />
	<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="post">
		<center>
			<p>
				<?php echo $MESS['settings_page_special_demo_offer']?>
				<input type="submit" style="width:100%" name="demo_spec_page" value="<?php echo $MESS['settings_page_special_demo_submit']?>" />
			</p>
		</center>
	</form>
	<hr />
	<?php echo $MESS['settings_page_forum_link']?>
	<hr />
	<small>&copy; <a href="http://vk.com/cupuyc1989" target="_blank">Makhonin Pavel</a>. 08.2014y.</small>
	<?php 
	// history page
	elseif (isset($_GET['history'])):
		// make files array
		global $history_dir; global $MESS;
		$arFiles = array(); $str = ''; $i = 1;
		if ($handle = opendir($history_dir)) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					$arFiles[] = array(
						"PATH" => $history_dir.$entry,
						"CREATED" => filectime($history_dir.$entry)
					);
				}
			}
			closedir($handle);
		}
		echo '<center><p style="font-size:150%; font-weight:bold;">'.$MESS['history_title'].'</p></center>';
		// history hasn't got files
		if (0 >= count($arFiles)) {
			echo '<p>Пока небыло сделано ни одного заказа.</p>';
		} else {
			// item status array
			$arStatus[] = $MESS['history_status_default'];
			$arStatus[] = $MESS['history_status_waiting'];
			$arStatus[] = $MESS['history_status_sucess'];
			$arStatus[] = $MESS['history_status_canceled'];
			
			// sorting array by file created time
			function cmp($a, $b) {
				if ($a['CREATED'] == $b['CREATED']) {
					return 0;
				}
				return ($a['CREATED'] > $b['CREATED']) ? -1 : 1;
			}
			usort($arFiles, "cmp");
			
			// pagination
			if (count($arFiles) > 15) {
				echo '<hr /><div style="text-align: right"> <div style="float:left">'.$MESS['history_pagination'].'</div>';
				for ($j = 0 ; $j<count($arFiles); $j++) {
					if ($j%15 == 0) { echo '<a style="dysplay: inline-block; padding: 5px 10px; margin: 5px 3px; background: #11171B; color: #fff; text-decoration:none" href="'.$_SERVER['HTTP_SELF'].'load.php?id=basket_plugin&history&page='.ceil($j/15).'">'.ceil($j/15+1).'</a>'; }
					if ($j%219 == 0 && $j !== 0) { echo '<br /><br />'; }
				}
				echo '</div><hr />';
			}
			
			//some little styles for history
			echo '<style type="text/css">.history-table td{vertical-align: middle!important;}.history-table .bordered th {border: 1px solid #000; text-align: center}.history-table p {margin-bottom:0}</style>';
			
			//table header
			$str = '<table class="history-table" width="100%" border="1" cellpadding="5" cellspacing="0">
					<thead>
						<tr class="bordered">
							<th>№</th>
							<th>'.$MESS['history_table_created_column'].'/'.$MESS['history_table_status_column'].'</th>
							<th>'.$MESS['history_table_name_column'].'</th>
							<th>'.$MESS['history_table_phone_column'].'</th>
							<th>'.$MESS['history_table_email_column'].'</th>
							<th>'.$MESS['history_table_message_column'].'</th>
							<th>'.$MESS['history_table_items_column'].'</th>
							<th>'.$MESS['history_table_sum_column'].' ('.$basket_settings['CURRENCY'].')</th>
						</tr>
					</thead>
					<tbody>';
			//table elements with pagination
			if (isset($_GET['page'])) {
				$page = $_GET['page'];
			} else {
				$page = 0;
			}
			for ($k = intVal($page*15) ; $k<intVal($page * 15 + 15); $k++) {
				if (file_exists(@$arFiles[$k]['PATH'])) {
					$status = '';
					$xmlItem = getXML($arFiles[$k]['PATH']);
					foreach ($arStatus as $oneStatus) { 
						if ($oneStatus == unserialize($xmlItem->status)) {
							$status .= '<option value="'.$oneStatus.'" selected>'.$oneStatus.'</option>';
						} else {
							$status .= '<option value="'.$oneStatus.'">'.$oneStatus.'</option>';
						}
					}
					$str .= '
					<tr>
						<td>'.intVal($k+1).'</td>
						<td align="center">
							'.unserialize($xmlItem->date).'
							<br />
							<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
								<input type="hidden" name="file" value="'.$arFiles[$k]['PATH'].'" />
								<select name="status_change" onchange="this.form.submit();">'.$status.'</select>
							</form>
						</td>
						<td>'.unserialize($xmlItem->name).'</td>
						<td>'.unserialize($xmlItem->phone).'</td>
						<td><a href="mailto:'.unserialize($xmlItem->email).'">'.unserialize($xmlItem->email).'</a></td>
						<td style="word-wrap: break-all;">'.unserialize($xmlItem->message).'</td>
						<td align="center"><a style="display:block; padding: 2px; background: #CF3805; text-decoration: none; color: #fff;" href="javascript:void(0)" onclick="$(\'#item_'.$i.'\').slideToggle()"><b>'.unserialize($xmlItem->items).'</b></a></td>
						<td align="center">'.unserialize($xmlItem->sum).'</td>
					</tr>
					<tr style="background: #F6F6F6">
						<td colspan="8" style="padding:0">
							<div id="item_'.$i.'" style="display:none">
								'.$xmlItem->order.''.' 
								<br>
								<form style="margin-bottom: 10px" action="'.$_SERVER['REQUEST_URI'].'" method="post">
									<center>
										<input type="hidden" name="file" value="'.$arFiles[$k]['PATH'].'" />
										<textarea name="admin_message" style="width:95%;height:100px">'.unserialize($xmlItem->admin_message).'</textarea>
										<input type="submit" value="'.$MESS['history_make_comment_button'].'">
									</center>
								</form>
							</div>
						</td>
					</tr>
					';
					++$i;
				}
			}
			$str .= '</tbody></table>';
			// show table
			echo $str;
		}
	elseif (isset($_GET['discounts'])):
		echo '<center><p style="font-size:150%; font-weight:bold;">'.$MESS['discounts_title'].'</p></center>';

		global $discounts_file;
		$DiscoutsXML = getXML($discounts_file);

		$add_discount = '
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<table>
					<thead>
						<tr>
							<th colspan="2">'.$MESS['discount_page_add_discount_title'].'</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>'.$MESS['discount_page_discount_code'].'</td>
							<td><input style="width:100%; padding: 5px;" type="text" name="code"></td>
						</tr>
						<tr>
							<td>'.$MESS['discount_page_discount_value'].'</td>
							<td><input style="width:100%; padding: 5px;" type="text" name="value"></td>
						</tr>
						<tr>
							<td>'.$MESS['discount_page_discount_use'].'</td>
							<td><input style="width:100%; padding: 5px;" type="text" name="use"></td>
						</tr>
						<tr>
							<td>'.$MESS['discount_page_discount_description'].'</td>
							<td><input style="width:100%; padding: 5px;" type="text" name="desc"></td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="2" align="center"><input style="padding:0 30px" type="submit" name="create_discount" value="'.$MESS['discount_page_create_discount_button'].'"></td>
						</tr>
					</tfoot>
				</table>
			</form>
			<hr/>
		';
		echo $add_discount;

		$discounts_table = '
			<table width="100%">
				<thead>
					<tr>
						<th width="15%">'.$MESS['discount_page_discount_code'].'</th>
						<th width="40%">'.$MESS['discount_page_discount_description'].'</th>
						<th width="30%">'.$MESS['discount_page_discount_value'].'</th>
						<th width="10%">'.$MESS['discount_page_discount_use'].'</th>
						<th colspan="2" width="10%">'.$MESS['discount_page_discount_actions'].'</th>
					</tr>
				</thead>
				<tbody>
		';
		foreach ($DiscoutsXML as $arDiscount) {
			$discounts_table .= '
				<tr>
					<td><strong>'.(string)$arDiscount->code.'</strong></td>
					<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
						<input type="hidden" name="code" value="'.(string)$arDiscount->code.'">
						<td>'.(string)$arDiscount->desc.'</td>
						<td><input type="text" name="value" value="'.(string)$arDiscount->value.'"></td>
						<td><input type="text" name="use" value="'.(string)$arDiscount->use.'"></td>
						<td><input type="submit" name="change_discount" value="'.$MESS['discount_page_discount_change'].'"></td>
					</form>
					<td>
						<center>
							<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
								<input type="hidden" name="code" value="'.(string)$arDiscount->code.'">
								<input type="submit" name="delete_discount" value="X">
							</form>
						</center>
					</td>
				</tr>
			';
		}
		$discounts_table .= '
				</tbody>
			</table>
		';
		echo $discounts_table;

	endif;
}
?>