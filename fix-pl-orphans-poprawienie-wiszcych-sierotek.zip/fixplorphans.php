<?php

// register plugin
$thisfile = basename(__FILE__, ".php");
register_plugin(
	$thisfile,
	'Fix Polish Orphans',
	'0.1',
	'Sebastian Batko',
	'http://SebastianBatko.com/get-simple/',
	'Remove orphans (sierotki) from page content'
);

// original function author Marcin Pietrzak
// http://iworks.pl/2011/02/16/sierotki/

function replace_orphans($content)
{
    if ( empty( $content ) ) {
        return;
    }
    $therms = array (
        'al.', 'ale', 'ależ',
        'b.', 'bł.', 'bm.', 'bp', 'br.', 'by', 'bym', 'byś',
        'cyt.', 'cz.', 'czyt.',
        'dn.', 'do', 'doc.', 'dr', 'ds.', 'dyr.', 'dz.',
        'fot.',
        'gdy', 'gdyby', 'gdybym', 'gdybyś', 'gdyż', 'godz.',
        'im.', 'inż.',
        'jw.',
        'kol.', 'komu', 'ks.', 'która', 'którego', 'której', 'któremu', 'który', 'których', 'którym', 'którzy',
        'lic.',
        'ma', 'max', 'mgr', 'm.in.', 'min', 'moich', 'moje', 'mojego', 'mojej', 'mojemu', 'mój', 'mych', 'na', 'nad', 'np.', 'nr', 'nt.', 'nw.',
        'od', 'oraz', 'os.',
        'p.', 'pl.', 'pn.', 'po', 'pod', 'pot.', 'prof.', 'przed', 'pt.', 'pw.', 'pw.',
        'są', 'śp.', 'św.',
        'tamtej', 'tamto', 'tej', 'tel.', 'tj.', 'to', 'twoich', 'twoje', 'twojego', 'twojej', 'twój', 'twych',
        'ul.',
        'we', 'wg', 'woj.',
        'za', 'ze',
        'że', 'żeby', 'żebyś',
    );
    $re = '/^([aiouwz]|'.preg_replace('/\./', '\.', implode('|', $therms)).') +/i';
    $content = preg_replace( $re, "$1$2&nbsp;", $content );
    /**
     * replace space in numbers
     */
    $content = preg_replace( '/(\d) (\d)/', "$1&nbsp;$2", $content );
    /**
     * single letters
     */
    $re = '/([ >\(]+)([aiouwz]|'.preg_replace('/\./', '\.', implode('|', $therms)).') +/i';
    $content = preg_replace( $re, "$1$2&nbsp;", $content );
    /**
     * single letter after previous orphan
     */
    $re = '/(&nbsp;)([aiouwz]) +/i';
    $content = preg_replace( $re, "$1$2&nbsp;", $content );
    /**
     * return
     */
    return $content;
}

add_action('edit-extras','fixorphans_edit'); 
add_filter('content','fixorphans_content');

function fixorphans_edit() {
  global $content;
  $content = replace_orphans($content);
}

function fixorphans_content($content) {
  $content = replace_orphans($content);
  return $content;
}