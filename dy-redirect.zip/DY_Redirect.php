<?php
/*
Plugin Name: DY Redirect
Description: Easily page redirection setup
Version: 1.1
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
 
Version history:

1.0 - 23/10/2015
  - Initial version
1.1 - 03/11/2015
  - Added option to choose redirect code
*/
 
$thisfile = basename(__FILE__, '.php');

i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');

register_plugin(
  $thisfile,
  'DY Redirect',
  '1.1',
  'Dmitry Yakovlev',
  'http://dimayakovlev.ru',
  i18n_r($thisfile . '/DESCRIPTION'),
  '',
  ''
);

add_action('index-pretemplate', 'dyRedirect');
add_action('edit-extras', 'dyRedirectExtra');
add_action('changedata-save', 'dyRedirectSave');

function dyRedirect() {
  global $data_index;
  if (!empty($data_index->redirect)) {
    $target = find_url((string)$data_index->redirect, returnPageField((string)$data_index->redirect, 'parent'));
    if (empty($data_index->redirectCode) || (string) $data_index->redirectCode == '302') {
      header("Location: " . $target, TRUE, 302);
    } elseif ((string) $data_index->redirectCode == '301') {
      header("Location: " . $target, TRUE, 301);
    }
  }    
}

function dyRedirectGetPagesMenuDropdown($parentitem, $menu, $level, $target) {  
  global $pagesSorted;
  global $id;  
  $items = array();
  foreach ($pagesSorted as $page) {
    if ($page['parent'] == $parentitem) $items[(string)$page['url']] = $page;
  }
  foreach ($items as $page) {
      $dash = '';
      if ($page['parent'] != '') {
        $page['parent'] = $page['parent'] . '/';
      }
    for ($i = 0; $i <= $level-1; $i++){
      if ($i != $level-1){
          $dash .= '<span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
      } else {
        $dash .= '<span>&nbsp;&nbsp;&ndash;&nbsp;&nbsp;&nbsp;</span>';
      }
    }
    $selected = ($target && $target == (string)$page['url']) ? ' selected' : '';
    $disabled = ((string)$id == (string)$page['url']) ? ' disabled' : '';
    $menu .= '<option' . $selected . $disabled . ' value="' . $page['url'] . '" >' . $dash . $page['url'] . '</option>';
    $menu = dyRedirectGetPagesMenuDropdown((string)$page['url'], $menu, $level + 1, $target);      
  }
  return $menu;
}

function dyRedirectExtra() {
  global $data_edit;
?>
<div class="clearfix">
  <p><label><?php i18n('DY_Redirect/EXTRA_TITLE'); ?></label></p>
  <p class="leftopt">
    <label for="post-redirect"><?php i18n('DY_Redirect/LABEL'); ?>:</label>
    <select class="text" id="post-redirect" name="post-redirect">
    <?php
      global $id;
      global $pagesArray;
      $count = 0;
      foreach ($pagesArray as $page) {
        if ($page['parent'] != '') { 
          $parentTitle = returnPageField($page['parent'], 'title');
          $sort = $parentTitle . ' ' . $page['title'];
        } else {
          $sort = $page['title'];
        }
        $page = array_merge($page, array('sort' => $sort));
        $pagesArray_tmp[$count] = $page;
        $count++;
      }
      $pagesSorted = subval_sort($pagesArray_tmp,'sort');
      $target = ($id && isset($pagesArray[$id]['redirect'])) ? $pagesArray[$id]['redirect'] : '';
      if ($target == '') { 
        $none = 'selected';
        $noneText = '< '.i18n_r('NO').' >'; 
      } else { 
        $none = ''; 
        $noneText = '< '.i18n_r('NO').' >'; 
      }
      echo '<option ' . $none . ' value="">' . $noneText . '</option>';
      echo dyRedirectGetPagesMenuDropdown('', '', 0, $target);
    ?>
    </select>
  </p>
  <p class="rightopt">
    <label for="post-redirect-code"><?php i18n('DY_Redirect/LABEL_CODE'); ?>:</label>
    <select class="text" id="post-redirect-code" name="post-redirect-code">
      <option value="301"<?php if (isset($data_edit) && (string)$data_edit->redirectCode == '301') echo ' selected'; ?>><?php i18n('DY_Redirect/CODE_301'); ?></option>
      <option value="302"<?php if (isset($data_edit) && (string)$data_edit->redirectCode == '302') echo ' selected'; ?>><?php i18n('DY_Redirect/CODE_302'); ?></option>
    </select>
  </p>
</div>
<?php
}

function dyRedirectSave() {
  global $xml;
  if (isset($_POST['post-redirect']) && empty($xml->redirect) && isset($_POST['post-redirect-code']) && empty($xml->redirectCode)) {
    $xml->addChild('redirect')->addCData(safe_slash_html($_POST['post-redirect']));
    $xml->addChild('redirectCode', $_POST['post-redirect-code']);
  }    
}
