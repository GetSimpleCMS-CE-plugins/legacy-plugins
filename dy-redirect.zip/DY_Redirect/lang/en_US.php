<?php
/**
 * English Language File for DY Redirect Plugin
**/

$i18n = array(
  'EXTRA_TITLE'     => 'Page redirection settings',
  'DESCRIPTION'     => 'Easily page redirection setup',
  'LABEL'           => 'Redirect target page',
  'LABEL_CODE'      => 'HTTP response status code',
  'CODE_301'        => '301 - Page moved permanently',
  'CODE_302'        => '302 - Page moved temporarily',
);