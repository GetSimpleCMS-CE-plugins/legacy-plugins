<?php
/*
Plugin Name: Cached Navigation
Description: Implements a cacheing mechanism of the main navigation menu so the server does not need to look through every page each time a page is requested.
Version: 0.8
Author: Erik
Author URI: http://www.fohlin.net/getsimple-cached-navigation-plugin
*/

// get correct id for plugin
$thisfile = basename(__FILE__, '.php'); // This gets the correct ID for the plugin.

// register plugin
register_plugin(
	$thisfile,	// ID of plugin, should be filename minus php
	'Cached Navigation',	# Title of plugin
	'0.8',	// Version of plugin
	'Erik',	// Author of plugin
	'http://www.fohlin.net/getsimple-cached-navigation-plugin',	// Author URL
	'Implements a cacheing mechanism of the main navigation menu so the server does not need to look through every page each time a page is requested.',	// Plugin Description
	'template',	// Page type of plugin
	'get_cached_navigation'	// Function that displays content
);

add_action('changedata-save','clear_cached_navigation_cache'); 

// functions
function clear_cached_navigation_cache() 
{
	$cachepath = GSDATAOTHERPATH.'navigation_cache/';
	if (is_dir($cachepath))
	{
		$dir_handle = @opendir($cachepath) or exit('Unable to open the folder ...getsimple/data/other/navigation_cache, check the folder privileges.');
		$filenames = array();
		
		while ($filename = readdir($dir_handle))
		{
			$filenames[] = $filename;
		}
		
		if (count($filenames) != 0)
		{
			foreach ($filenames as $file) 
			{
				if (!($file == '.' || $file == '..' || is_dir($cachepath.$file) || $file == '.htaccess'))
				{
					unlink($cachepath.$file) or exit('Unable to clean up the folder ...getsimple/data/other/navigation_cache, check folder content privileges.');
				}
			}
		}
	}
}


//****************************************************//
//** FUNCTION: get_cached_navigation()              **//
//** Replaces: get_navigation()                     **//
//** Returns the main menu of the site.             **//
//****************************************************//	
function get_cached_navigation($currentpage) 
{
	$cashepath = GSDATAOTHERPATH.'navigation_cache/'.$currentpage.'.cache';
	if (is_file($cashepath)) //We have a cashed file, use it.
	{
		echo file_get_contents($cashepath);
	}
	else //We do not have a cached file, create a new one.
	{
		global $PRETTYURLS;
		global $SITEURL;
		$menu = '';
	
		$path = GSDATAPAGESPATH;
		$dir_handle = @opendir($path) or die("Unable to open $path");
		$filenames = array();
		while ($filename = readdir($dir_handle)) {
			$filenames[] = $filename;
		}
		
		$count="0";
		$pagesArray = array();
		if (count($filenames) != 0) {
			foreach ($filenames as $file) {
				if ($file == "." || $file == ".." || is_dir(GSDATAPAGESPATH . $file) || $file == ".htaccess"  ) {
					// not a page data file
				} else {
					$data = getXML(GSDATAPAGESPATH . $file);
					if ($data->private != 'Y') {
						$pagesArray[$count]['menuStatus'] = $data->menuStatus;
						$pagesArray[$count]['menuOrder'] = $data->menuOrder;
						$pagesArray[$count]['menu'] = stripslashes(htmlspecialchars_decode($data->menu, ENT_QUOTES));
						$pagesArray[$count]['url'] = $data->url;
						$pagesArray[$count]['title'] = stripslashes(htmlspecialchars_decode($data->title, ENT_QUOTES));
						$pagesArray[$count]['parent'] = $data->parent;
						$count++;
					}
				}
			}
		}
		
		$pagesSorted = subval_sort($pagesArray,'menuOrder');
		if (count($pagesSorted) != 0) { 
			foreach ($pagesSorted as $page) {
				$sel = ''; $classes = '';
				$url_nav = $page['url'];
				
				if ($page['menuStatus'] == 'Y') { 
					if ("$currentpage" == "$url_nav") { $classes = "current ". $url_nav; } else { $classes = $url_nav; }
					if ($page['menu'] == '') { $page['menu'] = $page['title']; }
					if ($page['title'] == '') { $page['title'] = $page['menu']; }
					$menu .= '<li class="'. $classes .'" ><a href="'. find_url($page['url'],$page['parent']) . '" title="'. $page['title'] .'">'.$page['menu'].'</a></li>'."\n";
				}
			}
			
			
		}
		
		closedir($dir_handle);
		
		echo '<!-- non-cached -->'.$menu;
		
		if (is_dir(GSDATAOTHERPATH.'navigation_cache')==false)
		{
			mkdir(GSDATAOTHERPATH.'navigation_cache', 0755) or exit('Unable to create ...getsimple/data/other/navigation_cache folder, check GetSimple privileges.');
		}

		$fp = @fopen($cashepath, 'w') or exit('Unable to save ...getsimple/data/other/navigation_cache/'.$currentpage.'.cache, check GetSimple privileges.');
		fwrite($fp, $menu);
		fclose($fp);
	}
}	

?>