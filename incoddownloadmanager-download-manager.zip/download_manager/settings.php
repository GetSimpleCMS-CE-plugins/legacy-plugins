<?php
/*

Plugin Name: InCod Download Manager
Description: Менеджер для GetSimple
Version: 1.0
Author: Ufopera
Author URI: http://incod.ru/

# вкладка 2
*/

$style_num =  $indm_set['style'];

?>

<div id="tabx_2"><!--вкладка 2 -->
	<article id="indm_seting">
		
		<h3><?php i18n(ICDM_DIR."ICDM_OUTBUTINFO"); ?></h3>
		<fieldset id="style_num_1">
			<legend> <?php i18n(ICDM_DIR."ICDM_INFO_OUT"); ?> </legend>
			<label><input type=text spellcheck=true name=out_pre value="<?php echo $indm_set['pre']; ?>" placeholder="i18n" maxlength="20">
			<b class="help" title="<?php i18n(ICDM_DIR."ICDM_PREFIX").i18n("DOWNLOAD"); ?>">?</b></label>
			<label><input type=checkbox name=out_size <?php if($indm_set['size']!='') echo 'checked'; ?>> <?php i18n(ICDM_DIR."ICDM_SEZE"); ?></label>
			<label><input type=checkbox name=out_date <?php if($indm_set['date']!='') echo 'checked'; ?>> <?php i18n(ICDM_DIR."ICDM_DATE"); ?></label>
			<label><input type=checkbox name=out_cout <?php if($indm_set['count']!='') echo 'checked'; ?>> <?php i18n(ICDM_DIR."ICDM_COUNT"); ?></label>				
		</fieldset>
		
		<h3><?php i18n(ICDM_DIR."ICDM_STYLEBUT"); ?></h3>
		<fieldset id="style_num_2" name="numfields">
			<legend> <?php i18n(ICDM_DIR."ICDM_STYLE_OUT"); ?> </legend>
			<label><input type=checkbox <?php if($style_num !=0) echo 'checked'; ?> id="check_cssout" onclick="checkField(this,style_num_3);"> 
			 <?php i18n(ICDM_DIR."ICDM_USE_STYLE"); ?></label>
			<label><input type=checkbox checked disabled> <?php i18n(ICDM_DIR."ICDM_USESTYLDOWPAGE"); ?></label>
		</fieldset>
		
		<fieldset id="style_num_3" disabled>
			<legend> <?php i18n(ICDM_DIR."ICDM_VIEW_OUT"); ?> </legend>
		  <label><input type=radio name="style_num" value=1 onclick="styleNum(1);"> <?php i18n(ICDM_DIR."ICDM_VIEWB1"); ?></label>
	  	<label><input type=radio name="style_num" value=2 onclick="styleNum(2);"> <?php i18n(ICDM_DIR."ICDM_VIEWB2"); ?></label>
		  <label><input type=radio name="style_num" value=3 onclick="styleNum(3);"> <?php i18n(ICDM_DIR."ICDM_VIEWB3"); ?></label>
	  	<label><input type=radio name="style_num" value=4 onclick="styleNum(4);"> <?php i18n(ICDM_DIR."ICDM_VIEWB4"); ?></label>
		  <label><input type=radio name="style_num" value=5 onclick="styleNum(5);"> <?php i18n(ICDM_DIR."ICDM_VIEWB5"); ?></label>
			<label><input type=checkbox <?php if($style_num >5) echo 'checked'; ?> id="check_cssgr" onclick="styleNum(0);"> 
			<?php i18n(ICDM_DIR."ICDM_VIEWB6"); ?></label>				  
		</fieldset>
	
		<fieldset id="style_num_4" class="demo">
			<legend> <?php i18n(ICDM_DIR."ICDM_VIEW_BUTTONS"); ?> </legend>
			<div class="indm-0"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
			<div class="indm-1"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
			<div class="indm-2"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>	
			<div class="indm-3"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
			<div class="indm-4"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
			<div class="indm-5"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
			<div class="indm-6"><a href="#" title="test.zip"><b>InCod Download Manager</b> <span>500.50 KB, 2020-10-10, 50⬇</span></a></div>
		</fieldset>
		
	</article>
	
	<article id="indm_style_set"></article>
	
</div><!--вкладка 2 -->

<script type="text/javascript">

// INSTAL ---------------
<?php echo "styleNum($style_num);"; ?>
//-----------------------
function checkField(checkbox, field) {
if (checkbox.checked) {
  //alert( 'чекбокс включён' );
  field.disabled = false;
  styleNum(1);
 } else {
  //alert( 'чекбокс выключён' );
  field.disabled = true;
 }
}

function undisableCheckbox(id, check) {
  document.getElementById(id).checked = check;
}
function disabledFieldset(id, check) {
  document.getElementById(id).disabled = check;
}

// Оформления кнопок
function styleNum(num) {
	
	var style1 = '';
	var el = document.getElementsByName('style_num');

	if (num == 0) {
    for(var i = 0; i < el.length; i++) {
      if (el[i].checked) num = i+1;
    }
	} else{
    disabledFieldset('style_num_3',false);
	}

	if (num == 1 || num == 6) { // плоские прямые
		style1 =	'border:1px solid rgba(20,20,20,.1);';
		el[0].checked = 1;
	}
	if(num == 2 || num == 7){ // плоские слабо скругленые
		style1 =	'border:1px solid rgba(20,20,20,.1);border-radius:3px;';
		el[1].checked = 1;
	}
	if(num == 3 || num == 8){ // плоские сильно скругленые
		style1 =	'border:1px solid rgba(20,20,20,.1);border-radius:5px;';
		el[2].checked = 1;
	}
	if(num == 4 || num == 9){ // плоские слабо скругленые с мал-тенью
		style1 = 'box-shadow:1px 2px 3px rgba(0,0,0,.2);border:1px solid rgba(20,20,20,.1);border-radius:4px;';
		el[3].checked = 1;
	}
	if(num == 5 || num == 10){// плоские контрастные рамки и тени
		style1 = 'box-shadow:2px 3px 6px rgba(0,0,0,.4);border:1px solid rgba(20,20,20,.2);border-radius:5px;';
		el[4].checked = 1;
	}
	
	var dmstyle = document.getElementById('style_num_4');
	var elements = dmstyle.querySelectorAll('[class^="indm-"]');	
	
	for (var i = 0; i < elements.length; i++) {
    elements[i].style.cssText=style1;
  }
  
  if (check_cssgr.checked) {
  	var style_set = document.getElementById('indm_style_set');
  	style_set.innerHTML = '<style>\
		.indm-1{background:radial-gradient(#fcfcfc,#f7f7f7);}.indm-2{background:radial-gradient(#47b9d1,#329dc0);}\
		.indm-3{background:radial-gradient(#f36565,#d31010);}.indm-4{background:radial-gradient(#77d055,#35bb38);}\
		.indm-5{background:radial-gradient(#fcb001,#f88e01);}.indm-6{background:radial-gradient(#9d9d9d,#707070);}\
  	</style>';
	} else {
		var style_set = document.getElementById('indm_style_set');
		style_set.innerHTML = '';
	}
	
}

//добавить данные в запрос и отправить в форме
function dataSettings(ft) {
	try {
	//---------------
	var out_pre = document.getElementsByName('out_pre')[0].value;
	var out_size = document.getElementsByName('out_size')[0].checked;
	var out_date = document.getElementsByName('out_date')[0].checked;
	var out_cout = document.getElementsByName('out_cout')[0].checked;
	//-------	
	var style_num = document.getElementsByName('style_num');
	var num = 0;
	//-------	
	if (check_cssout.checked) {
		for ( var i = 0; i < style_num.length; i++ ) {
			if (style_num[i].checked){
				num = style_num[i].value;
			}
		}
		if (check_cssgr.checked) num = Number(num) + Number(5);		
	}
	//-------	
	var objData = {}; //
	objData.pre = out_pre;
	objData.size = out_size;
	objData.date = out_date;
	objData.count = out_cout;
	objData.style = num;	
	//-------
	var str = JSON.stringify(objData);
	ft.post_indm_settings.value = str;
	//-------		
	// создадим имя для скрытого поля
	// пердохранитель от случайного стирания данных если JS вдрук отключен
	document.getElementById('indm-fields').name = "post_indm_fields";
	// запускаем ф-ю сохранения и отправки данных
	if (SetDataTableIndm_JSON('table_indm'))ft.submit();
	//---------------
	} catch(e) {
		alert('Error JS ' + "\n" + e.name + ": " + e.message + "\n" + e.stack);
	}
}

//добавить данные из таблицы
function SetDataTableIndm_JSON(TableId, CountCells) {
	CountCells = typeof CountCells !== 'undefined' ?  CountCells : 7;
	//--------------------		
	var arrData = [];	
	var table = document.getElementById(TableId).getElementsByTagName('TBODY')[0];
	if(!table) return false;
	if(CountCells == 0) CountCells = table.rows[0].cells.length;
	//-------------------	
	for ( var i = 0; i < (table.rows.length); i++ ) {
		arrData[i] = new Array(CountCells);
		for ( var j = 0; j < CountCells; j++ ) {
			arrData[i][j] = table.rows[i].cells[j].innerHTML;
		}
	}
	//--------------------	
	var str = JSON.stringify(arrData);
	document.getElementById('indm-fields').value = str;
	return true;
}


</script>
