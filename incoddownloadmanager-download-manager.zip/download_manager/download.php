<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/*
	plugin InCod Download Manager
	download.php
 	Ufopera
	http://incod.ru/
*/

if (!empty($_GET['download'])) {
	$status = FALSE;
  $file_code = trim(strip_tags(basename($_GET['download'])));
  if ($file_code == "") {
  	error404();
  } else {
    // если есть файл в папке downloadmanager // и список закачек файлов плагина 
    if (file_exists(INCOD_DOWNLOAD_MANAGER_SETING)) { 
      #---------
    	$data_indm = getXML(INCOD_DOWNLOAD_MANAGER_SETING);
    	if ($data_indm and count($data_indm)) {
				$items = $data_indm->xpath("/settings/item[code='".$file_code."']");
				if (isset($items[0])) {
					$items[0]->count = (int)$items[0]->count +1;
					$filename = INCOD_DOWNLOADMANAGER_DIR.$items[0]->file;
					$status = TRUE;
				}		
				if (!$status) {
					error404();// если файла нет в списке закачек 
				}
    	} else {
    		error404();
      }
      //---------
 			$fh = @fopen($filename, "rb");
			if ($fh === false) { 
				header('Content-Type: text/plain');
			  exit("Unable open file");
			}
      //---------
      
      //---------		
			set_time_limit(0);// лимит времени выполнения 0 безлимит
			ignore_user_abort(false);// true продолжаем выполнятся при отключении пользователя
			ini_set('output_buffering', 0);
			ini_set('zlib.output_compression', 0);// required for IE & Safari
      //---------
      header('Content-Description: File Transfer');
      header('Content-Type: '.mime_content_type($filename));
      header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
      header('Content-Transfer-Encoding: binary');
      header('Connection: Keep-Alive');
      header('Expires: 0');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Last-Modified: '.gmdate('D, d M Y H:i:s', filemtime($filename)).' GMT');
      header('Pragma: public');
      header('Content-Length: ' . sprintf("%u", filesize($filename)));
      //---------    
			while(!feof($fh)) {
				print(fread($fh, 1024*256));
				flush();
				if (connection_status()!=CONNECTION_NORMAL) {
					@fclose($fh);
					die();
				}
			}
			@fclose($fh);
	    if(!XMLsave($data_indm, INCOD_DOWNLOAD_MANAGER_SETING)) {
	      writeLogFile($filename . ' Не удалось сохранить !');
	    }
			exit;
      //---------
    } else {
    	error404();
    }
  }
}

function error404() {
  header("HTTP/1.0 403 Forbidden");
  header('Content-Type: text/plain');
  exit('File not allowed!');
}

function writeLogFile($txt='') {
	$txt =  date("Y-m-d|H:i:s")."|".$_SERVER['REMOTE_ADDR']."|".$txt."\n";
	file_put_contents(INCOD_DM_LOG_FILE, $txt, FILE_APPEND | LOCK_EX);
}

?>