<?php

$i18n = array(

// tab 1
"ICDM_TITLE" => "Download Manager",
"ICDM_DESC" => "Download Manager for GetSimple",
"ICDM_ERROR_OPEN_FOLDER" => "Cannot open directory!",
"ICDM_OB_FIELD" => "Required field",
"ICDM_AUTOGEN_FIELD" => "Automatically Generated",
"ICDM_TITLE_ID" => "Leave blank to auto-fill, all characters are converted to Latin",
"ICDM_ADD_NEW" => "Add new",
"ICDM_USE" => "Apply",
"ICDM_MAX_SYMBOLS" => "Maximum 60 characters",
"ICDM_COUNT_DOWN" => "Download",
"ICDM_COUNT_DOWNLOAD" => "Number of downloads",
"ICDM_COLOUR" => "Button Color",
"ICDM_VIEW_BUTTONS" => "Design buttons",
"ICDM_DOWN_DESC" => "Description",
"ICDM_DOWN_ID" => "ID-code",
"ICDM_DOWN_CODE" => "Short-code",
"ICDM_COPU_CODE" => "Click on the text to copy to the clipboard",
"ICDM_COPU_OK" => "Code copied to clipboard",
"ICDM_COPU_NO" => "Impossible to copy",
"ICDM_ADD_DOWNLOAD" => "Add download file",
"ICDM_EDIT_DOWNLOAD" => "Change boot parameters",
"ICDM_DATE_CREATE" => "Creation date",
"ICDM_ID_EXISTS" => "The Specified ID already exists!",
"ICDM_DEL_REC" => "Are you sure You want to delete this record?",
"ICDM_NOT_HTACCESS" => "File Not found htaccess folder ",
"ICDM_ALL_ITEMS" => "All items",

// tab 2
"ICDM_OUTBUTINFO" => "Output Settings information",
"ICDM_STYLEBUT" => "Style Settings",
"ICDM_INFO_OUT" => "Select what to show on buttons",
"ICDM_STYLE_OUT" => "Output styles page",
"ICDM_VIEW_OUT" => "Select the design for all buttons",
"ICDM_SEZE" => "Show the size of files?",
"ICDM_DATE" => "Show date of creation?",
"ICDM_COUNT" => "Show count?",
"ICDM_USE_STYLE" => "Use inline css style?",
"ICDM_USESTYLDOWPAGE" => "Only Display the pages download?",
"ICDM_PREFIX" => "The Prefix for the name of the button, if the value of i18n will be replaced with the words: ",

"ICDM_VIEWB1" => "Flat, straight",
"ICDM_VIEWB2" => "Rounded",
"ICDM_VIEWB3" => "Strongly rounded",
"ICDM_VIEWB4" => "Rounded shadow",
"ICDM_VIEWB5" => "Contrast frame and shadow",
"ICDM_VIEWB6" => "Add a gradient?",

);

?>