<?php
/*
	plugin InCod Download Manager
	config.php
 	Ufopera
	http://incod.ru/
*/
########################################################

// create download manager directory
if(!is_dir(INCOD_DOWNLOADMANAGER_DIR)){
	if (mkdir(INCOD_DOWNLOADMANAGER_DIR, 0777, true)) {
	  echo '<div class="updated">'.sprintf(i18n_r('FOLDER_CREATED'),'<b>downloadmanager</b>').'</div>';

	if (!file_exists(''.INCOD_DOWNLOADMANAGER_DIR.'/.htaccess')) {
		file_put_contents(''.INCOD_DOWNLOADMANAGER_DIR.'/.htaccess', "Deny from all");
		file_put_contents(''.INCOD_DOWNLOADMANAGER_DIR.'/index.php', '<?php ?>');
	} 
 
	}else{
		echo '<div class="error">'.i18n_r('ERROR_CREATING_FOLDER').':<b> downloadmanager</b></div>';
	}
}
#------------

// create download directory для ЧПУ
if(!is_dir(INCOD_DOWNLOAD_DIR_CPLS)){
	if (mkdir(INCOD_DOWNLOAD_DIR_CPLS, 0777, true)) {
	  echo '<div class="updated">'.sprintf(i18n_r('FOLDER_CREATED'),'<b>download</b>').'</div>';
	  
	if (!file_exists(''.INCOD_DOWNLOAD_DIR_CPLS.'/.htaccess')) {
		$txt  ="RewriteEngine on\n";
		$txt .= "RewriteRule ^(.*)$ /index.php?download=$1 [L,QSA]";
		file_put_contents(''.INCOD_DOWNLOAD_DIR_CPLS.'/.htaccess', $txt);
		file_put_contents(''.INCOD_DOWNLOAD_DIR_CPLS.'/index.php', '<?php ?>');
	} 	  
	  
	}else{
		echo '<div class="error">'.i18n_r('ERROR_CREATING_FOLDER').':<b> download</b></div>';
	}
}
#------------

//Файл htaccess для папки downloadmanager
if (!file_exists(INCOD_DOWNLOADMANAGER_DIR.'/.htaccess')) {
	echo '<div class="error">'.i18n_r(ICDM_DIR.'ICDM_NOT_HTACCESS').':<b> downloadmanager</b></div>';
}
//Файл htaccess для папки download 
if (!file_exists(INCOD_DOWNLOAD_DIR_CPLS.'/.htaccess')) {
	echo '<div class="error">'.i18n_r(ICDM_DIR.'ICDM_NOT_HTACCESS').':<b> download</b></div>';
}
#------------


// поиск файлов
function re_GetArrDirFiles($dir, $ext = 'zip,rar,exe') {
 if (!is_dir($dir)) return FALSE;
 $result = array();
 $arr_ext = array();
 if(trim($ext) !=="") $arr_ext = explode(",", strtolower($ext));
 $cdir = scandir($dir) or die("<div class=error>".i18n_r(ICDM_DIR."ICDM_ERROR_OPEN_FOLDER")."<b> $dir </b></div>");
 foreach ($cdir as $key => $value) {
	if (!in_array($value,array(".","..",".htaccess", ".htpasswd"))) {
	  if (is_dir($dir . DIRECTORY_SEPARATOR . $value)) {
			$result[$value] = re_GetArrDirFiles($dir . DIRECTORY_SEPARATOR . $value, $ext);
	  } else {
	  	if(count($arr_ext) > 0){
		  	if(false !== ($i = strrpos($value, '.'))){
					$true = FALSE;
					foreach ($arr_ext as $e){
						if((strtolower(substr($value, $i+1))) == trim($e)) $true = TRUE;
					}
					if($true) $result[] = $value;
				}
			} else {$result[] = $value;}
	  }
	}
 }
 return $result; 
}

#------------
// Открыть каталог - считать содержимое
function GetFilesList_re($dir){
	#------
	$ext ='zip,rar,pNg ,jpg,exe,avi,mp3,mp4';
	$dirlist = re_GetArrDirFiles(INCOD_DOWNLOADMANAGER_DIR, $ext);
	$tmp ='';
	$stl = '+';
	#------
	foreach($dirlist as $key =>$value) {
	  if (is_array($value)) {
			foreach ($value as  $val) {
				$filesize = formatBytes(filesize(INCOD_DOWNLOADMANAGER_DIR."$key/$val"));
				$tmp = $tmp."<option class=\"dm-dir\" title=\"$filesize\">$key/$val</option>";
			}
		}else{
			$filesize = formatBytes(filesize(INCOD_DOWNLOADMANAGER_DIR."$value"));
			$tmp = $tmp. "<option title=\"$filesize\" class=\"dm-nod\" >$value</option>";
		}
	}
	return $tmp;
}
#------------

#------------
# получить размер
function formatBytes($bytes, $decimals = 2) {
  $factor = floor((strlen($bytes) - 1) / 3);
  if ($factor > 0) $sz = 'KMGT';
  return sprintf("%.{$decimals}f%s",$bytes / pow(1024,$factor),' '.@$sz[$factor-1].'B');
}

#------------
#	Сохранить параметры
if ( (isset($_POST['post_indm_fields'])) AND (isset($_POST['post_indm_settings'])) ){
  $array_indm =json_decode($_POST['post_indm_fields'], true);
  $t_count = count($array_indm);
  //-------
  $xml_indm_safe = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><settings />');
  # общие настройки
  $arr_options =json_decode($_POST['post_indm_settings'], true);
  //-------
	if (count($arr_options)) {
    $xml_indm_safe->addAttribute('pre', $arr_options['pre']);
    $xml_indm_safe->addAttribute('size', $arr_options['size']);
    $xml_indm_safe->addAttribute('date', $arr_options['date']);
    $xml_indm_safe->addAttribute('count', $arr_options['count']);
    $xml_indm_safe->addAttribute('style', $arr_options['style']);    
  }
	#------------    
	if ($t_count > 0) {
		#------------
	  for ($i=0; $i < $t_count; $i++) {
	  	#------------
	  	# основыные параметры
			$item = $xml_indm_safe->addChild('item');
			#------------
			$item->addChild('name', strip_tags($array_indm[$i][0]));
			$item->addChild('file', strip_tags($array_indm[$i][1]));
			$item->addChild('size', $array_indm[$i][2]);
			$item->addChild('code', incTranslate(strip_tags($array_indm[$i][3])));
			$item->addChild('date', $array_indm[$i][4]);								
			$item->addChild('count', $array_indm[$i][5]);
			if ($array_indm[$i][6] == "") $array_indm[$i][6] = 0;
			$item->addChild('style', $array_indm[$i][6]);
	    #------------				
		}
	}
  //Save XML File
  if(XMLsave($xml_indm_safe, INCOD_DOWNLOAD_MANAGER_SETING)) {
    echo '<div class="updated">'.i18n_r("SETTINGS_UPDATED").'</div>';
  }			
}

// предустановленные параметры
$indm_set = array("pre" => "i18n", "size" => "1", "date" => "1", "count" => "1", "style" => "2");
#------------
# чтение параметров +
function re_indm_table_item(&$indm_set){
	#------------
	$file = INCOD_DOWNLOAD_MANAGER_SETING;
	if (file_exists($file)) {
		$arr_indm = array();
		$arr_indm = getXML($file);
		# основыные параметры
		$indm_set['pre'] 	 = $arr_indm['pre'];
		$indm_set['size']  = $arr_indm['size'];
		$indm_set['date']  = $arr_indm['date'];
		$indm_set['count'] = $arr_indm['count'];
		$indm_set['style'] = $arr_indm['style'];
		#------------	
		$t_count = count($arr_indm);
		if ($arr_indm and $t_count > 0) {
			#------------
			$i=0;$tmp ='';
			#------------
			foreach ($arr_indm as $key ){
				#------------
				$i++;
				$tmp = $tmp . '
				<tr id="iddi_'. $i .'" onclick="get_cod_id('.$i.')"  ondblclick="findmShow('.$i.')">
					<td>'.$key->name.'</td>
					<td>'.$key->file.'</td>
					<td align="right">'.$key->size.'</td>
					<td>'.$key->code.'</td>
					<td align="right">'.$key->date.'</td>
					<td class="tbindn">'.$key->count.'</td>
					<td align="right">'.$key->style.'</td>
					<td class="indm_edit" title="'.i18n_r("EDIT").'" onclick="findmShow('.$i.')" >&#9998;</td>
					<td class="indm_close" title="'.i18n_r("ASK_DELETE").'" onclick="indm_Close('.$i.')" >&#10006;</td>
				</tr>';
			#------------	
			}
			return $tmp;
		}
	}	
	#------------
}

# transliteration
function incTranslate($str) {
	if (function_exists('doTransliteration')) { 
		$result = doTransliteration($str);
	} else {
		$result = $str;
		$transliteration = i18n_r("TRANSLITERATION");
		foreach ($transliteration as $from => $to) $result = str_replace($from, $to, $result);
	}
	return $result;
}


global $LANG;
$help_file = '../plugins/download_manager/help/'.substr($LANG,0,2).'/index.html';
if (!file_exists($help_file)) {
  $help_file = '../plugins/download_manager/help/en/index.html';
}

########################################################
?>

<script type="text/javascript" src="../plugins/download_manager/js/indm.js"></script> 
<style>@import "../plugins/download_manager/css/indm.css";</style>


<!-- Задний фон-->
<div onclick="findmShow(-1 ,'none')" id="findm_wrap" style="display: none;"></div>
<!-- Само окно-->
<div id="findm_window" style="display: none;">
	<!-- close pic -->
	<span class="win_close indm_close" onclick="findmShow( -1 ,'none')">&#10006;</span>
	<!-- ======================================================================== //-->	
	<h3 id="win_header"><?php i18n(ICDM_DIR."ICDM_ADD_DOWNLOAD"); ?></h3>
	<hr>	
	<ul><li>
	<label><?php i18n(ICDM_DIR."ICDM_DOWN_DESC"); ?>: <b>*</b></label>
	<input type="text" id="indm_add_name" tabindex="1" placeholder="<?php i18n(ICDM_DIR."ICDM_OB_FIELD"); ?>" 
		spellcheck="true" maxlength="60" title="<?php i18n(ICDM_DIR."ICDM_MAX_SYMBOLS"); ?>"/>
	</li><li>
	<label><?php i18n("FILE_NAME"); ?>: <b>*</b></label>
	<select id="indm_add_file" tabindex="2" title="<?php i18n("FILE_BROWSER"); ?>"><?php echo GetFilesList_re(INCOD_DOWNLOADMANAGER_DIR); ?></select>
	</li><li>
	<label><?php i18n(ICDM_DIR."ICDM_DOWN_ID"); ?>:</label>
	<input type="text" id="indm_add_id" tabindex="3" placeholder="<?php i18n(ICDM_DIR."ICDM_AUTOGEN_FIELD"); ?>" title="<?php i18n(ICDM_DIR."ICDM_TITLE_ID"); ?>"/>
	</li></ul>
	<div id="edit_datas">
	<ul>
		<li>
		<label><?php i18n("DATE"); ?>:</label> 
		<input type="date" id="edit_date" title="<?php i18n(ICDM_DIR."ICDM_DATE_CREATE"); ?>" placeholder=""/>
		</li>
		<li>
		<label><?php i18n(ICDM_DIR."ICDM_COUNT_DOWN"); ?>:</label> 
		<input type="number" id="edit_number" value="0" title="<?php i18n(ICDM_DIR."ICDM_COUNT_DOWNLOAD"); ?>" min=0 pattern="[0-9]"/>
		</li>	
		<li>
		<label><?php i18n(ICDM_DIR."ICDM_COLOUR"); ?>:</label>
		<select id="edit_select" title="<?php i18n(ICDM_DIR."ICDM_VIEW_BUTTONS"); ?>">
		 <option style="background:#fff;"  value="0">0</option>
		 <option style="background:#f2f2f2;" value="1">1</option>
		 <option style="background:#44a0d2;" value="2">2</option>
		 <option style="background:#d81010;" value="3">3</option>
		 <option style="background:#3cc854;" value="4">4</option>
		 <option style="background:#fe9403;" value="5">5</option>
		 <option style="background:#707070;" value="6">6</option>
		</select>
		</li>
		</ul>
	</div>
	<hr>	
	<button id="add_button" class="add_button" tabindex="4" onclick="AddElemInDM('table_indm')" style="float:right;">ADD</button>
	<!-- ======================================================================== //-->			
</div>


<div id="in_dm" class="clearfix">
	<noscript>JavaScript disabled!<br></noscript>
	<h2><?php i18n(ICDM_DIR."ICDM_TITLE"); ?></h2>
	<hr>
	
	<div class="tabx">
	  <input type="radio" name="odin" checked="checked" id="vkl1"/><label for="vkl1"><?php i18n(ICDM_DIR."ICDM_COUNT_DOWN"); ?></label>
	  <input type="radio" name="odin" id="vkl2"/><label for="vkl2"><?php i18n("TAB_SETTINGS"); ?></label>
	  <input type="radio" name="odin" id="vkl3"/><label for="vkl3"><?php i18n("HELP"); ?></label>
	  <input type="radio" name="odin" id="vkl4"/><label for="vkl4"><?php i18n("PLUGIN_VER"); ?></label>
	  
	  <div id="tabx_1"><!--вкладка 1 -->
			<!-- ======================================================================== //-->	
			<form id="form_indm" action="" name="person" method="post" accept-charset="utf-8" onsubmit="dataSettings(this);return false;">
			<!-- ======================================================================== //-->	
			<div class="wid_box">
				<table id="table_indm" border="0" width="100%">
				<!-- <caption>Менеджер загрузок - таблица</caption> -->
				 <thead>
				 <tr>
			      <td colspan="9">
			      	<span class="add_button dmbut" onclick="findmShow(-1, 'block')"><?php i18n(ICDM_DIR."ICDM_ADD_NEW"); ?></span>
			      </td>        
			    </tr>
				 <tr id="thead_indm">
						<th><span onclick="table_sort(thead_indm, tbody_indm, 0)"></span><?php i18n(ICDM_DIR."ICDM_DOWN_DESC"); ?></th>
						<th><span onclick="table_sort(thead_indm, tbody_indm, 1)"></span><?php i18n("FILE_NAME"); ?></th>
						<th width="80"><span onclick="table_sort(thead_indm, tbody_indm, 2)"></span><?php i18n("FILE_SIZE"); ?></th>
						<th><span onclick="table_sort(thead_indm, tbody_indm, 3)"></span><?php i18n(ICDM_DIR."ICDM_DOWN_ID"); ?></th>
						<th width="78"><span onclick="table_sort(thead_indm, tbody_indm, 4)"></span><?php i18n("DATE"); ?></th>
						<th width="94"><span onclick="table_sort(thead_indm, tbody_indm, 5)"></span><?php i18n(ICDM_DIR."ICDM_COUNT_DOWN"); ?></th>
						<th style="font-size:1.7em;">&#10059;</th>
						<th style="font-size:1.7em;">&#9998;</th>
						<th style="font-size:1.3em;">&#10006;</th>
				 </tr>
				 </thead>
				 <tbody id="tbody_indm">
					<?php echo re_indm_table_item($indm_set); ?>
					</tbody>
			    <tfoot><!-- optional -->
			      <tr>
			        <td colspan="3">
			        	<?php i18n(ICDM_DIR."ICDM_ALL_ITEMS"); ?>: 
			        	<script type="text/javascript">
			        	document.write(document.getElementById('table_indm').getElementsByTagName('TBODY')[0].rows.length);
			        	document.getElementById('indm_add_file').value = "";
			        	</script>
			        </td>
			        <td colspan="6">
			        	<?php i18n(ICDM_DIR."ICDM_DOWN_CODE"); ?>: <input type="text" onclick="copy_cod('indm_id_code')" 
			        		id="indm_id_code" value="" tabindex="5" title="<?php i18n(ICDM_DIR."ICDM_COPU_CODE"); ?>"/>
			        </td>      
			      </tr>
			    </tfoot>
				</table>
			</div>	
			<!-- ======================================================================== //-->	
			<hr>
			<input type="hidden" id="indm-fields">
			<input type="hidden" id="indm_settings" name="post_indm_settings" value="">
			<p><!--########################### -->
				<noscript>JavaScript disabled!</noscript><br>
				<input type="submit" class="submit" name="post_indm" value="<?php i18n("BTN_SAVESETTINGS"); ?>" disabled tabindex="5" />
				<script type="text/javascript">
				// блокировать/разблокировать нажатие на кнопку отправить если JS оключен.
				document.getElementsByName('post_indm')[0].disabled = 0 
				</script>
			</p><!--###########################  -->
			</form>
	</div><!--вкладка 1 -->

		<?php 
		# ====================================
		# Вывод вкладка 2 
		include(GSPLUGINPATH.'download_manager/settings.php'); 
		# ====================================
		?>

	  <div id="tabx_3"><!--вкладка 3 -->
			<iframe id="frame_box" src="<?php echo $help_file; ?>" name="tarbox" frameborder="0" src="<?php echo $help_file; ?>"></iframe>
	  </div><!--вкладка 3 -->
	  
	  <div id="tabx_4"><!--вкладка 4 -->
	  	<?php echo '<h2>InCodDownloadManager - ICDM v'. ICDM_VERSION . '</h2>'; ?>
	  	<p>&copy; 27-11-2017 &nbsp; Author: Ufopera, &nbsp; URI &nbsp;<a href="http://incod.ru/">InCod</a></p>
	  
	  </div><!--вкладка 4 -->
	  
	</div>
</div>


<script type="text/javascript">

var indm_name_code_id					=	<?php echo '"'.INCOD_DOWNLOAD_MANAGER_ID.'"'; ?>; // константана кода стр.
var title_but_col							=	'<?php i18n(ICDM_DIR."ICDM_COLOUR"); ?>';
var title_copy_cod_ok					=	'<?php i18n(ICDM_DIR."ICDM_COPU_OK"); ?>'; //Код скопирован в буфер обмена
var title_copy_cod_no					=	'<?php i18n(ICDM_DIR."ICDM_COPU_NO"); ?>'; // Невозможно скопировать
var title_win_header_edit			=	'<?php i18n(ICDM_DIR."ICDM_EDIT_DOWNLOAD"); ?>';	//Изменить параметры загрузки
var title_win_button_edit			=	'<?php i18n(ICDM_DIR."ICDM_USE"); ?>'; //Изменить
var title_win_header_add			=	'<?php i18n(ICDM_DIR."ICDM_ADD_DOWNLOAD"); ?>';	//Добавить файл загрузки
var title_win_button_add			=	'<?php i18n(ICDM_DIR."ICDM_USE"); ?>'; //Добавить
var message_add_corect_field	=	'<?php i18n("FILL_IN_REQ_FIELD"); ?>'; // заполните все обязательные поля
var message_add_corect_id			=	'<?php i18n(ICDM_DIR."ICDM_ID_EXISTS"); ?>'; // Указаный индефикатор уже существует!
var message_delet_item				=	'<?php i18n(ICDM_DIR."ICDM_DEL_REC"); ?>'; // Вы действительно хотите удалить эту запись?

var edit_row_index;      // редактируемая строка

// --------------------
var indm_add_name = document.getElementById('indm_add_name');
var indm_add_file = document.getElementById('indm_add_file');
var indm_add_id = document.getElementById('indm_add_id');
var edit_date = document.getElementById('edit_date');	
var edit_number = document.getElementById('edit_number');
var edit_select = document.getElementById('edit_select');
var edit_datas = document.getElementById('edit_datas');
var findm_window =document.getElementById('findm_window');
var findm_wrap =document.getElementById('findm_wrap');
//---------------


function copy_cod(xID){
	var copyEl = document.getElementById(xID);
	if (copyEl.value.indexOf(indm_name_code_id) != -1){
		copyEl.select(); // all select txt в input
		var result = document.execCommand('copy');
		if (result) {
			copyEl.value = title_copy_cod_ok;
		}else{
			copyEl.value = title_copy_cod_no;
		}
	}
}


//Функция показа окна
function findmShow(id, state){
	//--------
	id = typeof id !== 'undefined' ?  id : -1;
	state = typeof state !== 'undefined' ?  state : 'block';
	//--------
	edit_row_index = id;
	var height = '306';
	//--------
	indm_add_name.style.cssText="box-shadow:0 !important";
	indm_add_file.style.cssText="box-shadow:0 !important";
	indm_add_id.style.cssText="box-shadow:0 !important";
	//--------
	if (edit_row_index != -1){
		document.getElementById('win_header').innerHTML = title_win_header_edit;
		document.getElementById('add_button').innerHTML = title_win_button_edit;
		height = '382';
		//--------
		var row_edit = document.getElementById('iddi_' + id);
		//--------
		indm_add_name.value = row_edit.cells[0].innerHTML;
		indm_add_file.value = row_edit.cells[1].innerHTML;
		indm_add_id.value = row_edit.cells[3].innerHTML;
		edit_date.value = row_edit.cells[4].innerHTML;		
		edit_number.value = row_edit.cells[5].innerHTML;
		edit_select.value = row_edit.cells[6].innerHTML;
		//--------
		edit_datas.style.cssText="display: block;";
		//--------
	} else{
		document.getElementById('win_header').innerHTML = title_win_header_add;
		document.getElementById('add_button').innerHTML = title_win_button_add;
		//--------
		indm_add_name.value = '';
		indm_add_file.value = '';
		indm_add_id.value = '';	
		edit_date.value = '';	
		edit_number.value = '';
		edit_select.value = '';
		//--------
		edit_datas.style.cssText="display: none;";
		//--------
	}
	// показываем окно
	findm_window.style.cssText="left: 35%;top: 24%;display:"+ state +";height:"+ height +"px;";
	findm_wrap.style.display = state;
	//--------
}


// функция для редактирования ID
function findm_edit(xID) {
	xID = 'iddi_' + xID;
	//--------
	var row_edit = document.getElementById(xID);
	//--------
	row_edit.cells[0].innerHTML = indm_add_name.value;
	row_edit.cells[1].innerHTML = indm_add_file.value;
	row_edit.cells[2].innerHTML = indm_add_file.options[indm_add_file.selectedIndex].title;
	row_edit.cells[3].innerHTML = indm_add_id.value;
	row_edit.cells[4].innerHTML = edit_date.value;
	row_edit.cells[5].innerHTML = edit_number.value;
	row_edit.cells[6].innerHTML = edit_select.value;
	//--------
	findmShow( -1 ,'none');
	but_bg_col();
	//--------
}	


function AddElemInDM(id)
{
	try {
	//---------------
		var str;
		var d = document;
		//var itemID;if(!this.i) {this.i = 0;};itemID = this.i++;//статическая переменная
		var now = new Date();
		var valid = false;
		
		// Находим нужную таблицу
		var tbody = d.getElementById(id).getElementsByTagName('TBODY')[0];
		var itemID = tbody.rows.length + 1;
		
		indm_add_name.style.cssText="box-shadow:0 !important";
		indm_add_file.style.cssText="box-shadow:0 !important";
		indm_add_id.style.cssText="box-shadow:0 !important";
		
		if(indm_add_name.value=='') {
			indm_add_name.style.cssText="box-shadow:0 0 0 1px #ff2222;";
			valid=true;
		}
		if(indm_add_file.value=='') {
			indm_add_file.style.cssText="box-shadow:0 0 0 1px #ff2222;";
			valid=true;
		}
		if(valid==true) {
			alert(message_add_corect_field); 
			return;
		}
			
		//удалить пробелы " : "
		str = indm_add_id.value; indm_add_id.value = str.replace( /\s+/g, "" );
		
		var x_value = ''; var i = 1;
		
		if(indm_add_id.value=='') {
			x_value = basename(indm_add_file.value);
			// обрезать строку до .. 
			if(x_value.length > 30){
				x_value = x_value.slice(0,24) + '_' + x_value.slice(-4);
			}
			//---------
			while (vTableTrueTxt(id,3,x_value, -1)) { // Поиск дубликатов
			  i++;
			  x_value = x_value + '_' + i;
			}
			//---------			
			indm_add_id.value = x_value;
		}

		if(vTableTrueTxt(id,3,indm_add_id.value, edit_row_index)) {
			indm_add_id.style.cssText="box-shadow:0 0 0 1px #ff2222;";
			alert(message_add_corect_id); 
			return;
		}

		if(edit_row_index > 0) {
			findm_edit(edit_row_index);
			edit_row_index = -1;
			return;
		}	

		// Создаем строку таблицы и добавляем ее
		var row = d.createElement("TR");
		row.style.cssText="background:rgba(49,255,147,.12);";
		row.id = "iddi_" + itemID; 
		tbody.insertBefore(row, tbody.firstChild);

		// Создаем ячейки
		var td0 = d.createElement("TD");var td1 = d.createElement("TD");
		var td2 = d.createElement("TD");var td3 = d.createElement("TD");
		var td4 = d.createElement("TD");var td5 = d.createElement("TD");
		var td6 = d.createElement("TD");var td7 = d.createElement("TD");
		var td8 = d.createElement("TD");

		row.appendChild(td0);row.appendChild(td1);
		row.appendChild(td2);row.appendChild(td3);
		row.appendChild(td4);row.appendChild(td5);
		row.appendChild(td6);row.appendChild(td7);
		row.appendChild(td8);

		// заполняем ячейки
		td0.innerHTML = indm_add_name.value;
		
		//удалить пробелы в начале и в конце строки
		str = indm_add_file.value; indm_add_file.value = str.trim(str);
		
		td1.innerHTML = indm_add_file.value;
		td2.innerHTML = indm_add_file.options[indm_add_file.selectedIndex].title;
		td3.innerHTML = indm_add_id.value;
		td4.innerHTML = now.getFullYear()+"-"+now.getMonth()+"-"+now.getDate();
		td5.innerHTML = '0';
		
		td7.innerHTML = '&#9998;';
		td7.title = "Edit";
		td7.className = "indm_edit";
		td7.setAttribute("onclick", "findmShow('" + itemID + "')");
		
		td8.className = "indm_close";
		td8.title = "Close";
		td8.setAttribute("onclick", "indm_Close('" + itemID + "')");
		td8.innerHTML = "&#10006;";
		
		indm_add_name.value = "";
		indm_add_file.value = "";
		indm_add_id.value = "";
		findmShow( -1 ,'none');
		but_bg_col();
	//---------------
	} catch(e) {
		alert('Error JS ' + "\n" + e.name + ": " + e.message + "\n" + e.stack);
	}
}

function indm_Close(xID) {
result = confirm(message_delet_item);
if (result) {
	var xElem = document.getElementById('iddi_' + xID);
	xElem.parentNode.removeChild(xElem);
}
}


</script>


<?php 
#------------

#------------
?>
