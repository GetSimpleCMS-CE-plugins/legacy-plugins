// -----------------------------------
//	plugin InCod Download Manager
// 	Ufopera
//	http://incod.ru/
// -----------------------------------

window.onload = function() {
  //alert( 'Документ и все ресурсы загружены' );
  but_bg_col();
  show_win_move();  
};


function but_bg_col() {
	var opt = -1; var cel = 6; 
	var table = document.getElementById('table_indm').getElementsByTagName('TBODY')[0];
	for ( var i = 0; i < table.rows.length; i++ ) {
		table.rows[i].cells[cel].title = title_but_col;
		opt = table.rows[i].cells[cel].innerHTML;
		if(opt == 0) table.rows[i].cells[cel].style.cssText="background:#fff;color:#fff;";
		if(opt == 1) table.rows[i].cells[cel].style.cssText="background:#f2f2f2;color:#f2f2f2;";
		if(opt == 2) table.rows[i].cells[cel].style.cssText="background:#44a0d2;color:#44a0d2;";
		if(opt == 3) table.rows[i].cells[cel].style.cssText="background:#d81010;color:#d81010;";
		if(opt == 4) table.rows[i].cells[cel].style.cssText="background:#3cc854;color:#3cc854;";
		if(opt == 5) table.rows[i].cells[cel].style.cssText="background:#fe9403;color:#fe9403;";
		if(opt == 6) table.rows[i].cells[cel].style.cssText="background:#707070;color:#707070;";
	}
}

// функция для показа и копирования ID 
function get_cod_id(xID) {
	xID = 'iddi_' + xID;
	var rowsElem;
	var table = document.getElementById('table_indm').getElementsByTagName('TBODY')[0];
	var cElem = document.getElementById('indm_id_code');
	for ( var i = 0; i < table.rows.length; i++ ) {
		table.rows[i].removeAttribute('class','marked');
		if (table.rows[i].id == xID) {
			table.rows[i].setAttribute('class','marked');
			cElem.value = "(%" + indm_name_code_id + ":"+ table.rows[i].cells[3].innerHTML + "%)";
		}
	}
}


//Сравнение содержимого строк в table
function vTableTrueTxt(id, cel, txt, id_edit) {
	//--------------------	
	id_edit = typeof id_edit !== 'undefined' ?  id_edit : -1;
	//--------------------
	var table = document.getElementById(id).getElementsByTagName('TBODY')[0];
	for ( var i = 0; i < table.rows.length; i++ ) {
		//--------
		if ( (id_edit ==-1) || (table.rows[i].id != "iddi_" + id_edit)) { // если редактируем этот ID то не сравниваем на дубликат
			if (table.rows[i].cells[cel].innerHTML === txt){
				return i+1;
			}
		}
		//--------
	}
	return false;
}


//--------------------------
// получить имя файла
//--------------------------
function basename(path) {
   return path.split('/').reverse()[0];
}

//ТИПА СТАТИЧЕСКАЯ ПЕРЕМЕННАЯ
function dmIndexItem() {
  if(!this.i) {
     this.i = 0;
  }
  return this.i++;
}


//--------------------------
// перемещение окна
//--------------------------
function show_win_move(){
   var block = document.getElementById("findm_window");
   delta_x = 0;
   delta_y = 0;
   /* Ставим обработчики событий на нажатие и отпускание клавиши мыши */
   block.onmousedown = saveXY;
  block.addEventListener("onmousedown", saveXY, false);
   document.onmouseup = clearXY;
   /* При нажатии кнопки мыши попадаем в эту функцию */
   function saveXY(obj_event) {
     /* Получаем текущие координаты курсора */
     if (obj_event) {
       x = obj_event.pageX;
       y = obj_event.pageY;
     }
     else {
       x = window.event.clientX;
       y = window.event.clientY;
     }
     // опредиляем id=win_header за что тянуть -------
     var element =  document.elementFromPoint(x, y);
     if ((element) && (element.id != "win_header")){
     		return;
     }     
     /* Узнаём текущие координаты блока */
     x_block = block.offsetLeft;
     y_block = block.offsetTop;
     /* Узнаём смещение */
     delta_x = x_block - x;
     delta_y = y_block - y;
     /* При движении курсора устанавливаем вызов функции moveWindow */
     document.onmousemove = moveBlock;
     if (op || ff)
       document.addEventListener("onmousemove", moveBlock, false);
   }
   function clearXY() {
     document.onmousemove = null; // При отпускании мыши убираем обработку события движения мыши
   }
   function moveBlock(obj_event) {
     /* Получаем новые координаты курсора мыши */
     if (obj_event) {
       x = obj_event.pageX;
       y = obj_event.pageY;
     }
     else {
       x = window.event.clientX;
       y = window.event.clientY;
     }
     /* Вычисляем новые координаты блока */
     new_x = delta_x + x;
     new_y = delta_y + y;
     block.style.top = new_y + "px";
     block.style.left = new_x + "px";
   }
}
	

// sorting-table  ===============

var index;      // cell index
var toggleBool; // sorting asc, desc 

function table_sort(thead, tbody, index){
	
		for ( var i = 0; i < thead.cells.length; i++ ) {
			thead.cells[i].removeAttribute('class','sort_asc');
			thead.cells[i].removeAttribute('class','sort_desc'); 
		}	

    this.index = index;
    if(toggleBool){
      toggleBool = false;
      thead.cells[index].removeAttribute('class','sort_desc');
      thead.cells[index].setAttribute('class','sort_asc'); 
    }else{
      toggleBool = true;
      thead.cells[index].removeAttribute('class','sort_asc');
      thead.cells[index].setAttribute('class','sort_desc');
    }

    var datas= new Array();
    var tbodyLength = tbody.rows.length;
    for(var i=0; i<tbodyLength; i++){
      datas[i] = tbody.rows[i];
    }

    // sort by cell[index] 
    datas.sort(compareCells);
    for(var i=0; i<tbody.rows.length; i++){
      // rearrange table rows by sorted rows
      tbody.appendChild(datas[i]);
    }   
}

function compareCells(a,b) {
  var aVal = a.cells[index].innerText;
  var bVal = b.cells[index].innerText;

  aVal = aVal.replace(/\,/g, '');
  bVal = bVal.replace(/\,/g, '');

  if(toggleBool){
    var temp = aVal;
    aVal = bVal;
    bVal = temp;
  } 

  if(aVal.match(/^[0-9]+$/) && bVal.match(/^[0-9]+$/)){
    return parseFloat(aVal) - parseFloat(bVal);
  }
  else{
    if (aVal < bVal){
      return -1; 
    }else if (aVal > bVal){
      return 1; 
    }else{
      return 0;       
    }         
  }
}
