<?php
/*
Plugin Name: InCod Download Manager
Description: Менеджер для GetSimple
Version: 1.0
Author: ufopera
Author URI: http://incod.ru/
file:download_manager.php
*/

# get correct id for plugin
$thisfile_icdm=basename(__FILE__, ".php");

# plugin version
define('ICDM_VERSION', '1.0.0');

# add in this plugin's language file
if ( !is_frontend() ){
	i18n_merge($thisfile_icdm) || i18n_merge($thisfile_icdm, 'en_US');
}

# регистрируем плагин в системе
register_plugin(
	$thisfile_icdm, //идентификатор плагина
	i18n_r($thisfile_icdm.'/ICDM_TITLE'), 	//Название плагина
	ICDM_VERSION, 		//Версия плагина
	'ufoprra',  //автор плагина
	'http://incod.ru/', //сайт автора
	i18n_r($thisfile_icdm.'/ICDM_DESC'),  //краткое описание плагина
	'files', //тип страницы – на какой из вкладок административной панели появится плагин
	'incod_download_manager_config'  //главная функция плагина
);

#------------
global $SITEURL;
#------------
define('ICDM_DIR', 'download_manager/');
define('INCOD_DOWNLOAD_MANAGER_ID', 'InDownloadManager');
define('INCOD_DOWNLOAD_MANAGER_SETING', GSDATAOTHERPATH  . 'download_manager.xml');
define('INCOD_DOWNLOAD_MANAGER_COUNTER', GSDATAOTHERPATH  . 'counter/');
#define('INCOD_DOWNLOADMANAGER_DIR', '../data/uploads/downloadmanager/');
define('INCOD_DOWNLOADMANAGER_DIR', GSDATAUPLOADPATH .'downloadmanager/');
define('INCOD_DOWNLOAD_DIR_CPLS', '../download/');
define('INCOD_DOWNLOADMANAGER_DIR_URL', $SITEURL.'data/uploads/downloadmanager/');
define('INCOD_DM_LOG_FILE', GSDATAOTHERPATH .'logs/ic_download_manager.dat');
#------------

# activate filter/активируем фильтр 
#add_action('edit-content','incod_download_manager_edit');  //дополнительные поля после текстового поля в файле edit.php

# hooks ##########################
# Добавляем ссылку на вкладку files 
add_action('files-sidebar', 'createSideMenu', array($thisfile_icdm, i18n_r($thisfile_icdm.'/ICDM_TITLE')));

##Example for filter and action
add_action('index-pretemplate', 'pre_download');//pre template
add_action('theme-footer', 'indm_footer_css'); //theme footer

# filter ##########################
# activate filter
add_filter('content','indm_code_replace'); 
add_filter('theme-footer', 'indm_content_bottom');


function pre_download() {
  include(GSPLUGINPATH.'download_manager/download.php');
}

function incod_download_manager_config(){
  include(GSPLUGINPATH.'download_manager/config.php');
}

/*function incod_download_manager_edit() {
}*/

// [InDownloadManager:ID11:3] (%InDownloadManager:ID11#3%)
function indm_code_replace($content) {
  return preg_replace_callback("/\(%(.*)".INCOD_DOWNLOAD_MANAGER_ID.":(.*)%\)/",'dynpages_replace_match',$content);
}

function dynpages_replace_match($match) {
	if (isset($match[2]) and trim($match[2]) != ""){
		$arr_param = explode("#", $match[2]);
		if(count($arr_param) > 1){
			return re_indm_item($match[0], $arr_param[0], $arr_param[1]);	
		}else{			
			return re_indm_item($match[0], $arr_param[0]);
		}
	} else{ 
		return '';
	}
}


function re_indm_item($match0, $name, $col = 3){
	$name = trim($name); $col = trim($col);
	if($name == "" or $col == "") 
	#------
	global $g_ar_indm;
	static $g_ar_indm = array();
	#------
	if (!isset($GLOBALS['gindm_stat'])) {
		$GLOBALS['gindm_stat'] = 0;
		if (file_exists(INCOD_DOWNLOAD_MANAGER_SETING)) $g_ar_indm = getXML(INCOD_DOWNLOAD_MANAGER_SETING);
		if (isset($g_ar_indm['style'])) {
			$GLOBALS['gindm_stat'] = $g_ar_indm['style'];			
		}
	}
	#------
	if (isset($g_ar_indm)) {
		if (count($g_ar_indm)){
			#------
			$items = $g_ar_indm->xpath("/settings/item[code='".$name."']");
			#------
			if (isset($items[0])) {
				$tmp = '';
				$key = $items[0];
				#------				
				if($g_ar_indm['size']!='') $tmp = 			 "<i>$key->size</i>"; 
				if($g_ar_indm['date']!='') $tmp = $tmp . "<i>$key->date</i>"; 
				if($g_ar_indm['count']!='') $tmp = $tmp . "<i>$key->count&darr;</i>";
				if($g_ar_indm['pre']=='i18n') $g_ar_indm['pre'] = i18n_r("DOWNLOAD"). ': '; 
				#------
				return '<div class="indm-'.$key->style.'"><a href="/download/'.$key->code.'" title="'.basename($key->file).'" onclick="md_ev()">'
				. $g_ar_indm['pre'] ."$key->name <span>$tmp</span></a></div>";				
			}
			#------
		}			
	}
} 


# functions
function indm_footer_css() {

	if (isset($GLOBALS['gindm_stat']) and ($GLOBALS['gindm_stat'] !=0)) {
		
		$gstat = (int) $GLOBALS['gindm_stat'];
		$style1='';

		if ($gstat == 1 or $gstat == 6) { // плоские прямые
		$style1 =	'border:1px solid rgba(20,20,20,.1);';
		}
		elseif($gstat == 2 or $gstat == 7){ // плоские слабо скругленые
		$style1 =	'border:1px solid rgba(20,20,20,.1);border-radius:3px;';
		}
		elseif($gstat == 3 or $gstat == 8){ // плоские сильно скругленые
		$style1 =	'border:1px solid rgba(20,20,20,.1);border-radius:5px;';
		}
		elseif($gstat == 4 or $gstat == 9){ // плоские слабо скругленые с мал-тенью
		$style1 = 'box-shadow:1px 2px 3px rgba(0,0,0,.2);border:1px solid rgba(20,20,20,.1);border-radius:4px;';	
		}
		elseif($gstat == 5 or $gstat == 10){// плоские контрастные рамки и тени
		$style1 = 'box-shadow:2px 3px 6px rgba(0,0,0,.4);border:1px solid rgba(20,20,20,.2);border-radius:5px;';
		}

		?>
		<style type="text/css">
		/*## CSS InCod Download Manager ##*/
		[class^="indm-"]{display:inline-table;margin:.5em .5em .5em 0;user-select:none;outline:none;line-height:22px;font-weight:bold;<?php echo $style1; ?>}
		[class^="indm-"] a{display:table-cell;padding:15px 15px 15px 48px;font-size:16px;text-decoration:none;transition:all 0.2s ease-in-out;
		color:#fff !important;border:0 !important;background:url("data:image/gif;base64,R0lGODlhIAAgAIABAP///////yH5BAEAAAEALAAAAAAgACAAAAJOjI+py+0Po5y02g\
		MyuE1vvnhgqI2KaCJoaqysy3lyGc80aH/mXN2qj8kwgMGhkKSbEFtHyjLwdDyjnWaCakz+clxZtgv+grmssvmMRhcAADs=")10px 48% no-repeat;}
		[class^="indm-"] span{font-size:12px;display:block;white-space:pre;font-family:monospace;font-weight:normal;}
		[class^="indm-"] i:after{content:', ';}[class^="indm-"] i:last-child:after{content:none;}[class^="indm-"]:active{position:relative;top:2px;}
		[class^="indm-"] i{color:#fff;}.indm-0 i,.indm-1 i{color:#333;}
		.indm-0 a,.indm-1 a{color:#333 !important;background:url("data:image/gif;base64,R0lGODlhIAAgAIABAAAAAP///yH5BAEAAAEALAAAAAAgACAAAAJOjI\
		+py+0Po5y02gMyuE1vvnhgqI2KaCJoaqysy3lyGc80aH/mXN2qj8kwgMGhkKSbEFtHyjLwdDyjnWaCakz+clxZtgv+grmssvmMRhcAADs=")10px 48% no-repeat;}
		<?php if($gstat < 6): ?>
		.indm-1{background-color:#f2f2f2;}.indm-2{background-color:#44a0d2;}.indm-3{background-color:#d81010;}
		.indm-4{background-color:#3cc854;}.indm-5{background-color:#fe9403;}.indm-6{background-color:#777;}
		<?php else: ?>
		.indm-1{background:radial-gradient(#fcfcfc,#f7f7f7);}.indm-2{background:radial-gradient(#47b9d1,#329dc0);}
		.indm-3{background:radial-gradient(#f36565,#d31010);}.indm-4{background:radial-gradient(#77d055,#35bb38);}
		.indm-5{background:radial-gradient(#fcb001,#f88e01);}.indm-6{background:radial-gradient(#9d9d9d,#777);}
		<?PHP endif; ?>
		[class^="indm-"] a:hover{background-position-y:56%;box-shadow:2px 3px 6px rgba(0,0,0,.3);}
		</style>
		<?php
	}

}

# чтение параметров +
function icdm_get_table($get = true){
	#------------	
	if (is_frontend()){
		$thisfile_icdm=basename(__FILE__, ".php");
		i18n_merge($thisfile_icdm) || i18n_merge($thisfile_icdm, 'en_US');
	}
	#------------
	$file = INCOD_DOWNLOAD_MANAGER_SETING;
	if (file_exists($file)) {
		$arr_indm = array();
		$arr_indm = getXML($file);
		#------------	
		$t_count = count($arr_indm);
		if ($arr_indm and $t_count > 0) {
			#------------
			$i=0;$tmp ='';
			#------------
			foreach ($arr_indm as $key ){
				#------------
				$i++;
				$tmp = $tmp . '
				<tr>
					<td>'.$key->name.'</td>
					<td>'.$key->file.'</td>
					<td align="right">'.$key->size.'</td>
					<td align="right">'.$key->date.'</td>
					<td align="right">'.$key->count.' &darr;</td>
				</tr>';
			#------------	
			}
				$tmp = '
				<table id="indmtb" width="100%" border="1" bordercolor="#ccc" cellpadding="6" style="border-collapse:collapse;">
				 <thead>
				 <tr>
						<th>'.i18n_r(ICDM_DIR."ICDM_DOWN_DESC").'</th>
						<th>'.i18n_r("FILE_NAME").'</th>
						<th>'.i18n_r("FILE_SIZE").'</th>
						<th>'.i18n_r("DATE").'</th>
						<th>'.i18n_r(ICDM_DIR."ICDM_COUNT_DOWN").'</th>
				 </tr>
				 </thead>
				 <tbody>'
				. $tmp . 
				'</tbody>
				</table>';
			
			if ($get){
				echo $tmp.'
				<style>#indmtb td{padding:6px;border:1px solid #aaa}
				#indmtb th{background:#777;color:#fff;padding:10px;border-color:#777;text-align:center}
				#indmtb tbody tr:hover{background:#eee}</style>';
			}else{
				return $tmp;
			}
		}
	}	
	#------------
}


?>