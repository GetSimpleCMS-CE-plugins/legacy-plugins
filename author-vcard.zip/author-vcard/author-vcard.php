<?php
/*
Name: Author vCard
Description: Allows the author of a site to dynamically create a downloadble vCard
Version: 1.1
Author: Chris Cagle
Author URI: http://www.cagintranet.com/

*/

# http://www.troywolf.com/articles/php/class_vcard/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

$vcard_file=GSDATAOTHERPATH.'vcard.xml';

# register plugin
register_plugin(
	$thisfile,
	'Author vCard',
	'1.1',
	'Chris Cagle',
	'http://www.cagintranet.com/',
	'Allows the author of a site to dynamically create a downloadble vCard',
	'settings',
	'vcard_showform'
);


# hooks
add_action('settings-sidebar','createSideMenu',array($thisfile,'vCard Contact Form'));


function vcard_showform() {
	global $vcard_file;
	global $SITEURL;
	
	if (isset($_POST['submit'])) {
		$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
		$note = $xml->addChild('first_name');
		$note->addCData(@$_POST['first_name']);
		
		$note = $xml->addChild('last_name');
		$note->addCData(@$_POST['last_name']);
		
		$note = $xml->addChild('company');
		$note->addCData(@$_POST['company']);
		
		$note = $xml->addChild('title');
		$note->addCData(@$_POST['title']);
		
		$note = $xml->addChild('work_address');
		$note->addCData(@$_POST['work_address']);
		
		$note = $xml->addChild('work_city');
		$note->addCData(@$_POST['work_city']);
		
		$note = $xml->addChild('work_state');
		$note->addCData(@$_POST['work_state']);
		
		$note = $xml->addChild('work_postal_code');
		$note->addCData(@$_POST['work_postal_code']);
		
		$note = $xml->addChild('email');
		$note->addCData(@$_POST['email']);
		
		$note = $xml->addChild('office_tel');
		$note->addCData(@$_POST['office_tel']);
		
		$note = $xml->addChild('cell_tel');
		$note->addCData(@$_POST['cell_tel']);
		
		$note = $xml->addChild('fax_tel');
		$note->addCData(@$_POST['fax_tel']);
		
		$xml->asXML($vcard_file);
	}
	
	if (file_exists($vcard_file)) {
		$v = getXML($vcard_file);
		$vcard_fname = $v->first_name;
		$vcard_lname = $v->last_name;
		$vcard_company = $v->company;
		$vcard_title = $v->title;
		$vcard_street = $v->work_address;
		$vcard_city = $v->work_city;
		$vcard_state = $v->work_state;
		$vcard_zip = $v->work_postal_code;
		$vcard_email = $v->email;
		$vcard_officetel = $v->office_tel;
		$vcard_celltel = $v->cell_tel;
		$vcard_faxtel = $v->fax_tel;
	}
	
	?>
	<label>vCard Contact Form</label>
	<div class="edit-nav" >
		<a href="<?php echo $SITEURL .'plugins/author-vcard/vcard.php'; ?>">View vCard</a>
		<div class="clear"></div>
	</div>
	
	
	<form method="post" action="<?php	echo $_SERVER ['REQUEST_URI']?>">
	<table class="vcard cleantable">
	<tr>
	  <td style="width:25%" ><b>First Name</b></td>
	  <td><input type="text" name="first_name" class="text" style="width:250px;" value="<?php echo @$vcard_fname; ?>" /></td>
	</tr>
	<tr>
	  <td><b>Last Name</b></td>
	  <td><input type="text" name="last_name" class="text" style="width:250px;"  value="<?php echo @$vcard_lname; ?>" /></td>
	</tr>
	<tr>
	  <td><b>Company</b></td>
	  <td><input type="text" name="company" class="text" style="width:250px;"  value="<?php echo @$vcard_company; ?>" /></td>
	</tr>
	<tr>
	  <td><b>Title</b></td>
	  <td><input type="text" name="title" class="text" style="width:250px;"  value="<?php echo @$vcard_title; ?>" /></td>
	</tr>
	
	<tr>
	  <td><b>Work Address</b></td>
	  <td><input type="text" name="work_address" class="text" style="width:250px;"  value="<?php echo @$vcard_street; ?>" /><br />
	  	<span>Street Name</span></td>
	</tr>
	<tr>
	  <td></td>
	  <td>
	    <table class="cleantable" style="width:260px;padding:0;margin:0;" ><tr>
	    	<td style="padding-left:0px;" ><input type="text" name="work_city" class="text" style="width:130px;" value="<?php echo @$vcard_city; ?>" /><br /><span>City</span></td>
	    	<td><input type="text" name="work_state" class="text" style="width:20px;" value="<?php echo @$vcard_state; ?>" /><br /><span>State</span></td>
	    	<td><input type="text" name="work_postal_code" class="text" style="width:55px;" value="<?php echo @$vcard_zip; ?>" /><br /><span>Postal Code</span></td>
	  	</tr></table>
	  </td>
	</tr>
	<tr>
	  <td><b>Email Address</b></td>
	  <td><input type="text" name="email" class="text" style="width:250px;"  value="<?php echo @$vcard_email; ?>" /></td>
	</tr>
	<tr>
	  <td><b>Office Phone</b></td>
	  <td><input type="text" name="office_tel" class="text" style="width:150px;"  value="<?php echo @$vcard_officetel; ?>" /></td>
	
	</tr>
	<tr>
	  <td><b>Mobile Phone</b></td>
	  <td><input type="text" class="text" name="cell_tel" class="text" style="width:150px;" value="<?php echo @$vcard_celltel; ?>" /></td>
	</tr>
	<tr>
	  <td><b>Fax Number</b></td>
	  <td><input type="text" class="text" name="fax_tel" class="text" style="width:150px;" value="<?php echo @$vcard_faxtel; ?>" /></td>
	</tr>
	<tr>
	  <td>&nbsp;</td>
	  <td><input type="submit" name="submit" class="submit" value="Save Contact Data" /></td>
	</tr>
	</table>
	</form>
	
	<p><b><img src="<?php echo $SITEURL; ?>plugins/author-vcard/vcard.png" alt="vCard" />&nbsp;Code to link your vCard:</b><br />
	<code style="display:block;border:1px solid #ccc;background:#f9f9f9;padding:10px;font-size:11px;color:#666;" >&lt;a href="<?php echo $SITEURL; ?>plugins/author-vcard/vcard.php">Download vCard&lt;/a></code>
	</p>
	<?php
	
	
}
