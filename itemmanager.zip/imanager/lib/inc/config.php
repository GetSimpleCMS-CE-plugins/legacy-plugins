<?php

$this->checkInstalled = true;

$this->injectActions = false;

$this->useAllocater = true;

$this->hiddeAdmin = false;

$this->adminDisabledMsg = 'ItemManager\'s admin interface is currently disabled';
