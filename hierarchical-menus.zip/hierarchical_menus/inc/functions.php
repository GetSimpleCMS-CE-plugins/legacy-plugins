<?php
/**
 * General functions used by Hierarchical Menus plugin.
 *
 * (c)2012 mrdragonraaar.com
 */
if (!defined('IN_GS')) { die('you cannot load this page directly.'); }

/**
 * Template function to display hierarchical list of menus.
 * @param $currentpage current page slug
 * @param $display true to echo
 */
function get_hierarchical_navigation($currentpage, $display = true)
{
	if ($display)
		echo exec_filter('menuitems', menu_html(top_menu_data(), 
		   $currentpage));
	else
		return exec_filter('menuitems', menu_html(top_menu_data(), 
		   $currentpage));
}

/**
 * Template function to display list of top level menus.
 * @param $currentpage current page slug
 * @param $display true to echo
 */
function get_top_navigation($currentpage, $display = true)
{
	if ($display)
		echo exec_filter('menuitems', menu_html(top_menu_data(), 
		   $currentpage, false));
	else
		return exec_filter('menuitems', menu_html(top_menu_data(), 
		   $currentpage, false));
}

/**
 * Get array of top level menus.
 * @return array of top level menus
 */
function top_menu_data()
{
	return child_menu_data('');
}

/**
 * Template function to display list of child menus.
 * @param $currentpage current page slug
 * @param $display true to echo
 */
function get_child_navigation($currentpage, $display = true)
{
	if ($display)
		echo exec_filter('menuitems', menu_html(
		   child_menu_data($currentpage), $currentpage, false));
	else
		return exec_filter('menuitems', menu_html(
		   child_menu_data($currentpage), $currentpage, false));
}

/**
 * Get array of child menus.
 * @param $parentslug parent page slug
 * @return array of child menus
 */
function child_menu_data($parentslug)
{
	$menu_data = menu_data();
	$child_menu_data = array();

	foreach ($menu_data as $menu)
	{
		if ($menu['parent_slug'] == $parentslug)
		{
			$child_menu_data[] = $menu;
		}
	}

	return $child_menu_data;
}

/**
 * Get menu html.
 * @param $menus menu data
 * @param $currentpage current page slug
 * @param $includechildren true if to include child menus
 * @return menu html
 */
function menu_html($menus, $currentpage, $includechildren = true)
{
	$menu_html = '<ul>';

	foreach ($menus as $menu)
	{
		if ($menu['menu_status'] == 'Y')
		{
			$classes = ($menu['parent_slug'] ? 
			   $menu['parent_slug'] . ' ' : '') . 
			   $menu['slug'];
			if ($currentpage == $menu['slug'])
			{
				$classes = 'current ' . $classes;
			}

			$menu_html .= '<li class="' . $classes . '"><a href="' . $menu['url'] . '" title="' . encode_quotes(cl($menu['title'])) . '">' . strip_decode($menu['menu_text'] ? $menu['menu_text'] : $menu['title']) . '</a>';

			if ($includechildren)
			{
				$children = child_menu_data($menu['slug']);
				if (!empty($children))
				{
					$menu_html .= menu_html($children, $currentpage);
				}
			}

			$menu_html .= '</li>';
		}
	}

	$menu_html .= '</ul>';

	return $menu_html;
}

/**
 * Template function to display breadcrumb menu.
 * @param $currentpage current page slug
 * @param $seperator seperator between links (default: bullet)
 * @param $includehome true to include home link
 * @param $display true to echo
 */
function get_breadcrumb_navigation($currentpage, $seperator = '&#149;', $includehome = true, $display = true)
{
	$menu_data = menu_data();
	$seperator = '&nbsp;&nbsp;' . $seperator . '&nbsp;&nbsp;';
	$menu_html = '';
	$parentpage = $currentpage;

	while ($parentpage)
	{
		foreach ($menu_data as $menu)
		{
			if ($menu['slug'] == $parentpage)
			{
				if ($parentpage == $currentpage)
					$menu_html = strip_decode($menu['title']);
				else
					$menu_html = '<a class="' . $menu['slug'] . '" href="' . $menu['url'] . '" title="' . encode_quotes(cl($menu['title'])) . '">' . strip_decode($menu['title']) . '</a>' . $seperator . $menu_html;
				$parentpage = $menu['parent_slug'];
				break;
			}
		}
	}

	if ($includehome)
	{
		$menu_html = '<a class="home" href="' . get_site_url(false) . '" title="' . i18n_r('hierarchical_menus/HMENU_HOME') . '">' . i18n_r('hierarchical_menus/HMENU_HOME') . '</a>' . $seperator . $menu_html;
	}

	if ($display)
		echo $menu_html;
	else
		return $menu_html;
}

?>
