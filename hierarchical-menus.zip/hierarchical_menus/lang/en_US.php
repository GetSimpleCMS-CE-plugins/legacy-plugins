<?php
/**
 * English Language File for Hierarchical Menus Plugin
 *
 * (c)2012 mrdragonraaar.com
 */

$i18n = array(
	"HMENU_TITLE"=> "Hierarchical Menus",
	"HMENU_DESC" => "Display menu as hierarchical list",
	"HMENU_HOME" => "Home",
);
?>
