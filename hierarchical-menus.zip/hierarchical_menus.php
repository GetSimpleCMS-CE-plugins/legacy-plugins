<?php
/*
Plugin Name: Hierarchical Menus
Description: Display menus in a hierarchical list
Version: 1.1
Author: Adrian D. Elgar
Author URI: http://mrdragonraaar.com
*/

// plugin id
define('HMENU_PLUGIN_ID', basename(__FILE__, '.php'));
// plugin path
define('HMENU_PLUGIN_PATH', GSPLUGINPATH . HMENU_PLUGIN_ID . '/');
// plugin includes path
define('HMENU_INC_PATH', HMENU_PLUGIN_PATH . 'inc/');

// add in this plugin's language file
i18n_merge(HMENU_PLUGIN_ID) || i18n_merge(HMENU_PLUGIN_ID, 'en_US');

// register plugin
register_plugin(
	HMENU_PLUGIN_ID,
	i18n_r(HMENU_PLUGIN_ID . '/HMENU_TITLE'),
	'1.1',
	'Adrian D. Elgar',
	'http://mrdragonraaar.com',
	i18n_r(HMENU_PLUGIN_ID . '/HMENU_DESC'),
	'template',
	'get_hierarchical_navigation'
);

// includes
require_once(HMENU_INC_PATH . 'functions.php');

?>
