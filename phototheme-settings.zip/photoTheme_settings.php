<?php

 
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
 
# register plugin
register_plugin(
	$thisfile, //Plugin id
	'PhotoTheme - settings ', 	//Plugin name
	'1.0', 		//Plugin version
	'Mateusz Skrzypczak',  //Plugin author
	'https://multicolor.stargard.pl', //author website
	'Photo Theme Settings', //Plugin description
	'theme', //page type - on which admin tab to display
	'photoThemeSettings'  //main function (administration)
);
 
# activate filter 
 
# add a link in the admin tab 'theme'
add_action('nav-tab','createSideMenu',array($thisfile,'PhotoTheme Settings'));
 
# functions

function photoThemeSettings() {
	
	
echo <<<END
<style>

.photoThemeForm input{
	width:100%;
}

.photoThemeForm p{
	margin:0;
	margin-top:10px;
}

</style>

<script>

filebrowser.php?type=images
</script>

END;

// Set up the data
$foto1value = $_POST['foto1'];
$foto1linkvalue = $_POST['foto1link'];
$foto1namevalue = $_POST['foto1name'];
$foto2linkvalue = $_POST['foto2link'];
$foto2namevalue = $_POST['foto2name'];

$foto3linkvalue = $_POST['foto3link'];
$foto3namevalue = $_POST['foto3name'];

$foto2value = $_POST['foto2'];
$foto3value = $_POST['foto3'];
$logovalue = $_POST['logo'];
$pagebgvalue = $_POST['pagebg'];

 $plugin_id = 'photoThemeSettings';
// Set up the folder name and its permissions
// Note the constant GSDATAOTHERPATH, which points to /path/to/getsimple/data/other/
$folder        = GSDATAOTHERPATH . '/' . $plugin_id . '/';
$foto1     = $folder . 'foto1.txt';
$foto1link     = $folder . 'foto1link.txt';
$foto1name     = $folder . 'foto1name.txt';
$foto2     = $folder . 'foto2.txt';
$foto2link     = $folder . 'foto2link.txt';
$foto2name     = $folder . 'foto2name.txt';
$foto3     = $folder . 'foto3.txt';
$foto3link     = $folder . 'foto3link.txt';
$foto3name     = $folder . 'foto3name.txt';

$logo    = $folder . 'logo.txt';
$pagebg    = $folder . 'pagebg.txt';
$chmod_mode    = 0755;
$folder_exists = file_exists($folder) || mkdir($folder, $chmod_mode);

 $foto1show = file_get_contents($foto1);
 $foto1linkshow = file_get_contents($foto1link);
 $foto1nameshow = file_get_contents($foto1name);
 $foto2show = file_get_contents($foto2);
  $foto2linkshow = file_get_contents($foto2link);
 $foto2nameshow = file_get_contents($foto2name);

 $foto3show = file_get_contents($foto3);
  $foto3linkshow = file_get_contents($foto3link);
 $foto3nameshow = file_get_contents($foto3name);

  $logoshow = file_get_contents($logo);
 $pagebgshow = file_get_contents($pagebg);

 
 
 

echo'<form action="#" class="photoThemeForm" method="POST">';
echo'<h2>Menu</h2><p>Logo  (url)</p>';
echo'<input type="text" class="logo" name="logo" value="';  echo $logoshow ;echo'" />';


echo'<br><br><h2>Homepage</h2><p>Foto 1 (url)</p>';
echo'<input type="text" class="foto1" name="foto1" value="';  echo $foto1show ;echo '" />';
echo'<br><p>Foto 1 link</p>';
echo'<input type="text" class="foto1link" name="foto1link" value="';  echo $foto1linkshow ;echo '" />';
echo'<br><p>Foto 1 name</p>';
echo'<input type="text" class="foto1link" name="foto1name" value="';  echo $foto1nameshow ;echo '" />';
echo'<p>Foto 2  (url)</p>';
echo'<input type="text" class="foto2" name="foto2" value="';  echo $foto2show ;echo'" />';
echo'<br><p>Foto 2 link</p>';
echo'<input type="text" class="foto1link" name="foto2link" value="';  echo $foto2linkshow ;echo '" />';
echo'<br><p>Foto 2 name</p>';
echo'<input type="text" class="foto1link" name="foto2name" value="';  echo $foto2nameshow ;echo '" />';
echo'<p>Foto 3  (url)</p>';
echo'<input type="text" class="foto3" name="foto3" value="';  echo $foto3show ;echo'" />';
echo'<br><p>Foto 3 link</p>';
echo'<input type="text" class="foto1link" name="foto3link" value="';  echo $foto3linkshow ;echo '" />';
echo'<br><p>Foto 3 name</p>';
echo'<input type="text" class="foto1link" name="foto3name" value="';  echo $foto3nameshow ;echo '" />';
echo'<br><br><h2>Page background</h2><p>Page background  (url)</p>';
echo'<input type="text" class="pagebg" name="pagebg" value="';  ; echo  $pagebgshow ;echo '" /><br><br>';


echo'<input type="submit" name="submit" value="submit"></form>';



// Save the file (assuming that the folder indeed exists)
if ($_POST['submit'] && $folder_exists) {
  file_put_contents($foto1, $foto1value);
  file_put_contents($foto2, $foto2value);
  file_put_contents($foto3, $foto3value);
  
    file_put_contents($foto1link, $foto1linkvalue);
    file_put_contents($foto2link, $foto2linkvalue);
    file_put_contents($foto3link, $foto3linkvalue);

      file_put_contents($foto1name, $foto1namevalue);
    file_put_contents($foto2name, $foto2namevalue);
    file_put_contents($foto3name, $foto3namevalue);

  
  file_put_contents($logo, $logovalue);
  file_put_contents($pagebg, $pagebgvalue);

  echo "<meta http-equiv='refresh' content='0'>";

   
 
 
 //file upload

//


  }



}
?>