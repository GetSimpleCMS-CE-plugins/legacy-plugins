<?php
session_start();

$sc_message = htmlentities($_POST['sc_message'], ENT_QUOTES, 'UTF-8');

if($_POST['sc_message'] != '')
{
    $scfh = fopen('../../../data/other/simple_chat/'.date('m-d-Y').'-sc.txt','a');

    fwrite($scfh,'<p><span>'.$_SESSION['sc_username'].'</span> '.$sc_message.'</p>'."\n");
    fclose($scfh);
}

$sc_file = file('../../../data/other/simple_chat/'.date('m-d-Y').'-sc.txt');

$sl = 0;

foreach($sc_file as $line)
{
    if($sl >= $_SESSION['sc_number_lines'])
    {
        echo $line;
    }
    $sl++;
}
?>