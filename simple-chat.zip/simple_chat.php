<?php
session_start();
/*
Plugin Name: Simple Chat
Description: A Simple Chat Program
Version: 1.0
Author: David Shaner
Author URI: http://shaner.us/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile,
	'Simple Chat',
	'1.0',
	'David Shaner',
	'http://www.shaner.us/',
	'A simple chat that is stored in an XML file',
	'chat',
	'sc_init'
);


//echo $_SERVER['REQUEST_URI'];

add_action('content-top','sc_init');

#Register Stylesheet
register_style('simple_chat', $SITEURL.'plugins/simple_chat/css/simple_chat.css','1.0', 'screen');
queue_style('simple_chat',GSBOTH);

#Register CKEditor
register_script('ckeditor', $SITEURL.'admin/template/js/ckeditor/ckeditor.js', '3', FALSE);
queue_script('ckeditor',GSBOTH);

register_script('ckjquery_adapter', $SITEURL.'admin/template/js/ckeditor/adapters/jquery.js', '3', FALSE);
queue_script('ckjquery_adapter',GSBOTH);

# Add tab in admin
add_action('nav-tab','createNavTab',array('chat',$thisfile,'Chat', 'sc_chat_transcripts'));
//add_action('chat-sidebar','createSideMenu',array($thisfile,'Read Chat','sc_list_chat_function'));
//add_action('chat-sidebar','createSideMenu',array($thisfile,'Send Newsletter','send'));

    
/************************************************
 * Main Function Controls All Action
************************************************/
function sc_init()
{
    /* Route to admin function */
    $sc_action_url = $_SERVER['QUERY_STRING'];
    $sc_action = explode('&',$sc_action_url);
    $sc_action = $sc_action[1];

    switch($sc_action){
    case 'sc_chat_transcripts':
        sc_show_chats();
        break;
    default :
        /* Create simple_chat folder */
        if(!is_dir(GSDATAOTHERPATH.'/simple_chat'))
        {
            mkdir(GSDATAOTHERPATH.'/simple_chat');
        }
        
        /* Create today's chat text file */
        if(!file_exists(GSDATAOTHERPATH.'/simple_chat/'.date('m-d-Y').'-sc.txt'))
        {
            $scfh = fopen(GSDATAOTHERPATH.'/simple_chat/'.date('m-d-Y').'-sc.txt','w');
            fclose($scfh);
        }
    
    
    
    
        $sc_chat_pos = stripos($_SERVER['REQUEST_URI'],'chat');
        
        if($sc_chat_pos !== false){
            sc_username();
            
            /*
            if(!isset($_SESSSION['sc_username']))
            {
                if($_COOKIE['GS_ADMIN_USERNAME'] !='')
                {
                    
                    $_SESSION['sc_username'] = $_COOKIE['GS_ADMIN_USERNAME'];
                    $_SESSION['sc_number_lines'] = 0;
                }
                
                if($_SESSION['sc_username'] != '')
                {
                    $sc_number_lines = count(file(GSDATAOTHERPATH.'/simple_chat/'.date('m-d-Y').'-sc.txt'));
                    $_SESSION['sc_number_lines'] = $sc_number_lines;
                    sc_display_chat();
                }
                else
                {
                    sc_username();   
                }
                
            }
            */
        }
    }
}

/************************************************
 * Create a session to hold the username.
 * If admin is logged in automatically set
 * session for user.
************************************************/
function sc_username(){
    
    if($_SESSION['sc_username'] != ''){
        $sc_number_lines = count(file(GSDATAOTHERPATH.'/simple_chat/'.date('m-d-Y').'-sc.txt'));
        $_SESSION['sc_number_lines'] = $sc_number_lines;
            
        sc_display_chat();
    }
    
    if(!isset($_SESSSION['sc_username']))
    {
        if($_COOKIE['GS_ADMIN_USERNAME'] !='')
        {
            
            $_SESSION['sc_username'] = $_COOKIE['GS_ADMIN_USERNAME'];
            $_SESSION['sc_number_lines'] = 0;
        }
    }
    
    
    $error = null;
    if(isset($_POST['sc_username_submit']))
    {
        
        $sc_username = htmlentities(strip_tags($_POST['sc_username']));
        $sc_username = stripslashes($sc_username);
        
        if(stripos($sc_username, 'admin') === false)
        {
            $_SESSION['sc_username'] = $sc_username;
            $sc_number_lines = count(file(GSDATAOTHERPATH.'/simple_chat/'.date('m-d-Y').'-sc.txt'));
            $_SESSION['sc_number_lines'] = $sc_number_lines;
            sc_display_chat();
        }
        else
        {
            $error = '<p>You cannot use admin as part of your username</p>';
        }
    }
    if(!isset($_SESSION['sc_username']))
    {
    echo $error;
    ?>
    <form action="" method="post">
        <p>
            <label for="Desired Username">Desired Username (20 chars): </label>
            <input type="text" name="sc_username" maxlength="20" value="<?php echo $sc_username; ?>" />
        </p>
        <p>
            <input type="submit" name="sc_username_submit" value="Request Username"/>
        </p>
    <?php
    }
}

/************************************************
 * Display the Chat
 * Javascript moved to below to correct path
 * issues with site being in a folder.
************************************************/
function sc_display_chat(){
    
    /* Get website URL */
    $sc_siteurl_xml = GSDATAOTHERPATH.'website.xml';
    $scx = getXML($sc_siteurl_xml);
    $sc_siteurl = $scx->SITEURL;
    
    $sc_trailing = substr($sc_siteurl,-1);
    
    if($sc_trailing != '/')
    {
        $sc_siteurl = $sc_siteurl.'/';
    }
  
    /* Chat Javascript */
    echo '<script type="text/javascript">'."\n";
    echo 'var sc_chat_content;'."\n";
    echo '$(document).ready(function(){'."\n";
    echo '$("#sc_destroy").click(function(){'."\n";
    echo '$.post(\''.$sc_siteurl.'plugins/simple_chat/php/logout.php\')'."\n";
    echo 'window.location.href=window.location.href;'."\n";
    echo 'return false;'."\n";
    echo '});'."\n";
    echo 'var sc_refreshId = setInterval(function(){'."\n";
    echo '$(\'#simple_chat_display\').load(\''.$sc_siteurl.'plugins/simple_chat/php/simple_chat_display.php\');'."\n";
    echo '}, 1000);'."\n";
    echo '$(\'#sc_send_message\').keypress(function(kp){'."\n";
    echo 'if(kp.which === 13)'."\n";
    echo '{'."\n";
    echo 'sc_chat_content = $(\'#sc_send_message\').val();'."\n";
    echo 'if(sc_chat_content != "")'."\n";
    echo '{'."\n";
    echo '$.post(\''.$sc_siteurl.'plugins/simple_chat/php/simple_chat_display.php\',{sc_message:sc_chat_content},function(scddata){'."\n";
    echo '$(\'#simple_chat_display\').empty();'."\n";
    echo '$(scddata).appendTo(\'#simple_chat_display\');'."\n";
    echo '});'."\n";
    echo '}'."\n";
    echo '$(\'#sc_send_message\').val(\'\');'."\n";
    echo '}'."\n";
    echo '});'."\n";
    echo '});'."\n";
    echo '</script>'."\n";
    ?>
    <!-- Display the chat -->
    <div id="sc_chat_wrap">
    <div id="simple_chat_display"></div>
    </div>
        
    <form id="send-message-area">
        <p id="sc_p">Your message: </p>
        <textarea id="sc_send_message" maxlength = '100' ></textarea>
        <p><a id="sc_destroy" href="#">Logout of Simple Chat</a></p>
    </form>
    <?php
}

/************************************************
 * Admin functions
************************************************/
function sc_show_chats()
{
    $delete_error = null;
    $delete_success = null;
    if(isset($_POST['sc_delete_chats']))
    {
        if(count($_POST['sc_delete'])>0)
        {
            foreach($_POST['sc_delete'] as $sc_deleted){
                unlink($sc_deleted);
            }
            $delete_success = 'All chats selected were deleted.';
            echo '<p style="color:#669933;"><b>'. $delete_success .'</b></p>';
        }
        else
        {
            $delete_error = 'Please select at least one chat to delete.';
            echo '<p style="color:#cc0000;"><b>'. $delete_error .'</b></p>';
        }
    }
    
    $sc_chat_path = GSDATAOTHERPATH.'/simple_chat/';
    $sc_weeds = array('.','..','.DS_Store');
    $sc_scan = scandir($sc_chat_path);
    $sc_chats = array_diff($sc_scan,$sc_weeds);
    echo '<h3>Delete Chats</h3>'."\n";
    echo '<form method="post" action="'.$_SERVER ['REQUEST_URI'].'">'."\n";
    
    foreach($sc_chats as $sc_chat)
    {
        echo '<p><input type="checkbox" name="sc_delete[]" value="'.$sc_chat_path.$sc_chat.'"/> '.$sc_chat.'</p>'."\n";
    }
    echo '<p><input type="submit" id="submit" class="submit" value="Delete Chats" name="sc_delete_chats" /></p>';
    echo '</form>'."\n";
}


?>