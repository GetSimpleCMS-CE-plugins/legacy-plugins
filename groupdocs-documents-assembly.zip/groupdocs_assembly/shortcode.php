<?php

$numMaps=0;

function addGroupDocsAssembly($atts, $content = null) {
 extract(gdas_shortcode_atts(array(
    "id" => null,
    "width" => '500',
    "height" => '600'    
  ), $atts));
  return '<div><iframe src="https://apps.groupdocs.com/assembly2/questionnaire-assembly/'.$id.'?quality=50&use_pdf=False&download=False&referer=getsimple/1.0" frameborder="0" width="'.$width.'" height="'.$height.'"></iframe></div>';
}
gdas_add_shortcode('GroupDocsAssembly','addGroupDocsAssembly', '[groupdocs id="" width="" height="" /]');
