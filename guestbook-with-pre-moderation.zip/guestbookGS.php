<?php

/*
Plugin Name: guestbookGS
Description: simple guestbook with pre-moderation of reviews
Version: 1.0
Author: Aughrim
Author URI: http://www.php.net/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
define ('GUEST_BOOK', 'guestbookGS.xml');
define ('DATA_PATH', '../plugins/guestbookGS/data/');
define ('PAGE_PATH', 'plugins/guestbookGS/data/');
define ('CAPTCHA', 'plugins/guestbookGS/captcha.php');
define ('CSS_STYLE', 'plugins/guestbookGS/css/gstbook.css');
define ('CSS_ADMIN', 'plugins/guestbookGS/css/guestbook_admin.css');

# register plugin
register_plugin(
	$thisfile, 
	'guestbookGS', 	
	'1.1', 		
	'Aughrim',
	'http://www.php.net/', 
	'guestbook with pre-moderation of reviews',
	'theme',
	'moderation'  //moderation function in admin panel
);

# register and add css-style to backend
register_style('guestbook_css', $SITEURL.CSS_ADMIN , GSVERSION,  'screen');
queue_style('guestbook_css',GSBACK);

#i18n compatible language
i18n_merge('guestbookGS', $LANG) || i18n_merge('guestbookGS','en_US'); 

# add link in admin sidebar 
add_action('theme-sidebar','createSideMenu',array($thisfile,i18n_r('guestbookGS/MODERATION_LINK')));

# begin session in front-end
add_action('index-pretemplate','sess_start');

# add css to front-end
add_action('theme-header','include_css');

# functions
function sess_start()
	{if( !isset($_SESSION))
		{
			session_start();
		} 
	}

function include_css()
	{
	global $SITEURL;
  	echo '<link rel="stylesheet" href="',$SITEURL,CSS_STYLE,'" media="screen" type="text/css"/>';
	}

function moderation()  
	{
		//i18n compatible language
		global $i18n;
		i18n_merge('guestbookGS') || i18n_merge('guestbookGS','en_US');
		if (isset($_POST['vis']))  //обработка отзыва в true (treatment reviews to true)
		{
				$dtm = (string)trim(strip_tags($_POST['dtm']));
				if(file_exists(DATA_PATH.GUEST_BOOK))
				{
					$vxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
					if ($vxml) 
					{
						foreach ($vxml->record as $record)
						{ 
							if($record->dtm == $dtm)
							{
								$record->visibility = 'true';
							}
						}
						$vxml->asXML(DATA_PATH.GUEST_BOOK);
						unset($vxml);
					}
					else 
					{
					echo i18n("guestbookGS/XML_FORMAT_FILED");
					}	
				}
				else 
				{
				echo i18n("guestbookGS/XML_READ_FILED");
				}
				unset($dtm);
		}	
		if (isset($_POST['invis']))  //обработка отзыва в false (treatment reviews to false)
		{
				$dtm = (string)trim(strip_tags($_POST['dtm']));
				if(file_exists(DATA_PATH.GUEST_BOOK))
				{
					$vxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
					if ($vxml) 
					{
						foreach ($vxml->record as $record)
						{ 
							if($record->dtm == $dtm)
							{
							$record->visibility = 'false';
							}
						}
						$vxml->asXML(DATA_PATH.GUEST_BOOK);
						unset($vxml);
					}
					else 
					{
					echo i18n("guestbookGS/XML_FORMAT_FILED");
					}	
				}
				else 
				{
				echo i18n("guestbookGS/XML_READ_FILED");
				}
				unset($dtm);
		}	
		if (isset($_POST['delete']))  //удаление отзыва (removal of a review)
		{
				$dtm = (string)trim(strip_tags($_POST['dtm']));
				if(file_exists(DATA_PATH.GUEST_BOOK))
				{
					$vxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
					if ($vxml) 
					{
						$cnt = 0;
						foreach ($vxml->record as $record)
						{ 
							if($record->dtm == $dtm)
							{
								//echo $cnt;
								break;
							}
							 $cnt++;
						}
						unset($vxml->record[(int)$cnt]);
						$vxml->asXML(DATA_PATH.GUEST_BOOK);
						unset ($cnt);
					}
					else 
					{
					echo i18n("guestbookGS/XML_FORMAT_FILED");
					}	
					unset($vxml);
				}
				else 
				{
				echo i18n("guestbookGS/XML_READ_FILED");
				}
				unset($dtm);
		}		
		if (isset($_POST['edit']))  //редактирование отзыва (edit review)
		{
				$dtm = (string)trim(strip_tags($_POST['dtm']));
				if(file_exists(DATA_PATH.GUEST_BOOK))
				{
					$vxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
					if ($vxml) 
					{
						$cnt = 0;
						foreach ($vxml->record as $record)
						{ 
							if($record->dtm == $dtm)
							{
								break;
							}
							$cnt++;
						}
						echo '<form action="" method="post">';
						echo '<p><h1 class="userdata">',i18n("guestbookGS/USER_NAME"),'</h1><input class="inpt" type="text" name="username" value="',$vxml->record[(int)$cnt]->username,'"></p>';
						echo '<p><h1 class="userdata">',i18n("guestbookGS/USER_MAIL"),'</h1><input class="inpt" type="text" name="mail" value="',$vxml->record[(int)$cnt]->mail,'"></p>';
						echo '<p><h1 class="userdata">',i18n("guestbookGS/USER_REVIEW"),'</h1><textarea class="inpt2" name="message" rows="10" cols="20">',$vxml->record[(int)$cnt]->message,'</textarea></p>';
						echo '<input name="dtm" type="hidden" value="',$vxml->record[(int)$cnt]->dtm,'">';
						echo '<p><input class="posit" type="submit" name="save" value="',i18n("guestbookGS/SAVE_REVIEW"),'"></p>';
						echo '<p><input class="posit" type="submit" name="return" value="',i18n("guestbookGS/RETURN_REVIEW"),'"></p></form>';
						echo '<hr class="clrb">';
						exit();
					}
					else 
					{
					echo i18n("guestbookGS/XML_FORMAT_FILED");
					}	
				}
				else 
				{
				echo i18n("guestbookGS/XML_READ_FILED");
				}
				unset($dtm);
		}	
		if (isset($_POST['save']))  //сохранение отмодерированного отзыва (the preservation of moderated review)
		{
			$dtm = (string)trim(strip_tags($_POST['dtm']));
			$username = (string)trim(strip_tags($_POST['username']));
			$mail = (string)trim(strip_tags($_POST['mail']));
			$message = (string)trim(strip_tags($_POST['message']));
			if(file_exists(DATA_PATH.GUEST_BOOK))
				{	
					$vxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
					if ($vxml) 
					{
						foreach ($vxml->record as $record)
						{ 
							if($record->dtm == $dtm)
							{
								$record->username = $username;
								$record->mail = $mail;
								$record->message = $message;
							}
						}	
					$vxml->asXML(DATA_PATH.GUEST_BOOK);
					unset($vxml);
					unset ($cnt);
					}	
				}
		}
		if(file_exists(DATA_PATH.GUEST_BOOK))  //вывод немодерированных отзывов (the output of the feedback without moderation)
		{
			$nxml = simplexml_load_file(DATA_PATH.GUEST_BOOK);
			if ($nxml) 
			{
				$cnt = (int)0;
				foreach ($nxml->record as $record)
				{ 
					$cnt++;
					echo '<h1 class="message">',$cnt,') ',$record->message,'</h1>';
					echo '<h1 class="userdata">',i18n("guestbookGS/USER_NAME"),': ',$record->username,'</h1>';
					echo '<h1 class="userdata">',i18n("guestbookGS/USER_MAIL"),': ',$record->mail,'</h1>';
					echo '<h1 class="userdata">',i18n("guestbookGS/USER_DATE"),': ',date('d-m-Y H:i:s', (int)$record->dtm),'</h1>';
					echo "<br>";
					if(strtoupper($record->visibility) == "TRUE")
						{
							echo '<h1 class="vis">',i18n("guestbookGS/REV_VISIBLE"),'</h1>';
							echo '<br>';
							echo '<form action="" method="post">';
							echo '<input name="dtm" type="hidden" value="',$record->dtm,'">';
							echo '<input class="posit" type="submit" name="invis" value="',i18n("guestbookGS/MADE_INVISIBLE"),'"></form>';
						}
						else
						{
							echo '<h1 class="invis">',i18n("guestbookGS/REV_INVISIBLE"),'</h1>';
							echo '<br>';
							echo '<form action="" method="post">';
							echo '<input name="dtm" type="hidden" value="',$record->dtm,'">';
							echo '<input class="posit" type="submit" name="vis" value="',i18n("guestbookGS/MADE_VISIBLE"),'"></form>';
						}
					echo '<form action="" method="post">';
					echo '<input name="dtm" type="hidden" value="',$record->dtm,'">';
					echo '<input class="posit" type="submit" name="delete" value="',i18n("guestbookGS/REMOVE_COMMENT"),'"></form>';
					echo '<form action="" method="post">';
					echo '<input name="dtm" type="hidden" value="',$record->dtm,'">';
					echo '<input class="posit" type="submit" name="edit" value="',i18n("guestbookGS/EDIT_COMMENT"),'"></form>';
					echo '<p><hr class="clrb"></p>';
				}
				unset($cnt);	 
			}
			else 
			{
			echo i18n("guestbookGS/XML_FORMAT_FILED");
			}
			unset($nxml);
		}
		else 
		{
		echo i18n("guestbookGS/XML_READ_FILED");
		} 
 	}

function get_gstbook($slug) 
	{
		global $i18n;
		i18n_merge('guestbookGS') || i18n_merge('guestbookGS','en_US');  
		if((string)return_page_slug() == $slug )
		{
			if(file_exists(PAGE_PATH.GUEST_BOOK)) //Блок вывода модерированных отзывов (conclusion reviews of past moderation)
			{
				$xml = simplexml_load_file(PAGE_PATH.GUEST_BOOK);
				if ($xml) 
				{
					foreach ($xml->record as $record)
					{ 
						if( strtoupper($record->visibility) == "TRUE")
						{
						echo "<div class='cont'>";
						echo "<p id='msg'>$record->message</p>";
						echo "<p id='usr'>$record->username</p>";
						echo "<p id='dtm'>",date('d-m-Y H:i', (int)$record->dtm),"</p>";
						echo "</div>";
						}	
					}
				}
				else 
				{
				echo i18n("guestbookGS/XML_FORMAT_FILED");
				}
				unset($xml);
			}
			else 
			{
			echo i18n("guestbookGS/XML_READ_FILED");
			} 
			echo '<form action="',get_page_url(),'#ref" method="post" class="cont">';
			echo '<h4 class="cntr"><label>', i18n("guestbookGS/PLS_REVIEW"),'</label></h4>';
			echo '<p><input class="test0" required name="username" type="text" placeholder="  ',i18n("guestbookGS/YOUR_NAME"), '" maxlength = "30" title=" ',i18n("guestbookGS/ENTER_NAME"),'">';
			echo '<input class="test3" name="mail" type="text" pattern="|^[-0-9A-Za-z_\.]+@[-0-9A-Za-z^\.]+\.[a-z]{2,6}$|i" title="',i18n("guestbookGS/ENTER_EMAIL"),'" placeholder="  ',  i18n("guestbookGS/YOUR_EMAIL"),'" maxlength = "30"><br/></p>';
			echo '<textarea class="test2" name="message" required  placeholder=" ', i18n("guestbookGS/YOUR_MSG"),'" maxlength = "300" title="',i18n("guestbookGS/ENTER_MSG"),'"></textarea><br/><div id="cap">';
			echo '<img src="',get_site_url(),CAPTCHA,'"></div>';
			echo '<div id="code"><p id="code2">',i18n("guestbookGS/ENTER_CAPTCHA"), '</p>';
			echo '<input class="test" type="text" name="code" value="" maxlength = "4" required title="',i18n("guestbookGS/ENTER_CAPTCHA"),'">';
			echo '<input type="submit" value="',i18n("guestbookGS/SUBMIT_CAPTCHA"),'"></div><div id="ref" class="blank2"></div>';

			#session_start(); 
	 		if( !isset($_SESSION))
			{
			session_start();
			} 
			if (isset($_POST['code']))  //если отправлена форма
			{
				if ($_POST['code'] == $_SESSION['captcha'])
				{
					echo '<p class="rmsg">',i18n("guestbookGS/SEND"),'<p>';
					if($_SERVER['REQUEST_METHOD']=='POST')
					{		
						$username = (string)trim(strip_tags($_POST['username']));
						$mail = (string)trim(strip_tags($_POST['mail']));
						$message = (string)trim(strip_tags($_POST['message']));
							if(!file_exists(PAGE_PATH.GUEST_BOOK))  //Создание начальной формы XML (Create primary XML form)
							{
								$dom = new DOMDocument("1.0", "UTF-8");
								$title = $dom -> createElement('title');
								$dom -> appendChild($title);
								$dom -> save(PAGE_PATH.GUEST_BOOK);
							} 
						$sxml = simplexml_load_file(PAGE_PATH.GUEST_BOOK); // Заполнение XML (Populating XML data)
						$record = $sxml->addChild('record');
						$record->addChild('username', $username);
						$record->addChild('mail', $mail);
						$record->addChild('message', $message);
						$record->addChild('dtm', time());
						$record->addChild('visibility', "false");
						$sxml->asXML(PAGE_PATH.GUEST_BOOK);
					}
				}
				else
				{
				echo '<p class="rmsg">',i18n("guestbookGS/CAPTCHA_ERROR"),'<p>';
				}
			}
			echo '</form>';
		}
	}
?>