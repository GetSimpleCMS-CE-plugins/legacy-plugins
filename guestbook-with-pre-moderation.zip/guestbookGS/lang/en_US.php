<?php
//set internationalization


	$i18n = array (
		'SEND' => 'Your message has been sent!',
		'XML_FORMAT_FILED' => 'There are no reviews or Wrong XML-file format',
		'XML_READ_FILED' => 'Guest book file is corrupted',
		'CAPTCHA_ERROR' => 'Incorrect captcha!',
		'MODERATION_LINK' => 'Moderation of reviews',
		'SAVE_REVIEW' => 'Save comment',
		'REV_VISIBLE' => 'The review is visible on the website',
		'REV_INVISIBLE' => 'The review is only visible to the moderator',
		'MADE_VISIBLE' => 'Show Online',
		'MADE_INVISIBLE' => 'Hidden from view',
		'REMOVE_COMMENT' => 'Delete comment',
		'EDIT_COMMENT' => 'Edit a comment',
		'PLS_REVIEW' => 'Please leave your review',
		'YOUR_NAME' => 'Your name',
		'ENTER_NAME' => 'Enter your name',
		'YOUR_EMAIL' => 'E-mail ( optionally)',
		'ENTER_EMAIL' => 'Please enter a valid email or clear the field',
		'YOUR_MSG' => 'Enter a message of up to 300 characters',
		'ENTER_MSG' => 'Enter your message',
		'ENTER_CAPTCHA' => 'Enter the captcha',
		'SUBMIT_CAPTCHA' => 'Submit',
		'USER_NAME' => 'Author',
		'USER_MAIL' => 'Email',
		'USER_DATE' => 'Date',
		'USER_REVIEW' => 'Message',
		'RETURN_REVIEW' => 'Cancel'
		
	);
?>