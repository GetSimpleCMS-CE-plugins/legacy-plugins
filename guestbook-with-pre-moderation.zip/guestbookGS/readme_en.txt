------------------------------------------------------------------------
Guestbook with pre-moderation for GetSimple Version 1.1 README June 2016
------------------------------------------------------------------------

  
Installation:
-------------------------
  -  Upload the contents of the zip file to your /plugins folder.
  -  Activate the plugin in Admin > Plugins.
	
	
Usage:
-------------------------
The guestbook can be called in a template with php:
		
<?php get_gstbook($slug) ?>

where $slug is short name of page (page_slug)
			
[example] 
if the address of the page to insert a guestbook looks like this
(for such links it is necessary to use Fancy URLs!)

http://get-simple/example/guestbook 


then the function will be called as

<?php get_gstbook('guestbook') ?>
	

In the theme tab of the admin panel available moderation via the link 'Moderation of reviews'.
Reviews you can hide or display on the website, delete and edit.
All new reviews are marked as hidden and will not appear until moderated.	


Styling:
-------------------------

The CSS file for styling the Guestbook is /plugins/guestbook/guestbook.css
The CSS file for styling the panel moderation is /plugins/guestbook/guestbook_admin.css

Languages:
-------------------------

The folder /lang contains 2 language files: en_US, ru_RU 
