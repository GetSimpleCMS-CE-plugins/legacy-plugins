jQuery(document).ready(function() {
    jQuery('a#fb').fancybox({
        'hideOnContentClick': true
    });
     
    jQuery('a[rel]').fancybox();
     
}); 