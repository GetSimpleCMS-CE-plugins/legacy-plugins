<?php error_reporting(E_ALL);


/*
Plugin Name: ah-contact
Description_DE: Kontakt Formular
Description_EN: Contact Form
Version: 0.1
Author: Andre Herrmann
Author URI: https://aheffekt.net
*/


# variables
$ahpluginname =		'ah-contact';
$ahpluginversion =	'0.1';
$ahpluginauthor =	'Andre Herrmann';
$ahpluginhome =		'https://aheffekt.net/';
$ahpluginupdate =	$ahpluginhome.'ah_getsimple_plugins/'.$ahpluginname.'/';
$ahfunctionfrontend =	'ahcontact';
$ahfunctionbackend =	'ahcontact_show';


# create dirs
$ahroot =	$_SERVER["DOCUMENT_ROOT"].'/';
$ahdatadir =		$ahroot.'/data/'.$ahpluginname.'/';
	if(!is_dir($ahdatadir))
		{mkdir($ahdatadir);}
$aharchivedir =		$ahdatadir.'archive/';
	if(!is_dir($aharchivedir))
		{mkdir($aharchivedir);}
$ahplugindir =	$ahroot.'plugins/'.$ahpluginname.'/';
$ahlangdir =	$ahplugindir.'lang/';


#language
include($ahlangdir.$LANG.'.php');

 
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
 
 
# register plugin
register_plugin(
	$thisfile,					//Plugin id
	$ahlang['contact_form'],			//Plugin name
	$ahpluginversion,				//Plugin version
	$ahpluginauthor,				//Plugin author
	$ahpluginhome,					//author website
	$ahlang['plugin_description'],			//Plugin description
	$thisfile,					//page type - on which admin tab to display
	$ahfunctionbackend				//main function (administration)
	);


# Count Files for Info on Tab
$ahnewmsg = 0;
foreach (scandir($ahdatadir) as $ahfile)
	{
	if ($ahfile === ".." or $ahfile === "." or $ahfile === "archive") continue;
	$ahnewmsg++;
	}
if($ahnewmsg > 0) {$ahnewmsg = ' <font color="yellow">('.$ahnewmsg.')</font>';} else {$ahnewmsg = '';}

// Frontend
add_action('content-bottom',ahcontact); 


// Admin-Navigation Tab
add_action('nav-tab','createNavTab',array(ahcontact, $thisfile, $ahlang['contact_form'].$ahnewmsg));


# Function Frontend
function ahcontact()
{
	global $ahlangdir,$LANG,$ahdatadir;
	include($ahlangdir.$LANG.'.php');
	$ahrequest = str_replace('/', '', $_SERVER['REQUEST_URI']);
	if($ahrequest == 'kontakt' or $ahrequest == 'contact')
		{?>
		<style>
			.ah-contact-frontend input {
				display:		block;
				width:			100%;
				margin-bottom:		20px;}
			.ah-contact-frontend textarea {
				display:		block;
				width:			100%;
				height:			100px;
				margin-bottom:		20px;
				resize:			none;}
			#ah-checkbox {
				display:		inline;
				width:			inherit;
				margin-bottom:		4px;}
			.ah-contact-frontend p {
				margin-bottom:		10px;
				hyphens:		auto;
				text-align:		justify;}
		</style>
		<?php
		
		# show form
		if(!isset($_POST['email']))
		{
		echo '<div class="ah-contact-frontend">';
		echo '<form action="'.$_SERVER['REQUEST_URI'].'" method="POST">';
		
		echo $ahlang['email'].':';
		echo '<input type="text" name="email" ';
		echo 'title="'.$ahlang['fill_out'].'" ';
		echo 'oninvalid="this.setCustomValidity(\''.$ahlang['fill_out'].'\')" ';
		echo 'onchange="this.setCustomValidity(\'\')" autofocus required>';
		
		echo $ahlang['title'].':';
		echo '<input type="text" name="title" ';
		echo 'title="'.$ahlang['fill_out'].'" ';
		echo 'oninvalid="this.setCustomValidity(\''.$ahlang['fill_out'].'\')" ';
		echo 'onchange="this.setCustomValidity(\'\')" required>';

		echo $ahlang['message'].':';
		echo '<textarea name="text" ';
		echo 'title="'.$ahlang['fill_out'].'" ';
		echo 'oninvalid="this.setCustomValidity(\''.$ahlang['fill_out'].'\')" ';
		echo 'onchange="this.setCustomValidity(\'\')" required></textarea>';

		echo '<p>';
		echo '<input type="checkbox" name="conditions" id="ah-checkbox" ';
		echo 'title="'.$ahlang['conditions_check'].'" ';
		echo 'oninvalid="this.setCustomValidity(\''.$ahlang['conditions_check'].'\')" ';
		echo 'onchange="this.setCustomValidity(\'\')" required> ';
		echo $ahlang['i'].' '.$ahlang['accept'].' '.$ahlang['the_conditions'].':';
		echo '</p>';
		echo '<p>'.$ahlang['conditions_text'].'</p>';

		echo '<input type="submit" style="width:inherit;" ';
		echo 'value="'.$ahlang['send_message'].'" ';
		echo 'title="'.$ahlang['conditions_check'].'" ';
		echo 'oninvalid="this.setCustomValidity(\'custom text on invalid\')" ';
		echo 'onchange="this.setCustomValidity(\'\')" required>';

		echo '</form>';
		echo '</div>';
		}
		
		# show sent
		if(isset($_POST['email']))
		{
		$file = $ahdatadir.time().'|'.str_replace(' ','_',$_POST['title']).'.txt';
		$text = str_replace(["\r\n", "\r", "\n"], ' ', $_POST['text']);
		$text = str_replace('  ', ' ', $text);
		touch($file);
		file_put_contents($file, $_POST['email']."\r\n", FILE_APPEND);
		file_put_contents($file, $text, FILE_APPEND);
		echo $ahlang['message_sent'];
		}
		
		}
}


# Function Backend
function ahcontact_show()
{
	global $ahdatadir, $aharchivedir, $ahlang;
	
	?> <style>
		#ah-btn-page {
			float:		right;}
		.ah-contact hr {
			 border:	1px solid lightgray;}
		#ah-contact-info {
			font-style:	italic;
			color:		dimgray;}
		.ah-contact h4 {
			font-weight:	bold;
			margin-top:	-20px;}
		#ah-msg {
			margin-bottom:	10px;}
		#ah-warn {
			color:		red;}
		#ah-howto {
			margin-top:	40px;
			font-style:	italic;}
	</style> <?php
	
	echo '<div class="ah-contact">';
	
	# action delete question from archive

	if(isset($_GET['ahaction']) and $_GET['ahaction'] == 'deletenow')
		{
		unlink($aharchivedir.'/'.$_GET['ahfile'].'.txt');
		}
	
	# action send Question to Archive
	if(isset($_GET['ahaction']) and $_GET['ahaction'] == 'toarchive')
		{
		rename($ahdatadir.'/'.$_GET['ahfile'].'.txt', 
		$aharchivedir.'/'.$_GET['ahfile'].'.txt');
		}
	
	# action send Question to new Messages
	if(isset($_GET['ahaction']) and $_GET['ahaction'] == 'tomessages')
		{
		if(file_exists($aharchivedir.'/'.$_GET['ahfile'].'.txt'))
			{
			rename($aharchivedir.'/'.$_GET['ahfile'].'.txt', 
			$ahdatadir.'/'.$_GET['ahfile'].'.txt');
			}
		}

	# Btn go to Archive
	if(!isset($_GET['ahadminpage']))
		{
		echo '<a href="load.php?id=ah-contact&ahadminpage=show_archive">';
		echo '<button id="ah-btn-page">'.$ahlang['archive'].'</button></a>';
		}

	# Btn go to new Questions
	if(isset($_GET['ahadminpage']))
		{
		echo '<a href="load.php?id=ah-contact">';
		echo '<button id="ah-btn-page">'.$ahlang['new_questions'].'</button></a>';
		}

	# Heading
	echo '<h3>Kontaktformular';
	if(isset($_GET['ahadminpage']) and $_GET['ahadminpage'] == 'show_archive')
		{echo ' - '.$ahlang['archive'];}
	if(isset($_GET['ahadminpage']) and $_GET['ahadminpage'] == 'delete_question')
		{echo ' - '.$ahlang['really_delete'];}
	echo '</h3>';
	echo '<hr>';

	### new Questions List ###
	if(!isset($_GET['ahadminpage']))
		{
		$i = 0;
		foreach (scandir($ahdatadir) as $ahfile)
			{
			if ($ahfile === ".." or $ahfile === "." or $ahfile == "archive") continue;
			$date =		explode('|', $ahfile)[0];
			$date =		date("d.m.Y - H:i", $date).' Uhr';
			$heading =	explode('|', $ahfile)[1];
			$heading =	str_replace('.txt', '', $heading);
			$heading =	str_replace('_', ' ', $heading);
			$mail =		trim(file($ahdatadir.$ahfile)[0]);
			$message =	trim(file($ahdatadir.$ahfile)[1]);
			
			echo '<p id="ah-contact-info">'.$date.' - '.$mail.'</p>';
			echo '<h4>'.$heading.'</h4>';
			echo '<p id="ah-msg">'.$message.'</p>';
			
			echo '<a href="mailto:'.$mail;
			echo '?subject='.$ahlang['question'].'&#058;%20';
			echo str_replace(' ', '%20', $heading).'"><button>';
			echo $ahlang['answer'] .'</button></a> ';
			
			echo '<a href="load.php?id=ah-contact&ahaction=toarchive';
			echo '&ahfile='.str_replace('.txt', '', $ahfile);
			echo '"><button>';
			echo $ahlang['send_to_archive'].'</button></a>';
			
			echo '<hr>';
			$i++;
			}
		if($i < 1) {echo $ahlang['no_new_questions'];}
		echo '<p id="ah-howto">'.$ahlang['how_to_text'].'</p>';
		}

	### Archive List ###
	if(isset($_GET['ahadminpage']) and $_GET['ahadminpage'] == 'show_archive')
		{
		$i = 0;
		foreach (scandir($aharchivedir) as $ahfile)
			{
			if ($ahfile === ".." or $ahfile === "." ) continue;
			$date =		explode('|', $ahfile)[0];
			$date =		date("d.m.Y - H:i", $date).' Uhr';
			$heading =	explode('|', $ahfile)[1];
			$heading =	str_replace('.txt', '', $heading);
			$heading =	str_replace('_', ' ', $heading);
			$mail =		trim(file($aharchivedir.$ahfile)[0]);
			$message =	trim(file($aharchivedir.$ahfile)[1]);
		
			echo '<p id="ah-contact-info">'.$date.' - '.$mail.'</p>';
			echo '<h4>'.$heading.'</h4>';
			echo '<p id="ah-msg">'.$message.'</p>';
		
			echo '<a href="load.php?id=ah-contact&ahadminpage=delete_question';
			echo '&ahfile='.str_replace('.txt', '', $ahfile);
			echo '"><button>';
			echo $ahlang['delete'].'</button></a> ';
		
			echo '<a href="load.php?id=ah-contact&ahadminpage=show_archive';
			echo '&ahaction=tomessages';
			echo '&ahfile='.str_replace('.txt', '', $ahfile);
			echo '"><button>';
			echo $ahlang['restore'].'</button></a>';
		
			echo '<hr>';
			$i++;
			}
		if($i < 1) {echo $ahlang['archive_empty'];}
		}

	### really delete? ###
	if(isset($_GET['ahadminpage']) and $_GET['ahadminpage'] == 'delete_question')
		{
		$date =		explode('|', $_GET['ahfile'])[0];
		$date =		date("d.m.Y - H:i", $date).' Uhr';
		$heading =	explode('|', $_GET['ahfile'])[1];
		$heading =	str_replace('.txt', '', $heading);
		$heading =	str_replace('_', ' ', $heading);
		$mail =		trim(file($aharchivedir.$_GET['ahfile'])[0]);
		$message =	trim(file($aharchivedir.$_GET['ahfile'])[1]);
		echo '<p id="ah-warn">';
		echo $ahlang['really_del_text_1'];
		echo '<b>'.$heading.'</b>';
		echo $ahlang['really_del_text_2'];
		echo $date;
		echo $ahlang['really_del_text_3'];
		echo '</p>';
		
		echo '<a href="load.php?id=ah-contact&ahadminpage=show_archive';
		echo '&ahaction=deletenow';
		echo '&ahfile='.str_replace('.txt', '', $_GET['ahfile']);
		echo '"><button>';
		echo $ahlang['yes'].' '.$ahlang['delete'].'</button></a> ';
		
		echo '<a href="load.php?id=ah-contact&ahadminpage=show_archive';
		echo '"><button>';
		echo $ahlang['no'].' '.$ahlang['cancel'].'</button></a> ';
		}
	
	echo '</div>';

}


?>
