<?php

// english language File for
// ah-contact

$ahlang = array();

$ahlang['plugin_description'] = 'A simple Contact Form.';

$ahlang['answer'] = 		'answer';
$ahlang['archive'] = 		'Archive';
$ahlang['archive_empty'] =	'Archive is empty';
$ahlang['cancel'] =		'cancel';
$ahlang['contact_form'] =	'Contact Form';
$ahlang['delete'] =		'l&ouml;schen';
$ahlang['new_questions'] =	'new Questions';
$ahlang['no'] =			'No';
$ahlang['no_new_questions'] =	'no new existing Questions';
$ahlang['really_delete'] =	'really delete?';
$ahlang['restore'] =		'restore';
$ahlang['send_to_archive'] = 	'to Archive';
$ahlang['question'] =		'Question';
$ahlang['yes'] =		'Yes';


$ahlang['really_del_text_1'] =	'Really delete the Question named "';
$ahlang['really_del_text_2'] =	'" from "';
$ahlang['really_del_text_3'] =	'" ?';


?>


<?php

// deutsche Sprachdatei für
// ah-contact

$ahlang = array();

$ahlang['plugin_description'] = 'A simple Contact Form.';

$ahlang['accept'] = 		'accept';
$ahlang['answer'] = 		'answer';
$ahlang['archive'] = 		'Archive';
$ahlang['archive_empty'] =	'Archive is empty';
$ahlang['cancel'] =		'cancel';
$ahlang['fill_out'] =		'fill in all fields';
$ahlang['the_conditions'] =	'the conditions';
$ahlang['contact_form'] =	'Contact Form';
$ahlang['delete'] =		'delete';
$ahlang['email'] =		'Mail';
$ahlang['i'] =			'I';
$ahlang['message'] =		'Message';
$ahlang['new_questions'] =	'new Questions';
$ahlang['no'] =			'No';
$ahlang['no_new_questions'] =	'no new existing Questions';
$ahlang['really_delete'] =	'really delete?';
$ahlang['restore'] =		'restore';
$ahlang['send_message'] = 	'send Message';
$ahlang['send_to_archive'] = 	'send to archive';
$ahlang['title'] = 		'Title';
$ahlang['question'] =		'Question';
$ahlang['yes'] =		'Yes';

$ahlang['really_del_text_1'] =	'Really delete the Question named "';
$ahlang['really_del_text_2'] =	'" from "';
$ahlang['really_del_text_3'] =	'" ?';

$ahlang['how_to_text'] =	'How-to: Create a Page named "Contact". Then the Contact Form will be shown there automatically. If a new Message comes in, you\'ll see it right here.';

$ahlang['conditions_text'] =	'If you use this Contact Form, your Email-Adress will only be used to answer your Question. If we finished our conversation, your Messages and personal Data will be deleted immediatly. Nothing of your personal Data will ever be given to third Persons. With your acceptance of this Conditions, you give the Permission to contact you by Mail.';

$ahlang['conditions_check'] =	'Your Message can only be sent, by accept this Conditions!';

$ahlang['message_sent'] =	'Thank you! The Message was successfully sent.';


?>
