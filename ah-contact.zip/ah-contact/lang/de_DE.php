<?php

// deutsche Sprachdatei für
// ah-contact

$ahlang = array();

$ahlang['plugin_description'] = 'Ein einfaches Kontaktformular.';

$ahlang['accept'] = 		'aktzeptiere';
$ahlang['answer'] = 		'beantworten';
$ahlang['archive'] = 		'Archiv';
$ahlang['archive_empty'] =	'das Archiv ist leer';
$ahlang['cancel'] =		'abbrechen';
$ahlang['fill_out'] =		'Bitte alle Felder ausfüllen';
$ahlang['the_conditions'] =	'die Bedingungen';
$ahlang['contact_form'] =	'Kontaktformular';
$ahlang['delete'] =		'l&ouml;schen';
$ahlang['email'] =		'E-Mail';
$ahlang['i'] =			'Ich';
$ahlang['message'] =		'Nachricht';
$ahlang['new_questions'] =	'neue Anfragen';
$ahlang['no'] =			'Nein';
$ahlang['no_new_questions'] =	'keine neue Anfragen vorhanden';
$ahlang['really_delete'] =	'wirklich löschen?';
$ahlang['restore'] =		'wiederherstellen';
$ahlang['send_message'] = 	'Nachricht absenden';
$ahlang['send_to_archive'] = 	'archivieren';
$ahlang['title'] = 		'Titel';
$ahlang['question'] =		'Anfrage';
$ahlang['yes'] =		'Ja';

$ahlang['really_del_text_1'] =	'Wirklich endgültig die Anfrage "';
$ahlang['really_del_text_2'] =	'" vom "';
$ahlang['really_del_text_3'] =	'" löschen?';

$ahlang['how_to_text'] =	'Benutzung: Erstelle eine Seite mit dem Namen "Kontakt". Dort wird das Kontaktformular automatisch angezeigt. Wenn neue Nachrichten ankommen werden diese hier angezeigt.<br><br>Im Template sollte für eine deutschsprachige Ausgabe <b><&quest;php $LANG = &OpenCurlyDoubleQuote;de_DE&CloseCurlyDoubleQuote;; &quest;></b> gesetzt werden.';

$ahlang['conditions_text'] =	'Bei der Kontaktaufnahme wird die Emailadresse einzig zur Verwendung der Kommunikation verwendet. Beim Abschluss der Kommunikation werden Deine Nachrichten und Deine persönlichen Daten umhegehend wieder gelöscht. Es werden keine erfassten Daten oder Nachrichten an Dritte weitergegeben. Hiermit wird der Kontaktaufnahme per Email zugestimmt.';

$ahlang['conditions_check'] =	'Diese Nachricht kann nur mit der Zustimmung zu den Bedingung abgesendet werden!';

$ahlang['message_sent'] =	'Vielen Dank! Die Nachricht wude erfolgreich versendet.';


?>
