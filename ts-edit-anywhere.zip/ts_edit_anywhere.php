<?php
/*
Plugin Name: TS Edit Anywhere
Description: Let you edit any part of your site. Add a class "iedit" to your DIV-Container.
Version: 1.0a
Author: Lars Flintzak
Author URI: http://www.flintzak.de/gsplugins
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, //Plugin id
	'TS Edit Anywhere', 	//Plugin name
	'1.0a', 		//Plugin version
	'Lars Flintzak',  //Plugin author
	'http://www.flintzak.de/gsplugins', //author website
	'Let you edit any part of your site.<br>Add a class "iedit" to your DIV-Container.', //Plugin description
	'pages', //Page type
	''  //main function (administration) - there is no need for it, as there is no administration backend yet
);

//Change hook name to alter the position where the link is being displayed
add_action('theme-footer', 'edit_anywhere');
add_action('footer','do_tsclearblanks');


# functions

function do_tsclearblanks()
{
	echo "<script>
	$('a[target=\"_blank\"]').removeAttr('target');
	</script>";
	echo "TS Parsdown message: target='_blank' removed.";
}


function edit_anywhere() 
{
   global $USR;
	if (isset($USR) && $USR == get_cookie('GS_ADMIN_USERNAME')) 
	{
	Echo '<script>
	var s = "iedit";                // Edit class
	$.each($("."+s), function(index, value) 
	{
	var label = "!";                        // Label or character for the Edit link
	var labelnew = "+";                        // Label or character for the Edit link
	var slug = "';get_page_slug(); 
	echo '";
	var path = "';get_site_url();echo 'admin/edit.php";
	var a=this;
	var i=0;
	var es = "";
	var cn = $(a).attr("class");
	var id = "#"+$(a).attr("id");
	var res = cn.split(" "); 
	var edit_slug = res[1];
	if(res.length==1) edit_slug=slug;
	if(res.length>1)
	{
	if(res[1].substring(0,1)=="_") edit_slug=slug+res[1];
	}
	
	 $(id).append("<a href=\'"+path+"?id="+edit_slug+"\' class=\'editbutton\'>"+label+"</a>"); 
	$(id).prepend("<a href=\'"+path+"?id="+edit_slug+"\' class=\'editbutton\'>"+label+"</a>"); 
	
	$(id).append("<a href=\'"+path+"\' class=\'editbutton newbutton\'>"+labelnew+"</a>"); 
});
</script>
<!-- ----------------------------------------->';
	}
}

?>