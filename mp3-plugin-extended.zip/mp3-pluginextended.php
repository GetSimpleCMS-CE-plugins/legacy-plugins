<?php
/*
==============  ORIGINAL AUTHOR (based on) ====================
Plugin Name: Mp3 Plugin
Description: Replace links to mp3 files with a flash player inside of page contents
Version: 1.0
Author: Michele de Angelis
Author URI: http://www.micheledeangelis.net/
==============  ORIGINAL AUTHOR ====================

============== CHANGED AUTHOR ===================
Plugin Name: Mp3 Plugin Extended
Description: Place mp3 flash player inside of page contents in specific TAGS
Version: 0.1d
Author: Dominion IT
Author URI: http://www.dominion-it.co.za/
============== CHANGED AUTHOR ===================
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Mp3 Plugin Extended', 	# Title of plugin
	'0.1d', 		# Version of plugin
	'Johannes Pretorius',	# Author of plugin
	'http://www.dominion-it.co.za/', 	# Author URL
	'Place mp3 flash player inside of page contents in specific TAGS', 	# Plugin Description
	'plugins', 	# Page type of plugin
	'show_config'  	# Function that displays content
);

# activate filter
add_filter('content','content_mp3tags_show'); 
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Mp3 Plugin Extended'));

/*
  Filter Content for adsense markers (%ad_id%)
    the add of that id will be inserted in the markers section of the conent
*/
function content_mp3tags_show($contents){
    install_player();
    $bgColor = implode("",@file(GSDATAOTHERPATH. '/mp3playerextended.cfg'));
    $tmpContent = $contents;
	preg_match_all('/\(%(.*)mp3(.*):(.*)%\)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER);
    
    $AlltoReplace = $tmpArr[count($tmpArr)-1];
    $totalToReplace = count($AlltoReplace);
    for ($x = 0;$x < $totalToReplace;$x++) {
       $targetMp3= str_replace('&nbsp;',' ',$AlltoReplace[$x]);
       $targetMp3 = trim($targetMp3);
      $adTeks = playerAdd($targetMp3,$bgColor);
      $tmpContent = preg_replace("/\(%(.*)mp3(.*):(.*)$targetMp3(.*)%\)/i",$adTeks,$tmpContent);
    }
    
  return $tmpContent;
}

function playerAdd($targetFile,$bgColor){
        global $SITEURL;
        $site = $SITEURL;
        if (file_exists(GSDATAUPLOADPATH."$targetFile")) {
          $targetFile = $site."data/uploads/$targetFile";
        }
        
        $player 	 = "<object type='application/x-shockwave-flash' data='".$site."player.swf'";
		$player	.= " width='310' height='24' id='audioplayer1'><param name='movie' value='".$site."player.swf' />";
		$player	.= "<param name='FlashVars'value='&amp;bg=0xf8f8f8&amp;leftbg=0xeeeeee&amp;lefticon=0x666666&amp;rightbg=0xcccccc&amp;";
		$player	.= "rightbghover=0x999999&amp;righticon=0x666666&amp;righticonhover=0xffffff&amp;text=0x666666&amp;slider=0x666666&amp;";
		$player	.="track=0xFFFFFF&amp;border=0x666666&amp;";
		$player	.="loader=0x9FFFB8&amp;soundFile=$targetFile' /><param name='quality' value='high' /><param name='menu' value='true' />";
		$player	.="<param name='bgcolor' value='$bgColor' /><param name='wmode' value='opaque' /></object>";
        return $player;
}

/**
 * Install player.swf into /root site
 * Check if player.swf exists in root site
 *
 */

function install_player(){

	$file = 'player.swf';

	if(!file_exists(GSROOTPATH.$file)) {
		if (copy(GSPLUGINPATH.'mp3-plugin/'.$file, GSROOTPATH.$file)) { }
	}

}

/*
  * Show the config for the player..
  *
*/
function show_config(){
    if(isset($_POST['stoor']) && $_POST['stoor'] == 'Save') {
            
            $color  = $_POST['kleur'] ;
            $filePointer = fopen(GSDATAOTHERPATH. '/mp3playerextended.cfg',"w");
            fwrite($filePointer,$color);
            fclose($filePointer);
            unset($tmpS,$filePointer);    
    }    else {
      if (is_file(GSDATAOTHERPATH. '/mp3playerextended.cfg')) {
        $color = implode("",@file(GSDATAOTHERPATH. '/mp3playerextended.cfg'));
      } else {
        $color = '#FFFFFF';
      }
      
    }
    
?>
<form action="<?php	echo $_SERVER ['REQUEST_URI']?>"  method="post" id="management">
  <p>How  to use the plugin : Just add anywhere in your page  the following tag (% mp3:filename %)
     where the filename is the name of the MP3 file you have uploaded (note it can be case sensitive). <br/>For example if I have uploaded
     My personal Song.mp3 then the tag will be <br/><b>(% mp3:My personal Song.mp3 %)</b>.<br/>
     Version 0.1d</p>
 <p>Background color : <input type='text' name='kleur' value='<?php echo $color; ?>'> (hex color)<br/>
    <input type='submit' name='stoor' value='Save'></p>
</form>

<?php
}