<?php

function addGDDotNetViewer($atts, $content = null) {
    extract(gdvd_shortcode_atts(array(
        "server" => null,
        "width" => null,
        "height" => null,
    ), $atts));

    return  "<iframe src='{$server}' width='{$width}' height='$height'></iframe>     ";



}
gdvd_shortcode('GDDotNetViewer','addGDDotNetViewer', '[gd_dotnet_viewer server="" width="" height="" /]');
