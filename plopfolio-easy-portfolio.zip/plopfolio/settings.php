<?php

# definitions
define('GSDATAPORTFOLIOPATH', GSDATAOTHERPATH . PLUGINNAME . '/');
define('GSPORTFOLIOPATH', GSPLUGINPATH . PLUGINNAME . '/');

define('SETTINGSFILENAME','settings');
define('DATAFILENAME','data');
# UI

define('ENTRYNAME',i18n_r(PLUGINNAME."/ENTRYNAME"));
define('ENTRYIMG',i18n_r(PLUGINNAME."/ENTRYIMG"));
define('ENTRYTHUMB',i18n_r(PLUGINNAME."/ENTRYTHUMB"));
define('ENTRYYEAR',i18n_r(PLUGINNAME."/ENTRYYEAR"));
define('ENTRYMONTH',i18n_r(PLUGINNAME."/ENTRYMONTH"));
define('ENTRYCLIENTNAME',i18n_r(PLUGINNAME."/ENTRYCLIENTNAME"));
define('ENTRYKEYWORDS',i18n_r(PLUGINNAME."/ENTRYKEYWORDS"));
define('ENTRYDESCRIPTION',i18n_r(PLUGINNAME."/ENTRYDESCRIPTION"));
define('ENTRYURL',i18n_r(PLUGINNAME."/ENTRYURL"));
define('ENTRYNAMES',i18n_r(PLUGINNAME."/ENTRYNAMES"));
define('ENTRYNOTIFYSAVING',i18n_r(PLUGINNAME."/ENTRYNOTIFYSAVING"));
define('ENTRYNEWLABEL',i18n_r(PLUGINNAME."/ENTRYNEWLABEL"));
define('ENTRYEDITLABEL',i18n_r(PLUGINNAME."/ENTRYEDITLABEL"));
define('PORTFOLIOSIDEBARBUTTONNAME',i18n_r(PLUGINNAME."/PORTFOLIOSIDEBARBUTTONNAME"));
define('PORTFOLIOSIDEBARSETUPBUTTONNAME',i18n_r(PLUGINNAME."/PORTFOLIOSIDEBARSETUPBUTTONNAME"));
define('SETTINGSNOTIFYSAVING',i18n_r(PLUGINNAME."/SETTINGSNOTIFYSAVING"));
define('BIGFILESFOLDERLABEL',i18n_r(PLUGINNAME."/BIGFILESFOLDERLABEL"));
define('SMALLFILESFOLDERLABEL',i18n_r(PLUGINNAME."/SMALLFILESFOLDERLABEL"));
define('ISURLUSEDLABEL',i18n_r(PLUGINNAME."/ISURLUSEDLABEL"));
define('ISKEYWORDUSEDLABEL',i18n_r(PLUGINNAME."/ISKEYWORDUSEDLABEL"));
define('ISCLIENTUSEDLABEL',i18n_r(PLUGINNAME."/ISCLIENTUSEDLABEL"));
define('USECUSTOMTHUMBNAILLABEL',i18n_r(PLUGINNAME."/USECUSTOMTHUMBNAILLABEL"));
define('ONPAGEEXEMPLELABEL',i18n_r(PLUGINNAME."/ONPAGEEXEMPLELABEL"));

class PlopfolioSettings {

	protected $_filename = '';
	protected $_datafilename = '';

	public function __construct() {
        $this->_filename = GSDATAPORTFOLIOPATH . SETTINGSFILENAME . '.xml';
        if (!file_exists($this->_filename)) {
			$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
			$xml->addChild('empty')->addCData("true");
			XMLsave($xml, $this->_filename);
        }
        $this->_datafilename = GSDATAPORTFOLIOPATH . DATAFILENAME . '.xml';
        if (!file_exists($this->_datafilename)) {
			$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
			$xml->addChild('empty')->addCData("true");
			XMLsave($xml, $this->_datafilename);
        }
    }

	/*******************************************************
	 * @function edit_settings
	 * @action edit plugin settings
	 */
	public function edit_settings() {
	  ?>
	  <h3>Usage</h3>
	  <h4 style="font-weight: bold;"><?php echo ONPAGEEXEMPLELABEL ;?></h4>
	  <p>
		<script src="https://gist.github.com/janssens/315aada3e32eee9a1e82.js"></script>
	  </p>
	  <h3><?php i18n("SETTINGS"); ?></h3>
	  <style type="text/css">
			#editform > div{ margin-bottom: 10px;}
	  </style>
	  <form class="largeform" id="editform" action="load.php?id=plopfolio&setup" method="post" accept-charset="utf-8">
	    <div>
			<b><?php echo BIGFILESFOLDERLABEL ;?>:</b><br />
			<input class="text name" name="entry-big" type="text" value="<?php echo @BIGFILESFOLDER; ?>" id="big"/>
			<div></div>
	    </div>
		<div>
			<b><?php echo USECUSTOMTHUMBNAILLABEL ;?>:</b><br />
			<input id="usecustomthumbnail" class="text name" name="entry-usecustomthumbnail" type="checkbox" value="true" <?php echo (USECUSTOMTHUMBNAIL) ? "checked=\"checked\"" : "" ; ?> />
	    </div>
	    <div id="toggle_usecustomthumbnail" <?php echo (USECUSTOMTHUMBNAIL) ? ""  : "style=\"display:none;\"" ; ?>>
			<b><?php echo SMALLFILESFOLDERLABEL ;?>:</b><br />
			<input class="text name" name="entry-small" type="text" value="<?php echo @SMALLFILESFOLDER; ?>" id="small"/>
			<div></div>
		</div>
	    <div>
	    <b><?php echo ISURLUSEDLABEL ;?>:</b><br />
	      <input class="text name" name="entry-isurlused" type="checkbox" value="true" <?php echo (ISURLUSED) ? "checked=\"checked\"" : "" ; ?> />
	    </div>
	    <div>
	    <b><?php echo ISKEYWORDUSEDLABEL ;?>:</b><br />
	      <input class="text name" name="entry-iskeywordused" type="checkbox" value="true" <?php echo (ISKEYWORDUSED) ? "checked=\"checked\"" : "" ; ?> />
	    </div>
	    <div>
	    <b><?php echo ISCLIENTUSEDLABEL ;?>:</b><br />
	      <input class="text name" name="entry-isclientused" type="checkbox" value="true" <?php echo (ISCLIENTUSED) ? "checked=\"checked\"" : "" ; ?> />
	    </div>
	    <div>
	      <input id="save" name="submit" type="submit" class="submit" value="OK" />
	      &nbsp;&nbsp;or&nbsp;&nbsp;
	      <a href="#" class="cancel" title="Cancel">Cancel</a>
	    </div>
	  </form>
	  <script>

		function showAvailableDir(div){
			div.parent().find("div").load("../plugins/<?php echo PLUGINNAME; ?>/pages/pickupdir.php?key=" + div.val() + "&dest=" + div.attr("id"));
		}
		$("#big").keyup(function () {
			$(this).parent().find("div").show();
			showAvailableDir($(this));
		})
		$("#big").focus(function () {
			$(this).parent().find("div").show();
			showAvailableDir($(this));
		})
		$("#small").keyup(function () {
			$(this).parent().find("div").show();
			showAvailableDir($(this));
		})
		$("#small").focus(function () {
			$(this).parent().find("div").show();
			showAvailableDir($(this));
		})
		$("#usecustomthumbnail").click(function(){
			$('#toggle_usecustomthumbnail').toggle($(this).attr('checked'));
		});
		
	  </script>
	<?php
	}
	/*******************************************************
	 * @function load_settings
	 * @action load plugin settings
	 */
	public  function load_settings($data = "") {
	    if (!isset($data)||empty($data)){
	      $data = @getXML($this->_filename);
	    }
	    if ($data) {
	      define('BIGFILESFOLDER',stripslashes($data->bigfilesfolder));
	      define('SMALLFILESFOLDER',stripslashes($data->smallfilesfolder));
	      define('USECUSTOMTHUMBNAIL',stripslashes(($data->usecustomthumbnail) ? $data->usecustomthumbnail : false));
	      define('ISURLUSED',stripslashes(($data->isurlused) ? $data->isurlused : false));
	      define('ISKEYWORDUSED',stripslashes(($data->iskeywordused) ? $data->iskeywordused : false));
	      define('ISCLIENTUSED',stripslashes(($data->isclientused) ? $data->isclientused : false));
	    } else {
	      die("unable to load ". $this->_filename);
	    }
	  }

	  /*******************************************************
	 * @function load_data
	 * @action load data
	 */
	public  function load_data($data = "") {
	    return $this->enforce_array(getXML($this->_datafilename));
	  }
	/*******************************************************
	 * @function save_data
	 * @action write $data
	 */
	public function save_data($data = array()) {
	  
	  $old_data = $this->enforce_array($this->load_data());

	  foreach ($data as $key => $value) {
		$old_data[$key] = $value;
	  }

	  $isclientused = htmlentities(isset($_POST['entry-isclientused']), ENT_QUOTES, 'UTF-8');
	  
	  $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
	  
	  foreach ($old_data as $key => $value) {
	    $child = htmlentities($value, ENT_QUOTES, 'UTF-8');
	    $xml->addChild($key)->addCData($child);
	  }

	  XMLsave($xml, $this->_datafilename);

	}
	  /*******************************************************
	 * @function save_settings
	 * @action write $_POST data to a file
	 */
	public function save_settings() {
	  
	  $bigfilesfolder = htmlentities($_POST['entry-big'], ENT_QUOTES, 'UTF-8');
	  $smallfilesfolder = htmlentities($_POST['entry-small'], ENT_QUOTES, 'UTF-8');
	  $isurlused = htmlentities(isset($_POST['entry-isurlused']), ENT_QUOTES, 'UTF-8');
	  $iskeywordused = htmlentities(isset($_POST['entry-iskeywordused']), ENT_QUOTES, 'UTF-8');
	  $isclientused = htmlentities(isset($_POST['entry-isclientused']), ENT_QUOTES, 'UTF-8');
	  $usecustomthumbnail = htmlentities(isset($_POST['entry-usecustomthumbnail']), ENT_QUOTES, 'UTF-8');
	  
	  $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
	  
	  $xml->addChild('bigfilesfolder')->addCData($bigfilesfolder);
	  $xml->addChild('smallfilesfolder')->addCData($smallfilesfolder);
	  $xml->addChild('isurlused')->addCData($isurlused);
	  $xml->addChild('iskeywordused')->addCData($iskeywordused);
	  $xml->addChild('isclientused')->addCData($isclientused);
	  $xml->addChild('usecustomthumbnail')->addCData($usecustomthumbnail);

	  XMLsave($xml, $this->_filename);

	  $this->load_settings($xml);

	  echo '<div class="updated">'.SETTINGSNOTIFYSAVING.'</div>';
	}

	private function enforce_array($obj) { 
		$array = (array)$obj; 
		if(empty($array)) { 
		$array = ''; 
		} 
		else { 
		foreach($array as $key=>$value) { 
		if(!is_scalar($value)) { 
		 if(is_a($value,'SimpleXMLElement')) { 
		  $array[$key] = ''.$value; 
		 } 
		 else { 
		  $array[$key] = enforce_array($value); 
		 } 
		} 
		else { 
		 $array[$key] = $value; 
		} 
		} 
		} 
		return $array; 
	}
}