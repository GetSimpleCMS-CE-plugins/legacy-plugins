<?php
/**
 * English Language File for Plopfolio Plugin
 *
 * Date:    26 Feb 2013
 * Revision: 0.1	
 * Version:   GetSimple 3.0
 * Traductors:	Gaëtan Janssens
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	'ENTRYNAME' => "Name",
	'ENTRYIMG' => "Main Image",
	'ENTRYTHUMB' => "Thumbnail",
	'ENTRYYEAR' => "Year",
	'ENTRYMONTH' => "Month",
	'ENTRYCLIENTNAME' => "Customer Name",
	'ENTRYKEYWORDS' => "Keywords",
	'ENTRYDESCRIPTION' => "Description",
	'ENTRYURL' => "Web Url",
	'ENTRYNAMES' => "Entry",
	'ENTRYNOTIFYSAVING' => "Entry saved",
	'ENTRYNEWLABEL' => "New Entry",
	'ENTRYEDITLABEL' => "Edit Entry",
	'PORTFOLIOSIDEBARBUTTONNAME' => "Portfolio",
	'PORTFOLIOSIDEBARSETUPBUTTONNAME' => "Portfolio Setup",
	'SETTINGSNOTIFYSAVING' => "Settings saved",
	'BIGFILESFOLDERLABEL' => "Name of the folder where are stored original files",
	'SMALLFILESFOLDERLABEL' => "Name of the folder where are stored thumb files",
	'ISURLUSEDLABEL' => "Display Web url option",
	'ISKEYWORDUSEDLABEL' => "Display keywords option",
	'ISCLIENTUSEDLABEL' => "Display Customer name option",
	'USECUSTOMTHUMBNAILLABEL' => "Use custom thumbnails",
	'ONPAGEEXEMPLELABEL' => "On page exemple"
);

