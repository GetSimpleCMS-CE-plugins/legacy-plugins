<?php
/**
 * French Language File for Plopfolio Plugin
 *
 * Date:    26 Feb 2013
 * Revision: 0.1	
 * Version:   GetSimple 3.0
 * Traductors:	Gaëtan Janssens
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	'ENTRYNAME' => "Nom",
	'ENTRYIMG' => "Visuel",
	'ENTRYTHUMB' => "Miniature",
	'ENTRYYEAR' => "Année",
	'ENTRYMONTH' => "Mois",
	'ENTRYCLIENTNAME' => "Client",
	'ENTRYKEYWORDS' => "Mots Clefs",
	'ENTRYDESCRIPTION' => "Informations Spéciales",
	'ENTRYURL' => "Adresse Web",
	'ENTRYNAMES' => "Entrées",
	'ENTRYNOTIFYSAVING' => "Entrée enregistrée",
	'ENTRYNEWLABEL' => "Nouvelle entrée",
	'ENTRYEDITLABEL' => "Editer une entrée",
	'PORTFOLIOSIDEBARBUTTONNAME' => "Portfolio",
	'PORTFOLIOSIDEBARSETUPBUTTONNAME' => "Portfolio Setup",
	'SETTINGSNOTIFYSAVING' => "Paramétres enregistrés",
	'BIGFILESFOLDERLABEL' => "Nom du dossier des grosses images",
	'SMALLFILESFOLDERLABEL' => "Nom du dossier des petites images",
	'ISURLUSEDLABEL' => "Utiliser le champ URL",
	'ISKEYWORDUSEDLABEL' => "Utiliser le mot clef",
	'ISCLIENTUSEDLABEL' => "Utiliser le champ client",
	'USECUSTOMTHUMBNAILLABEL' => "Utiliser des mignatures personalisées",
	'ONPAGEEXEMPLELABEL' => "Exemple intégration dans une page"
);

