<?php 
/****************************************************
*
* @File:  pickupdir.php
* @Package: GetSimple
* @Action:    
*
*****************************************************/

  $path = getcwd();
  $path = explode("plugins", $path);
  $path = end($path);
  $path = explode("pages", $path);
  $path = $path[0];
  $name = str_replace("/", "", $path);
  
  define('PLUGINNAME',$name);

  
  // Include common.php
  include('../../../gsconfig.php');

  if (!defined('GSADMIN')) {define('GSADMIN', 'admin');}

  include('../../../'.GSADMIN.'/inc/common.php');

  // Variable Settings
  /*if (!myplugin_is_frontend() && myplugin_gsversion() == '3.0') {
    // workaround for GetSimple 3.0:
    if (isset($_COOKIE['GS_ADMIN_USERNAME'])) setcookie('GS_ADMIN_USERNAME', $_COOKIE['GS_ADMIN_USERNAME'], 0, '/');
  }*/

  function myplugin_is_frontend() {
    return function_exists('get_site_url');
  }

  function myplugin_gsversion() {
    @include(GSADMININCPATH.'configuration.php');
    return GSVERSION;
  }


  if (isset($_GET['key'])&&strlen($_GET['key'])<10){
  $dirs = array();
  $files = directoryToArray(GSDATAPATH.'uploads/',true);

  foreach ($files as $file) {
    if (is_dir($file)) {
      $dirs[] = $file;
    }
  }

  echo "<table>";
  $int = 0;
  asort($dirs);
  foreach ($dirs as $dir) {
    if (preg_match("/".$_GET['key']."/i", $dir)) {
        echo '<tr><td>';
        echo '<a id="quicklink'.$int.$_GET['dest'].'" href="';
        echo "javascript:$('#".$_GET['dest']."').val($('#quicklink".$int.$_GET['dest']."').attr('title'));$('#".$_GET['dest']."').parent().find('div').fadeOut(500);";
        echo '" style="display:table-cell; vertical-align:middle;text-decoration: none;" ';
        echo 'title="'.str_replace(GSDATAPATH.'uploads/', '', $dir).'">';
        echo '<span style="color: #666;">'.'uploads/' .'</span>'.str_replace(GSDATAPATH.'uploads/', '', $dir).'</a></td></tr>';
        $int++;
    } 
  }
  echo "</table>";
  }
?>