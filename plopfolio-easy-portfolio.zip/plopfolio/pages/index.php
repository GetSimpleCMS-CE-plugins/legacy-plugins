<?php 
/****************************************************
*
* @File: 	pickup.php
* @Package:	GetSimple
* @Action:		
*
*****************************************************/

  // Include common.php
  include('../../../gsconfig.php');
  include('../../../'.GSADMIN.'/inc/common.php');

?>