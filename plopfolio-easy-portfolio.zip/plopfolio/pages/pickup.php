<?php 
/****************************************************
*
* @File:  pickup.php
* @Package: GetSimple
* @Action:    
*
*****************************************************/

  $path = getcwd();
  $path = explode("plugins", $path);
  $path = end($path);
  $path = explode("pages", $path);
  $path = $path[0];
  $name = str_replace("/", "", $path);
  
  define('PLUGINNAME',$name);

  
  // Include common.php
  include('../../../gsconfig.php');

  if (!defined('GSADMIN')) {define('GSADMIN', 'admin');}

  include('../../../'.GSADMIN.'/inc/common.php');
  include('../settings.php');

  
  $settings = new PlopfolioSettings();
  $settings->load_settings();
  
  switch ($_GET['dest']) {
    case 'visuel':
      define('SUBFOLDER',BIGFILESFOLDER);
      break;
    case 'thumb':
      define('SUBFOLDER',SMALLFILESFOLDER);
      break;    
    default:
      define('SUBFOLDER','.');
      break;
  }

  // Variable Settings
  if (!myplugin_is_frontend() && myplugin_gsversion() == '3.0') {
    // workaround for GetSimple 3.0:
    if (isset($_COOKIE['GS_ADMIN_USERNAME'])) setcookie('GS_ADMIN_USERNAME', $_COOKIE['GS_ADMIN_USERNAME'], 0, '/');
  }

  function myplugin_is_frontend() {
    return function_exists('get_site_url');
  }

  function myplugin_gsversion() {
    @include(GSADMININCPATH.'configuration.php');
    return GSVERSION;
  }

  if (isset($_GET['key'])&&strlen($_GET['key'])<10){
  $imgs = array();
  $files = getFiles(GSDATAPATH.'uploads/'.SUBFOLDER);

  foreach ($files as $file) {
    if (is_file(GSDATAPATH . 'uploads/'.SUBFOLDER. '/' . $file) && (preg_match("/.jpg$/", $file)||preg_match("/.jpeg$/", $file)||preg_match("/.png$/", $file)||preg_match("/.gif$/", $file) ) ) {
      $imgs[] = $file;
    }
  }
  echo "<table>";
  $int = 0;
  foreach ($imgs as $img) {
    if (preg_match("/".$_GET['key']."/i", $img)) {
        echo '<tr><td>';/*<!--<img src="';
        echo $SITEURL.'data/uploads/'.$img;
        echo '" height="60px" style="float:left;"/>-->';*/
        echo '<a id="quicklink'.$int.$_GET['dest'].'" href="';
        echo "javascript:$('#".$_GET['dest']."').val($('#quicklink".$int.$_GET['dest']."').attr('title'));";
        echo "$('#".$_GET['dest']."sub').fadeOut(500);";
        echo "$('#".$_GET['dest']."img').attr('src',$('#".$_GET['dest']."').val());";
        echo "$('#".$_GET['dest']."img').trigger('selected',['".$img."','".$SITEURL.'data/thumbs/'.SUBFOLDER.'/'."']);";
        echo '" style="display:table-cell; vertical-align:middle;text-decoration: none;" ';
        echo 'title="'.$SITEURL.'data/uploads/'.SUBFOLDER.'/' .$img.'">';
        echo '<span style="color: #666;">'.$SITEURL.'data/uploads/'.SUBFOLDER.'/' .'</span>'.$img.'</a></td></tr>';
        $int++;
    } 
  }
  echo "</table>";
  }
?>