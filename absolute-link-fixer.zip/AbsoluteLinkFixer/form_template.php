<?php if (isset($success)): ?>
	<div class="<?php echo $success ? 'updated' : 'error'?>" style="display: block;">
	  <p>
		<?php echo $success ? 'Your changes have been saved.' : 'File save error.'?> 
	  </p>
	</div>
<?php endif; ?>

<form class="largeform" id="edit" action="load.php?id=AbsoluteLinkFixer" method="post">
<h3 class="Floated">Link Fixer settings</h3>


	<p>Current site path is: <strong><?php echo suggest_site_path(); ?></strong>	</p>
	
	<p>
		<label for="append">Replace all occurencies of site path string in page fields to:</label>
		<input class="text" id="replace_to" name="replace_to" type="text" value="<?php echo $settings->replace_to; ?>" />
	</p>
	
	<p>
		<input name="post" type="submit" class="submit" value="Save changes" />
	</p>
	
	
</form>