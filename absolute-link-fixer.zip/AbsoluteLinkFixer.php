<?php
/*
Plugin Name: Absolute Link Fixer
Description: This plugin replaces all occurencies of current site path string to specified string, while saving pages. By this way you have all image, file links changed from absolute to relative in page content and page fields.
Version: 1.00
Author: Michał Gańko
Author URI: http://foureyes.pl
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Absolute Link Fixer', 	
	'1.00', 		
	'Michał Gańko',
	'http://foureyes.pl', 
	'This plugin replaces all occurencies of current site path string to specified string, while saving pages. By this way you have all image, file links changed from absolute to relative in page content and page fields.',
	'plugins',
	'link_fixer_admin_tab'  
);

add_action('common','link_fixer_on_common'); 

add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Configure Absolute Link Fixer'));


function link_fixer_admin_tab() {
	if (isset($_POST['replace_to'])){ //is post, saving
		$success = link_fixer_save_settings( $_POST['replace_to']	);
	}
	$settings = link_fixer_get_settings();
	require_once('AbsoluteLinkFixer/form_template.php');
}

function link_fixer_on_common(){

	if ( basename($_SERVER['PHP_SELF'])=='changedata.php' && isset($_POST) ) { //only when saving pages
		$settings = link_fixer_get_settings();
		$sitePath = suggest_site_path(); 
		
		foreach ($_POST as &$value) {
			$value = str_replace($sitePath, $settings->replace_to, $value);
		}
	}
}

//retrieves settings from xml
function link_fixer_get_settings() {
    $file = GSDATAOTHERPATH . 'absolute_link_fixer.xml';
	
	if (!file_exists($file)) {
		link_fixer_save_settings(); //create empty one
	}
	
	$data = getXML($file);
	
	$settings = new stdClass();

	$settings->replace_to = (string) $data->replace_to;
	
	return $settings;
}

//saves settings to xml
function link_fixer_save_settings($replace_to = '') {
    $file = GSDATAOTHERPATH . 'absolute_link_fixer.xml';
	
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><settings></settings>');
	
	
	$obj = $xml->addChild('replace_to');
	$obj->addCData($replace_to);

	# write data to file
	return XMLsave($xml, $file) === true ? true : false;
}