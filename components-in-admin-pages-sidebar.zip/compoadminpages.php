<?php
$thisfile = basename(__FILE__, ".php");

register_plugin(
  $thisfile,
  'Components in Admin Pages sidebar',   
  '0.2',       
  'Carlos Navarro',
  'http://www.cyberiada.org/cnb/',
  'Adds shortcut link to Edit Components in Page Management sidebar',
  'pages',
  ''
);

add_action('pages-sidebar', 'sidebarcomponentslink');

function sidebarcomponentslink() { ?>

    <li id="sb_components"><a href="components.php"><?php echo strip_tags(i18n_r('SIDE_COMPONENTS')); ?></a></li>
<?php }

// end of file