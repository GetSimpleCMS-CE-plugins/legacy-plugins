<?php

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
 
# register plugin
register_plugin(
  $thisfile,
  'Scroll to top',
  '0.2.1',
  'xxdex',
  'http://www.get-simple.info', //author website
  'Animated Scrolling arrow to site top using jquery', //Plugin description
  'theme',
  'scrolltotop'
);
 
# activate filter 
add_action('theme-footer','scrolling_gs'); 
add_action('theme-sidebar','createSideMenu',array($thisfile,'Scroll to top'));
add_action('theme-header','styles_sttop');


define('STTOP_PLUGIN', GSPLUGINPATH  . 'scrolltop/img/');
define('STTOP', GSDATAOTHERPATH  . 'sttop/');
define('STTOP_SETTINGS', STTOP . 'settings.xml');
define('STTOP_LINK', suggest_site_path(true) . '/plugins/scrolltop/img/');


register_script('scrolltotopjquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.jskk', '1.7.1', FALSE);


# load settings
$data = @getXML(STTOP_SETTINGS);
$sttop_arrow       	= isset($data->arrow) ? $data->arrow : 'style_1';
$sttop_arrow_color 	= isset($data->arrow_color) ? $data->arrow_color : 'white';
$sttop_arrow_size 	= isset($data->icon_size) ? $data->icon_size : '64';
$margin_bottom		= isset($data->margin_bottom	) ? $data->margin_bottom	 : '0';
$margin_right		= isset($data->margin_right) ? $data->margin_right : '0';
$arrow_background	= isset($data->arrow_background) ? $data->arrow_background : 'black';
$sttop_border_radius= isset($data->border_radius) ? $data->border_radius : '20';





function styles_sttop() {
	
	global $sttop_arrow;
	global $sttop_arrow_color;
	global $sttop_arrow_size;
	global $margin_bottom;
	global $margin_right;
	global $arrow_background;
	global $sttop_border_radius;
	

// backgrounds
if ($arrow_background=='black'){
$color_bg = '#000';
}
if ($arrow_background=='white'){
$color_bg = '#fff';
}
if ($arrow_background=='green'){
$color_bg = '#0bcf27';
}
if ($arrow_background=='blue'){
$color_bg = '#02c8cf';
}
if ($arrow_background=='yellow'){
$color_bg = '#fcff00';
}
if ($arrow_background=='silver'){
$color_bg = '#dbdbdb';
}
if ($arrow_background=='red'){
$color_bg = '#ff0000';
}
if ($arrow_background=='transparent'){
$color_bg = '';
}
// icons 
	echo '
<!-- for scroll to top plugin -->
<style type="text/css" >
#back-top {
	position: fixed;
	bottom: '.$margin_bottom.'px;
	right:'.$margin_right.'px;
	z-index: 20000;
	

}
#back-top a {
	
	display: block;
	text-align: center;
	font: 11px/100% Arial, Helvetica, sans-serif;
	text-transform: uppercase;
	text-decoration: none;
	color: #bbb;
	/* background color transition */
	-webkit-transition: 1s;
	-moz-transition: 1s;
	transition: 1s;
}
#back-top a:hover {
	color: #000;
}
/* arrow icon (span tag) */
#back-top span {
	width: '.$sttop_arrow_size.'px;
	height: '.$sttop_arrow_size.'px;
	display: block;
	
	
	background: '.$color_bg.' url('.suggest_site_path().'plugins/scrolltop/img/'.$sttop_arrow.'_'.$sttop_arrow_color.'.png) no-repeat center center;
	background-size: '.$sttop_arrow_size.'px '.$sttop_arrow_size.'px ;

	filter:alpha(opacity=50);
	opacity: 0.5;
	-moz-opacity:0.5;

	-webkit-border-radius: '.$sttop_border_radius.'px;
	-moz-border-radius: '.$sttop_border_radius.'px;
	border-radius: '.$sttop_border_radius.'px;
	
	-webkit-transition: 1s;
	-moz-transition: 1s;
	transition: 1s;
	margin: 0 auto;
	position: relative;
}

#back-top a:hover span {
	filter:alpha(opacity=100);
	opacity: 1;
	-moz-opacity:1;
	
}
</style>
';	
}




function scrolltotop() {


if (!file_exists(STTOP)) {
  	mkdir(STTOP, 0777);
	
	$fh = fopen(STTOP . '.htaccess', 'w');
    fwrite($fh, 'Deny from all');
    fclose($fh);
	
} else {



}

   
	
	
	
	
	global $sttop_arrow;
	global $sttop_arrow_color;
	global $sttop_arrow_size;
	global $margin_bottom;
	global $margin_right;
	global $arrow_background;
	global $sttop_border_radius;
	
	
	
// backgrounds
if ($arrow_background=='black'){
$color_bg = '#000';
}
if ($arrow_background=='white'){
$color_bg = '#fff';
}
if ($arrow_background=='green'){
$color_bg = '#0bcf27';
}
if ($arrow_background=='blue'){
$color_bg = '#02c8cf';
}
if ($arrow_background=='yellow'){
$color_bg = '#fcff00';
}
if ($arrow_background=='silver'){
$color_bg = '#dbdbdb';
}
if ($arrow_background=='red'){
$color_bg = '#ff0000';
}
if ($arrow_background=='transparent'){
$color_bg = '';
}
	
?>

<h3 class="floated">Scroll to top settings</h3><br><br>

<?php

	if (!$_POST['icon_set']) {
?>
<script type="text/javascript">

function switchArrow(){
   var javacolor = document.getElementById("java_color").value;
   var javaarrow = document.getElementById("java_arrow").value;

   var src = "<?php echo STTOP_LINK; ?>" + javaarrow + "_" + javacolor + ".png";
   document.getElementById('#AvatarImage').src = src;
   
}

function switchBackground(){
   var dop = document.getElementById("java_bg_icon").value;
   var tlokolor = "none";
	
	if (dop == "transparent") { tlokolor = "transparent";	}
	if (dop == "white") { tlokolor = "#fff";	}
	if (dop == "black") { tlokolor = "#000";	}
	if (dop == "green") { tlokolor = "#0bcf27";	}
	if (dop == "blue") { tlokolor = "#02c8cf";	}
	if (dop == "yellow") { tlokolor = "#fcff00";	}
	if (dop == "silver") { tlokolor = "#dbdbdb";	}
	if (dop == "red") { tlokolor = "#ff0000";	}
	
  document.getElementById('AvatarBackground').style.backgroundColor = tlokolor;

}

function switchSize(){
var javafunction_get_size = document.getElementById("java_size").value;

	
  document.getElementById('AvatarBackground').style.width = javafunction_get_size + "px";
  document.getElementById('AvatarBackground').style.height = javafunction_get_size + "px";
   document.getElementById('#AvatarImage').style.width = javafunction_get_size + "px";
  document.getElementById('#AvatarImage').style.height = javafunction_get_size + "px";
  
}

function borderRadius(){
var javafunction_radius= document.getElementById("java_radius").value;

	
  document.getElementById('AvatarBackground').style.borderRadius = javafunction_radius + "px";
  document.getElementById('AvatarBackground').style.MozBorderRadius = javafunction_radius + "px";
  document.getElementById('AvatarBackground').style.WebkitBorderRadius = javafunction_radius + "px";

  
}



</script>

Configuration:<br/>

<form class="largeform" id="settings" action="load.php?id=scrolltotop" method="post" accept-charset="utf-8">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="50%">
      <label for="icon-set">Icon set:</label>
      <select class="text" name="icon_set" style="width:300px;"  onChange="switchArrow();" id="java_arrow">
      <option value="style_1" <?php if ($sttop_arrow  == 'style_1') echo 'selected="selected"'; ?> >style 1</option>
      <option value="style_2" <?php if ($sttop_arrow  == 'style_2') echo 'selected="selected"'; ?> >style 2</option>
      <option value="style_3" <?php if ($sttop_arrow  == 'style_3') echo 'selected="selected"'; ?> >style 3</option>
      <option value="style_4" <?php if ($sttop_arrow  == 'style_4') echo 'selected="selected"'; ?> >style 4</option>
      <option value="style_5" <?php if ($sttop_arrow  == 'style_5') echo 'selected="selected"'; ?> >style 5</option> 
      <option value="style_6" <?php if ($sttop_arrow  == 'style_6') echo 'selected="selected"'; ?> >style 6</option> 
      </select>	
        <label for="arrow_color">Icon color:</label>
      <select class="text" name="arrow_color" style="width:300px;" onChange="switchArrow();" id="java_color" >
      <option value="black" <?php if ($sttop_arrow_color  == 'black') echo 'selected="selected"'; ?>  >black</option>
      <option value="white" <?php if ($sttop_arrow_color  == 'white') echo 'selected="selected"'; ?> >white</option>
      <option value="green" <?php if   ($sttop_arrow_color  == 'green') echo 'selected="selected"'; ?> >green</option>
      <option value="blue" <?php if ($sttop_arrow_color  == 'blue') echo 'selected="selected"'; ?> >blue</option>  
      <option value="yellow" <?php if ($sttop_arrow_color  == 'yellow') echo 'selected="selected"'; ?>  >yellow</option>  
      <option value="silver" <?php if ($sttop_arrow_color  == 'silver') echo 'selected="selected"'; ?> >silver</option>  
       <option value="red" <?php if ($sttop_arrow_color  == 'red') echo 'selected="selected"'; ?>  >red</option>  
      </select>	
        <label for="background-color">Background icon color:</label>
      <select class="text" name="arrow_background" style="width:300px;" onChange="switchBackground();" id="java_bg_icon">
      <option value="transparent" <?php if ($arrow_background  == 'transparent') echo 'selected="selected"'; ?> >-transparent-</option>  
      <option value="black" <?php if ($arrow_background  == 'black') echo 'selected="selected"'; ?>  >black</option>
      <option value="white" <?php if ($arrow_background  == 'white') echo 'selected="selected"'; ?> >white</option>
      <option value="green" <?php if   ($arrow_background  == 'green') echo 'selected="selected"'; ?>>green</option>
      <option value="blue" <?php if ($arrow_background  == 'blue') echo 'selected="selected"'; ?> >blue</option>  
      <option value="yellow" <?php if ($arrow_background  == 'yellow') echo 'selected="selected"'; ?>  >yellow</option>  
      <option value="silver" <?php if ($arrow_background  == 'silver') echo 'selected="selected"'; ?> >silver</option>  
       <option value="red" <?php if ($arrow_background  == 'red') echo 'selected="selected"'; ?> >red</option>  
      </select>	
      

		</td>
		<td width="50%" rowspan="3" valign="top">

        <div id="AvatarBackground" style="background-color:<?php echo $color_bg; ?>; width:<?php echo $sttop_arrow_size; ?>px; height:<?php echo $sttop_arrow_size; ?>px; border-radius:<?php echo $sttop_border_radius; ?>px; -webkit-border-radius:<?php echo $sttop_border_radius; ?>px; -moz-border-radius:<?php echo $sttop_border_radius; ?>px;" >
        <img id="#AvatarImage" src="<?php echo STTOP_LINK.$sttop_arrow .'_'.$sttop_arrow_color;?>.png" style="width:<?php echo $sttop_arrow_size; ?>px; height:<?php echo $sttop_arrow_size; ?>px;"/>
        </div>
        </td>
	</tr>
	<tr>
		<td>
    <label for="icon_size">Icon size:</label>
      <select class="text" name="icon_size" style="width:300px;" onChange="switchSize(); " id="java_size">
      <option value="16" <?php if ($sttop_arrow_size  == '16') echo 'selected="selected"'; ?> >16px</option>
      <option value="32" <?php if ($sttop_arrow_size  == '32') echo 'selected="selected"'; ?> >32px</option>
      <option value="64" <?php if ($sttop_arrow_size  == '64') echo 'selected="selected"'; ?> >64px</option>

      </select>	 
    <label for="border_radius">Border radius:</label>
      <select class="text" name="border_radius" style="width:300px;" id="java_radius" onChange="borderRadius();">
      <option value="0" <?php if ($sttop_border_radius  == '0') echo 'selected="selected"'; ?> >-no border radius-</option>
      <option value="5" <?php if ($sttop_border_radius  == '5') echo 'selected="selected"'; ?> >5px</option>
      <option value="10" <?php if ($sttop_border_radius  == '10') echo 'selected="selected"'; ?> >10px</option>
      <option value="20" <?php if ($sttop_border_radius  == '20') echo 'selected="selected"'; ?> >20px</option>
      <option value="50" <?php if ($sttop_border_radius  == '50') echo 'selected="selected"'; ?> >50px</option>
      </select>	 
      
      </td>
      </tr>
      <tr>
      <td>
      
      <label for="margin_bottom">Margin from bottom (in pixels):</label>
      <input class="text required" type="text" name="margin_bottom" value="<?php echo $margin_bottom; ?>" style="width:100px;" />
      <br />
       <label for="margin_right">Margin from right (in pixels):</label>
      <input class="text required" type="text" name="margin_right" value="<?php echo $margin_right; ?>" style="width:100px;" />
        </td>
        
      
     
        
	</tr>
    
   
</table>

  <span>
      <input class="submit" type="submit" name="settings" value="Save Settings" />
    </span>
    &nbsp;&nbsp;or&nbsp;&nbsp;
    <a href="load.php?id=scrolltotop&cancel" class="cancel">Cancel</a>
  </p>
</form>

<?php
	} else {
sttop_save_xml();
echo '
 <p style="color:#669933;"><b>Your settings have been updated</b></p>
<a href=""></a>
';

	}



}


 queue_script('jquery',GSFRONT);
# functions
function scrolling_gs() {
	echo '


<script>
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$(\'#back-top\').fadeIn();
			} else {
				$(\'#back-top\').fadeOut();
			}
		});

		// scroll body to 0px on click
		$(\'#back-top a\').click(function () {
			$(\'body,html\').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});
</script>








	<p id="back-top">
		<a href="#top"><span></span></a>
	</p>	
';
}


function sttop_save_xml() {
	global $sttop_arrow;
	global $sttop_arrow_color;
	global $sttop_arrow_size;
	global $margin_bottom;
	global $margin_right;
	global $arrow_background;
	global $sttop_border_radius;
	
  $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><item></item>');
  
  $obj = $xml->addChild('arrow', $_POST['icon_set']);
  $obj = $xml->addChild('arrow_color', $_POST['arrow_color']);
  $obj = $xml->addChild('arrow_background', $_POST['arrow_background']);
  
  
  
  $obj = $xml->addChild('icon_size', $_POST['icon_size']);
  $obj = $xml->addChild('margin_bottom', $_POST['margin_bottom']);
  $obj = $xml->addChild('margin_right', $_POST['margin_right']);
  $obj = $xml->addChild('border_radius', $_POST['border_radius']);


  return @XMLsave($xml, STTOP_SETTINGS);
}


?>
