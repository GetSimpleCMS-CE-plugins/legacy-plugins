Add files rss.php and news.php to the specific theme foder. 
File template.php have added RSS Feed Menu and Latest News Menu.

If you do not need this Menus do not replace existing  template.php file.

