<?php
/*****************************************************
* @File: 	template.php
* @Package:		GetSimple
* @Action:		WatchThis theme for the GetSimple CMS
******************************************************/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>	
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />	
		<title><?php get_page_clean_title(); ?> &bull; <?php get_site_name(); ?></title>	
		<?php get_header(); ?>	
		<meta name="robots" content="index, follow" />	
		<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css" media="all" />	
		<script type="text/javascript">
			<!--		try {			
				document.execCommand("BackgroundImageCache", false, true);		} catch(err) {}		
					/* IE6 flicker hack from http://dean.edwards.name/my/flicker.html */	-->
		</script>	
	</head>
	<body id="<?php get_page_slug(); ?>" >	
		<div id="content">		
			<h1><?php get_site_name(); ?></h1>		
			<ul id="top">			
				<?php get_navigation(return_page_slug()); ?>		
				</ul>				
				<div class="clear"></div>				
				<div id="left">			
					<h2><?php get_page_title(); ?></h2>			
					<?php show_news(); ?>	
				</div>		
				<div id="right">			
					<div class="section">					
						<?php get_component('sidebar');	?>			
					</div>
                     <div class="section news_latest rss_holder">
                        <h2 class="rss">RSS</h2>
                        <div class="feed_icons">
                            <?php rss_link(); ?>
                        </div>
                    </div>
                    <div class="section news_latest rss_holder">
                        <?php list_news(); ?>
                    </div>
	
				</div>		
				<div id="footer">			
					<p>&copy; <?php echo date('Y'); ?> <?php get_site_name(); ?> &nbsp;&bull;&nbsp; <?php get_site_credits(); ?> &nbsp;&bull;&nbsp; Theme by <a title="Free CSS Templates" href="http://www.solucija.com/">Solucija</a> and <a href="http://www.cagintranet.com/">Cagintranet</a></p>		
				</div>	
		</div>
	</body>
</html>