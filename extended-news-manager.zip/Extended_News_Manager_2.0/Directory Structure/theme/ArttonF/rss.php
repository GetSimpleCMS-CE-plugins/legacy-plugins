<?php 
if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

	header("Content-Type: application/rss+xml");
	header("Content-Type: application/xhtml+xml");
	header("Content-Type: application/rss+xml");
	header("Content-Type: text/xml"); 
	rss_feed();
/* End of file feed.php */
/* Location: ./system/application/controllers/feed.php */ 
