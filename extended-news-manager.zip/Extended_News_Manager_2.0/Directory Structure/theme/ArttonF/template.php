<?php
/* template.php, v1.0 20110321, Artton - GetSimple Theme - created by P R A G */
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php get_page_clean_title(); ?> | <?php get_site_name(); ?>, <?php get_component('tagline'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<?php get_header(); ?>
	<meta name="robots" content="index, follow" />
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css" media="all" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php get_theme_url(); ?>/images/favicon.ico" />
	<script type="text/javascript" src="<?php get_theme_url(); ?>/js/jquery-1.5.1.min.js"></script>
	<!--[if lt IE 9]><script type="text/javascript" src="<?php get_theme_url(); ?>/js/html5.js"></script><![endif]-->
</head>

<body id="<?php get_page_slug(); ?>" >
<div class="wrapper">
	<header id="bodyheader">
		<div class="content clearfix">
			<a class="logo" href="<?php get_site_url(); ?>"><?php get_site_name(); ?></a>
			<p class="tagline"><?php get_component('tagline'); ?></p>
			
			<!-- <div id="find"> You may put the serch form here! </div> -->
				
			<nav id="navPrim">
				<ul><?php get_navigation(return_page_slug()); ?></ul>
			</nav>
		</div>
	</header><!-- end #bodyheader -->
	
	<section id="bodycontent" class="clearfix">
	
		<article class="main clearfix">
			<header>
				<h1><?php get_page_title(); ?></h1>
			</header>
			<section class="maincontent">
				<?php get_page_content(); ?>
			</section>
			<footer class="meta" >
				<time datetime="<?php get_page_date('c'); ?>" pubdate="pubdate"><b>Published on:</b> <?php get_page_date('F jS, Y'); ?></time>
			</footer>
		</article><!-- end .main -->
	
		<aside id="sidebar" class="clearfix">

			<?php get_component('colors'); ?>
			
			<!-- wrap each sidebar section like this -->
			<div class="section">
				<?php get_component('sidebar');	?>
			</div>
	<div class="section">
             	<h2>RSS</h2>
		<div class="icons">
        	<?php rss_link(); ?>
         </div>
	</div>
	<div class="section">
         <?php list_news(); ?>
	 </div>			
    </aside><!-- end #sidebar -->
		
	</section><!-- end #bodycontent -->
	
	<footer id="bodyfooter" class="clearfix">
		<p class="left-footer"><?php echo date('Y'); ?> &copy; <strong class="logo"><?php get_site_name(); ?></strong></p>
		<p class="right-footer"><a href="http://www.pragbg.co.cc" title="DESIGN...and more" >Created by PRAG</a> <span>|</span> <?php get_site_credits(); ?></p>
		
		<?php get_footer(); ?>
		
	</footer><!-- end #footer -->

</div><!-- end div.wrapper -->

</body>
</html>