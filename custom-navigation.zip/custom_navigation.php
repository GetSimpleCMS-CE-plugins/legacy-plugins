<?php
/*
Plugin Name: Custom Navigation
Description: This is a theme function that customizes the navigation for your theme with tags and classes to use; this is a revisit of get_navigation() code
Version: 0.1
Author: Sergio Guastaferro
Author URI: https://www.linkedin.com/in/sergio-guastaferro-5826a171
*/

//including for dependencies of the code of get_navigation 
include(GSADMININCPATH.'configuration.php');


# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Custom Navigation', 	
	'0.1', 		
	'Sergio Guastaferro',
	'https://www.linkedin.com/in/sergio-guastaferro-5826a171', 
	'This is a theme function that customizes the navigation for your theme with tags and classes to use; this is a revisit of get_navigation() code',
	'theme',
	null  
);




//-------------------------------- functions ----------------------------

/**
 * Get Main Navigation [REVISIT]
 *
 * This will return unordered list of main navigation
 * This function uses the menu opitions listed within the 'Edit Page' control panel screen
 *
 * @since 1.0
 * @uses GSDATAOTHERPATH
 * @uses getXML
 * @uses subval_sort
 * @uses find_url
 * @uses strip_quotes 
 * @uses exec_filter 
 *
 * @param string $currentpage This is the ID of the current page the visitor is on
 * @param string $classPrefix Prefix that gets added to the parent and slug classnames
 * @param array  $arrayHtml Indicates the tags to use in the code and its classes; the default is {li, class_li, a, class_a, current_li }
 *
 * @return string 
 */	
function custom_navigation($arrayHtml = null,$currentpage,$classPrefix = "") {

	$menu = '';

	if( $arrayHtml == null ){
		$arrayHtml = array('li', '', 'a', '', 'current active');
	}

	global $pagesArray;
	
	$pagesSorted = subval_sort($pagesArray,'menuOrder');
	if (count($pagesSorted) != 0) { 
		foreach ($pagesSorted as $page) {
			$sel = ''; $classes = '';
			$url_nav = $page['url'];
			
			if ($page['menuStatus'] == 'Y') { 
				$parentClass = !empty($page['parent']) ? $classPrefix.$page['parent'] . " " : "";
				$classes = trim( $parentClass.$classPrefix.$url_nav);
				if ("$currentpage" == "$url_nav") $classes .= " " . $arrayHtml[4];
				if ($page['menu'] == '') { $page['menu'] = $page['title']; }
				if ($page['title'] == '') { $page['title'] = $page['menu']; }
				$menu .= '<'.$arrayHtml[0].' class="'. $classes . ' ' . $arrayHtml[1] .'"><'.$arrayHtml[2].' class="'. $arrayHtml[3] .'" href="'. find_url($page['url'],$page['parent']) . '" title="'. encode_quotes(cl($page['title'])) .'">'.strip_decode($page['menu']).'</'.$arrayHtml[2].'></'.$arrayHtml[0].'>'."\n";
			}
		}
		
	}
	
	echo exec_filter('menuitems',$menu);
}


?>