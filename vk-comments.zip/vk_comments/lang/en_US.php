<?php
/**
 * English Language File for "VK Comments" plugin
 *
 */
$i18n = array(
  	'NAME_PLUGIN' => 'VK Comments',
	'AUTHOR' => 'Vadim Mikheev',
	'SIDE_MENU_NAME_PLUGIN' => 'VK Comments',
	'DESCRIPTION' => 'Provides vk.com comments on pages',
	'API' => 'API ID (Open API user vk.com)',
	'WIDTH' => 'Specifies the width of the box in pixels (>300)',
	'LIMIT' => 'Number of comments on the page (5-100)',	
	'ATTACH' => 'Sets the ability to create attachments to comments (false-for disable)',
	'MINI' => 'Use minimalistic view widget (1-yes,0-no)',
	'HEIGHT' => 'Sets the maximum height of the widget in pixels (>500)',
	'NOREALTIME' => 'Disables update feeds comments in real time (1-yes,0-no)',
	'PLUGINTITLE'    => 'Configuration VK Comments',
	'PLUGINHELP'     => '<hr />Enable comments on a single page by adding the tag (% vk_comments %) in you page. Alternately insert <b>&lt?php get_vk_comments(); ?&gt</b> in your page template to have comments for all pages. <br /><br />Fields marked <font color="red">*</font> are obligatory for filling<br /><br />Get API ID on page -> <a href="http://vk.com/dev/Comments">http://vk.com/dev/Comments</a> add new site and copy API ID from widget form',
	'BTN_SERVICE'    => 'Update External Comment Service',
	'BTN_SAVE'       => 'Save Settings',
	'MSG_UPDATED'    => 'Updated settings',
	'MSG_SAVEERROR'  => 'Unable to save',
	'MSG_CHECKPRIV'  => 'check server privileges'
);
?>