<?php
/*
Plugin Name: VK Comments / Комментарии Вконтакте
Description: Provides VK comments on pages / Добавляет возможность вставить комментарии Вконтакте на страницы вашего сайта

Version: 1.1
Author: Vadim Mikheev / Вадим Михеев
Author URI: http://vadim.mikheev.ru/
*/

# get correct id for plugin / получение корректного id для плагина
$thisfile=basename(__FILE__, '.php');

#load internationalzation (Загрузка локализации)
i18n_merge('vk_comments') || i18n_merge('vk_comments','en_US');

# register plugin / регистрация плагина
register_plugin(
    $thisfile, 
    i18n_r('vk_comments/NAME_PLUGIN'),     
    '1.1',         
    i18n_r('vk_comments/AUTHOR'),
    'http://vadim.mikheev.ru', 
    i18n_r('vk_comments/DESCRIPTION'),
    'plugins',
    'vk_comments_config'  
);

# activate filter / Добавление фильтров
add_filter('content','vk_comments_display'); 

add_action('plugins-sidebar','createSideMenu',array($thisfile,i18n_r('vk_comments/SIDE_MENU_NAME_PLUGIN')));
add_action('theme-header','vk_comments_header',array());

# global vars / Глобальные переменные
$vk_comments_conf = vk_comments_loadconf();

# insert code VK into header / Вставка кода Вконтакте в раздел head вашего сайта
function vk_comments_header()
{
  global $vk_comments_conf, $data_index;
	# Если в тексте встречается наша переменная и VKapi существует, то загрузим в head нашего сайта api скрипт Вконтакте
	if (strpos($data_index->content, '(% vk_comments %)') !== false && $vk_comments_conf['vkapiid']!='')
	{
	echo '<script type="text/javascript" src="//vk.com/js/api/openapi.js?101"></script>'."\n";
	}
}

/* frontend content replacement */
function vk_comments_display($contents) {
  $tmp_content = $contents;
  $location = stripos($tmp_content, '(% vk_comments %)');
      
  if ($location !== FALSE) {
    $tmp_content = str_replace('(% vk_comments %)','',$tmp_content);
    $start_content = substr($tmp_content, 0 ,$location);
    $end_content = substr($tmp_content, $location, strlen($tmp_content)-$location );
    
    $tmp_content = $start_content . return_vk_comments() . $end_content;
  }
  // build page
  return $tmp_content;
}

function get_vk_comments() { echo return_vk_comments(); }

/* returns the appropriate page code */
function return_vk_comments()
{
  global $vk_comments_conf;

	if ($vk_comments_conf['vkapiid']!='')
	{
		$addinfo="";
		if ($vk_comments_conf['vkwidth']!='' OR $vk_comments_conf['vklimit']!='' OR $vk_comments_conf['vkattach']!='' OR $vk_comments_conf['vkmini']!='' OR $vk_comments_conf['vkheight']!='' OR $vk_comments_conf['vknorealtime']!='')
		{
		$addinfo=", {";
		if ($vk_comments_conf['vkwidth']!='' AND $vk_comments_conf['vkwidth']>300 AND $vk_comments_conf['vkwidth']<5000 ) $addinfo .= "width:$vk_comments_conf[vkwidth],";
		if ($vk_comments_conf['vklimit']!='' AND ($vk_comments_conf['vklimit']>4 OR $vk_comments_conf['vklimit']<101 )) $addinfo .= "limit:$vk_comments_conf[vklimit],";
		if ($vk_comments_conf['vkattach']!='' AND $vk_comments_conf['vkattach']=="false") $addinfo .= "attach:$vk_comments_conf[vkattach],";
		if ($vk_comments_conf['vkmini']!='' AND ($vk_comments_conf['vkmini']=="1" OR $vk_comments_conf['vkmini']=="0" )) $addinfo .= "mini:$vk_comments_conf[vkmini],";
		if ($vk_comments_conf['vkheight']!='' AND ($vk_comments_conf['vkheight']>500 OR $vk_comments_conf['vkheight']=="0")) $addinfo .= "width:$vk_comments_conf[vkheight],";
		if ($vk_comments_conf['vknorealtime']!='' AND ($vk_comments_conf['vknorealtime']=="1" OR $vk_comments_conf['vknorealtime']=="0" )) $addinfo .= "norealtime:$vk_comments_conf[vknorealtime],";
		$addinfo .="}";
		}

  	$new_content = "\n<!-- vk comments plugin embed code -->\n";  
	$new_content .= "<script type='text/javascript'>VK.init({apiId: ".$vk_comments_conf['vkapiid'].", onlyWidgets: true });</script>";
	$new_content .= "<div id='vk_comments'></div>";
	$new_content .= "<script type='text/javascript'>VK.Widgets.Comments('vk_comments'" .$addinfo. ");</script>";
	$new_content .= "\n<!-- vk comments plugin embed code -->\n";

	return $new_content;
	}
}


/* backend management page */
function vk_comments_config()
{
	# Сохранение настроек
	if (isset($_POST) && sizeof($_POST)>0)
	{
	# Сохранение настроек в файл
	$configfile=GSDATAOTHERPATH . 'vk_comments.xml';
	$xml_root = new SimpleXMLElement('<settings></settings>');

	if (isset($_POST['vkapiid'])) { $xml_root->addchild('vkapiid', $_POST['vkapiid']); }
	if (isset($_POST['vkwidth'])) { $xml_root->addchild('vkwidth', $_POST['vkwidth']); }
	if (isset($_POST['vklimit'])) { $xml_root->addchild('vklimit', $_POST['vklimit']); }
	if (isset($_POST['vkattach'])) { $xml_root->addchild('vkattach', $_POST['vkattach']); }
	if (isset($_POST['vkmini'])) { $xml_root->addchild('vkmini', $_POST['vkmini']); }
	if (isset($_POST['vkheight'])) { $xml_root->addchild('vkheight', $_POST['vkheight']); }
	if (isset($_POST['vknorealtime'])) { $xml_root->addchild('vknorealtime', $_POST['vknorealtime']); }
	
		if ($xml_root->asXML($configfile) === FALSE)
		{
		exit(i18n_r('vk_comments/MSG_SAVEERROR') . ' ' . $configfile . ', ' . i18n_r('vk_comments/MSG_CHECKPRIV'));
		}
	echo '<div style="display: block;" class="updated">' . i18n_r('vk_comments/MSG_UPDATED') . '.</div>';
	}

$vk_comments_conf = vk_comments_loadconf();

echo '<h3 class="floated">' . i18n_r('vk_comments/PLUGINTITLE') . '</h3><br/><br/>';
echo '<form name="settings" action="load.php?id=vk_comments" method="post">';
echo '<input name="vkapiid" type="text" size="10" maxlength="10" value="'.$vk_comments_conf['vkapiid'] .'"> - <b>' . i18n_r('vk_comments/API') . '</b> <font color="red">*</font><br />';
echo '<input name="vkwidth" type="text" size="10" maxlength="4" value="'.$vk_comments_conf['vkwidth'] .'"> - <b>' . i18n_r('vk_comments/WIDTH') . '</b><br />';
echo '<input name="vklimit" type="text" size="10" maxlength="3" value="'.$vk_comments_conf['vklimit'] .'"> - <b>' . i18n_r('vk_comments/LIMIT') . '</b><br />';
echo '<input name="vkattach" type="text" size="10" maxlength="5" value="'.$vk_comments_conf['vkattach'] .'"> - <b>' . i18n_r('vk_comments/ATTACH') . '</b><br />';
echo '<input name="vkmini" type="text" size="10" maxlength="1" value="'.$vk_comments_conf['vkmini'] .'"> - <b>' . i18n_r('vk_comments/MINI') . '</b><br />';
echo '<input name="vkheight" type="text" size="10" maxlength="4" value="'.$vk_comments_conf['vkheight'] .'"> - <b>' . i18n_r('vk_comments/HEIGHT') . '</b><br />';
echo '<input name="vknorealtime" type="text" size="10" maxlength="1" value="'.$vk_comments_conf['vknorealtime'] .'"> - <b>' . i18n_r('vk_comments/NOREALTIME') . '</b><br />';
echo '<br /><br />'; 
echo "<input name='submit_settings' class='submit' type='submit' value='" . i18n_r('vk_comments/BTN_SAVE') . "'><br />";
echo '</form>';
echo '<br /><p><i>' . i18n_r('vk_comments/PLUGINHELP') . '</i></p>';
}

/* get config settings from file */
function vk_comments_loadconf() {
  $vals=array();
  $configfile=GSDATAOTHERPATH . 'vk_comments.xml';
  if (!file_exists($configfile)) {
    //default settings
    $xml_root = new SimpleXMLElement('<settings><vkapiid></vkapiid><vkwidth></vkwidth><vklimit></vklimit><vkattach></vkattach><vkmini></vkmini><vkheight></vkheight><vknorealtime></vknorealtime></settings>');
    if ($xml_root->asXML($configfile) === FALSE) {
	  exit(i18n_r('vk_comments/MSG_SAVEERROR') . ' ' . $configfile . ', ' . i18n_r('vk_comments/MSG_CHECKPRIV'));
    }
    if (defined('GSCHMOD')) {
	  chmod($configfile, GSCHMOD);
    } else {
      chmod($configfile, 0755);
    }
  }

  $xml_root = simplexml_load_file($configfile);
  
  if ($xml_root !== FALSE) {
    $node = $xml_root->children();
  
	$vals['vkapiid'] = (string)$node->vkapiid;
	$vals['vkwidth'] = (string)$node->vkwidth;
	$vals['vklimit'] = (string)$node->vklimit;
	$vals['vkattach'] = (string)$node->vkattach;
	$vals['vkmini'] = (string)$node->vkmini;
	$vals['vkheight'] = (string)$node->vkheight;
	$vals['vknorealtime'] = (string)$node->vknorealtime;
  }
  return($vals);
}

?>