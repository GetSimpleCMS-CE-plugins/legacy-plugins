<?php

// No direct access
defined('IN_GS') or die('Cannot load plugin directly.');
$thisfile = basename(__FILE__, ".php");

// Register the plugin
register_plugin(
    $thisfile,
    'Force HTTPS',
    '1.0.0',
    'Helge Sverre',
    'https://helgesverre.com/',
    'Force HTTPS on your Website',
    'plugins'
);


// Run this hook everywhere before anything else is loaded in.
add_action('common', 'force_https');


function force_https()
{
    if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] == "off") {
        $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: ' . $redirect);
    }
}