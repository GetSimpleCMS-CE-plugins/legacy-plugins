<?php
/*
Plugin Name: DY CSV Table
Version: 1.0
Description: Presents a data from CSV file in a HTML table
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY CSV Table',                    # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  'Presents a data from CSV file in a HTML table',   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content', 'dyCSVTableShortcode');

function dyCSVTableShortcode($content) {
  // (% dyCSVTable filename:'data.csv' attributes:'class="table" id="table-1"' headers:"Title|Description" autonumbering:'true' delimeter:';' enclosure:'"' escape:'//' %)
  $pattern = '(\(%\s+dyCSVTable\s+(.*)\s+%\))';
  return preg_replace_callback($pattern, 'dyCSVTableCallback', $content);
}

function dyCSVTableCallback($matches) {
  if (isset($matches[1])) {
    preg_match("/filename\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
    if (isset($tmp[2])) {
      $filename = $tmp[2];
      preg_match("/attributes\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $attributes = isset($tmp[2]) ? $tmp[2] : false;
      preg_match("/headers\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $headers = isset($tmp[2]) ? explode('|', $tmp[2]) : false;
      preg_match("/autonumbering\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $autonumbering = (isset($tmp[2]) && $tmp[2] === 'true') ? true : false;      
      preg_match("/delimeter\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $delimeter = isset($tmp[2]) ? $tmp[2] : ',';
      preg_match("/enclosure\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $enclosure = isset($tmp[2]) ? $tmp[2] : '"';
      preg_match("/escape\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $escape = isset($tmp[2]) ? $tmp[2] : "\\";
      return dyCSVTable($filename, $attributes, $headers, $autonumbering, $delimeter, $enclosure, $escape, false);
    }
  }  
}

function dyCSVTable($filename, $attributes = false, $headers = false, $autonumbering = false, $delimeter = ',', $enclosure = '"',  $escape = "\\", $echo = true) {
  $filename = GSDATAUPLOADPATH . DIRECTORY_SEPARATOR . $filename;
  if (is_file($filename)) {
    $args = func_get_args();
    array_push($args, filemtime($filename));
    $cache = GSCACHEPATH . 'dyCSVTable-' . md5(json_encode($args)) . '.txt';
    if (is_file($cache)) {
      $table = file_get_contents($cache);
    } else {
      $table = '';
      ini_set('auto_detect_line_endings', true);
      foreach(file($filename, FILE_SKIP_EMPTY_LINES) as $string)
        $data[] = str_getcsv($string, $delimeter, $enclosure, $escape);
      ini_set('auto_detect_line_endings', false);              
      if (isset($data)) {
      # Create THEAD
        $thead = '<thead><tr>';
        if ($autonumbering) $thead .= '<th class="dy-csv-table-autonumbering"></th>';
        if (is_array($headers) && count($headers) > 0) {
          foreach ($headers as $item) $thead .= '<th>' . $item . '</th>';
          $startIndex = 0;
        } else {
          foreach ($data[0] as $item) $thead .= '<th>' . $item . '</th>';
          $startIndex = 1;
        }
        $thead .= '</tr></thead>';
      # Create TBODY
        $tbody = '<tbody>';
        $rowCount = 0;
        for ($i = $startIndex; $i < count($data); $i++) {
          $tbody .= '<tr>';
          if ($autonumbering) $tbody .= '<td>' . ++$rowCount . '</td>';
          foreach($data[$i] as $item) $tbody .= '<td>' . $item . '</td>';
          $tbody .= '</tr>';
        }
        $tbody .= '</tbody>';
      # Create full table
        if ($attributes) {
          $table = '<table ' . $attributes . '>';
        } else {
          $table = '<table>';
        }
        $table .= $thead . $tbody . '</table>';
      # Create cache file
        file_put_contents($cache, $table);
      }
    }
    if ($echo) {
      echo $table;
    } else {
      return $table;
    }
  }
}

?>