getsimple-groupdocs-annotation-dotnet-source
======================================
GroupDocs.Annotation for .NET plugin for GetSimple CMS (Source code)

This module is designed based on the [GroupDocs' HTML5 PDF Annotation Library](http://groupdocs.com/dot-net/document-annotation-library) for .NET and allows you to seamlessly add document annotation capability into your GetSimple CMS. The module is 100% independent and can be used without any external dependencies and GroupDocs server calls.

Once installed, you'll be able to easily embed HTML5 annotation UI into any page within your GetSimple website. Users can then upload and annotate PDF and Microsoft Office documents online, right from the web page.

<strong>Please note.</strong> To use the module, you need to have a license for the GroupDocs.Annotation for .NET library. If you don't have one, please [contact sales](http://groupdocs.com/corporate/contact) for a free evaluation copy.

### CMS Installation:
 * Download CMS package
 * Upload all files to your virtual host.
 * Access vhostname (for example - getsimple/) and you will be redirected to http://getsimple/admin/install.php
 * Check requirements and continue installation if all is ok.
 * Enter website name, username and email (password will be generated dinamically)
 * Check admin password and you are all set.

### Plugin installation:
 * Upload plugin's files to getsimplewebfolder/plugins/
 * Go to http://getsimple/admin/plugins.php (Plugin tab in the admin panel) and check plugins list.
 * You can deactivate/activate plugins. By default installed plugin is activated so you can start to use it.

###[Sign, Manage, Annotate, Assemble, Compare and Convert Documents with GroupDocs](http://groupdocs.com)
* [Annotate Microsoft Office documents, PDFs and images online](http://groupdocs.com/dot-net/document-annotation-library)
* [Download Annotation plugin package here](https://github.com/groupdocs/getsimple-groupdocs-annotation-dotnet)
* [See package for GroupDocs Annotation plugin for GetSimple CMS](https://github.com/groupdocs/getsimple-groupdocs-annotation-dotnet-source)



###Created by [GroupDocs Marketplace Team](http://groupdocs.com/marketplace).
