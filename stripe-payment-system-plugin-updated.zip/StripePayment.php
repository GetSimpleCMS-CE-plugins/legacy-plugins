<?php
/*
Plugin Name: Stripe Payments
Description: Allows Stripe Payments Via Buttons
Version: 1.0
Author: Kyle Buttress
Author URI: http://www.LukCon.com/
*/
 
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
$stripe_config_file = GSDATAOTHERPATH .'stripeconfig.xml';

# register plugin
register_plugin(
	$thisfile, //Plugin id
	'Stripe Payment', 	//Plugin name
	'0.8', 		//Plugin version
	'Kyle Buttress',  //Plugin author
	'http://www.lukcon.com/', //author website
	'Sends Payments to a Stripe Account Via Buttons', //Plugin description
	'plugins', //page type - on which admin tab to display
	'stripe_payments_show'  //main function (administration)
);
  
# add a link in the admin tab 'theme'
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Stripe Payments'));
register_script('jquery', "//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js", "3.3.1", FALSE);
register_script('jquery-ui',"ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js", "1.12.1",FALSE);
	
register_script('fancybox', "https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.6/dist/jquery.fancybox.min.js", "3.5.6",FALSE);
register_style('fancybox-css', "https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.6/dist/jquery.fancybox.min.css", "3.5.6", 'screen');

register_script('StripeBoxConfig', $SITEURL . 'plugins/StripePayment/js/StripeBoxConfig.js', '1.0', TRUE);

queue_script('jquery', GSFRONT);
queue_script('fancybox', GSFRONT);
queue_style('fancybox-css',GSFRONT);

queue_script('StripeBoxConfig', GSFRONT);

# functions
function stripe_payments() {
global $stripe_config_file, $ct_pk, $ct_sk,$ct_bn,$ct_bv, $ct_bd, $ct_it;

	if (file_exists($stripe_config_file)) {
		
		$x = getXML($stripe_config_file);
			$ct_pk = $x->pk; 
			$ct_sk = $x->sk;
			$ct_bn = $x->bn;
			$ct_bv = $x->bv;
			$ct_bd = $x->bd;
			$ct_bd = $x->it;
            $ct_language = $x->language;
		//
		
		$something = 0;
		
		if(isset($_GET['buyForm'])) {
		 $something =  $_GET['buyForm'];
		}
		
		if($something == 1) {
		
			loadStripeForm();
		}
		else {
				//echo '<a id="stripe" class="strframe" href="#sform"><button> '.$ct_bn.' '.$ct_bv.'</button></a><br>';
				echo "<div id='sform' style='display:none;'> ";
					loadForm();
				echo "</div>"; 
		}
		
		
	}
	else {
		echo "Configuration Not done";
	}
}
 
if (file_exists($stripe_config_file)) {
			$x = getXML($stripe_config_file);
			$ct_pk = $x->pk; 
			$ct_sk = $x->sk;
			$ct_bn = $x->bn;
			$ct_bv = $x->bv;
			$ct_bd = $x->bd;
			$ct_it = $x->it;
                        $ct_language = $x->language;


	}
	else {
            $ct_pk = "Public Key"; 
			$ct_sk = "Secret Key";
			$ct_bn = "Name of Payment Button";
			$ct_bv = "$ 10.00 amount";
			$ct_bd = "Description of your payment";
			$ct_it = "invoice tag";
                        $ct_language = "en_US";
        }

i18n_merge($thisfile,$ct_language);

function stripe_payments_show() {

global $stripe_config_file, $ct_pk, $ct_sk,$ct_bn,$ct_bv, $ct_bd, $ct_it;

$data = getXML($stripe_config_file);

	if($_GET['action'] == 'delete') {
		removeButton($_GET['bid'], $data);
	}
	if($_GET['action'] == 'edit') {
		stripe_payments_show_single($_GET['bid'], $data);
	}
	else if($_GET['action'] == 'new') {
		stripe_payments_show_single('new', '');
	}
	else {
	
	$data = getXML($stripe_config_file);

	  if($data) {
		$componentsec = $data->item;
		
		if($success) { 
			echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
		} 
		if($error) { 
			echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
		}	
	
		echo "<p><h3>Stripe Settings</h3></p>";
		echo "<p>version 0.8</p>";
		echo "<p>This plugin will allow you set up payment buttons to display on your site for taking payments via the Stripe Payment Gateway.</p>";
		echo "<p>This version adds the ability to add multiple buttons.</p>";
		if (count($componentsec) != 0) {
			echo "<table>";
				echo "<tr bgcolor='#ccc'><td>Title</td><td>Description</td><td>Action</td><td bgcolor='#63C98D' align='center'><a href='load.php?id=StripePayment&action=new&bid=new' class='current'> Add New </a></td></tr>";
				foreach ($componentsec as $component) {
				 echo "<tr>";
					echo "<td> ";
						echo "".$component->bn;
					echo "</td> ";
					echo "<td> ";
						echo "".$component->bd;
					echo "</td> ";
					echo "<td align='center'> ";
						echo "<a href='load.php?id=StripePayment&action=edit&bid=".$component->bid."'> Edit </a>";
					echo "</td> ";
					 echo "<td align='center'> ";
						echo "<a href='load.php?id=StripePayment&action=delete&bid=".$component->bid."' class='cancel toggleEnable'> Delete </a>";
					echo "</td> ";
					echo "</tr>";
					echo"<tr>";
					echo "<td colspan='4' bgcolor='#D3D3D3' align='center'>Embed with [ &lt;a id='str-".$component->bid."' class='strframe' href='#sform'&gt&lt;button&gt".$component->bn."&lt;/button&gt&lt;/a&gt ]</td>";
				  echo "</tr>";
				}
	
			echo "</table>";
	
		  }
		  else {
			echo "<p class='.section blockquote'>It looks like you have no buttons click to <a href='load.php?id=StripePayment&action=new&bid=new' class='current'> Add New </a></p>";
		  } 
		
		echo "<br><div id='showButton'>To add your button in any page copy and paste the relevant button code into the source of you page.</div>";	
		 echo "<br><div id='side'>Make sure you add this in all pages using the side bar code, add the following to your template.<br><br> <blockquote><code> &lt;?PHP stripe_payments(); ?&gt</code></blockquote></div>";
		 
		 }
		else {
		
			echo "<p class='.section blockquote'>It looks like you have no buttons click to <a href='load.php?id=StripePayment&action=new&bid=new' class='current'> Add New </a></p>";

		
		}
	}
}

function stripe_payments_show_multiple() {

}

function stripe_payments_show_single($bid = '', $data = '') {

global $stripe_config_file, $ct_pk, $ct_sk,$ct_bn,$ct_bv, $ct_bd, $ct_it;

// submitted form
	if (isset($_POST['submit'])) {		
		$ct_bn = isset($_POST['bn']) ? $_POST['bn'] : $ct_bn;
		$ct_bv = isset($_POST['bv']) ? $_POST['bv'] : $ct_bv;
		$ct_bd = isset($_POST['bd']) ? $_POST['bd'] : $ct_bd;	
		$ct_pk = isset($_POST['pk']) ? $_POST['pk'] : $ct_pk;
		$ct_sk = isset($_POST['sk']) ? $_POST['sk'] : $ct_sk;
		$ct_it = isset($_POST['it']) ? $_POST['it'] : $ct_it;
		$bid = isset($_POST['bid']) ? $_POST['bid'] : $ct_bid;
		$new = isset($_POST['new']) ? $_POST['new'] : "";
		$ct_language = isset($_POST['language']) ? $_POST['language'] : $ct_language;
		# if there are no errors, Save data
		if (!$error) {
		
			$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><items></items>'); 
	
			$count = 1;
			$data = getXML($stripe_config_file);
			$items = $data->item;
			if(sizeof($items) > 0) {
				foreach ($items as $item) {	
					if($item->bid != $bid) {
						$addItem = $xml->addChild('item');
						 $addItem->addChild('bid', $item->bid);
						 $addItem->addChild('pk', $item->pk);
						 $addItem->addChild('sk', $item->sk);
						 $addItem->addChild('bn', $item->bn);
						 $addItem->addChild('bv', $item->bv);
						 $addItem->addChild('bd', $item->bd);
						 $addItem->addChild('it', $item->it);
						 $addItem->addChild('language', $item->language);
			
					}
					else {
						$addItem = $xml->addChild('item');
						 $addItem->addChild('bid', $bid);
						 $addItem->addChild('pk', $ct_pk);
						 $addItem->addChild('sk', $ct_sk);
						 $addItem->addChild('bn', $ct_bn);
						 $addItem->addChild('bv', $ct_bv);
						 $addItem->addChild('bd', $ct_bd);
						 $addItem->addChild('it', $ct_it);
						 $addItem->addChild('language', $ct_language);
					}
					
				}
			}
			if($new == "new") {
					$addItem = $xml->addChild('item');
					 $addItem->addChild('bid', $bid);
					 $addItem->addChild('pk', $ct_pk);
					 $addItem->addChild('sk', $ct_sk);
					 $addItem->addChild('bn', $ct_bn);
					 $addItem->addChild('bv', $ct_bv);
					 $addItem->addChild('bd', $ct_bd);
					 $addItem->addChild('it', $ct_it);
					 $addItem->addChild('language', $ct_language);

			}

			XMLsave($xml, GSDATAOTHERPATH."stripeconfig.xml");

			if (! $xml->asXML($stripe_config_file)) {
				$error = i18n_r('CHMOD_ERROR');
			} else {
				$x = getXML($stripe_config_file);
				$ct_bn = $x->bn; 
				$ct_bv = $x->bv;
				$ct_bd = $x->bd;
				$ct_pk = $x->pk;
				$ct_sk = $x->sk;
				$ct_it = $x->it;
				$bid = $x->bid;
				$ct_language = $x->language;
				
				$success = i18n_r('SETTINGS_UPDATED');
			}
		}
	}

      if($success) { 
		echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
	} 
	if($error) { 
		echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
	}	
	
	if($bid && $data) {
	
		//assume this is edit data
		
		$items = $data->item;
		
		foreach($items as $item) {
		
			if($bid == $item->bid) {
				$ct_bn = $item->bn; 
					$ct_bv = $item->bv;
					$ct_bd = $item->bd;
					$ct_pk = $item->pk;
					$ct_sk = $item->sk;
					$ct_it = $item->it;
					$ct_language = $V->language;
			}
		}
	}
	
	if($bid == 'new') {
		$action = $bid;
		$bid = mt_rand(100,999);
	}

       echo"<form method='post' action='". $_SERVER ['REQUEST _URI']."'>";
	echo "<p><h3>Stripe Settings</h3></p>";
	echo "<p>version 0.8</p>";
	echo "<p align='right'><a href='load.php?id=StripePayment'>Back</a></p>";
	echo "<p>This plugin will allow you set up currently a single button to display on your site for taking payments via the Stripe Payment Gateway.</p>";
	echo "<p>The intention is to allow more buttons that will be configurable in this settings area. In the current version there is only 1 button in use.</p>";
    echo"<p><label for='name' >Name</label><input id='name' name='bn' class='text' value='".$ct_bn."'></p>";
	echo "<p><label for='value' >Value (10.00 with decimal)</label><input id='value' name='bv' class='text' value='".$ct_bv."'></p>";
	echo "<p><label for='describe' >Description</label><input id='describe' name='bd' class='text' value='".$ct_bd."'></p>";
	echo "<p><label for='publickey' >Public Key</label><input id='pk' name='pk' class='text' value='".$ct_pk."'></p>";
	echo "<p><label for='secretkey' >Secret Key</label><input id='sk' name='sk' class='text' value='".$ct_sk."'></p>";
	echo "<p><label for='invtag' >Invoice Tag</label><input id='it' name='it' class='text' value='".$ct_it."'></p>";
	echo "<input id='language' type='hidden' name='language' value='".$ct_language."'>";
	echo "<input id='bid' type='hidden' name='bid' value='".$bid."'>";
	echo "<input id='new' type='hidden' name='new' value='".$action."'>";
    echo "<input type='submit' id='submit' class='submit' value='Save' name='submit' />";
    echo"</form>";
    

}

function loadForm() {

		
	?>
				<iframe width='800' height='580' frameborder='0' id='stifs' src='./plugins/StripePayment/index.php?bid=<?PHP echo $bid; ?>'></iframe>
				<br>
			
	<?PHP
}

function loadStripeForm() {
global $stripe_config_file, $ct_pk, $ct_sk,$ct_bn,$ct_bv, $ct_bd, $ct_it;

			$x = getXML($stripe_config_file);
			$ct_pk = $x->pk; 
			$ct_sk = $x->sk;
			$ct_bn = $x->bn;
			$ct_bv = $x->bv;
			$ct_bd = $x->bd;
			$ct_it = $x->it;
            $ct_language = $x->language;


?>
 Nothing here.

<?PHP

}

function removeButton($bid, $data) {

	echo "<p style='color:#669933;'><b>Removing button ".$bid."</b></p>";
	
	$items = $data->item;
	
	$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><items></items>'); 
	
	$count = 1;
	
	foreach ($items as $item) {	
		if($item->bid != $bid) {
			$addItem = $xml->addChild('item');
			 $addItem->addChild('bid', $item->bid);
			 $addItem->addChild('pk', $item->pk);
			 $addItem->addChild('sk', $item->sk);
			 $addItem->addChild('bn', $item->bn);
			 $addItem->addChild('bv', $item->bv);
			 $addItem->addChild('bd', $item->bd);
			 $addItem->addChild('it', $item->it);
			 $addItem->addChild('language', $item->language);

		}
	}
	XMLsave($xml, GSDATAOTHERPATH."stripeconfig.xml");
	
	
}

function editButton($bid, $data) {

	echo "<p style='color:#669933;'><b>Edit this button button ".$bid."</b></p>";
}

?>