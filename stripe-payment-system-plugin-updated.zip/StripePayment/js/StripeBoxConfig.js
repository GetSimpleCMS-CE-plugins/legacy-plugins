jQuery.noConflict();
jQuery(document).ready(function() {
		jQuery(".strframe").click(function () {
			var idVal = jQuery(this).attr('id');
			var id = idVal.split("-");
			var stifs = jQuery('#stifs');
			stifs.attr('src', './plugins/StripePayment/index.php?bid='+id[1]);
		});
    	jQuery(".strframe").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});
	  jQuery('a.inline').fancybox({
       'hideOnContentClick': true
       });
     
}); 