<?php 
// Light Theme Lang. File
$i18n = array(
	'MASTERCOLORS'	=>		'Kolor główny',
	'BODYCOLOR'		=>		'Body Kolor',
	'MODERN'		=>		'nowoczesna przeglądarka plików?',
	'LEFTSIDE'		=>		'Sidebar po lewej?',
	'FONTAWESOME'	=>		'zaimportuj czcionki google by użyć',
	'FONTFAMILY'	=>		'wklej font-family:',
	'FONTSIZEBODY'	=>		'Określ główny rozmiar czczionki: ',
	'FONTSIZEHEADER' =>		'Określ główny rozmiar nagłówków: ',
	'MAINCONTENTH3'	=>		'okreśł rozmiar czczionki H3: ',
	'CUSTOMSTYLE'	=>		'Dodaj własne style jeśli się na tym znasz: ',
	'SAVESETTING'	=>		'Zapisz ustawienia',
	'LIGHTTHEMENAME' =>		'Light Theme Ustawienia',
	'MODERNMODE'	=>		'Nowoczesny tryb' ,
	'CLASSICMODE'	=>		'Klasyczny tryb',
	'RIGHTSIDE'		=>		'Po prawej' ,
	'LEFTSIDE'		=>		'Po lewej',
);

?>