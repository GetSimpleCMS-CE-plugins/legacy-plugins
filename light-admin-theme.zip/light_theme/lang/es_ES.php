<?php 
// Light Theme Lang. File
$i18n = array(
	'MASTERCOLORS'	=>		'Color principal',
	'BODYCOLOR'		=>		'Color del cuerpo',
	'MODERN'		=>		'¿Utilizar vista de archivos moderna?',
	'LEFTSIDE'		=>		'¿Mover el menú de la barra lateral a la izquierda?',
	'FONTAWESOME'	=>		'¡Las fuentes son impresionantes! ¡Mira estas y diviértete!',
	'FONTFAMILY'	=>		'Utilizar familia de fuentes:',
	'FONTSIZEBODY'	=>		'Tamaño de fuente del cuerpo:: ',
	'FONTSIZEHEADER' =>		'Tamaño de fuente del encabezado: ',
	'MAINCONTENTH3'	=>		'Contenido principal H3 fuente tamaño: ',
	'CUSTOMSTYLE'	=>		'CSS personalizado: ',
	'SAVESETTING'	=>		'Guardar ajustes',
	'LIGHTTHEMENAME' =>		'Ajustes de tema Light ',
	'MODERNMODE'	=>		'Modo moderno' ,
	'CLASSICMODE'	=>		'Modo clásico',
	'RIGHTSIDE'		=>		'Lado derecho' ,
	'LEFTSIDE'		=>		'Lado izquierdo',
);

?>