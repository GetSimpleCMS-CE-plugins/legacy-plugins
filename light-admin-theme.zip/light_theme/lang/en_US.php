<?php 
// Light Theme Lang. File
$i18n = array(
	'MASTERCOLORS'	=>		'Main Color',
	'BODYCOLOR'		=>		'Body Color',
	'MODERN'		=>		'Use modern file-browser view?',
	'LEFTSIDE'		=>		'Move Sidebar-Menu to the left?',
	'FONTAWESOME'	=>		'Fonts are awesome!! Check these out and have fun!',
	'FONTFAMILY'	=>		'Use font-family:',
	'FONTSIZEBODY'	=>		'Body font-size: ',
	'FONTSIZEHEADER' =>		'Header font-size: ',
	'MAINCONTENTH3'	=>		'Maincontent H3 font-size: ',
	'CUSTOMSTYLE'	=>		'Custom CSS: ',
	'SAVESETTING'	=>		'Save Settings',
	'LIGHTTHEMENAME' =>		'Light Theme Settings',
	'MODERNMODE'	=>		'Modern mode' ,
	'CLASSICMODE'	=>		'Classic mode',
	'RIGHTSIDE'		=>		'Right side' ,
	'LEFTSIDE'		=>		'Left side',
);

?>