<?php $i18n = array(	'DESCRIPTION' => 'Zet uw site in "Onderhoudsmodus".',	'CHECKBOX' => '"Onderhoudsmodus" Aan/Uit.',);
?>