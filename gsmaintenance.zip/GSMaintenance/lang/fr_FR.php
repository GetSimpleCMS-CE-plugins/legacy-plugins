<?php $i18n = array(	'DESCRIPTION' => 'Mettez votre site en "Mode Maintenance".',	'CHECKBOX' => 'Aciver/Désactiver le "Mode Maintenance".',);
?>