<?php $i18n = array(	'DESCRIPTION' => 'Put your site in "Maintenance Mode".',	'CHECKBOX' => 'Enable/Disable "Maintenance Mode".',);
?>