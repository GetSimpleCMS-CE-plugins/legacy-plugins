<?php
/**
 * English Language File for The Photo Gallery Plugin
 *
 * Date:				30 Apr 2011
 * Revision:		
 * Version:			GetSimple 3.0
 * Traductors: 	Chris Cagle 
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	
	"PLUGIN_TITLE"=>  "The Photo Gallery",
	"PLUGIN_DESC" =>  "A photo gallery based on an uploads folder",
	"PLUGIN_BODY"	=>	"Choose the folder within your <a href='upload.php' target='_blank'>Uploads</a> directory that you want to be the root of your photo gallery. Leave this blank if you want to make the base <code>/uploads/</code> folder your photo gallery.",
	"PHOTO_GALLERY" => "Photo Gallery",
	"PHOTOS" => "Photos",
	"ALBUMS" => "Albums",
	"DIRECTIONS" => "Directions &amp; Support",
	"VIEW_ALBUM" => "View Album",
	"EMPTY_FOLDER" => "Empty Album",
	"SHOW_EMPTY_ALBUMS" => "Show empty albums?",
	"GALLERY_FOLDER" => "Photo Gallery Folder",
	"THUMB_SIZE" => "Thumbnail Size",
);