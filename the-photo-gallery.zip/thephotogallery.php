<?php
/*
Plugin Name: The Photo Gallery
Description: A photo gallery based on an uploads folder
Version: 1.5
Author: Chris Cagle
*/

# get correct id for plugin
$thisfile_tphotogall=basename(__FILE__, ".php");
$photogallery_file=GSDATAOTHERPATH .'thephotogallery.xml';

# add in this plugin's language file
i18n_merge($thisfile_tphotogall,'en_US');

# register plugin
register_plugin(
	$thisfile_tphotogall, 
	i18n_r($thisfile_tphotogall.'/PLUGIN_TITLE'),
	'1.5', 
	'Chris Cagle',
  'http://www.cagintranet.com/',
	i18n_r($thisfile_tphotogall.'/PLUGIN_DESC'), 
	'settings',  # Page type of plugin
	'the_photo_gallery_setup'
);

# get XML data
if (file_exists($photogallery_file)) {
  $x = getXML($photogallery_file);
  $foldergallery = $x->folder;
  $thumbnailsize = $x->thumbsize;
  $showemptyalbums = $x->showempty;
} else {
  $foldergallery = '';
  $thumbnailsize = 100;
  $showemptyalbums = 'false';
} 

/* check for cache directory existance */
if (!file_exists(GSROOTPATH. 'data/cache/')) {
	mkdir(GSROOTPATH. 'data/cache/', 0777);
}

/*
 * Actions / Filters
 */
add_action('settings-sidebar', 'createSideMenu', array($thisfile_tphotogall, i18n_r($thisfile_tphotogall.'/PLUGIN_TITLE')));
add_filter('content','the_photo_gallery_check');
add_action('theme-header','the_photo_gallery_header');
add_action('header','the_photo_gallery_admin_header');

/*
 * ShortCode Detection Script
 */
function the_photo_gallery_check($contents) { 
	 	
  $tmpContent = $contents;
  $pattern = '/\(%(.*)the_photo_gallery(.*)%\)/i';
	preg_match($pattern,$tmpContent, $matches);
	if (empty($matches)) {    
  	return $contents;
	} else {
		add_filter('header','the_photo_gallery_header');
		$photogallerycode = get_the_photo_gallery();
		$tmpContent = preg_replace($pattern,$photogallerycode,$tmpContent); 
		return $tmpContent;
	}
	
}


/*
 * Plugin Control Panel
 */
function the_photo_gallery_setup() {
	global $photogallery_file, $foldergallery, $thumbnailsize, $thisfile_tphotogall, $showemptyalbums;
	
  if (isset($_POST['submit'])) {
    if ($_POST['foldergallery'] != '') {
	    $foldergallery = tsl($_POST['foldergallery']);
	  } else {
	  	$foldergallery = '';
	  }
	  if ($_POST['thumbnailsize'] != '') {
	    $thumbnailsize = (int)$_POST['thumbnailsize'];
	  } else {
	  	$thumbnailsize = 100;
	  }
	  if (isset($_POST['showemptyalbums'])) {
	    $showemptyalbums = 'true';
	  } else {
	  	$showemptyalbums = 'false';
	  }
          
    # if there are no errors, save data
    if (!$error) {
      $xml = @new SimpleXMLElement('<item></item>');
      $xml->addChild('folder', $foldergallery);
      $xml->addChild('thumbsize', $thumbnailsize);
      $xml->addChild('showempty', $showemptyalbums);
      
      if (! $xml->asXML($photogallery_file)) {
        $error = i18n_r('CHMOD_ERROR');
      } else {
        $x = getXML($photogallery_file);
        $foldergallery = $x->folder;
        $thumbnailsize = $x->thumbsize;
        $showemptyalbums = $x->showempty;
        $success = i18n_r('SETTINGS_UPDATED');
      }
    }
  }
  
  ?>
  <h3><?php i18n($thisfile_tphotogall.'/PLUGIN_TITLE'); ?></h3>
  
  <?php 
  if($success) { 
    echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
  } 
  if($error) { 
    echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
  }
  
  $alluploadfolders = dir_tree(GSDATAUPLOADPATH); $select = null;
  foreach ($alluploadfolders as $sub) {
  	$sub = tsl(str_replace(GSDATAUPLOADPATH .'/', '', $sub));
  	$select .= '<option value="'.$sub.'" '.check_select($foldergallery, $sub, false).'>'.$sub.'</option>';
  }
  ?>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8'); ?>">
  	<p><?php i18n($thisfile_tphotogall.'/PLUGIN_BODY'); ?> <a href="http://get-simple.info/extend/plugin/the-photo-gallery/151/" target="_blank" ><?php i18n($thisfile_tphotogall.'/DIRECTIONS'); ?></a></p>
    <p><label for="foldergallery"><?php i18n($thisfile_tphotogall.'/GALLERY_FOLDER'); ?>:</label>
    	<code>/uploads/</code>&nbsp;<select id="foldergallery" name="foldergallery" class="text" style="width:325px" />
    		<?php echo $select; ?>
    	</select> &nbsp; <a href="upload.php?path=<?php echo $foldergallery; ?>"><?php i18n("UPLOAD"); ?></a>
    </p>
    <p><label for="thumbnailsize"><?php i18n($thisfile_tphotogall.'/THUMB_SIZE'); ?>:</label><input type="text" id="thumbnailsize" name="thumbnailsize" class="text" value="<?php echo $thumbnailsize; ?>" style="width:30px" /> <code>px</code></p>
    <?php $chk_empty = null; if ($showemptyalbums == 'true') $chk_empty = 'checked'; ?>
    <p><label for="showemptyalbums"><?php i18n($thisfile_tphotogall.'/SHOW_EMPTY_ALBUMS'); ?> &nbsp;<input type="checkbox" id="showemptyalbums" name="showemptyalbums" value="true" <?php echo $chk_empty; ?> /></label></p>
    <p><input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" /></p>
  </form>
  <?php
}


/*
 * Show The Photo Gallery
 *
 * called from a template file
 */
function the_photo_gallery() {
	echo get_the_photo_gallery();
}


/*
 * Generate The Photo Gallery
 *
 * called from a shortcode install
 */
function get_the_photo_gallery($folder = null) {
  global $foldergallery, $thumbnailsize, $SITEURL, $thisfile_tphotogall, $showemptyalbums;
  
	$allowed_exts = array('jpg', 'png', 'gif', 'jpeg', 'JPG', 'PNG', 'JPEG', 'GIF');
	if (!$folder) {
		$folder = $_GET['album'];
	}
	
	if ($folder) {
		$folder = tsl($folder);
	}
	$abs_folder = GSDATAUPLOADPATH . $foldergallery . $folder;
	
  $files = array(); $folders = array();
  if($handle = opendir($abs_folder)) {
    while(false !== ($file = readdir($handle))) {
      $extension = pathinfo(GSDATAUPLOADPATH . $foldergallery . $file, PATHINFO_EXTENSION);
      if($extension && in_array($extension,$allowed_exts)) {
        $files[] = $file;
      } elseif (is_dir(GSDATAUPLOADPATH . $foldergallery . $folder. $file) && $file != '.' && $file != '..') {
      	$folders[] = $file;
      }
    }
    closedir($handle);
  }
  $code = '<div id="the_photo_gallery">';
  $code .= '<h3>'.name_convert($folder).'</h3>';
  
  # breadcrumbs
  if (strpos($folder, '/')) {
	  $code .= '<div id="the_photo_gallery_breadcrumbs">';
	  $crumbs = explode('/', $folder);
	  $baseurl = trim(remove_querystring_var($_SERVER['REQUEST_URI'], 'album'), '/');
	  $code .= '<a href="'.$baseurl.'" >'.i18n_r($thisfile_tphotogall.'/PHOTO_GALLERY').'</a> &raquo; ';
	  $crumbadd = null;
	  foreach ($crumbs as $crumb) {
	  	if ($crumb != '') { 
		  	if ($crumbadd) {
		  		$crumbadd = $crumbadd.'/'.$crumb;
		  	} else {
		  		$crumbadd = $crumb;
		  	}
		  	if (name_convert($crumb) == name_convert($folder)) {
		  		$code .= '<strong>'.name_convert($crumb).'</strong>';
		  	} else {
		  		$code .= '<a href="'.add_querystring_var($baseurl, 'album', $crumbadd).'" >'.name_convert($crumb).'</a> &raquo; ';
		  	}
		  }
	  }
	  $code .= '</div>';
  }  
  
  # Show available albums
  if (count($folders) > 0) {
  	$code .= '<div id="the_photo_gallery_albums" class="clearfix" >';
	  foreach ($folders as $album) {
	  	$abs_folder_temp = GSDATAUPLOADPATH . $foldergallery . $folder.$album;
			$album_url = add_querystring_var($_SERVER['REQUEST_URI'], 'album', $folder.$album);
			$img_temp = null; $img_count = 0; $album_count = 0;
			if($handle_tmp = opendir($abs_folder_temp)) {
	  		while(false !== ($f = readdir($handle_tmp))) {
	  			$extension = pathinfo($abs_folder_temp .'/'. $f, PATHINFO_EXTENSION);
	  			if($extension && in_array($extension,$allowed_exts)) {
		        $img_temp = $f;
						$img_count++;
		      } elseif (is_dir($abs_folder_temp .'/'. $f) && $f != '.' && $f != '..') {
		      	$album_count++;
		      }
	  		}
	    }
	    closedir($handle_tmp);
	    $image_url_temp = $SITEURL.'data/uploads/'.$foldergallery . $folder.$album .'/'. $img_temp;
	    if ($album_count > 0) {
	    	$album_count = '<strong>'.$album_count.'</strong> '.i18n_r($thisfile_tphotogall.'/ALBUMS').'<br />';
	    } else {
	    	$album_count = null;
	    }
	    if ($img_count > 0) {
	    	$img_count = '<strong>'.$img_count.'</strong> '.i18n_r($thisfile_tphotogall.'/PHOTOS').'<br />';
	    } else {
	    	$img_count = null;
	    	$image_url_temp = $SITEURL.'plugins/'.$thisfile_tphotogall.'/empty.png';
	    }
	    if (!$img_count && !$album_count) {
	    	$empty_count = '<em>'.i18n_r($thisfile_tphotogall.'/EMPTY_FOLDER').'</em><br />';
	    	$show_album = false;
	    } else {
	    	$empty_count = null;
	    	$show_album = true;
	    }
			
			
			if ($showemptyalbums == 'true') $show_album = true;

			if ($show_album) {
				$code .= '<p class="clearfix" ><a href="'.$album_url.'" class="thumbnail" />
				<img src="'.$SITEURL.'plugins/'.$thisfile_tphotogall.'/timthumb.php?src='.$image_url_temp.'&amp;w='.$thumbnailsize.'&amp;h='.$thumbnailsize.'" alt="" /></a>
				<strong class="tpg_title">'.name_convert($album).'</strong><br />
				'. $album_count . $img_count . $empty_count .'<a href="'.$album_url.'">'.i18n_r($thisfile_tphotogall.'/VIEW_ALBUM').'</a>
				</p>';
			}
	  }
	  $code .= '</div>';
	}
  
  # Show image gallery
  if (count($files) > 0) {
	  $code .= '<div id="the_photo_gallery_photos" class="clearfix" >';
	  foreach ($files as $image) {
	  	$image_url = $SITEURL.'data/uploads/'.$foldergallery . $folder . $image;
	  	$code .= '<a href="'.$image_url.'" class="thumbnail" rel="tpgallery" ><img src="'.$SITEURL.'plugins/'.$thisfile_tphotogall.'/timthumb.php?src='.$image_url.'&amp;w='.$thumbnailsize.'&amp;h='.$thumbnailsize.'" alt="" /></a>';
	  }
	  $code .= '</div>';
	}
  
  $code .= '</div>';
  return $code;

}

/*
 * Generate The Photo Gallery Admin Header CSS/JS
 */
function the_photo_gallery_admin_header() {
	if( get_filename_id()=='upload') {
		global $SITEURL, $foldergallery, $thisfile_tphotogall;
		$icon = $SITEURL.'plugins/'.$thisfile_tphotogall.'/pic-icon.png';
		$header = '
		<script>
		jQuery(document).ready(function() { 
			$("#imageTable tr.'.trim($foldergallery, '/').' td img").attr("src", "'.$icon.'").css("opacity", .8);
			$(".crumbs:contains(\''.trim($foldergallery, '/').'\')").addClass("found-gallery");
			if($(".crumbs").hasClass("found-gallery")) {
				$("#imageTable tr td img").attr("src", "'.$icon.'").css("opacity", .8);
			}
		});
		</script>
		';
		echo $header;
	}
}

/*
 * Generate The Photo Gallery Header CSS/JS
 */
function the_photo_gallery_header() {
	global $GSADMIN, $SITEURL, $thumbnailsize;
	
	$header = '
	
	<!-- The Photo Gallery [start] -->
	<script type="text/javascript" src="'.$SITEURL . $GSADMIN.'/template/js/jquery.min.js"></script> 
	<script type="text/javascript" src="'.$SITEURL . $GSADMIN.'/template/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script> 
	<link rel="stylesheet" type="text/css" href="'.$SITEURL . $GSADMIN.'/template/js/fancybox/jquery.fancybox-1.3.4.css" media="screen" />	
	<script>
	jQuery(document).ready(function() { 
		if(jQuery().fancybox) {
			$("a[rel*=tpgallery]").fancybox();
		}
	});
	</script>
	<style>
		#the_photo_gallery h3 {margin:0 0 20px 0;}
		#the_photo_gallery, #the_photo_gallery_albums {margin:0 0 10px 0;}
		#the_photo_gallery_breadcrumbs {font-size:11px;margin:0 0 20px 0;padding:5px 10px;border:1px solid #ccc;background:#f6f6f6;}
		#the_photo_gallery a.thumbnail img {padding:3px;margin:0 10px 10px 0;}
		#the_photo_gallery_albums a.thumbnail img {float:left;margin-right:15px;max-height:80px;}
		#the_photo_gallery_albums p {margin:0;line-height:18px;font-size:12px;}
		#the_photo_gallery_albums p strong.tpg_title {line-height:25px;font-size:14px;}
		#the_photo_gallery em {font-style:italic;color:#666;}
		#the_photo_gallery a.thumbnail:link img, #the_photo_gallery a.thumbnail:visited img {border:1px solid #ccc;}
		#the_photo_gallery a.thumbnail:hover img, #the_photo_gallery a.thumbnail:focus img {border:1px solid #999;}
		.clearfix:before, .clearfix:after { content: "\0020"; display: block; height: 0; visibility: hidden; }
		.clearfix:after { clear: both; }
	</style>
	<!-- The Photo Gallery [end] -->
	
	';

	echo $header;
}

/*
 * Convert Folder Slug to Title Name
 */
function name_convert($str) {
	$str = trim($str, '/');
	if (strpos($str, '/')) {
		$str = strstr($str, '/');
		$str = substr(strrchr($str, "/"), 1);
		$strarray = explode('/', $str);
		//print_r($strarray);
	}
	$str = str_replace('_', "'", trim($str, "'"));
  $str = ucwords(str_replace('-', ' ', trim($str, '/')));
  return $str;
}

/*
 * General use functions
 */
function add_querystring_var($url, $key, $value) {
  $url = preg_replace('/(.*)(\?|&)' . $key . '=[^&]+?(&)(.*)/i', '$1$2$4', $url . '&');
  $url = substr($url, 0, -1);
  if (strpos($url, '?') === false) {
      return ($url . '?' . $key . '=' . $value);
  } else {
      return ($url . '&' . $key . '=' . $value);
  }
}
function remove_querystring_var($url, $key) {
  $url = preg_replace('/(.*)(\?|&)' . $key . '=[^&]+?(&)(.*)/i', '$1$2$4', $url . '&');
  $url = substr($url, 0, -1);
  return ($url);
}

function dir_tree($dir) {
	$path = '';
	$stack[] = $dir;
	while ($stack) {
	 $thisdir = array_pop($stack);
	 if ($dircont = scandir($thisdir)) {
	   $i=0;
	   while (isset($dircont[$i])) {
	     if ($dircont[$i] !== '.' && $dircont[$i] !== '..') {
	       $current_file = "{$thisdir}/{$dircont[$i]}";
	       if (is_dir($current_file) && $current_file != '.' && $current_file != '..') {
	         $path[] = "{$thisdir}/{$dircont[$i]}";
	         $stack[] = $current_file;
	       }
	     }
	     $i++;
	   }
	 }
	}
	return $path;
}
function check_select($i,$m,$e=true) {
  if ($i != null) { 
    if ( $i == $m ) { 
      $var = ' selected="selected" '; 
    } else {
      $var = '';
    }
  } else {
    $var = '';      
  }
  if(!$e) {
    return $var;
  } else {
    echo $var;
  }
}

