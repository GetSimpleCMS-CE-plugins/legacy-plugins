<?php
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Private Functions', 	# Title of plugin
	'0.1', 		# Version of plugin
	'Rolf J. Dietz',	# Author of plugin
	'http://www.rolfjdietz.de/', 	# Author URL
	'Run FUNCTIONS inside of page contents in specific TAG <br>(%function:myfirstfunction%) and put your functions at the end of the this plugin (plugins/functions.php)', 	# Plugin Description
	'', 	# Page type of plugin
	''  	# Function that displays content
);

# activate filter
add_filter('content','functions'); 

function functions($contents){
    $tmpContent = $contents;
	preg_match_all('/\(%(.*)function(.*):(.*)%\)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER); 
    $AlltoReplace = $tmpArr[count($tmpArr)-1];
    $totalToReplace = count($AlltoReplace);
    for ($x = 0;$x < $totalToReplace;$x++) {
       $targetfunction= str_replace('&nbsp;',' ',$AlltoReplace[$x]);
       $targetfunction = trim($targetfunction);      
      $substtext = script($targetfunction);
      $tmpContent = preg_replace("/\(%(.*)function(.*):(.*)$targetfunction(.*)%\)/i",$substtext,$tmpContent);      
    }    
  return $tmpContent;
}
function script($targetfunction){
	switch ($targetfunction) {
		case "myfirstfunction":			
			return "1111111111111";
			break;
		case "secondfunction":
			$variable="2222222222222";
			return $variable;
			break;
		case "function-blabla":
			return "bla bla";
			break;
	}
}


