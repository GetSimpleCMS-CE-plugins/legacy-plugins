<?php
/*
Plugin Name: Components Highlight
Description: 
      Подсветка синтаксиса в редакторе компонентов
      Syntax highlighting in the component editor
Version: 1.0
Author: Dmitry Korn
*/

/*
Максимальная высота полей редактора задаётся в:
The maximum height of the editor fields is set to:

components-syntax-highlight.css (max-height: px)
*/

# получение корректного идентификатора плагина
# getting the correct plugin ID
$thisfile = basename(__FILE__, ".php");

# регистрируем плагин в системе
# register the plugin in the system
register_plugin(
	$thisfile,										
	'Components Highlight', 	
	'1.0', 
	'Dmitry Korn',	
	'https://', 
	'Highlight the syntax in the component editor',
	'', 
	'' 
);

# добавляем хук
# add a hook	
if (pathinfo($_SERVER[SCRIPT_NAME])['filename'] == "components") {
	add_action('header', 'addCodeMirrorToComponents', array());
}

# регистрируем стили и скрипты
# register styles and scripts
register_script('codemirror', $SITEURL.$GSADMIN.'/template/js/codemirror/lib/codemirror-compressed.js', '0.2.0', FALSE);
register_style('codemirror-css',$SITEURL.$GSADMIN.'/template/js/codemirror/lib/codemirror.css','screen',FALSE);
register_style('codemirror-theme',$SITEURL.$GSADMIN.'/template/js/codemirror/theme/default.css','screen',FALSE);
register_style('components_highlight',$SITEURL.'plugins/components_highlight/css/components_highlight.css','screen',FALSE);

queue_script('codemirror', GSBACK);
queue_style('codemirror-css', GSBACK);
queue_style('codemirror-theme', GSBACK);
queue_style('components_highlight', GSBACK);

function addCodeMirrorToComponents() {
	echo '
    <script type="text/javascript">
    window.onload = function() {
		var components = document.querySelectorAll(".compdiv textarea");
		for (var i = 0, cnt = components.length; i < cnt; i++) {
			var newcomp = CodeMirror.fromTextArea(components[i], {
				lineNumbers: true,
				lineWrapping: false,
				matchBrackets: true,
				indentUnit: 4,
				indentWithTabs: true,
				enterMode: "keep",
				mode:"application/x-httpd-php",
				tabMode: "shift"
			});
		}
    }  
    </script>
	';
}
