<?php

function addGDJavaAnnotation($atts, $content = null) {
 extract(gdaj_shortcode_atts(array(
    "server" => null,
    "width" => null,
    "height" => null
  ), $atts));

  if ($width == 0) {
      $width = "650";
  }
  if ($height == 0) {
      $height = "500";
  }

  return '<div><iframe src="'.$server.'?referer=getsimple-annotation-java/1.0" frameborder="0" width="'.$width.'" height="'.$height.'"></iframe></div>';
}
gdaj_shortcode('GDJavaAnnotation','addGDJavaAnnotation', '[gd_java_annotation server="" width="" height="" /]');
