Title: Nivo Slider for I18N Gallery for GetSimple
Version: 0.9.5
Author: Alexander Amatuni
Description:
This pack adds Nivo Slider gallery type to the I18N Gallery plugin for GetSimple CMS.
http://get-simple.info
http://get-simple.info/extend/plugin/i18n-gallery/160/

Installation:
Unzip the contents of this zip file directly into the /plugins/i18n_gallery. 
Note, that in v1.0 /css/nivo-slider.css file has also changed (not only plugin_nivoSlider.php).

Usage:
Select nivoSlider type for your i18n gallery, set desired parameters and use it as any other i18n gallery.

Changelog:
1.0
- FIX: CSS styles are now used correctly (according to i18n_gallery settings).
- NEW: Option to select text for captions: from title or description or both. Also the captions can be switched off.
- NEW: Can write custom callback functions in gallery options.
- CHANGE: 'Default' slider theme is now default for new galleries.
- CHANGE: Options page cleaned and styled.

0.9.4
nivoSlider version bug fixed

0.9.3:
Fixed a problem with jQuery version (now uses 1.7.1 version from google CDN).
Removed empty function definitions from initialization source.