<?php
$i18n = array(
	# general
	'NAME' 			=> 		'Simple Thumbs',
	'DESCRIPTION' 	=> 		'Helps to regenerate thumbnails when needed.',
	# settings page
	'SETTINGS' 		=> 		'Simple Thumbs Settings',
	'IWIDTH' 		=> 		'Image width',
	'IWIDTHDESC'	=>		'Set maximum width of thumbnail in px. Default value is ',
	'IHEIGHT' 		=>		'Imahe height',
	'IHEIGHTDESC'	=>		'Set maximum height of thumbnail in px. Default value is 0 (auto).',
	'IWCUT'			=>		'Image cut width',
	'IWCUTDESC'		=>		'Set thumbnail cut width. Default value is 0 (do not cut).',
	'IHCUT'			=>		'Image cut height',
	'IHCUTDESC'		=>		'Set thumbnail cut height. Default value is 0 (do not cut).',
	'IQUALITY'		=>		'Image quality',
	'IQUALITYDESC'	=>		'Set thumbnail image quality in %. Default value is 65%.',
	'BATCH'			=>		'Images per batch',
	'BATCHDESC'		=>		'Set number of images that can be processed in single batch. Default value is 50.',
	'INTRO'			=>		'Introduction',
	'INSTRUCTIONS'	=>		'By default, images are resized to value set in gsconfig.php.
								Their height is always set based on width, so if you want to have images with max. height too, use "Image height".
								Image cut width/height can be used to crop thumbnails from top left corner and dimensions are calculated from ORIGINAL image dimensions, NOT THUMBNAILS.
								Image quality is by default 65% - set by GetSimple. Images per batch needs to be lowered, if % number gets stuck - process timed out. If server can handle more, you can increase this number.
								After the configuration is saved, you can find a "Reganerate thumbnails" button in Files sidebar.
								By clicking it, all thumbnails in CURRENT DIRECTORY will be regenerated. Navigate to desired folder to regenerate thumbnails as they are processed only within single directory.',
	
	# files page
	'REGENERATE'	=>		'Regenerate thumbnails',
	'CFGERROR'		=>		'Missing configuration file!',
	'JSERROR'		=>		'This plugin requires JavaScript to be enabled.',
	'PROCESSING'	=>		'Processing',
	'SUCCESS'		=>		'Successfuly processed',
	'THUMBNAILS'	=>		'thumbnails'
);