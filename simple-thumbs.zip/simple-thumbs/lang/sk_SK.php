<?php
$i18n = array(
	# general
	'NAME' 			=> 		'Simple Thumbs',
	'DESCRIPTION' 	=> 		'Pomáha pri regenerovaní náhľadov keď je to potrebné.',
	# settings page
	'SETTINGS' 		=> 		'Simple Thumbs Nastavenia',
	'IWIDTH' 		=> 		'Šírka náhľadu',
	'IWIDTHDESC'	=>		'Nastavte maximálnu šírku náhľadu v px. Základná hodnota je ',
	'IHEIGHT' 		=>		'Výška náhľadu',
	'IHEIGHTDESC'	=>		'Nastavte maximálnu výšku náhľadu v px. Základná hodnota je 0 (auto).',
	'IWCUT'			=>		'Šírka výrezu obrázka',
	'IWCUTDESC'		=>		'Nastavte šírku výrezu z obrázka. Základná hodnota je 0 (nevyrezávať).',
	'IHCUT'			=>		'Výška výrezu obrázka',
	'IHCUTDESC'		=>		'Nastavte výšku výrezu z obrázka. Základná hodnota je 0 (nevyrezávať).',
	'IQUALITY'		=>		'Kvalita náhľadu',
	'IQUALITYDESC'	=>		'Nastavte kvalitu náhľadov v %. Základná hodnota je 65%.',
	'BATCH'			=>		'Počet obrázkov na dávku',
	'BATCHDESC'		=>		'Nastavte počet obrázkov, ktoré je možné spracovať v jednom volaní. Základná hodnota je 50.',
	'INTRO'			=>		'Úvod',
	'INSTRUCTIONS'	=>		'Pri základnej konfigurácii sú obrázky zmenšené na veľkosť nastavenú v gsconfig.php.
								Ich výška je vždy vypočítaná zo šírky, takže ak chcete obrázky aj s maximálnou výškou, použite "Výška náhľadu".
								Šírka a výška výrezu môžu byť použité na orezanie náhľadov od ľavého horného rohu a rozmery sú vypočítavané z ORIGINÁLNEHO obrázka, NIE Z NÁHĽADU.
								Kvalita obrázkov je v základe 65% - ako v GetSimple. Počet obrázkov na dávku znížte v prípade, ak % ostanú stáť - procesu vypršal časový limit. Ak server zvláda viac, môžete toto číslo zvýšiť.
								Po uložení konfigurácie nájdete tlačidlo "Regenerovať náhľady" v bočnom paneli v časti Súbory.
								Po kliknutí na tlačidlo, všetky náhľady v AKTUÁLNEJ ZLOŽKE budú nanovo vygenerované. Vojdite do zložky, kde chcete aktualizovať náhľady keďže sú spracovávané iba v rámci jednej zložky.',
	
	# files page
	'REGENERATE'	=>		'Regenerovať náhľady',
	'CFGERROR'		=>		'Chýba konfiguračný súbor!',
	'JSERROR'		=>		'Tento zásuvný modul vyžaduje zapnutý JavaScript.',
	'PROCESSING'	=>		'Spracúvam',
	'SUCCESS'		=>		'Úspešne spracovaných',
	'THUMBNAILS'	=>		'náhľadov'
);