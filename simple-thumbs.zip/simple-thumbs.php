<?php
/*
Plugin Name: Simple Thumbs
Description: Helps to regenerate thumbnails when needed.
Version: 0.2
Author: morvy
Author URI: http://moped.jepan.sk/
*/
 
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

$configfile = GSDATAOTHERPATH . $thisfile . '.xml';

# merge i18n strings
i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');
 
# register plugin
register_plugin(
	$thisfile,
	i18n_r($thisfile.'/NAME'),
	'0.2',
	'morvy',
	'https://moped.jepan.sk/',
	i18n_r($thisfile.'/DESCRIPTION'),
	'plugins',
	'pmo_st_config'
);
register_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
queue_script('jquery', GSBACK);
if(basename($_SERVER['REQUEST_URI']) != "plugins.php" && pmo_st_allow_regenerate()) add_action('file-extras', 'pmo_st_javascript');
if(!empty($_REQUEST['action']) && $_REQUEST['action']=="process_thumbnails") {
	add_action('admin-pre-header', 'pmo_st_process_step');
}
add_action('header', 'pmo_st_add_mu_permissions');
add_action('header', 'pmo_st_styles');
if(pmo_st_allow_settings()) {
	add_action('plugins-sidebar','createSideMenu', array($thisfile, i18n_r('simple-thumbs/SETTINGS')));
}
if(pmo_st_allow_regenerate() && file_exists($configfile)) {
	add_action('files-sidebar','createSideMenu', array($thisfile, i18n_r('simple-thumbs/REGENERATE'),'regenerate'));
}
 
# Configuration functions
function pmo_st_config() {
	if(isset($_GET['regenerate'])) {
		echo '<div class="error"><p>'.i18n_r('simple-thumbs/JSERROR').'</p></div>';
	}
	if(!pmo_st_allow_settings()) die('Access not allowed!');
	global $configfile;
	
	if (!defined('GSIMAGEWIDTH')) {
		$width = 200; //New width of image  	
	} else {
		$width = GSIMAGEWIDTH;
	}
	
	if(file_exists($configfile)) {
        $st_data = getXML($configfile);
    }

	if(isset($_POST['submit'])) {
	   	$xml = @new SimpleXMLElement('<root></root>');
	   	foreach ($_POST as $key => $value) {
	   		if($key!="submit") {
	   			$xml->addChild($key, $value);
	   		}
	   	}
	   	if(!$xml->asXML($configfile)) {
			$error = i18n_r('CHMOD_ERROR');
		} else {
			$st_data = getXML($configfile);
			$success = i18n_r('SETTINGS_UPDATED');
		}
	}

	if(!empty($success)) {
		echo '<div class="updated"><p><b>'. $success .'</b></p></div>';
	}
	if(!empty($error)) {
		echo '<div class="error"><p><b>'. $error .'</b></p></div>';
	}
?>
	<h3>Simple Thumbs Settings</h3>
	<h4><strong><?php i18n('simple-thumbs/INTRO'); ?></strong></h4>
	<p><?php i18n('simple-thumbs/INSTRUCTIONS'); ?></p>
	<form method="POST" action="<?php echo $_SERVER["REQUEST_URI"] ?>">
		<div>
			<label for="max_x">
				<b><?php i18n('simple-thumbs/IWIDTH'); ?></b>
				<span><?php i18n('simple-thumbs/IWIDTHDESC'); echo $width; ?>.</span>
			</label>
			<input id="max_x" name="max_x" value="<?php echo (!empty($st_data->max_x)) ? $st_data->max_x : $width; ?>" type="number" min="10" max="2048" class="text" />
			<hr>
			<label for="max_y">
				<b><?php i18n('simple-thumbs/IHEIGHT'); ?></b>
				<span><?php i18n('simple-thumbs/IHEIGHTDESC'); ?></span>
			</label>
			<input id="max_y" name="max_y" value="<?php echo (!empty($st_data->max_y)) ? $st_data->max_y : '0'; ?>" type="number" min="0" max="2048" class="text" />
			<hr>
			<label for="cut_x">
				<b><?php i18n('simple-thumbs/IWCUT'); ?></b>
				<span><?php i18n('simple-thumbs/IWCUTDESC'); ?></span>
			</label>
			<input id="cut_x" name="cut_x" value="<?php echo (!empty($st_data->cut_x)) ? $st_data->cut_x : '0'; ?>" type="number" min="0" max="2048" class="text" />
			<hr>
			<label for="cut_y">
				<b><?php i18n('simple-thumbs/IHCUT'); ?></b>
				<span><?php i18n('simple-thumbs/IHCUTDESC'); ?></span>
			</label>
			<input id="cut_y" name="cut_y" value="<?php echo (!empty($st_data->cut_y)) ? $st_data->cut_y : '0'; ?>" type="number" min="0" max="2048" class="text" />
			<hr>
			<label for="quality">
				<b><?php i18n('simple-thumbs/IQUALITY'); ?></b>
				<span><?php i18n('simple-thumbs/IQUALITYDESC'); ?></span>
			</label>
			<input id="quality" name="quality" value="<?php echo (!empty($st_data->quality)) ? $st_data->quality : '65'; ?>" type="number" min="1" max="100" class="text" />
			<hr>
			<label for="batch">
				<b><?php i18n('simple-thumbs/BATCH'); ?></b>
				<span><?php i18n('simple-thumbs/BATCHDESC'); ?></span>
			</label>
			<input id="batch" name="batch" value="<?php echo (!empty($st_data->batch)) ? $st_data->batch : '50'; ?>" type="number" min="1" max="1000" class="text" />
		</div>
		<p>
			<input id="submit" class="submit" type="submit" name="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" />
		</p>
	</form>
<?php
}

# Multi-User permissions
function pmo_st_add_mu_permissions() {
  if (function_exists('add_mu_permission')) {
    add_mu_permission('pmo_st_config', i18n_r('Simple Thumbs Settings'));
	add_mu_permission('pmo_st_theme_button', i18n_r('Thumbnails Recreate button'));
  }
}

function pmo_st_allow_settings() {
  global $USR;
  if (function_exists('check_user_permission'))
    return check_user_permission($USR, 'pmo_st_config');
  else
    return true;
}

function pmo_st_allow_regenerate() {
  global $USR;
  if (function_exists('check_user_permission'))
    return check_user_permission($USR, 'pmo_st_theme_button');
  else
    return true;
}

# User functions
function pmo_st_process_step() {
	# get configuration and dependencies
	global $configfile; $i=0;
	include(GSADMININCPATH.'image.class.php');
	if(!file_exists($configfile)) die(i18n_r('simple-thumbs/CFGERROR'));
	$cfg = getXML($configfile);
	
	# prepare variables for processing
	if(isset($_REQUEST['path'])) {
		$path = $_REQUEST['path'];
		$dir = '/'.substr($path, strpos($path, '='));
	}
	else $dir = "";
	
	$step = intval($_REQUEST['step']);
	$batch = (!empty($cfg->batch)) ? $cfg->batch : 50;
	
	# scan for images, count offsets
	$images = glob(GSDATAUPLOADPATH.$dir.'/*.{jpg,jpeg,gif,png,JPG,JPEG,GIF,PNG}', GLOB_BRACE);
	$total = count($images);
	$steps = ceil($total/$batch);
	
	$start = $step*$batch;
	$stop = $start+$batch;
	if($stop>$total) $stop=$total;
	
	if($step<$steps) {
		# process thumbnails
		for($i==$start; $i<$stop; $i++) {
			$img = new Zubrag_image;
			
			# check for image dimensions and calculate height if needed
			$width	= intval($cfg->max_x);
			$height	= intval($cfg->max_y);
			
			if($height == 0) {
				$imgsize = getimagesize($images[$i]);
				$height = $imgsize[1]/$imgsize[0]*$width;
			}

			# initialize
			$img->max_x			= $width;
			$img->max_y			= $height;
			$img->cut_x			= intval($cfg->cut_x);
			$img->cut_y			= intval($cfg->cut_y);
			$img->quality		= intval($cfg->quality);
			$img->save_to_file	= true;

			# generate thumbnail
			ob_start();
			$img->GenerateThumbFile($images[$i], GSTHUMBNAILPATH . $dir . '/thumbnail.'. basename($images[$i]));
			unset($img);
			ob_end_clean();
		}
		$percentage = round(($step/$steps*100));
		$step++;
	}
	else {
		$step = "done";
		$percentage = 100;
	}
	
	
	$response = array(
		'step' => $step,
		'percentage' => $percentage,
		'count' => $total
	);
	
	echo json_encode($response);
	exit;
}

function pmo_st_javascript() {
?>
<script type="text/javascript">
	$(document).on('click', '#sb_simple-thumbs', function(e) {
		e.preventDefault();
		$this = $(this);
		$this.after('<li id="st_progress" class="plugin_sb"><a href="' + window.location.href + '"><?php i18n('simple-thumbs/PROCESSING'); ?>: <span id="st_percentage">0%</span></a></li>');
		process_step(0, window.location.href);
	});

	function process_step(step, path) {
		$.ajax({
			type: 'POST',
			url: path,
			data: {
				from: path,
				action: 'process_thumbnails',
				step: step
			},
			dataType: "json",
			success: function( response ) {
			console.log( response );
				if( 'done' == response.step ) {
					$('#st_percentage').text(response.percentage+'%');
					$('#st_progress').delay(1000).slideUp();
					$('#maincontent').before('<div class="updated"><p><?php i18n('simple-thumbs/SUCCESS');?> <b>' + response.count + '</b> <?php i18n('simple-thumbs/THUMBNAILS');?>.</p></div>').prev().delay(5000).slideUp();

				} else {
					$('#st_percentage').text(response.percentage+'%');
					process_step( parseInt( response.step ), path);
				}

			}
		}).fail(function (response) {
			if ( window.console && window.console.log ) {
				console.log( response );
			}
		});
	}
</script>
<?php
}

function pmo_st_styles() {
	echo '<style type="text/css">
		label > span {
		display: block;
		margin-bottom: 0.35em;
		font-weight: normal;
	}
	hr {
		border: 0;
		border-top: 1px solid #ccc;
	}
	.submit {
		margin-top: 1em;
	}
	#st_percentage {
		float: right;
	}
	</style>';
}
?>