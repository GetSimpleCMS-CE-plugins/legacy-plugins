<?php
$i18n = array(
    'CONF_SIDEBAR' => 'Konfiguruj Plugin Lock',
    'ON_DENIED' => 'Plugin Lock: brak dostępu, na liście zabronionych!',
    'NOT_ALLOWED' => 'Plugin Lock: brak dostępu, nie na liście dozwolonych!',
    'CONF_SETTINGS' => 'ustawienia',
    'CONF_USERNAMES_LABEL' => 'Nazwy użytkowników dla których użyć reguł sprawdzania dostępu (admin jest wykluczony)',
    'CONF_USERNAMES_HINT' => 'Wartości oddzielone przecinkami',
    'CONF_RULE_ALLOW' => 'Zezwalaj',
    'CONF_RULE_DENY' => 'Zabroń',
    'CONF_RULE' => 'Zasada:',
    'CONF_QUERIES_HINT' => 'Parametry URL (query strings) do sprawdzenia gdy wykonywany jest plik \'load.php\'. Wielkość liter nie ma znaczenia w parametrach i ich wartościach, kolejność parametrów we wpisach nie ma znaczenia',
    'CONF_DELETE' => 'Usuń',
    'CONF_ADD' => 'Dodaj',
    'CONF_SAVE' => 'Zapisz zmiany',
    'CONF_SUCCESS' => 'Zmiany zostały zapisane.',
    'CONF_ERROR' => 'Błąd zapisu pliku.'
);