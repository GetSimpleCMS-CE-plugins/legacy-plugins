

<?php
/*
Plugin Name: Fixed-Social-Toolbar
Description: Adds fixed social toolbar to the bottom of the website.
Version: 1.0
Author: Minvas Pc User
Author URI: http://www.comgr.net/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
define('FIXEDSOCIALTOOLBARPATH', $SITEURL.'');


# registration
register_plugin(
	$thisfile,
	'Fixed-Social-Toolbar',
	'1.0',
	'Minvas Pc User',
	'http://www.comgr.net/',
	'Adds fixed social toolbar to the bottom of the website',
	'',
	''
);












# hooks
add_action('theme-footer', 'toolbar_css');
add_action('theme-footer', 'toolbar_code');

# functions
function toolbar_css() {
	echo '


		<style type="text/css">

 
		#site-bottom-bar {
			background-color: #F0F0F0 ;
			border-top: 1px solid #CCCCCC ;
			bottom: 0px ;
			font-family: verdana, arial ;
			font-size: 11px ;
			height: 30px ;
			position: fixed ;
			width: 100% ;
			z-index: 1000 ;
			}
 
		#site-bottom-bar-frame {
			height: 30px ;
			margin: 0px 10px 0px 10px ;
			position: relative ;
			}
 
		#site-bottom-bar-content {
			padding: 3px 0px 0px 0px ;
			}
 
		
		</style>
	';
}

function toolbar_code() {
	echo '
		<div id="site-bottom-bar" class="fixed-position">
		<div id="site-bottom-bar-frame">
		<div id="site-bottom-bar-content" >

 <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js"></script>
 <div class="addthis_toolbox addthis_default_style">
<span><a class="addthis_button_facebook_like" fb:like:layout="button_count"></a></span>
<span> <a class="addthis_button_tweet"></a> </span>
<span><a class="addthis_button_google_plusone" g:plusone:size="medium"></a></span>
<span><a class="addthis_button_facebook_share" fb:share:layout="horizontal"></a></span>


 </div>

</div>
</div>
</div>
 
 

	';
}

?>