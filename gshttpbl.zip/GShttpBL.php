<?php

$thisfile = basename(__FILE__, ".php");
$configfile = GSDATAOTHERPATH . 'GShttpBL.xml';
if (!class_exists('Blacklist')) {
    require_once(GSPLUGINPATH.'GShttpBL/thasmo.php');
}

i18n_merge('GShttpBL') || i18n_merge('GShttpBL', 'en_US');

register_plugin(
    $thisfile,
    'GShttpBL',
    '0.3',
    'morvy',
    'http://moped.jepan.sk',
    i18n_r('GShttpBL/DESCRIPTION'),
    'plugins',
    'hbl_backend'
);

add_action('index-pretemplate', 'hbl_frontend');
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, i18n_r('GShttpBL/SETTINGS_LABEL')));

function hbl_backend()
{

    global $configfile;
	
    if(file_exists($configfile)) {
        $hbl_data = getXML($configfile);
    }

	if(isset($_POST['submit'])) {
	   	$xml = @new SimpleXMLElement('<root></root>');
	   	foreach ($_POST as $key => $value) {
	   		if($key!="submit") {
	   			$xml->addChild($key, $value);
	   		}
	   	}
	   	if(!$xml->asXML($configfile)) {
			$error = i18n_r('CHMOD_ERROR');
		} else {
			$hbl_data = getXML($configfile);
			$success = i18n_r('SETTINGS_UPDATED');
		}
	}

	?>
	<h3 class="floated">GShttpBL</h3>
	<div class="edit-nav">
		<a href="log.php?log=GShttpBL.log" title="<?php echo i18n_r('LOGS'); ?>"><?php echo i18n_r('LOGS'); ?></a>
		<div class="clear"></div>
	</div>
	<p><?php echo i18n_r('GShttpBL/HOWTO'); ?><a href="http://www.projecthoneypot.org?rf=168891" target="_blank"><?php echo i18n_r('GShttpBL/LINK'); ?></a></p>
	<p><?php echo i18n_r('GShttpBL/OBTAIN_KEY'); ?><a href="http://www.projecthoneypot.org/httpbl_configure.php" target="_blank"><?php echo i18n_r('GShttpBL/LINK_KEY'); ?></a></p>
	<?php
		if($success) { 
			echo '<p style="color:#669933;"><b>'. $success .'</b></p>';
		} 
		if($error) { 
			echo '<p style="color:#cc0000;"><b>'. $error .'</b></p>';
		}
	?>
	<form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
		<table class="highlight">
			<tbody>
				<tr>
					<td style="white-space: nowrap;">
						<label for="api_key"><?php echo i18n_r('GShttpBL/API_KEY'); ?></label>
					</td>
					<td>
						<input id="api_key" name="key" value="<?php echo (!empty($hbl_data->key)) ? $hbl_data->key : ''; ?>" type="text" minlength="12" maxlength="12" class="text" />
					</td>
				</tr>
				<tr>
					<td style="white-space: nowrap;">
						<label for="visitor_type"><?php echo i18n_r('GShttpBL/VISITOR_TYPE'); ?>&nbsp;<a href="https://www.projecthoneypot.org/faq.php" target="_blank">(?)</a></label>
					</td>
					<td>
						<select id="visitor_type" name="visitor" class="text">
							<?php
								for($i=0;$i<=7;$i++) {
									$selected = ($i == $hbl_data->visitor) ? ' selected="selected"' : '';
									echo '<option value="'.$i.'"'.$selected.'>'.i18n_r('GShttpBL/VT_'.$i).'</option>'.PHP_EOL;
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td style="white-space: nowrap;">
						<label for="threat_level"><?php echo i18n_r('GShttpBL/THREAT_LEVEL'); ?>&nbsp;<a href="https://www.projecthoneypot.org/threat_info.php" target="_blank">(?)</a></label>
					</td>
					<td>
						<input value="<?php echo (!empty($hbl_data->threat)) ? $hbl_data->threat : '255'; ?>" id="threat_level" name="threat" length="5" type="number" min="0" max="255" class="text" />
					</td>
				</tr>
				<tr>
					<td style="white-space: nowrap;">
						<label for="filter_type"><?php echo i18n_r('GShttpBL/FILTERING_BY'); ?></label>
					</td>
					<td>
						<select id="filter_type" name="filter" class="text">
							<?php
								for($i=0;$i<=3;$i++) {
									$selected = ($i == $hbl_data->filter) ? ' selected="selected"' : '';
									echo '<option value="'.$i.'"'.$selected.'>'.i18n_r('GShttpBL/TL_'.$i).'</option>'.PHP_EOL;
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td style="white-space: nowrap;">
						<label for="hbl_ignorelist"><?php echo i18n_r('GShttpBL/IGNORE_LIST'); ?></label>
					</td>
					<td>
						<textarea style="height:4.5em; width: 97.55%;" name="ignorelist" id="hbl_ignorelist" class="text"><?php echo (!empty($hbl_data->ignorelist)) ? $hbl_data->ignorelist : "127.0.0.1;localhost;::1"; ?></textarea>
					</td>			
				</tr>
				<tr>
					<td style="white-space: nowrap;">
						<label for="hbl_message"><?php echo i18n_r('GShttpBL/ERROR_503_MSG'); ?></label>
					</td>
					<td>
						<textarea style="height:4.5em; width: 97.55%;" name="message" id="hbl_message" class="text"><?php echo (!empty($hbl_data->message)) ? $hbl_data->message : i18n_r('GShttpBL/DEFAULT_MSG'); ?></textarea>
					</td>			
				</tr>
			</tbody>
		</table>
		<p>
			<input id="submit" class="submit" type="submit" name="submit" value="<?php echo i18n_r('BTN_SAVESETTINGS'); ?>" />
		</p>
	</form>
<?php 
}

function hbl_frontend() {
	global $USR, $configfile;
	$ip = $_SERVER['REMOTE_ADDR'];
	//$ipcheck = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);

	if(file_exists($configfile)) {
		$block = false;
		$data = getXML($configfile);
		$ignorelist = explode(";", $data->ignorelist);
		
		if (function_exists('get_cookie') && (!isset($USR) || $USR !== get_cookie('GS_ADMIN_USERNAME')) && !in_array($ip, $ignorelist)) {
			if (!empty($data->key)) {
				try {
					$client = new Thasmo\ProjectHoneypot\Blacklist($ip, $data->key);
					$result = $client->getResult();
					if (is_array($result)) {
						switch ($data->filter) {
							case 0:
								if($result['type'] == $data->visitor)
									$block = true;
								break;
							case 1:
								if($result['threat'] >= $data->threat)
									$block = true;
								break;
							case 2:
								if($result['type'] == $data->visitor || $result['threat'] >= $data->threat)
									$block = true;
								break;
							case 3:
								if($result['type'] == $data->visitor && $result['threat'] >= $data->threat)
									$block = true;
								break;
							default:
								$block = false;
								break;
						}
					}
				} catch (Exception $e) {}
			}
			if($block) {
				$protocol = "HTTP/1.0";
				if ( "HTTP/1.1" == $_SERVER["SERVER_PROTOCOL"] ) $protocol = "HTTP/1.1";
				header( "$protocol 503 Service Unavailable", true, 503 );
				header( "Retry-After: 3600" );
				hbl_saveip($result['type'],$result['threat']);
				echo "<h1>".i18n_r('GShttpBL/DEFAULT_HEADING')."</h1>";
				die($data->message);
			}
		}
	}
}

function hbl_saveip($type,$threat) {
	$log_file= GSDATAOTHERPATH.'logs/GShttpBL.log';

	//if not exists file => create this file
	if (!file_exists($log_file)) {       
		$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><root></root>');
	} else {
		$xml = getXML($log_file);
	}
	$dater = date("r");
	$thislog = $xml->addChild('entry');
	$thislog->addChild('date', htmlspecialchars($dater));
	$thislog->addChild('ip_address', htmlentities($_SERVER['REMOTE_ADDR']));
	$thislog->addChild('visitor_type', htmlspecialchars(i18n_r('GShttpBL/VT_'.$type)));
	$thislog->addChild('threat_level', $threat);
			
	XMLsave($xml, $log_file);
}
?>