<?php 

$i18n = array(

	//GENERAL
	'DESCRIPTION' => 'Protect your website and display Error 503 to bad bots.',
	'HOWTO' => 'This plugin uses http:BL service provided by projecthoneypot.org to block bad bots from your website. It needs personal API key, so if you are not registered, you can do so by using this link: ',
	'LINK' => 'projecthoneypot.org free registration',
	'OBTAIN_KEY' => 'After registration, go to following link and copy&paste your API key: ',
	'LINK_KEY' => 'http:BL Access',
	'SETTINGS_LABEL' => 'GShttpBL Settings',
	
	//API_KEY
	'API_KEY' => 'honeyPot API key',

	//VISITOR_TYPE
	'VISITOR_TYPE' => 'Visitor type',
	'VT_0' => 'Search Engine',
	'VT_1' => 'Suspicious',
	'VT_2' => 'Harvester',
	'VT_3' => 'Suspicious &amp; Harvester',
	'VT_4' => 'Comment Spammer',
	'VT_5' => 'Suspicious &amp; Comment Spammer',
	'VT_6' => 'Harvester &amp; Comment Spammer',
	'VT_7' => 'Suspicious &amp; Harvester &amp; Comment Spammer',

	//THREAT_LEVEL
	'THREAT_LEVEL' => 'Threat level',
	'TL_0' => 'Visitor type',
	'TL_1' => 'Threat level',
	'TL_2' => 'Visitor type OR Threat level',
	'TL_3' => 'Visitor type AND Threat level',

	//FILTERING_BY
	'FILTERING_BY' => 'Filtering by',
	
	//IGNORE LIST
	'IGNORE_LIST' => 'Ignore list',

	//ERROR_503_MSG
	'ERROR_503_MSG' => 'Error 503 message',
	'DEFAULT_HEADING' => 'ERROR 503',
	'DEFAULT_MSG' => 'We are sorry, this page is not available at the moment, please try again later.'
);

?>