<?php
/*
Plugin Name: I18N Extras
Description: This plugin adds new features to I18N multilanguage plugin. Button that allows you to easy copy all or single field text from other language version of edited page. To enable go to plugins tab and click: Configure I18N Extras.
Version: 1.01
Author: Michał Gańko
Author URI: http://flexphperia.net
*/

if (!is_frontend()){
    require_once('I18NExtras/I18NExtrasClass.php');
    
    $g = new I18NExtrasClass();
    
    $g->init();
    
}
