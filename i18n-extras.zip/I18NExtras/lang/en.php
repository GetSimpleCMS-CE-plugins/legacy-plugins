<?php
$i18n = array(
    'CONF_SIDEBAR' => 'Configure I18N Extras',
    //global configuration
    'CONF_LANG_COPY' => 'Enable fields copying from other languages',
    'CONF_LANG_COPY_HINT' => 'When enabled and I18N plugin is installed it will display button while editing page that allows you to copy all field texts from other language version of page.<br>The button will be displayed only when other language page version exists or creating page in new language by clicking plus char in language column.',
    'CONF_SAVE_SETTINGS' => 'Save settings',
    'CONF_SAVED' => 'Settings saved.',
    'CONF_SAVE_ERROR' => 'Saving error.',
    
    //language copier
    'EDIT_LANG_BUTTON' => 'Copy fields',
    'EDIT_LANG_COPY_ALL' => 'Copy all fields from language',
    'EDIT_LANG_COPY_SINGLE' => 'Copy from language'
    
);