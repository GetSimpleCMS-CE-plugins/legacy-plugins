<?php
$i18n = array(
    'CONF_SIDEBAR' => 'Konfiguruj I18N Extras',
    //global configuration
    'CONF_LANG_COPY' => 'Aktywuj kopiowanie pól z innego języka',
    'CONF_LANG_COPY_HINT' => 'Gdy włączone i zainstalowano wtyczkę I18N, w trakcie edycji strony wyświetlony zostanie przycisk umożliwiający skopiowanie treści pól z innej wersji językowej.<br>Przycisk zostanie wyświetlony tylko wtedy gdy inna wersja językowa edytowanej strony istnieje lub gdy tworzona jest nowa poprzez kliknięcie znaku plus w kolumnie języka.',
    'CONF_SAVE_SETTINGS' => 'Zapisz ustawienia',
    'CONF_SAVED' => 'Ustawienia zapisane.',
    'CONF_SAVE_ERROR' => 'Błąd.',
    
    //language copier
    'EDIT_LANG_BUTTON' => 'Kopiuj zawartość pól',
    'EDIT_LANG_COPY_ALL' => 'Kopiuj zawartość wszystkich pól z języka',
    'EDIT_LANG_COPY_SINGLE' => 'Kopiuj zawartość z języka'
    
);