<?php

class I18NExtrasClass{

    public $id;
    public $currentFile;
    public $title = 'I18N Extras';
    
    public $storageDir; 
    public $settingsFile;    
    
    public $settings;
    
    //used to pass view vars, and type to JS
    public $v = array();

    public function __construct() { 
        $this->id = 'I18NExtras';
        
        $this->currentFile = strtolower(basename($_SERVER['PHP_SELF']));
        
        $this->storageDir =  GSDATAOTHERPATH . 'I18NExtras/';
        $this->settingsFile =  'settings.xml';
    } 
    
    public function init(){
        # register plugin
        register_plugin(
            $this->id, 
            $this->title, 	
            '1.01', 		
            'Michał Gańko',
            'http://flexphperia.net', 
            'This plugin adds new features to I18N multilanguage plugin. Button that allows you to easy copy all or single field text from other language version of edited page. To enable go to plugins tab and click: Configure I18N Extras.',
            'plugins',
            array($this, 'adminTab') 
        );
    
        global $LANG,$live_plugins;
        i18n_merge($this->id, substr($LANG,0,2)) || i18n_merge($this->id,'en');
        
        add_action( 'plugins-sidebar', 'createSideMenu', array($this->id, i18n_r($this->id.'/CONF_SIDEBAR')) ); 
        
        //i18n not enabled
        if (!@$live_plugins['i18n_base.php'])
            return;
        
        require_once('I18NExtrasSettings.php');
        $this->settings = new I18NExtrasSettings($this->storageDir, $this->settingsFile);
        
        //currently in plugin configuration or edition of galleries
        if ($this->currentFile == 'load.php' && @$_GET['id'] == $this->id){

            add_action('header', array($this, 'onConfigurationHeader') ); 
            add_action('footer', array($this, 'onConfigurationFooter') ); 
            $this->_routeConfigAction();
        }    
        else if ($this->currentFile == 'edit.php'){ //in page edition
            add_action('header', array($this, 'onEditHeader') ); 
        }    
        
        
    }

    public function adminTab(){
        $settings = $this->settings->getArray();
        
        require_once('views/configuration.html');
    }  


    public function onEditHeader(){
        $settings = $this->settings->getArray();
        
        if (!$settings['language-copier'])
            return;
            
        getPagesXmlValues(true); //prepare pageArraay
        
        global $url, $pagesArray;
        
        $slug = @$_GET['newid'] ? $_GET['newid'] : $url;

        if (empty($slug)){ //new page with empty slug, not by creating language page
            return;
        }
        //remove language from slug
        if (($pos = strrpos($slug,'_')) !== false){
            $currentLanguage = substr($slug,$pos + 1);
            $slug = substr($slug,0,$pos);
        }
        else{
            $currentLanguage = return_i18n_default_language();
        }
        $l = return_i18n_available_languages($slug);   
        
        //sotre available languages, minus currently edited language
        $languages = array();
        for ($i = 0; $i < count($l); $i++){
            if ($l[$i] != $currentLanguage)
                $languages[] = $l[$i];
        }
        
        //if any languges other than current one exists
        if (count($languages)){
            $langContents = array();
            
            for ($i = 0; $i < count($languages); $i++){
                $s = $languages[$i] == return_i18n_default_language() ? $slug : $slug.'_'.$languages[$i];
                
                $langContents[$languages[$i]] = $pagesArray[$s];
                //add content, it does not exist in pageArray;
                $langContents[$languages[$i]]['content'] = returnPageContent($s);
            }
            
            require_once('views/editJS.php');
            ?>
                <link rel="stylesheet" href="../plugins/I18NExtras/css/edit.css" />
            <?php
        }
    }    
  
    
    public function onConfigurationHeader(){
        ?>
            <link rel="stylesheet" href="../plugins/I18NExtras/css/configuration.css" />
        <?php
    }  

    public function onConfigurationFooter(){
        $settings = $this->settings->getArray();
        echo '<script>';
        require_once('views/configurationJS.php');
        echo '</script>';
    }
   
    
    //routes action inside plugin
    private function _routeConfigAction (){
    
        //save settings
        if (@$_POST['save']){
            if ($this->settings->saveSettings()){
                $this->v['message'] = i18n_r($this->id.'/CONF_SAVED');
                $this->v['messageType'] = 'updated';
            }
            else{
                $this->v['message'] = i18n_r($this->id.'/CONF_SAVE_ERROR');
                $this->v['messageType'] = 'error';
            }
        } 
    }      
}