$( document ).ready(function() {
    var $mainContent = $('#maincontent');
    
    var startMessage = '<?php echo @$this->v['message']; ?>';
    var messageType = '<?php echo @$this->v['messageType']; ?>';

    
    function showMessage(message, type){
        if (!type) type = 'error';
        $('.error,.updated').remove();
        $('div.bodycontent').before('<div class="'+type+'" style="display:block;">'+message+'</div>');
        $('.error,.updated').delay(200).fadeOut(500).fadeIn(500);
    }
    
    
    //------------------------------- main logic ------------------------------------
    $mainContent.show(); //show its hidden

    if (startMessage)
        showMessage(startMessage, messageType);
 
});