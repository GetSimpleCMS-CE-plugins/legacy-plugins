
<script>
    $(document).ready(function() {  
        var $langPopup = $('#copyLanguage'),
            $mainLangButton = $('<button type="button" class="i18ne" ><?php i18n($this->id.'/EDIT_LANG_BUTTON'); ?> &#9660;</button>'),
            $specialFields = $('*[id^="post-sp-"]'),
            $mainContent = $('#maincontent'),
            $popupOpener;
            
        var langContents = <?php echo json_encode($langContents); ?>; //other languages data
        
        $mainContent.append($langPopup);//move to the end of page
        $('#editform').addClass('i18ne-copier-active'); //we are here coz copier will be visible
            
        //main lang button for copying all
        $mainLangButton
            .insertAfter('#maincontent .edit-nav:first a:last')
            .click(function(event){
                toggleLangPopup(false, $(this));
                event.stopPropagation();
            });
             
        //static fields buttons
        
        //title, with label or not
        $('#edit_window').append($(copyButton()).data('inputName', 'post-title').data('fieldName', 'title'));
        $('#post-metak').closest('p').append($(copyButton()).data('inputName', 'post-metak').data('fieldName', 'meta'));
        $('#post-metad').closest('p').append($(copyButton()).data('inputName', 'post-metad').data('fieldName', 'metad'));
        $('#menu-items').append($(copyButton()).data('inputName', 'post-menu').data('fieldName', 'menu'));
        
        $('#post-content').closest('p').attr('id', 'content-p').append($(copyButton()).data('inputName', 'post-content').data('fieldName', 'content'));
            
        //add single-copier buttons for each field
        $specialFields.each(function(){
            var $input = $(this),
                $cell = $input.closest('.spe_cell'),
                $copyButton = $(copyButton());
                
            $copyButton.data('inputName', $input.attr('name'));
                
            $cell.append($copyButton);
        });
        
        //single-copier buttons
        $mainContent.on('click', 'button.i18ne.single-copier', function(){
            var $button = $(this);
            toggleLangPopup(true, $button);
        });
            
       // hiding language popup
        $(document).on('click', function (e) {
            var $target = $(e.target),
                isPopover = $(e.target).is($langPopup),
                inPopover = $(e.target).closest($langPopup).length > 0

            //hide only if clicked on button or inside popover
            if (!isPopover && !inPopover && !$target.is($popupOpener) && $popupOpener) 
               hideLangPopup()
        });
        
        $langPopup.on('click', 'button', function(event) {
            var lang = $(this).text(),
                all = !$popupOpener.hasClass('single-copier');
        
            if (all){
                fillField(lang, 'post-title', 'title');
                // the same as in GS, when menu is empty it will be title
                fillField(lang, 'post-menu', !langContents[lang]['menu'] ? 'title' : 'menu');
                fillField(lang, 'post-metak', 'meta');
                fillField(lang, 'post-metad', 'metad');
                fillField(lang, 'post-content', 'content');
                
                $specialFields.each(function(){
                    var $input = $(this),
                        name = $input.attr('id').substr(8);
                        
                    fillField(lang, $input.attr('id'), name);
                });
            }
            else{
                // var 
                var $input = $('#'+$popupOpener.data('inputName')),
                    id =  $popupOpener.data('inputName'),
                    name = id.indexOf('post-sp-') > -1 ? id.substr(8) : id;
                        
                fillField(lang, id, $popupOpener.data('fieldName') ? $popupOpener.data('fieldName') : name);
            }
            
            hideLangPopup();
        });
        

        function fillField(lang, inputId, fieldName){
            var $input = $('#'+inputId);
            if ( $input.is('[type="checkbox"]') ){
                if (!langContents[lang][fieldName])
                    $input.removeAttr('checked');
                else    
                    $input.attr('checked', langContents[lang][fieldName]);
            }
            else if ( $input.is('textarea') ){
                $input.val(langContents[lang][fieldName]); //without cke
                if (typeof CKEDITOR != 'undefined' && CKEDITOR.instances && CKEDITOR.instances[inputId]){ //with cke
                    CKEDITOR.instances[inputId].setData(langContents[lang][fieldName]);
                }
            }    
            else{
                if (fieldName == 'menu') //the same as in GS changedata.php
                   fieldName = !langContents[lang]['menu'] ? 'title' : 'menu';
                
                $input.val(langContents[lang][fieldName]); 
            }
                
            $input.trigger('change');
        }
        
        function copyButton(){
            return '<button type="button" class="i18ne single-copier" title="<?php i18n($this->id.'/EDIT_LANG_COPY_SINGLE'); ?>"></button>';
        }      
        
        function toggleLangPopup(single, $el){
            var newOne = !$el.is($popupOpener);
        
            if ($langPopup.is(':visible'))
                hideLangPopup();


            //new opnenr is not new opener
            if (newOne){
                $popupOpener = $el;
                showLangPopup(single);
            }
        }  

        function showLangPopup(single){
            $langPopup.find('p').hide();
            if (single)
                $langPopup.find('p:eq(1)').show();
            else
                $langPopup.find('p:eq(0)').show();
            
            var pos = $popupOpener.offset();
           
            $langPopup.css({
                top : pos.top  +($popupOpener.height() + 4) + 'px',
                right : ($('body').width() - pos.left - $popupOpener.outerWidth()) + 'px'
            });

            $langPopup.show(); 
            $popupOpener.addClass('active');
        }   

        function hideLangPopup(){
            $langPopup.hide();
            $popupOpener.removeClass('active');
            $popupOpener = null;
        }
    });
</script>
<div id="copyLanguage" style="display:none;">
    <p><?php i18n($this->id.'/EDIT_LANG_COPY_ALL'); ?>:</p>
    <p><?php i18n($this->id.'/EDIT_LANG_COPY_SINGLE'); ?>:</p>
    <ul>
        <?php for ($i = 0; $i < count($languages); $i++): ?>
        <li><button class="i18ne"><?php echo $languages[$i]; ?></button></li>
        <?php endfor; ?>
    </ul>   
</div>