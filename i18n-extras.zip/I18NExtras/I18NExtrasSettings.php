<?php
class I18NExtrasSettings {

    private $_settings;
    
    private $_settingsDir;
    

    public function __construct($settingsDir, $settingsFile) { 
        $this->_settingsDir = $settingsDir;
        $this->_settingsFile = $settingsFile;
    } 
    
    public function getArray(){
        if ($this->_settings)
            return $this->_settings;
    
        $this->_settings = $this->_loadSettings();
        return $this->_settings;
    }
    
    public function get($name){
        $a = $this->getArray();
        
        return $a[$name];
    }
    
    
    private function _loadSettings(){
        $xml = getXML($this->_settingsDir .$this->_settingsFile);  
        
        $data = array();
        $data['language-copier'] = (string)@$xml->{'language-copier'};
               
        return $data;
    }  

    public function saveSettings(){
        $data = $this->_parse();
        
        if (!$this->_validate($data))
            return false;
            
        $this->_settings = $data;
    
        $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><i18nextras></i18nextras>');

        $xml->addChild('language-copier', $data['language-copier']);

        //if filder doesnt exists, create one
        if (!file_exists($this->_settingsDir)){
            if (!@mkdir($this->_settingsDir))
                return false;
        }

        return XMLsave($xml, $this->_settingsDir .$this->_settingsFile);
    }
    
    
    //get data from post
    private function _parse()
    {
        $data = array();
        $data['language-copier'] = (bool) @$_POST['language-copier'];
        return $data;
    }    
    
    private function _validate($data){
        return true;
    }
    

}