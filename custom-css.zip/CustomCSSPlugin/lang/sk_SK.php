<?php
/**
 * Slovak Language File for Custom CSS Plugin
 *
 * Date:		24 June 2020
 * Revision:	0.1	
 * Version:		GetSimple 3.3
 * Traductors: 	Pavol Bokor 
 *
 * @package GetSimple
 * @subpackage Language
 */
 
$i18n = array (
	
	"CUSTOMCSS_TITLE"	=>	"Custom CSS",
	"CUSTOMCSS_DESC"	=>	"Pridá vlastné CSS do motívu"
);
