<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/*
Plugin Name: HTML Navigation
Description: Static  Pages
Version: 2.0
GS : 3.1
Author: Abhishek Shukla<abhishek.simsree@gmail.com>
Author URI: http://www.eeyesolutions.com/
Updated 03-APR-2012
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'HTML Navigation 2.0', 	# Title of plugin
	'2.0', 		# Version of plugin
	'Abhishek Shukla',	# Author of plugin
	'http://www.eeyesolutions.com/', 	# Author URL
	'HTML pages are generated at GS Root', 	# Plugin Description
	'pages', 	# Page type of plugin
	'html_navigation'  	# Function that displays content
);

# hooks
add_action('pages-sidebar','createSideMenu',array($thisfile,'HTML Navigation 2.0')); //to allow configuration
add_action('theme-header', 'hn_theme_header_js');

function hn_theme_header_js(){
//auto redirect to html pages
 global $SITEURL;
 if (file_exists(GSROOTPATH.'index.html') && $_GET['create']<>'html') {
 echo'<script type="text/javascript"> 
<!--
 window.location="'.$SITEURL.'index.html"; 
 //--> 
	</script>
 ';
 }
}

function html_navigation(){
  //constants
  $msg = '';
  global $SITEURL;
  //recreate all static files at root
  if (isset($_POST['recreateatroot'])) {
	
	  $files = scandir(GSDATAPAGESPATH);
	   $msg ="No HTML File Created";
	  foreach ($files as $file){
		if (strpos($file,'.xml') > 0) {
		  $id = strpos($file,'.xml');
		  $id = substr($file,0,$id);
		  hn_get_file($SITEURL."index.php?id=$id&create=html",GSROOTPATH."$id.html",true);
		  $html = file_get_contents(GSROOTPATH."$id.html");
		  $html = hn_replaceAnchorsWithPage($html,$SITEURL);
		  $refreshjsex='window.location="'.$SITEURL.'index.html"'; 
		  $html = str_replace($refreshjsex,'',$html);
		  
		  file_put_contents(GSROOTPATH."$id.html",$html);
		  $msg = 'HTML pages recreated at GS ROOT. Visit Site to navigate html pages.';
		}
	  }
	  hn_handle_fancy_url();
	  /*$msg .= '<br>Put the following code in header of current template for html navigation<br>';
	  $msg .= "<textarea cols=50 rows=12><?php\r\n global \$SITEURL;\r\n if (file_exists('index.html')) {\r\n echo'<script type=\"text/javascript\"> \r\n<!--\r\n window.location=\"'.\$SITEURL.'index.html\"; \r\n //--> \r\n	</script>\r\n ';\r\n }\r\n?></textarea>";
	  */
  }
  
   //delete created all static files
  elseif (isset($_POST['deleteatroot'])) {
		$msg = hn_delete_html_files(GSROOTPATH);
  }

  //check whether pages are already created
	if (file_exists(GSROOTPATH."index.html")) { 
		//form to recreate and delete html files
		$form="<form method='post'>
		<input type='checkbox' name='relativepath'> &nbsp; Use Relative path instead of complete url<br/><br/>
		<input style='padding:5px;' type='submit' name='recreateatroot' value='Recreate HTML Files'>
		<input style='padding:5px;' type='submit' name='deleteatroot' value='Delete HTML Files'>
		</form>";
	}
	else{ 
		//form create only
		$form="<form method='post'>
		<input type='checkbox' name='relativepath'> &nbsp; Use Relative path instead of complete url<br/><br/>
		<input style='padding:5px;' type='submit' name='recreateatroot' value='Create HTML Files'>
		</form>";
	}
?>
<h2>HTML Navigation</h2>
<h3>Version : 2.0 by Abhishek Shukla &ltabhishek.simsree@gmail.com&gt -
<a href="http://get-simple.info/forum/topic/3750/html-navigation-plugin/" target="_blank">Support Forum</a></h3>
<div>
<ul>
<li>Create HTML Files at GET-SIMPLE ROOT to start HTML Navigation in the front-end. </li> 
<li>Deleting HTML Pages will stop HTML Navigation and restore usual navigation.</li> 
<li><b>The plugin works with GS 3.2.1.</b></li>  
<li>The plugin also works with fancy URLs.</li>  
<li>Option for using relative path instead of complete url added.(Thanks to akaziuna for suggestion.)</li> 
<li>Changes in site/ content/ theme will reflect in the front-end only after Recreating HTML Pages.</li> 
</ul>
<p>NB: Adding 'DirectoryIndex index.html index.php' to .htaccess of GS ROOT will ensure that 
index.html gets priority over index.php and avoid chances of php redirecting to html everytime the home page is visited.</p>

<?php echo $form; ?>
<br/></div>
<?php $list=hn_list_html_files(GSROOTPATH,$SITEURL);
	if($list<>''){
		echo "<h3>List of HTML Files Created</h3><ol>".$list."</ol>";
	}
?>
					<br/>
<div style='margin-top:10px;color:red'><p ><?php echo $msg; ?></p></div>
<?php  

}

/*Credits:: Author: Johannes Pretorius 
as used in GS plugin Static  Pages v 0.3 */

function hn_replaceAnchorsWithPage($html,$baseURL) {
	global $SITEURL;
	//replace site url with relative path
	$tofind=$SITEURL."index.php";
	$replace="index.html";
	//return str_replace($tofind,$replace,$html);
	$regex = '/href=[\'"]+?.*?[\'"]/i'; //kry die skakel
    preg_match_all($regex, $html,$tmpArr,PREG_PATTERN_ORDER);
	foreach ($tmpArr[0] as $key => $data) {
	   $newData = $data;
	   $newData = str_replace($SITEURL,$baseURL,$newData);
	   $i = strpos($newData,'/index.php?id=');
	   if ($i ===  false) {
	     $arrReplace[$key] =  $newData;   
	   } else {
	     $hfile = substr($newData,$i+14);
		 $hfile= str_replace('"','',$hfile);
		 $hfile= str_replace("'",'',$hfile);
		 $newData = substr_replace($newData,"/$hfile.html\"",$i);
	   }
	   $data= str_replace('/','\/',$data);
	   $data= str_replace('?','\?',$data);
	   $regex = "/$data+?/i"; //kry die skakel
	   $html = str_replace($data,$newData,$html);
	}
	return $html;
}

/*Credits:: Author: Nashruddin Amin <me@nashruddin.com> 
as modified and used by 
Johannes Pretorius in GS plugin Static Pages v 0.3 
prefix hn_ added before the function*/

function hn_get_file($remote, $local,$addQuery = false)
{
	/* get hostname and path of the remote file */
	$host = parse_url($remote, PHP_URL_HOST);
	if ($addQuery == true) { 
	  $path = parse_url($remote, PHP_URL_PATH )."?".parse_url($remote, PHP_URL_QUERY  );
	} else {
	  $path = parse_url($remote, PHP_URL_PATH );
    }	
	
	/* prepare request headers */
	$reqhead = "GET $path HTTP/1.1\r\n"
			 . "Host: $host\r\n"
			 . "Connection: Close\r\n\r\n";
	/* open socket connection to remote host on port 80 */
	$fp = fsockopen($host, 80, $errno, $errmsg, 30);
	
	/* check the connection */
	if (!$fp) {
		error_log("Cannot connect to $host!\n");
		return false;
	}
	
	/* send request */
	fwrite($fp, $reqhead);
	/* read response */
	$res = "";
	while(!feof($fp)) {
		$res .= fgets($fp, 4096);
	}		
	fclose($fp);
	
	/* separate header and body */
	$neck = strpos($res, "\r\n\r\n");
	$head = substr($res, 0, $neck);
	$body = substr($res, $neck+4);

	/* check HTTP status */
	$lines = explode("\r\n", $head);
	preg_match('/HTTP\/(\\d\\.\\d)\\s*(\\d+)\\s*(.*)/', $lines[0], $m);
	$status = $m[2];

	if ($status == 200) {
		file_put_contents($local, $body);
		return(true);
	} else {
		return(false);
	}
}

function hn_delete_html_files($directory){
	$msg = 'No File to delete. HTML Navigation disabled in the front-end.';
	$files = scandir($directory);
	  foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			unlink(GSROOTPATH.$file);
			$msg = 'HTML files deleted from GS ROOT. HTML Navigation disabled in the front-end.';
		}
	 }
	return $msg;
}

function hn_list_html_files($directory,$directoryurl=''){
	$list= '';
	$files = scandir($directory);
	  foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			if ($directoryurl && $directoryurl<>''){
				$list .=  '<li><a href="'.$directoryurl.$file.'" target="_blank">'.$file.'</a></li>';
			}
			else{
				$list .=  '<li>'.$file.'</li>';
			}
		}
	 }
	return $list;
}

function hn_handle_fancy_url(){
	global $SITEURL;
	$files = scandir(GSROOTPATH);
	$i=0;
	//array of fancy urls an corresponding html url
	foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			$fancyurl[$i]=str_replace('.html','/',$SITEURL.$file);
			$htmlurl[$i]=$SITEURL.$file;
			$i++;
		}
	}
	foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			$html = file_get_contents(GSROOTPATH.$file); 
			$html = str_replace($fancyurl,$htmlurl,$html);
			//fix for extra characters before/after valid html
			$matchexp='/\S*\s*<!DOCTYPE/';
			$html =preg_replace($matchexp,"<!DOCTYPE" , $html);
			$matchexp='/\/html\s*\S*\s*\S*/';
			$html =preg_replace($matchexp,"/html>" , $html);
			if($_POST['relativepath'])$html = str_replace($SITEURL,"",$html);
			file_put_contents(GSROOTPATH.$file,$html);
		}
	}
}
?>