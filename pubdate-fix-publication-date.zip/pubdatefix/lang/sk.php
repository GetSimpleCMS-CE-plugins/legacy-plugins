<?php
$i18n = array(
  "PUBDATE" => "Dátum publikácie"
);