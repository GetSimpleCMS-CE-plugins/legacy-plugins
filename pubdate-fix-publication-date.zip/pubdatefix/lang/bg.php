<?php
$i18n = array(
  "PUBDATE" => "Дата на публикуване"
);