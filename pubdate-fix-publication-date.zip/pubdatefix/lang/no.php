<?php
$i18n = array(
  "PUBDATE" => "Publiseringsdato"
);