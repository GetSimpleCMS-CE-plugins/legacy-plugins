<?php
$i18n = array(
  "PUBDATE" => "Ημερομηνία δημοσίευσης"
);