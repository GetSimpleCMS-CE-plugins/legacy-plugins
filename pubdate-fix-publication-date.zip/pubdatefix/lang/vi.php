<?php
$i18n = array(
  "PUBDATE" => "Ngày Xuất bản"
);