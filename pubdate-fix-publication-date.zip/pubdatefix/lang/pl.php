<?php
$i18n = array(
  "PUBDATE" => "Data publikacji"
);