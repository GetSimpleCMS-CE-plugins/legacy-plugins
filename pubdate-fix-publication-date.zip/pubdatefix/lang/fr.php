<?php
$i18n = array(
  "PUBDATE" => "Date de publication"
);