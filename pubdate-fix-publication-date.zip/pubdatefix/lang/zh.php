<?php
$i18n = array(
  "PUBDATE" => "发布日期"
);