<?php
$i18n = array(
  "PUBDATE" => "Data de Publicação"
);