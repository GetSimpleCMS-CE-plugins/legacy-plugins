<?php
$i18n = array(
  "PUBDATE" => "Fecha de publicación"
);