<?php
$i18n = array(
  "PUBDATE" => "วันที่ประกาศ"
);