<?php
$i18n = array(
  "PUBDATE" => "Data di pubblicazione"
);