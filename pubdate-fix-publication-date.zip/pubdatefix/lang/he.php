<?php
$i18n = array(
  "PUBDATE" => "תאריך פרסום"
);