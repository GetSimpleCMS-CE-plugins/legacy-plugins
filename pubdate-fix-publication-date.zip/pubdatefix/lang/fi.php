<?php
$i18n = array(
  "PUBDATE" => "Julkaisupäivämäärä"
);