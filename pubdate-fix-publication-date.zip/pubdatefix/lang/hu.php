<?php
$i18n = array(
  "PUBDATE" => "Közzététel dátuma"
);