**Description**
GZipIt! enables gzip compression per zlib.output_compression. If it is not enabled, PHP output buffering will used as substitute.

The disadvantage with zlib is that you need access to the php.ini file to edit/add some functions. In the case that some ISPs do not give you access to this file we have to go a workaround.

This plugin takes advantage of PHP's output buffering function if zlib is not enabled. This will stores the output in an internal buffer and determines the compression to use ('deflate' or 'gzip'). Then the content will compressed and sent to the browser/client back.

**Usage**
After installing (and activating) this plugin it is ready to use. There is *nothing further to adjust*.

**Testing**
To make sure that the functionality is given, take an overview about your HTTP Headers. Here you can do it: http://nontroppo.org/tools/gziptest/?url=domain.tld

**Limitations**
This method is dependant on the Apache server and in addition, the mod_gzip module must be installed and loaded.

**Support**
'phpinfo()' can give you back the current status of zlib.
If you need help or have a suggestion for improvement, visit yckart.com or contact me directly: dev@yckart.com.