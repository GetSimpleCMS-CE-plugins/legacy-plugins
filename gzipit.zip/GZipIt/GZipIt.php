<?php
// Get the correct ID for the plugin.
$thisfile = basename(__FILE__, ".php");

// Hooks
add_action('support-sidebar', 'createSideMenu', array($thisfile, 'GZipIt'));
add_action('index-pretemplate', 'GZipIt', array());

// Definitions
register_plugin(
    $thisfile,  # ID /filename -php
    'GZipIt',   # Title
    '0.3',  # Version
    'Yannick Albert',   # Author Name
    'http://yckart.com/',   # Author URL
    'Enables GZip compression per zlib.output_compression. If it is not enabled, PHP output buffering will used. To learn more read the <a href="load.php?id=GZipIt">documentation</a>.',  # Description
    'plugins',  # Pagetype as injected
    'GZipIt_Info'   # Settings/Documentation
);



/**
 * Output Buffering
 *
 * Starts the output buffering
 *
 * @return bool
 */
function GZipIt() {
    ini_set("zlib.output_compression", 4096);
    ob_start('ob_gzhandler');
}



/**
 * GZipIt Info
 *
 * The documentation page under 'Support' in GetSimple backend
 *
 * @param string $root - This is your page url, it is used in the GZip-Testlink redirect /r60
 * @return bool
 */
function GZipIt_Info() {
$root = $_SERVER["HTTP_HOST"];
?>
    <div id="GZipIt" class="description">
        <h2>GZipIt</h2>
        <h3>Description</h3>
        <p><strong>GZip</strong>It enables gzip compression per zlib.output_compression. If it is not enabled, PHP output buffering will used as substitute.</p>
        <p>The disadvantage with zlib is that you need access to the php.ini file to edit/add some functions.</p>
        <p>In the case that some ISPs do not give you access to this file we have to go a workaround.</p>
        <p>This plugin takes advantage of PHP's output buffering function if zlib is not enabled. This will stores the output in an internal buffer and determines the compression to use ('deflate' or 'gzip'). Then the content will compressed and sent to the browser/client back.</p>

        <h3>Usage</h3>
        <p>After installing (and activating) this plugin it is ready to use. There is <u>nothing further to adjust</u>.</p>

        <h3>Testing</h3>
        <p>To make sure that the functionality is given, take an overview about your HTTP Headers. Here you can <a href="http://nontroppo.org/tools/gziptest/?url=<?php echo($root); ?>">do it!</a></p>

        <h3>Limitations</h3>
        <p>This method is dependant on the Apache server and in addition, the mod_gzip module must be installed and loaded.</p>

        <h3>Support</h3>
        <p><code>phpinfo()</code> can give you back the current status of zlib.</p>
        <p>If you need help or have a suggestion for improvement, visit <a href="http://yckart.com/">yckart.com</a> or contact me directly <a href="mailto:dev@yckart.com">dev@yckart.com</a>.</p>
    </div>

    <style>
        #GZipIt h4 {
            font:400 15px Georgia, Times, Times New Roman, serif;

            color: #666;
            margin: 0 0 10px 0;
            text-shadow: 1px 1px 0 white;
        }
        #GZipIt ul {margin:0 !important; list-style:none;}
        #GZipIt .red{color:red}
    </style>
<?php } ?>