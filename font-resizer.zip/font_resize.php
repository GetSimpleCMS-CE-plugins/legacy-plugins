<?php
/*
Plugin Name: Font Resize
Description: Increase/Decrease Font Size
Version: 1.01
Author: David Shaner
Author URI: http://www.shaner.us/
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Font Resize', 	
	'1.01', 		
	'David Shaner',
	'http://www.shaner.us/', 
	'Increase/Decrease Font Size',
	'content',
	'font_resizer'  
);

$website_xml = GSDATAOTHERPATH.'website.xml';
$x = getXML($website_xml);
$website = $x->SITEURL;

register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
queue_script('jquery',GSFRONT);

add_action('content-top','font_resizer');
add_action('content-bottom','close_font_sizer');

/**
 * Main portion of the user tools script
 */
function font_resizer(){
    $site_url = get_site_url('',TRUE);
    ?>
    <style type="text/css">
    #font_larger div{
        display:inline-block;
        height:24px;
        width:24px;
        background: url('plugins/font_resize/images/fontsizeup.png') no-repeat;
    }
    
    #font_smaller div{
        display:inline-block;
        height:24px;
        width:24px;
        background: url('plugins/font_resize/images/fontsizedown.png') no-repeat;
    }
    </style>
    <span>
    <a href="#" id="font_larger"><div>&nbsp;</div></a>&nbsp;
    <a href="#" id="font_smaller"><div>&nbsp;</div></a>&nbsp;
    <span id="current_size"></span>
    </span><br/><br/>
    <div id="font_sizer">
        
    <?php
    register_font_resize_script();
}

function register_font_resize_script(){
    $site_url = get_site_url('',TRUE);
    register_script('font_resizer',$site_url.'plugins/font_resize/js/font_resize.js', '0.1', TRUE);
    queue_script('font_resizer',GSFRONT);
    
}
function close_font_sizer(){
    echo '</div>';
}
?>