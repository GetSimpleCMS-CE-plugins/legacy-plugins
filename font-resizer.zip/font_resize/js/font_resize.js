$(document).ready(function(){
    var start_size = $('#font_sizer p').css('font-size');
    $('#current_size').empty();
    $('<span>'+start_size+'</span>').appendTo('#current_size');
    
   $('#font_larger, #font_smaller').click(function(){
        var clicked = $(this).attr('id');
        var default_size = change_font_size(clicked);
        return false;
    });
});

var smallest_size = 8;
var largest_size = 72;
var resizeable_elements = new Array('a','p','li','address','blockquote','pre','code');

function clickability(){
    $('#font_larger, #font_smaller').click(function(){
        var clicked = $(this).attr('id');
        var default_size = change_font_size(clicked);
        return false;
    });
}


function change_font_size(clicked){
    var current_size = $('#font_sizer p').css('font-size');
        current_size = current_size.replace('px','');
        current_size = parseInt(current_size);
    
    if(current_size > smallest_size && current_size < largest_size){
           
        var new_size = 0;
        
        switch(clicked){
            case 'font_smaller' :
                new_size = parseInt(current_size - 1);
                break;
            case 'font_larger' :
                new_size = parseInt(current_size + 1);
                break;
        }
    } else{
        switch(current_size){
            case smallest_size :
                alert('The font cannot be smaller than 8px.');
                new_size = parseInt(current_size + 1);
                break;
            case largest_size :
                alert('The font cannot be larger than 72px');
                new_size = parseInt(current_size - 1);
                break;
        }
    }
    
    for(var i = 0; i < resizeable_elements.length; i++){
        $('#font_sizer '+resizeable_elements[i]).each(function(){
            $(this).css('font-size',new_size+'px');
            var line_height = parseInt(new_size+2);
            $(this).css('line-height',line_height+'px');
            $('#current_size').empty();
            $('<span>'+new_size+'px</span>').appendTo('#current_size');
        });
    }
}