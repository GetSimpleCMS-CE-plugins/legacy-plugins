<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ==========================================================
 * Main plugin file
 * Set Id - include main plugin class - initialize the plugin
 * ==========================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * ==========================================================
 * @package    mod1fy_dlmanager
 * ==========================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

// get id of plugin based on this file name
$mod1fy_dlmanagerId = basename(__FILE__, '.php');

// include the main plugin class
include($mod1fy_dlmanagerId . '/lib/plugin.class.php');

// instantiate an object so that we can initialize and register the plugin
$mod1fy_dlmanager = new Mod1fy_DLManager($mod1fy_dlmanagerId);
$mod1fy_dlmanager->autoload();    // autoloader, so classes in /lib/ are automatically included 
$mod1fy_dlmanager->i18nMerge();   // load correct language file
$mod1fy_dlmanager->register();    // register the plugin
$mod1fy_dlmanager->init();        // initialize the plugin, set defaults

?>
