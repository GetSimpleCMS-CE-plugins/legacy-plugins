<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ==========================================================
 * English en_US language file
 * Contains all i18n translation strings
 * ==========================================================
 * @link:      http://mod1fy.net
 * @since      1.0.1
 * ==========================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lang/en_US.php
 * ==========================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

$i18n = array();

$i18n['DLM_TITLE']   		   = 'Download Manager by mod1fy.net';
$i18n['DLM_DESC']    		   = 'Download Manager for GetSimple.';
$i18n['DLM_SIDEBAR'] 		   = 'Download Manager';
$i18n['DLM_VIEWDESCRIPTION']   = 'Information';
$i18n['DLM_VIEWSETTINGS'] 	   = 'Settings';
$i18n['DLM_VIEWLOGS'] 	  	   = 'Logs';
$i18n['DLM_SORTTIME'] 	  	   = 'Time :';
$i18n['DLM_SORTREF'] 	  	   = 'Referrer :';
$i18n['DLM_SORTFILE'] 	  	   = 'File :';
$i18n['DLM_SORTSIZE'] 	  	   = 'Size :';
$i18n['DLM_TRAFFIC'] 	  	   = 'Traffic :';
$i18n['DLM_LOGFILESIZE'] 	   = 'Logfile size :';
$i18n['DLM_FOLDERSIZE'] 	   = 'Disk usage :';
$i18n['DLM_DISKFREE'] 	       = 'Disk free space :';
$i18n['DLM_TOTAL'] 	           = 'Total downloads :';
$i18n['DLM_BTNDEFAULTS'] 	   = 'Restore defaults';
$i18n['DLM_SETTINGSSAVED'] 	   = 'Your settings have been successful saved.';
$i18n['DLM_DEFAULTSRESTORED']  = 'Defaults have been successful restored.';
$i18n['DLM_DLTOTAL'] 	       = 'Total download count :';
$i18n['DLM_FILES'] 	           = 'Total files :';
$i18n['DLM_SYSTEMINFO']        = 'System information';
$i18n['DLM_LOGDOWNLOADS'] 	   = 'Enable download logs ?';
$i18n['DLM_REFERRER'] 	       = 'Allowed referrer. Empty = allow hotlinking. Yourdomain.com = disallow hotlinking.';
$i18n['DLM_MSGNOFILE'] 	       = 'Error message if someone trys download?f= without given file name.';
$i18n['DLM_MSGNOHOTLINK'] 	   = 'Error message if someone trys to hotlink while hotlinking is not allowed.';
$i18n['DLM_MSGNOTEXIST'] 	   = 'Error message if requested file not exists.';
$i18n['DLM_MSGNOTALLFTYPE']    = 'Error message if requested a not allowed file type.';
$i18n['DLM_INFOPAGEHEADER']    = 'Information Page';
$i18n['DLM_INFOPAGEHEADER1']   = 'Installation instructions :';
$i18n['DLM_INFOPAGECONTENT']   = 'After activation of this plugin there will be generated a new template file in your current themes root directory called "download_manager.php" .';
$i18n['DLM_INFOPAGECONTENT1']  = 'Go to <b>pages tab</b> and create a <b>new page</b>. Open the page options and enter <b>download</b> as page title. Next choose <b>"download_manager.php"</b> as page template and enter <b>download</b> as custom url (slug). <b>Do not</b> add this page to the menu or enter some meta informations. Save this page.';
$i18n['DLM_INFOPAGECONTENT2']  = 'Now click on the <b>files tab</b> and hit download manager on the right sidebar. In the settings tab you can define your preferred settings. In the logs tab you can view the download logs and some stats about your file system.';
$i18n['DLM_INFOPAGECONTENT3']  = 'When you move to your file management menu you will notice that there is a new directory called "downloadmanager". This directory is the download managers root path. All files in this directory and its subdirectorys will be indexed by the download manager. You can create as many sub-folders as you want to sort your files by category`s.';
$i18n['DLM_INFOPAGECONTENT4']  = 'All files in download manager´s root and subdirectorys can be accessed by adding links like :<br><code><b>download?f=filename.xxx</b></code> - if you have fancy urls enabled. If you not have fancy urls enabled use :<br><code><b>index.php?id=download&f=filename.xxx</code></b> instead. This way no one will know the full path of your files and of your download_manager.php.';
$i18n['DLM_INFOPAGEHEADER2']   = 'Short-codes :';
$i18n['DLM_INFOPAGECONTENT5']  = 'Download manager provides some short-codes which can be accessed by <b>(% dlm filename.xxx parameter %)</b>.';
$i18n['DLM_INFOPAGECONTENT6']  = '<b>(% dlm filename.xxx button %)</b> generates a full styled and shiny :) button with all informations about that file like file-size and download count.';
$i18n['DLM_INFOPAGECONTENT7']  = '<b>(% dlm filename.xxx link %)</b> echoes out a text link with the file-name.';
$i18n['DLM_INFOPAGECONTENT8']  = '<b>(% dlm filename.xxx size %)</b> echoes out the file-size.';
$i18n['DLM_INFOPAGECONTENT9']  = '<b>(% dlm filename.xxx count %)</b> echoes out the number of times the file was downloaded.';
$i18n['DLM_INFOPAGECONTENT10'] = '<b>(% dlm totalfiles %)</b> echoes the number of all files which are available for download.';
$i18n['DLM_INFOPAGECONTENT11'] = '<b>(% dlm totalcount %)</b> echoes the overall download count.';
$i18n['DLM_INFOPAGECONTENT12'] = '<b>(% dlm totalsizes %)</b> echoes the size of all files which are available for download.';
$i18n['DLM_INFOPAGECONTENT13'] = '<b>Make sure that your editor don´t places some &amp;nbsp;´s into your short-codes!';

?>