Download Manager by Mod1fy.net - Readme file

*****************************************************

Support : http://mod1fy.net/gsplugins/download-manager/

Requires: at least GetSimple v. 3.0.0

Tested up to : 3.3.4

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

*****************************************************

Installation instructions :
###########################

After activation of this plugin there will be generated a new template file in your current themes root directory called "download_manager.php" .

Go to pages tab and create a new page. Open the page options and enter download as page title. Next choose "download_manager.php" as page template and enter download as custom url (slug). Do not add this page to the menu or enter some meta informations. Save this page.

Now click on the files tab and hit download manager on the right sidebar. In the settings tab you can define your preferred settings. In the logs tab you can view the download logs and some stats about your file system.

When you move to your file management menu you will notice that there is a new directory called "downloadmanager". This directory is the download managers root path. All files in this directory and its subdirectorys will be indexed by the download manager. You can create as many sub-folders as you want to sort your files by category`s.

All files in download manager�s root and subdirectorys can be accessed by adding links like :
download?f=filename.xxx - if you have fancy urls enabled. If you not have fancy urls enabled use :
index.php?id=download&f=filename.xxx instead. This way no one will know the full path of your files and of your download_manager.php.

Short-codes :
#############

Download manager provides some short-codes which can be accessed by (% dlm filename.xxx parameter %).

(% dlm filename.xxx button %) generates a full styled and shiny :) button with all informations about that file like file-size and download count.

(% dlm filename.xxx link %) echoes out a text link with the file-name.

(% dlm filename.xxx size %) echoes out the file-size.

(% dlm filename.xxx count %) echoes out the number of times the file was downloaded.

(% dlm totalfiles %) echoes the number of all files which are available for download.

(% dlm totalcount %) echoes the overall download count.

(% dlm totalsizes %) echoes the size of all files which are available for download.

Make sure that your editor don�t places some &nbsp;�s into your short-codes!

Version : 1.0.4
###############

== Changelog ==

v. 1.0.4

* Added: Redo function
* Added: Restore defaults function
* Added: Information page
* Added: More Short-codes
* Fixed: Some smaller bugs

v. 1.0.3

* Added: Table sorter to logs page
* Added: Short-code for download button
* Added: Short-codes for each file
* Moved: Download script to themes root
* Fixed: More bugs

v. 1.0.2

* Added: File stats to logs page
* Added: Logs admin page
* Added: Download counts
* Added: Download logging
* Fixed: Some bugs

v. 1.0.1

* Added: Settings pages
* Added: Admin menu -> files tab
* Added: English language file

v. 1.0.0

* First stable version

== ToDo features ==

* German translation
* More download statistics
* More button styles
* More short-codes

� 2015 Dennis Maassen

dennis-maassen(at)t-online(dot)de

http://mod1fy.net