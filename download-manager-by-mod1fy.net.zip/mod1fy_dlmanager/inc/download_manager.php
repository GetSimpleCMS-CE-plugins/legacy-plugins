<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ================================================================
 * Download Manager template file.
 * To include as pages template for providing file downloads
 * and hide the path of this file.
 * ================================================================
 * @link:      http://mod1fy.net
 * @since      1.0.3
 * ================================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/inc/download_manager.php
 * @copy       theme/$TEMPLATE/download_manager.php
 * ================================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * Load settings from xml
 * @since 1.0.3
 */
$data = @getXML(GSDATAOTHERPATH . 'mod1fy_dlmanager_settings.xml');

/**
 * Check if logging is enabled
 * @since 1.0.3
 */
$logdownloads = $data->logdownloads;
	if ($logdownloads == 'on') {

			define('LOG_DOWNLOADS',true);

		} else {

			define('LOG_DOWNLOADS',false);
	}

/**
 * Set allowed referrer and define paths
 * @since 1.0.3
 */
define('ALLOWED_REFERRER', $data->referrer);
define('BASE_DIR','data/uploads/downloadmanager/');
define('LOG_FILE','data/other/logs/downloadlog.xml');
define('COUNT_FILE','data/other/logs/downloadcount.dat');

/**
 * Allowed extensions array
 * @since 1.0.3
 */
$allowed_ext = array (

	'7z'      => 'application/x-compress',
	'asf'     => 'video/x-ms-asf',
	'avi'     => 'video/x-msvideo',
	'bin'     => 'application/octet-stream',
	'bmp'     => 'image/bmp',
	'cgi'     => 'magnus-internal/cgi',
	'css'     => 'text/css',
	'dcr'     => 'application/x-director',
	'dll'     => 'application/octet-stream',
	'doc'     => 'application/msword',
	'dxr'     => 'application/x-director',
	'exe'     => 'application/octet-stream',
	'gif'     => 'image/gif',
	'gtar'    => 'application/x-gtar',
	'gz'      => 'application/gzip',
	'htm'     => 'text/html',
	'html'    => 'text/html',
	'iso'     => 'application/octet-stream',
	'jar'     => 'application/java-archive',
	'java'    => 'text/x-java-source',
	'jnlp'    => 'application/x-java-jnlp-file',
	'jpe'     => 'image/jpg',
	'jpeg'    => 'image/jpeg',
	'jpg'     => 'image/jpg',
	'js'      => 'application/x-javascript',
	'lzh'     => 'application/octet-stream',
	'mdb'     => 'application/mdb',
	'mid'     => 'audio/x-midi',
	'midi'    => 'audio/x-midi',
	'mov'     => 'video/quicktime',
	'mp2'     => 'audio/x-mpeg',
	'mp3'     => 'audio/mpeg',
	'mpe'     => 'video/mpeg',
	'mpeg'    => 'video/mpeg',
	'mpg'     => 'video/mpeg',
	'pdf'     => 'application/pdf',
	'php'     => 'application/x-httpd-php',
	'php3'    => 'application/x-httpd-php3',
	'php4'    => 'application/x-httpd-php',
	'png'     => 'image/png',
	'ppt'     => 'application/mspowerpoint',
	'qt'      => 'video/quicktime',
	'qti'     => 'image/x-quicktime',
	'ra'      => 'audio/x-pn-realaudio',
	'ram'     => 'audio/x-pn-realaudio',
	'rar'     => 'encoding/x-compress',
	'rm'      => 'audio/x-pn-realaudio',
	'rtf'     => 'application/rtf',
	'swa'     => 'application/x-director',
	'swf'     => 'application/x-shockwave-flash',
	'tar'     => 'application/x-tar',
	'tgz'     => 'application/gzip',
	'tif'     => 'image/tiff',
	'tiff'    => 'image/tiff',
	'torrent' => 'application/x-bittorrent',
	'txt'     => 'text/plain',
	'wav'     => 'audio/x-wav',
	'wma'     => 'audio/x-ms-wma',
	'wmv'     => 'video/x-ms-wmv',
	'xls'     => 'application/vnd.ms-excel',
	'xml'     => 'application/xml',
	'zip'     => 'application/x-zip-compressed'

);

/**
 * Check if allowed referrer is set
 * @since 1.0.3
 */
if (ALLOWED_REFERRER !== '' && (!isset($_SERVER['HTTP_REFERER']) || strpos(strtoupper($_SERVER['HTTP_REFERER']),strtoupper(ALLOWED_REFERRER)) === false)) {
	die($data->msgnohotlink);
}

/**
 * Prevent program execution time out (no limit)
 * @since 1.0.3
 */
set_time_limit(0);

/**
 * Check if no filename is given
 * @since 1.0.3
 */
if (!isset($_GET['f']) || empty($_GET['f'])) {
  die($data->msgnofile);
}

/**
 * Nullbyte hack fix
 * @since 1.0.3
 */
if (strpos($_GET['f'], "\0") !== FALSE) die('');

/**
 * Get the file name
 * @since 1.0.3
 */
$fname = basename($_GET['f']);

/**
 * Function find_file()
 * @Parameters $dirname, $fname, $file_path
 * Check root and sub-folders if the file exists
 * @since 1.0.3
 */
function find_file ($dirname, $fname, &$file_path) {

	$dir = opendir($dirname);

	while ($file = readdir($dir)) {

		if (empty($file_path) && $file != '.' && $file != '..') {

			if (is_dir($dirname.'/'.$file)) {
				find_file($dirname.'/'.$file, $fname, $file_path);

			} else {

				if (file_exists($dirname.'/'.$fname)) {

					$file_path = $dirname.'/'.$fname;

				return;
				}
			}
		}
	}
}

/**
 * Get full file path (including subfolders)
 * @since 1.0.3
 */
$file_path = '';
find_file(BASE_DIR, $fname, $file_path);

if (!is_file($file_path)) {
	die($data->msgnotexist);
}

/**
 * Get the filesize in bytes
 * @since 1.0.3
 */
$fsize = filesize($file_path);

/**
 * Get the file extension
 * @since 1.0.3
 */
$fext = strtolower(substr(strrchr($fname,"."),1));

/**
 * Check if allowed extension
 * @since 1.0.3
 */
if (!array_key_exists($fext, $allowed_ext)) {
	die($data->msgnotallftype);
}

/**
 * Get the mime type
 * @since 1.0.3
 */
if ($allowed_ext[$fext] == '') {

	$mtype = '';

		if (function_exists('mime_content_type')) {

			$mtype = mime_content_type($file_path);

		} else if (function_exists('finfo_file')) {

			$finfo = finfo_open(FILEINFO_MIME);
			$mtype = finfo_file($finfo, $file_path);
			finfo_close($finfo);
		}

	if ($mtype == '') {

		$mtype = "application/force-download";
	}

} else {

	$mtype = $allowed_ext[$fext];
}

/**
 * Browser will try to save file with this filename, regardless original filename.
 * You can override it if needed.
 * @since 1.0.3
 */
if (!isset($_GET['fc']) || empty($_GET['fc'])) {

	$asfname = $fname;

} else {

	$asfname = str_replace(array('"',"'",'\\','/'), '', $_GET['fc']);
	if ($asfname === '') $asfname = 'NoName';
}

/**
 * Set headers
 * @since 1.0.3
 */
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: public");
header("Content-Description: File Transfer");
header("Content-Type: $mtype");
header("Content-Disposition: attachment; filename=\"$asfname\"");
header("Content-Transfer-Encoding: binary");
header("Content-Length: " . $fsize);

/**
 * readfile($file_path)
 * @since 1.0.3
 */
$file = @fopen($file_path,"rb");
if ($file) {
	while(!feof($file)) {

		print(fread($file, 1024*8));
		flush();

		if (connection_status()!=0) {
			@fclose($file);
			die();
		}
	}
	@fclose($file);
}

/**
 * Count downloads
 * @data/other/logs/downloadcount.dat
 * @since 1.0.3
 */
$h = @fopen(COUNT_FILE,'a');

if ($h) {
	@flock($h, LOCK_EX);
	@fwrite($h, $fname."|".date("Y-m-d|H:i:s")."|".$_SERVER['REMOTE_ADDR']."|".$fsize."\n");
	@flock($h, LOCK_UN);
	@fclose($h);
}

/**
 * Log downloads as xml if logging is enabled
 * @data/other/logs/downloadlog.xml
 * @since 1.0.3
 */
if (!LOG_DOWNLOADS) die();

$f = @fopen(LOG_FILE, 'r+');

if ($f) {
	@flock($f, LOCK_EX);
	@fseek($f, -7, SEEK_END);
	@fputs($f, "\n<downloadlog>\n\t<dltime>".date("Y-m-d H:i:s")."</dltime>\n\t<dlreferrer>".$_SERVER['REMOTE_ADDR']."</dlreferrer>\n\t<dlfilename>".$fname."</dlfilename>\n\t<dlfilesize>".$fsize."</dlfilesize>\n</downloadlog>\n</log>");
	@flock($f, LOCK_UN);
	@fclose($f);
}

?>