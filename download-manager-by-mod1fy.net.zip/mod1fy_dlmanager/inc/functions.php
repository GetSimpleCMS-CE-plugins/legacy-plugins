<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ==========================================================
 * Main functions file
 * Provides some needed functions
 * @formatBytes since 1.0.3
 * @download_count since 1.0.4
 * @get_folder_size since 1.0.3
 * ==========================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * ==========================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/plugin.class.php
 * ==========================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
* Function formatBytes to reformat sizes into more readable ones
* Uncomment variable $bytes for binary or decimal system
* @since 1.0.3
*/
function formatBytes($bytes, $precision = 2) {
	$units = array('B', 'KB', 'MB', 'GB', 'TB');

	$bytes = max($bytes, 0);
	$pow = floor(($bytes ? log($bytes) : 0) / log(1024));
	$pow = min($pow, count($units) - 1);

	$bytes /= pow(1024, $pow);
	// $bytes /= (1 << (10 * $pow));

	return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
* Function download_count()
* Parameter $file to get download count for this file
* @since 1.0.4
*/
function download_count($file) {

	$count = 0;

	if (file_exists(GSDATAOTHERPATH . 'logs/downloadcount.dat')) {
		$download = explode("\n", file_get_contents(GSDATAOTHERPATH . 'logs/downloadcount.dat'));

		foreach ($download as $line) {
			list($dlmfile, $dlmdate, $dlmtime, $dlmreferrer, $dlmsize) = array_pad(explode('|', $line, 5), 5, null);

			if ($file == $dlmfile) {
				$count++;
			}
		}
	}
return $count;
}

/**
 * Function get_folder_size including sub folders
 * Summary of all file sizes in bytes in parameters given $dir
 * @since 1.0.3
 */
function get_folder_size($dir){
	$size = "";
	$fp=opendir($dir);
		while($file=readdir($fp)){
			if ($file != "." && $file != "..") {
				if(is_dir($dir.$file)) $size=get_folder_size($dir.$file."/")+$size;
				else $size=filesize($dir.$file)+$size;
			}
		}
	closedir($fp);
	return $size;
}
?>