<?php
  /** CKEDITOR
    
    * This file exists for easy implementation of CKEditor blocks in the admin panel
    * When creating a textarea that should be turned into a WYSIWYG editor, give that
      textarea a unique id. Then immediately afterwards, in PHP, define a $textarea 
      variable with that id, then include this file.
      
      e.g.
      
      <textarea id="mytextarea"></textarea>
      <?php
        $textarea = 'mytextarea';
        include('/path/to/inc/ckeditor.php');
      ?>
  */
  $toolbar = !is_null($GLOBALS['EDTOOL']) ? ", toolbar: '" . trim($GLOBALS['EDTOOL'], ",'") . "'" : '';
  $options = !is_null($GLOBALS['EDOPTIONS']) ? ',' . trim($GLOBALS['EDOPTIONS'], ",") : '';
?>
	<?php if ($GLOBALS['HTMLEDITOR'] != '') { ?>
	<script type="text/javascript" src="template/js/ckeditor/ckeditor.js"></script>
	<script type="text/javascript">
	  var editor = CKEDITOR.replace('<?php echo isset($textarea) ? $textarea : 'post-content'; ?>', {
			  skin : 'getsimple',
			  forcePasteAsPlainText : true,
			  language : '<?php echo $GLOBALS['EDLANG']; ?>',
			  defaultLanguage : 'en',
			  <?php if (file_exists(GSTHEMESPATH . $GLOBALS['TEMPLATE'] ."/editor.css")) { 
				  $fullpath = suggest_site_path();
				  ?>
				  contentsCss: '<?php echo $fullpath; ?>theme/<?php echo $GLOBALS['TEMPLATE']; ?>/editor.css',
			  <?php } ?>
			  entities : false,
			  uiColor : '#FFFFFF',
			  height: '<?php echo isset($height) ? $height : $GLOBALS['EDHEIGHT']; ?>',
			  baseHref : '<?php echo $GLOBALS['SITEURL']; ?>',
			  tabSpaces:10,
			  filebrowserBrowseUrl : 'filebrowser.php?type=all',
			  filebrowserImageBrowseUrl : 'filebrowser.php?type=images',
			  filebrowserWindowWidth : '730',
			  filebrowserWindowHeight : '500'
			  <?php echo $toolbar; ?>
			  <?php echo $options; ?>					
	  });
	</script>
	<?php
		# CKEditor setup functions
		ckeditor_add_page_link();
		exec_action('html-editor-init'); 
	?>
	<?php } ?>
