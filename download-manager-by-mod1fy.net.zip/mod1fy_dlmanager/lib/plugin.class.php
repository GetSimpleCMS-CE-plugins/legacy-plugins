<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ==========================================================
 * Main plugin class file
 * Registers the plugin 
 * ==========================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * ==========================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/plugin.class.php
 * ==========================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

class Mod1fy_DLManager {
	private $id;  // plugin id
	
	// constructor
	public function __construct($id) {
		$this->id = $id;  // set the plugin id (so we can use it in other methods)
	}
	
	// register the autoloader function
	public function autoload() {
		spl_autoload_register(array($this, 'autoloader'));
	}
	
	// autoload function: load the class if its file exists in /lib/ (with a lowercase name)
	private function autoloader($class) {
		if (file_exists($file = GSPLUGINPATH . $this->id . '/lib/' . strtolower($class) . '.class.php')) {
			include($file);
		}
	}
	
	// load the correct language file
	public function i18nMerge() {
		i18n_merge($this->id) || i18n_merge($this->id, 'en_US');
	}
	
	// register the plugin
	public function register() {
		register_plugin(
			$this->id,                               // id
			i18n_r($this->id . '/DLM_TITLE'),        // title
			'1.0.5',                                 // version
			'Dennis Maassen',                        // author
			'http://mod1fy.net/',                    // author site
			i18n_r($this->id . '/DLM_DESC'),         // description
			'files',                                 // admin page in files tab
			array($this, 'displayAdminPanel')        // admin panel function
		);
	}
	
	// initialization
	public function init() {
		global $SITEURL, $TEMPLATE;
		
		// create sidebar link in admin page (files)
		add_action('files-sidebar','createSideMenu', array($this->id, i18n_r($this->id . '/DLM_SIDEBAR')));
		
		add_filter('content', array($this, 'filterContent'));
		
		// register & queue scripts & styles
		register_script('tablesorter', $SITEURL.'plugins/mod1fy_dlmanager/assets/js/jquery.tablesorter.min.js', '2.0.5', FALSE);
		register_script('sorterpager', $SITEURL.'plugins/mod1fy_dlmanager/assets/js/addons/pager/jquery.tablesorter.pager.js', '2.0.5', FALSE);
		register_style('dlmanageradmin', $SITEURL.'plugins/mod1fy_dlmanager/assets/css/adminstyle.css', '1.0.0', 'screen');
		register_style('dlmanagerfront', $SITEURL.'plugins/mod1fy_dlmanager/assets/css/dlmanager.css', '1.0.0', 'screen');
		queue_script('tablesorter',GSBACK);
		queue_script('sorterpager',GSBACK);
		queue_style('dlmanageradmin',GSBACK);
		queue_style('dlmanagerfront',GSFRONT);
		
		// copy default settings file
		if (!file_exists($settings = GSDATAOTHERPATH . $this->id . '_settings.xml')) {
			copy(GSPLUGINPATH . $this->id . '/assets/xml/settings.xml', $settings);
		}
		
		// copy downloadlog dummy file
		if (!file_exists($downloadlog = GSDATAOTHERPATH . '/logs/downloadlog.xml')) {
			copy(GSPLUGINPATH . $this->id . '/assets/xml/downloadlog.xml', $downloadlog);
		}
		
		// copy downloadcount dummy file
		if (!file_exists($downloadcount = GSDATAOTHERPATH . '/logs/downloadcount.dat')) {
			copy(GSPLUGINPATH . $this->id . '/inc/downloadcount.dat', $downloadcount);
		}
		
		// copy download manager template to current template directory
		global $TEMPLATE;
		if (!file_exists($download = GSTHEMESPATH . $TEMPLATE . '/download_manager.php')) {
			copy(GSPLUGINPATH . $this->id . '/inc/download_manager.php', $download);
		}

		// create download manager root directory
		global $SITEURL;
			$path =  '../data/uploads/downloadmanager';
		if(!is_dir($path)){
			mkdir($path, 0777, true);
		}
	}
	
	public function filterContent($content) {
		// load the placeholder class and filter the content
		$dlplaceholder = new DlManagerPlaceholder();
		return $dlplaceholder->filter($content);
	} 
	
	// display the admin panel
	public function displayAdminPanel() {
		$admin = new Mod1fy_DLManagerAdminDisplay($this->id);   // load admin panel object
		$admin->getPage();                                      // get the correct admin panel page
	}
}

?>
