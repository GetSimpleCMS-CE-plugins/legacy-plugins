<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ================================================================
 * Admin class file
 * Save settings to xml
 * ================================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * ================================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/mod1fy_dlmanageradmin.class.php
 * ================================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * Main admin class
 * @since 1.0.0
 */
class Mod1fy_DLManagerAdmin {
	private $id; // useful to have the plugin id
	private $url; // useful to have the admin plugin link

	/**
	 * Constructor
	 * @since 1.0.0
	 */
	public function __construct($id) {
		$this->id = $id;
		$this->url = 'load.php?id=' . $id;
	}

	/**
	 * Function saveSettings()
	 * Save all settings to xml
	 * @since 1.0.0
	 */
	protected function saveSettings($settingsFile, array $data) {
	$xml = new SimpleXMLExtended($settingsFile, 0, true);

		// loop through data array and set the properties
		foreach ($data as $field => $value) {
			$xml->{$field} = null;
			$xml->{$field}->addCData($value);
		}

	// save the xml file and return the success boolean
	return $xml->saveXML($settingsFile);
	}
}

?>
