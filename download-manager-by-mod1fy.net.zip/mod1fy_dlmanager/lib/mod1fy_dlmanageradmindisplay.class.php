<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * =======================================================================
 * Admin display class
 * Creates all settings pages / load settings
 * =======================================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * =======================================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/mod1fy_dlmanageradmindisplay.class.php
 * =======================================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * Main class to display the admin panel
 * @since 1.0.0
 */
class Mod1fy_DLManagerAdminDisplay extends Mod1fy_DLManagerAdmin {

	/**
	 * Function getPage
	 * Display the correct admin page
	 * @since 1.0.0
	 */
	public function getPage() {
	
	$error = "";
	$isSuccess = "";
	$canUndo = false;
	$settingsFile = GSDATAOTHERPATH . 'mod1fy_dlmanager_settings.xml';
	$backupFile = GSBACKUPSPATH . '/other/mod1fy_dlmanager_settings.xml';
	$defaultFile = GSPLUGINPATH . '/mod1fy_dlmanager/assets/xml/settings.xml';
	
		if (isset($_POST['submit'])) {
		
			if (file_exists($settingsFile)) {
			
				if (copy($settingsFile, $backupFile)) {
				
					$canUndo = true;
				}
			}
			if ($this->saveSettings($settingsFile, $_POST)) {
			
				$isSuccess = true;
			}
			$msg = $isSuccess ? i18n_r('mod1fy_dlmanager/DLM_SETTINGSSAVED') : i18n_r('ERROR');
			if ($isSuccess && $canUndo) $msg .= ' <a href="load.php?id=mod1fy_dlmanager&view=settings&undo">' . i18n_r('UNDO') . '</a>';
		}
		if (isset($_POST['defaults'])) {
		
			if (file_exists($settingsFile)) {
			
				if (copy($settingsFile, $backupFile)) {
				
					$canUndo = true;
				}
			}
			$isSuccess = !file_exists($settingsFile) || copy($defaultFile, $settingsFile);
			$msg = $isSuccess ? i18n_r('mod1fy_dlmanager/DLM_DEFAULTSRESTORED') : i18n_r('ERROR');
			if ($isSuccess && $canUndo) $msg .= ' <a href="load.php?id=mod1fy_dlmanager&view=settings&undo">' . i18n_r('UNDO') . '</a>';
		}
		if (isset($_REQUEST['undo'])) {
		
			if (file_exists($backupFile)) {
			
				if (copy($backupFile, $settingsFile)) {
				
					$isSuccess = true;
				}
			}
			$msg = $isSuccess ? i18n_r('ER_OLD_RESTORED') : i18n_r('ERROR');
		}
	// load settings object and display the settings
	$settings = new Mod1fy_DLManagerSettings($settingsFile);
	$this->displaySettings($settings);

	if (isset($msg)) {
			?>
			<script type="text/javascript">
				$(function() {
					$('div.bodycontent').before('<div class="<?php echo $isSuccess ? 'updated' : 'error'; ?>" style="display:block;">'+<?php echo json_encode($msg); ?>+'</div>');
					$(".updated, .error").fadeOut(500).fadeIn(500);
				});
			</script>
			<?php
			}
	
	}
	/**
	 * Main function to display the admin panel
	 * @since 1.0.0
	 */
	private function displaySettings(Mod1fy_DLManagerSettings $settings) {

		include_once(GSPLUGINPATH.'mod1fy_dlmanager/inc/functions.php');

		// set default admin page
		$view = @$_REQUEST['view'];
			if (!$view) $view = 'description';
			$link = "load.php?id=mod1fy_dlmanager&view=settings";
?>
		<h3 class="floated" style="float:left"><?php i18n('mod1fy_dlmanager/DLM_SIDEBAR'); ?></h3>
		<div class="edit-nav" >
			<p>
				<a href="<?php echo $link; ?>&view=description" <?php echo $view=='description' ? 'class="current"' : ''; ?> ><?php echo i18n_r('mod1fy_dlmanager/DLM_VIEWDESCRIPTION'); ?></a>
				<a href="<?php echo $link; ?>&view=settings" <?php echo $view=='settings' ? 'class="current"' : ''; ?> ><?php echo i18n_r('mod1fy_dlmanager/DLM_VIEWSETTINGS'); ?></a>
				<a href="<?php echo $link; ?>&view=logs" <?php echo $view=='logs' ? 'class="current"' : ''; ?> ><?php echo i18n_r('mod1fy_dlmanager/DLM_VIEWLOGS'); ?></a>
			</p>
			<div class="clear"></div>
		</div>

		<?php if ($view == 'logs') { ?>

		<div>
			<table class="tablesorter">
				<thead>
					<tr>
						<th width="25%"><?php echo i18n('mod1fy_dlmanager/DLM_SORTTIME'); ?></th>
						<th width="25%"><?php echo i18n('mod1fy_dlmanager/DLM_SORTREF'); ?></th>
						<th width="25%"><?php echo i18n('mod1fy_dlmanager/DLM_SORTFILE'); ?></th>
						<th width="25%"><?php echo i18n('mod1fy_dlmanager/DLM_SORTSIZE'); ?></th>
					</tr>
				</thead>
				<tbody>
		<?php
					$xml = @getXML(GSDATAOTHERPATH . 'logs/downloadlog.xml');
					foreach ( $xml->downloadlog as $logfile ) {
						$filesize = (float)$logfile->dlfilesize;
						echo '<tr><td>' . $logfile->dltime . '</td><td>' . $logfile->dlreferrer . '</td><td>' . $logfile->dlfilename . '</td><td>' . formatBytes($filesize) . '<td></tr>';
					}
		?>
				</tbody>
			</table>
			<div id="pager" class="pager">
				<form>
					<img src="../plugins/mod1fy_dlmanager/assets/js/addons/pager/icons/first.png" class="first"/>
					<img src="../plugins/mod1fy_dlmanager/assets/js/addons/pager/icons/prev.png" class="prev"/>
					<input type="text" class="pagedisplay"/>
					<img src="../plugins/mod1fy_dlmanager/assets/js/addons/pager/icons/next.png" class="next"/>
					<img src="../plugins/mod1fy_dlmanager/assets/js/addons/pager/icons/last.png" class="last"/>
				<select class="pagesize">
					<option selected="selected"  value="10">10</option>
					<option value="20">20</option>
					<option value="30">30</option>
					<option value="40">40</option>
					<option value="40">50</option>
					<option value="40">80</option>
					<option value="40">100</option>
					<option value="40">200</option>
				</select>
				</form>
			</div>
		</div>

		<br>

		<script type="text/javascript">
			$(document).ready(function() {
				$("table")
				.tablesorter({widthFixed: true, widgets: ['zebra'], sortList: [[0,1]]})
				.tablesorterPager({container: $("#pager")});
			});
		</script>

		<table class="edittable highlight">
			<thead>
				<tr><th><?php i18n('mod1fy_dlmanager/DLM_SYSTEMINFO'); ?></th><th></th></tr>
			</thead>
			<tbody>
				<?php
					// get downloadcount filesizes from xml
					$xxx = array();
					foreach ($xml->downloadlog as $bytes) {
						$xxx[] = (string)$bytes->dlfilesize;  
					}
					// sum all to get the generated traffic
					$traffic = array_sum($xxx);
					$rootsize=get_folder_size(GSROOTPATH);
					$logfile = filesize(GSDATAOTHERPATH . 'logs/downloadlog.xml');
					$quota = disk_free_space(GSROOTPATH);
					$ite=new RecursiveDirectoryIterator(GSDATAUPLOADPATH . 'downloadmanager/');
					$bytestotal=0;
					$nbfiles=0;
					foreach (new RecursiveIteratorIterator($ite) as $filename=>$cur) {
						$filesize=$cur->getSize();
						$bytestotal+=$filesize;
						$nbfiles++;
						//echo $filename ,PHP_EOL;
						//echo $cur->getFilename(), PHP_EOL;
					}
					$bytestotal=(float)$bytestotal;
					$dltotal=0;
					foreach ( $xml->downloadlog as $filenames ) {
						$dltotal++;
					}
				?>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_TRAFFIC'); ?></td><td><?php echo formatBytes($traffic); ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_LOGFILESIZE'); ?></td><td><?php echo formatBytes($logfile); ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_FOLDERSIZE'); ?></td><td><?php echo formatBytes($rootsize); ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_DISKFREE'); ?></td><td><?php echo formatBytes($quota); ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_FILES'); ?></td><td><?php echo $nbfiles; ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_TOTAL'); ?></td><td><?php echo formatBytes($bytestotal); ?></td></tr>
				<tr><td><?php echo i18n('mod1fy_dlmanager/DLM_DLTOTAL'); ?></td><td><?php echo $dltotal; ?></td></tr>
			</tbody>
		</table>

		<?php } if ($view == 'settings') { ?>
		
		<form id="settings" action="<?php echo $link; ?>" method="post" accept-charset="utf-8" onSubmit="window.location.reload()">
			<p> 
				<label for="logdownloads"><?php i18n('mod1fy_dlmanager/DLM_LOGDOWNLOADS'); ?></label>
				<input type="radio" id="on" name="logdownloads" value="on" <?php if ($settings->getSetting('logdownloads') == 'on') echo "checked=\"checked\""; ?> /> On
				<input type="radio" id="off" name="logdownloads" value="off" <?php if ($settings->getSetting('logdownloads') == 'off') echo "checked=\"checked\""; ?> /> Off</br>
			</p>
			<p>
				<label for="referrer"><?php i18n('mod1fy_dlmanager/DLM_REFERRER'); ?></label>
				<input type="text" class="text" name="referrer" placeholder="example.com" value="<?php echo $settings->getSetting('referrer'); ?>"/>
			</p>
			<p>
				<label for="msgnofile"><?php i18n('mod1fy_dlmanager/DLM_MSGNOFILE'); ?></label>
				<input type="text" class="text" name="msgnofile" value="<?php echo $settings->getSetting('msgnofile'); ?>"/>
			</p>
			<p>
				<label for="msgnohotlink"><?php i18n('mod1fy_dlmanager/DLM_MSGNOHOTLINK'); ?></label>
				<input type="text" class="text" name="msgnohotlink" value="<?php echo $settings->getSetting('msgnohotlink'); ?>"/>
			</p>
			<p>
				<label for="msgnotexist"><?php i18n('mod1fy_dlmanager/DLM_MSGNOTEXIST'); ?></label>
				<input type="text" class="text" name="msgnotexist" value="<?php echo $settings->getSetting('msgnotexist'); ?>"/>
			</p>
			<p>
				<label for="msgnotallftype"><?php i18n('mod1fy_dlmanager/DLM_MSGNOTALLFTYPE'); ?></label>
				<input type="text" class="text" name="msgnotallftype" value="<?php echo $settings->getSetting('msgnotallftype'); ?>"/>
			</p>
			<p id="submit_line">
				<span>
					<input onClick="window.location.reload()" type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" />
					<input onClick="window.location.reload()" type="submit" id="defaults" class="submit" value="<?php i18n("mod1fy_dlmanager/DLM_BTNDEFAULTS"); ?>" name="defaults" />
				</span>
			</p>
		</form>
		
		<?php } if ($view == 'description') { ?>
		
		<div class="fileinfo">
			<h3><?php i18n('mod1fy_dlmanager/DLM_INFOPAGEHEADER1'); ?></h3>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT1'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT2'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT3'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT4'); ?></p>
		</div><br>
		<div class="fileinfo">
			<h3><?php i18n('mod1fy_dlmanager/DLM_INFOPAGEHEADER2'); ?></h3>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT5'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT6'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT7'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT8'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT9'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT10'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT11'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT12'); ?></p>
			<p><?php i18n('mod1fy_dlmanager/DLM_INFOPAGECONTENT13'); ?></p>
		</div><br>
		<div class="clear"></div>
		<div style="padding-right:1%;width:49%;" class="leftsec">
			<div style="font-family:consolas;" class="fileinfo">
				Version : 1.0.4<br><br>
				== Changelog ==<br><br>
				v. 1.0.5<br><br>
				* Fixed: A PHP 5.3+ function to 5.2+ compatibility<br><br>
				v. 1.0.4<br><br>
				* Added: Redo function<br>
				* Added: Restore defaults function<br>
				* Added: Information page<br>
				* Added: More Short-codes<br>
				* Fixed: Some smaller bugs<br><br>
				v. 1.0.3<br><br>
				* Added: Table sorter to logs page<br>
				* Added: Short-code for download button<br>
				* Added: Short-codes for each file<br>
				* Moved: Download script to themes root<br>
				* Fixed: More bugs<br><br>
				v. 1.0.2<br><br>
				* Added: File stats to logs page<br>
				* Added: Logs admin page<br>
				* Added: Download counts<br>
				* Added: Download logging<br>
				* Fixed: Some bugs<br><br>
				v. 1.0.1<br><br>
				* Added: Settings pages<br>
				* Added: Admin menu -> files tab<br>
				* Added: English language file<br><br>
				v. 1.0.0<br><br>
				* First stable version<br>
			</div>
		</div>
		<div style="padding-left:1%;width:49%;" class="rightsec">
			<div style="text-align:center;" class="fileinfo">
				&copy; 2014 Dennis Maassen<br><br>
				<a href="http://mod1fy.net/" target="_blank">http://mod1fy.net</a><br><br>
				<p>If you like my work buy me a coffee :)</p>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="S8FN58PVGSVC4">
					<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
					<img alt="" border="0" src="https://www.paypalobjects.com/de_DE/i/scr/pixel.gif" width="1" height="1">
				</form><br><br>
				<div style="text-align:left;font-family:consolas;">
					== ToDo features ==<br><br>
					* German translation<br>
					* More download statistics<br>
					* More button styles<br>
					* More short-codes<br>
				</div>
			</div>
		</div>
		<div class="clear"></div>
		
		<?php
		
		}
	}	
} 

?>