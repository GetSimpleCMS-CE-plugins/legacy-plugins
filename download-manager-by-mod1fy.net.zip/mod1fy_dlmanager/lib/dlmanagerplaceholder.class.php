<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ================================================================
 * Place-holder class file
 * Generates place-holders for each file in dlmanager root folder
 * ================================================================
 * @link:      http://mod1fy.net
 * @since      1.0.3
 * ================================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/dlmanagerplaceholder.class.php
 * ================================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * Main place-holder class
 * @since 1.0.3
 */
class DlManagerPlaceholder {
	private $placeholders = array();
	private $replacements = array();

	public function __construct() {
		$this->setPlaceholders();
	}

	/**
	 * Main function for place-holders
	 * @since 1.0.3
	 */
	private function setPlaceholders() {

		include_once(GSPLUGINPATH.'mod1fy_dlmanager/inc/functions.php');
		
		$xml = @getXML(GSDATAOTHERPATH . 'logs/downloadlog.xml');
		$dltotal=0;
		foreach ( $xml->downloadlog as $filenames ) {
			$dltotal++;
		}
		// Check dlmanager root recursive for new files
		$ite=new RecursiveDirectoryIterator(GSDATAUPLOADPATH . 'downloadmanager/');

		$bytestotal=0;
		$nbfiles=0;
		global $SITEURL;

		/**
		* Create placeholders for each file in dlmanager root
		* @since 1.0.3
		*/
		foreach (new RecursiveIteratorIterator($ite) as $filename=>$cur) {

			$dlimage = $SITEURL.'plugins/mod1fy_dlmanager/assets/css/download.png';
			$filesize=$cur->getSize();
			$bytestotal+=$filesize;
			$nbfiles++;
			$fname = $cur->getFilename();

			$this->placeholders[] = '(% dlm '.$fname.' button %)';
			$this->replacements[] = '<a href="'.$SITEURL.'index.php?id=download&f='.$fname.'"><button id="glow" class="dlmbtn"><span class="divider"><img src="'.$dlimage.'"></span><span class="file">'.$fname.'</span><br><span class="count"><span style="padding-right:2px;color:#8F8DD8;">&#9660;</span>'.download_count($fname).'</span><span class="size">'.formatBytes($filesize, $precision = 0).'</span></button></a>';

			$this->placeholders[] = '(% dlm '.$fname.' size %)';
			$this->replacements[] = formatBytes($filesize);

			$this->placeholders[] = '(% dlm '.$fname.' link %)';
			$this->replacements[] = '<a href="download?f='.$fname.'">'.$fname.'</a>';

			$this->placeholders[] = '(% dlm '.$fname.' count %)';
			$this->replacements[] = download_count($fname);

		}

		$this->placeholders[] = '(% dlm totalfiles %)';
		$this->replacements[] = $nbfiles;

		$this->placeholders[] = '(% dlm totalcount %)';
		$this->replacements[] = $dltotal;

		$this->placeholders[] = '(% dlm totalsizes %)';
		$this->replacements[] = formatBytes($bytestotal);

	}

	/**
	* Function filter($content)
	* Replace all place-holders with its replacements
	* @since 1.0.3
	*/
	public function filter($content) {
		return str_replace($this->placeholders, $this->replacements, $content);
	}
}
?>