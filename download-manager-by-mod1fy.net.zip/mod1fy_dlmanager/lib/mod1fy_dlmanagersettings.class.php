<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/**
 * Download Manager by Mod1fy.net for GetSimple CMS
 * ===================================================================
 * Main dlmanagersettings class file
 * Generate settings file and set defaults
 * ===================================================================
 * @link:      http://mod1fy.net
 * @since      1.0.1
 * ===================================================================
 * @package    mod1fy_dlmanager
 * @subpackage mod1fy_dlmanager/lib/mod1fy_dlmanagersettings.class.php
 * ===================================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * Main settings class
 * @since 1.0.1
 */
class Mod1fy_DLManagerSettings {
	private $settings = array();

	/**
	 * Main settings function
	 * @since 1.0.1
	 */
	public function __construct($settingsFile) {

	// load xml settingsFile
	$xml = new SimpleXMLExtended($settingsFile, 0, true);

	// set each xml field as a string in the settings array
		foreach ($xml as $field => $value) {
			$this->settings[$field] = (string) $value;
		}
	}

	/**
	 * getSetting function
	 * @since 1.0.1
	 */
	public function getSetting($setting) {
		if (isset($this->settings[$setting])) {
		return $this->settings[$setting];
		}
		else return null;
	}
}

?>