Version 1.0.1 (April 2012)
==========================
* No longer using the __DIR__ magic variable - should now work with PHP < 5.3.0

Version 1.0.0
==========================
Initial release.

* Update your out-of-date plugins with a single click
* Update your GetSimple installation to the latest version
