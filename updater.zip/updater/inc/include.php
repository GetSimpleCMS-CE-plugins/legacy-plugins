<?php
define('UPDATER_INCLUDEPATH', dirname(__FILE__));

require_once UPDATER_INCLUDEPATH.'/defines.php';
require_once UPDATER_INCLUDEPATH.'/config.php';
require_once UPDATER_INCLUDEPATH.'/helpers.php';

require_once UPDATER_INCLUDEPATH.'/admin.php';
require_once UPDATER_INCLUDEPATH.'/api.php';
require_once UPDATER_INCLUDEPATH.'/getsimple.php';
require_once UPDATER_INCLUDEPATH.'/plugins.php';
require_once UPDATER_INCLUDEPATH.'/status.php';
