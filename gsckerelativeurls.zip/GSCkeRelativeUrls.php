<?php

/**
* GSCkeRelativeUrls plugin
* replaces editor links with site relative links
* @version 0.1
* @author Shawn Alverson
* @link http://get-simple.info
* @file GSCkeRelativeUrls
*/

$pluginid = "GSCkeRelativeUrls";

function init_GSCkeRelativeUrls($pluginid){
	$thisfile = basename(__FILE__, ".php");	// Plugin File
	$name     = $pluginid;
	$version  = "0.1";
	$author   = "getsimple";
	$url      = "http://get-simple.info";
	$desc     = "Overrides ckeditor absolute links with relative links, GS 3.3.x";
	$type     = "";
	$func     = "";

	register_plugin($thisfile,$name,$version,$author,$url,$desc,$type,$func);
}

init_GSCkeRelativeUrls($pluginid);
add_filter('editorlinks',$pluginid.'_editorlinks');

function GSCkeRelativeUrls_editorlinks($array){	
	foreach($array as &$menu){
		$menu[1] = getRootRelURIPath($menu[1]);
	}
	return $array;
}

if(!function_exists('getRootRelURIPath')){
	/**
	 * get web root-relative url
	 * parses the host:// part and removes it
	 *
	 * @since  3.4
	 * @var str url to normalize
	 */
	function getRootRelURIPath($url){
	  $urlparts = parse_url($url);
	  $strip    = isset($urlparts['scheme']) ? $urlparts['scheme'] .':' : '';
	  $strip   .=  '//';
	  $strip   .= isset($urlparts['host']) ? $urlparts['host'] : '';
	  // debugLog(__FUNCTION__.' base = ' . $strip);
	  if(strpos($url,$strip) === 0) return str_replace($strip,'',$url);
	  return $url;
	}
}

?>