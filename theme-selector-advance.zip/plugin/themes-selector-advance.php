<?php
/*
Plugin Name: Theme Selector Advance
Description: Generate a preview of all sites from a remote sentral point. Select one and it will be downloaded and made locally active
Version: 0.1b
Author: Dominion IT (Johannes Pretorius)
Author URI: http://www.dominion-it.co.za/
GS Version : 3
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Theme Selector Advance', 	# Title of plugin
	'0.1b', 		# Version of plugin
	'Johannes Pretorius',	# Author of plugin
	'http://www.dominion-it.co.za/', 	# Author URL
	' Generate a preview of all sites from a remote sentral point. Select one and it will be downloaded and made locally active', 	# Plugin Description
	'theme', 	# Page type of plugin
	'dominion_adv_theme_previews'  	# Function that displays content
);

# activate filter
add_action('theme-sidebar','createSideMenu',array($thisfile,'Adv Themes Selector'));


function dominion_adv_theme_previews(){
       global $TEMPLATE;
       
       global $SITEURL;
       require_once(GSPLUGINPATH."dominion-it-shared/dominion-common.php");
	   require_once(GSPLUGINPATH."dominion-it-shared/http_files.php");
	   $settingsfile =  GSPLUGINPATH.'theme-selector-advance/themesettings.cfg';
	   $themeurls =  GSPLUGINPATH.'theme-selector-advance/themeurls.cfg';
       if (!class_exists ( 'ZipArchive' , false)) {
		  include('inc/ZipArchive.php');
	   }
	   $nopZip = '';
	   if (!class_exists ( 'ZipArchive' , false)) {
	     $nopZip = "PHP Package ZipArchive needs to included, please view your webhealth check.";
	   }
	   
	    $lastThemeDownloaded = '';
		 
		 if (file_exists($settingsfile)) {
		   $settings = parse_ini_file($settingsfile);
		   $lastThemeDownloaded = $settings['lasttheme'];
		   $aparteThemes = $settings['sepereatethemes'];

		 }
		 if (isset($_GET['stooropsie'])) {
		    $aparteThemes = isset($_GET['sepereatethemes'])?1:0;
			file_put_contents($settingsfile,"lasttheme=$lastThemeDownloaded \n\rsepereatethemes=$aparteThemes");
		 }
		 
		 if (file_exists($themeurls)) {
		    $fileurl=fopen($themeurls,"r");
		   $urls = fgetcsv($fileurl);
		   foreach ($urls as $key => $url) { 
             if (is_null($url)) { 
                unset($urls[$key]); 
             } 
           } 
		   fclose($fileurl);
		 }		 
		 $error = '';
		 if (isset($_POST['themeurl'])) {
		  
  		    $urls[] = trim($_POST['themeurl']);
			$fileurl=fopen($themeurls,"w");
              fputcsv($fileurl,$urls);
			fclose($fileurl);
            
		 }
		 
		 if ((isset($_GET['verwyder']))  && ($_GET['verwyder'])) {
		    $fileurl=fopen($themeurls,"r");
		   $urls = fgetcsv($fileurl);
		   fclose($fileurl);
		   $tiekenVrw = urldecode($_GET['verwyder']);
		   foreach ($urls as $key => $url){
		     if ($tiekenVrw == $url) {
			   unset($urls[$key]);
			   break;
			 }
		   }
			$fileurl=fopen($themeurls,"w");
              fputcsv($fileurl,$urls);
			fclose($fileurl);
		 }
		 
		 
	   if ((isset($_GET['opsies'])) && ($_GET['opsies'])) {
	      echo "<div>";
		  echo "<p><a href='?id=themes-selector-advance'>Select Theme</a></p>";
		  echo "<p><form method='post'>Theme URL (add / at end): <input size='50' type='text' name='themeurl' value='http://www.'><input type='submit' name='stoor' value='Save'></form></p>";
		  foreach ($urls as $url) {
		   $urlVerw = urlencode($url);
		  echo "<p>$url - <a href='?id=themes-selector-advance&opsies=1&verwyder=$urlVerw'>Remove</a></p>";
		  }
		  echo "</div>";
		  return;
       }	   
         $curThemeURL = isset($_GET['CURT'])?urldecode($_GET['CURT']):'';
		
		$themeurlslist = '';
		foreach ($urls as $url) {
		   $urlVerw = urlencode($url);
		   if ($curThemeURL == '') {
		     $curThemeURL = $url;
		   }
		   if ($curThemeURL == $url) {
		       $themeurlslist .= "<option selected='selected' value='$urlVerw'>$url</option>";
		    } else {
			  $themeurlslist .= "<option value='$urlVerw'>$url</option>";
            }			
		}
		if ($curThemeURL == '') {
		   $curThemeURL = 'http://www.dominion-it.co.za/kliente/GS/'; //last default no config yet.
        }	
		$curThemeURLEnc = urlencode($curThemeURL);
       if ((isset($_GET['TN'])) && (class_exists ( 'ZipArchive' , false))) {
	     
		
	     $selected = $_GET['TN'];
		 if ($lastThemeDownloaded <>  $selected) {

		      $newActiveName = ($aparteThemes == 1)?$selected:'ThemeSelector';

			 
			 $local_file = GSPLUGINPATH.'theme-selector-advance/local.zip';
			 $server_file = "$curThemeURL/central-themedir/zips/$selected.zip"; //wat was selected
			 $res = get_file($server_file, $local_file);
			 if ($res) {
				 if (is_dir(GSTHEMESPATH.$newActiveName)) {
				   removeDirectory(GSTHEMESPATH.$newActiveName);
				 }  
				 $zip = new ZipArchive; 
				$res =$zip->open($local_file ); 
				if ($res === TRUE) {
				  $zip->extractTo(GSTHEMESPATH.$newActiveName);
				  $zip->close();
				   //yes.. k.. lets save as default temaplte
		  
					$pathToOther = GSDATAOTHERPATH;
					$file = "website.xml";
					// create new site data file
					$bakpath = GSBACKUPSPATH.'other/';
					createBak($file, $pathToOther, $bakpath);
					
					// Update changes
					$xml = getDominionXML($pathToOther.$file); //@new SimpleXMLExtended('<item></item>');
					$activeTemplate = $xml->xpath("//item");
					
					$activeTemplate[0]->TEMPLATE->updateCData($newActiveName);
					$activeTemplate[0]->SITENAME->updateCData(stripslashes($activeTemplate[0]->SITENAME));
					$activeTemplate[0]->SITEURL->updateCData(stripslashes($activeTemplate[0]->SITEURL));
					if ((string)$activeTemplate[0]->PRETTYURLS <> '') {
					  $activeTemplate[0]->PRETTYURLS->updateCData(stripslashes($activeTemplate[0]->PRETTYURLS));
					}  
					if ((string)$activeTemplate[0]->PERMALINK <> '') {
					  $activeTemplate[0]->PERMALINK->updateCData(stripslashes($activeTemplate[0]->PERMALINK));
					}  
					
					$xml->XMLSave($pathToOther . $file);
					//$success = $i18n['THEME_CHANGED'];
					$TEMPLATE = $newActiveName;
					file_put_contents($settingsfile,"lasttheme=$selected \n\rsepereatethemes=$aparteThemes");
				    $lastThemeDownloaded = $selected;
				} else {
					$error = 'Could not unzip local downloaded template archive.';
				}
			   
			 } else {
			   $error =  'Error downloading the Template file from Central Server.';
			 }        
         }
       }
        

 		
        $jsonurl = "$curThemeURL/central-themedir/dominion-theme-control.php";
        $json = file_get_contents($jsonurl,0,null,null);
        $json_output = json_decode($json);
		

		$amountThemese = count($json_output);
        $amountThemese = round(((($amountThemese / 2)+($amountThemese % 2)) * 305)) + 50;
        $lastAct = isset($_GET['AC'])?$_GET['AC']:'';
			
        echo "<div style='height:{$amountThemese}px'>";
		echo "<div style='background-color:red;'>$nopZip</div>";
		echo "<div style='background-color:red;'>$error</div>";
		
		$septhemecheck = ($aparteThemes == 1)?"checked='checked'":'';
		echo "<div ><a href='?id=themes-selector-advance&opsies=1'>Settings</a><br/>Theme Server URL <select name='themurl' id='themurl' onchange='window.location = \"".$SITEURL."admin/load.php?id=themes-selector-advance&CURT=\"+this.value'>$themeurlslist</select><br/><form style='border:1px solid black' method='get'><input name='stooropsie' value='1' type='hidden'><input name='id' value='themes-selector-advance' type='hidden'><input type='hidden' name='CURT' value='$curThemeURLEnc'><br/>Save as Seperate Themes  : <input type='checkbox' name='sepereatethemes' value='1' $septhemecheck><br/><input type='submit' name='stoor' value='Save'></form><br/></div>";
            echo "<div style='background-color: #DAE86F;font-size: 1.2em;padding:2px;text-align: left;margin-bottom:10px;height:19px;width:98%;border:1px solid black;'>Select a theme to make it the active theme - Last made active : $lastThemeDownloaded</div>";
			$x = 0;
            foreach ($json_output as $jsonData) {
                    $ThemeName = $jsonData->themename;
					  
					$screenshot = "$curThemeURL/central-themedir/".$jsonData->screenshot;
					$fileInfo = implode("",$jsonData->info);
                    $thisThemeURL = "load.php?id=themes-selector-advance&TN=".urlencode($ThemeName)."&CURT=$curThemeURLEnc";
                    $tipInfo = str_replace('<br/>',' | ',$fileInfo);
                    if ($lastThemeDownloaded == $ThemeName) {
                       echo "<div title='$tipInfo' id='theme_info_box' style='display:inline;height:315px;overflow:hidden;'><a href='$thisThemeURL' ><div  style='font-weight: bold;background-color: #5963C1;font-size: 1.2em;text-align: center;margin:2px;float:left;width:275px;height:313px;border:2px solid black;'><img height='225' width='275' src='$screenshot'><br/>$ThemeName</a><p id='d_$x' style='font-weight: normal;text-align: left;font-size: 0.8em;'>$fileInfo</p>  </div></div>";
                    } else {
                      echo "<div title='$tipInfo' id='theme_info_box' style='display:inline;height:315px;overflow:hidden;'><a href='$thisThemeURL' ><div  style='font-weight: bold;background-color: #cacaca;font-size: 1.2em;text-align: center;margin:2px;float:left;width:275px;height:313px;border:2px solid black;'><img height='225' width='275' src='$screenshot'><br/>$ThemeName</a><p id='d_$x' style='font-weight: normal;text-align: left;font-size: 0.8em;'>$fileInfo</p>  </div></div>";
                    }  
                   
              $x++;   
            }
        
        echo "</div><div style='clear:both;padding-top:5px;'>GS Plugin - Theme Selector Advance (v 0.1b) - Developed by <a href='http://www.dominion-it.co.za'>Dominion IT</a></div>";                           
?>		
	
 <?php  
}