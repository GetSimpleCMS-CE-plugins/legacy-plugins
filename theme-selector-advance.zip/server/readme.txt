Purpose : The purpose of this project is to provide a webtype service for the Theme Selector Advance plugin for GS
Programmed by : Johannes Pretoris
Date : 14 July 2011
version : 0.1
How to use
------------

The server does not have a admin page yet , thus the structure must be setup by hand

All service must be under the directory 
  central-themedir
 
 inside this you will have 
   dominion-theme-control.php -> provides service to clients
   zips -> folder with zip files in them (more shortly)
   "Theme Folder Names" -> The Folder names that represent the themes as normally with the themese dir of GS, more shortly
   
   
zips
-----
The zip files inside this folder must be EXACTLY the same name as the directory name of the "Theme Folders". 
Also the files inside must be the template files themselve and not within another directory for a example
look at sample theme given with 

GuitarHero.zip
   
"Theme Folder Names"   
---------------------

This is basically a copy of the GS Theme folder where each folder represents a Theme name. BUT with a small catch.
we only care about the following files

template.php
images/screenshot.png

The rest is not needed and dont have to be there. Look at sample given with project called

GuitarHero


What to come
-------------
A) Admin page to upload and manage themese by just uploading a single zip file per theme.
B) Optimize Server to build DB of themese to get past reading dirs for information. this will be a optional feature for those
   that want to allow external changes to directories and zip folder, otherwise if all theme changes are going to be via
    Admin page, then a simple db (config file) can be setup to increase speed and lower resources.

Any request, please feel free to mail me at

development@dominion-it.co.za
	



  