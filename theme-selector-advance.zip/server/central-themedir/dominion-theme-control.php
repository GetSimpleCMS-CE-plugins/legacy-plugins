<?php
  $path = './';
  $filenames = scandir('.'); 
        $amountThemese = 0;
        if (count($filenames) != 0) {
            foreach ($filenames as $file) {
                if ((is_dir($path . $file) && !(($file == "." || $file == ".." ||  $file == ".htaccess"))) && (is_file($path . $file."/template.php"))) {
                  $amountThemese++;
                } 
            }
        }        
        if (count($filenames) != 0) {
            foreach ($filenames as $file) {
                if ((is_dir($path . $file) && !(($file == "." || $file == ".." ||  $file == ".htaccess"))) && (is_file($path . $file."/template.php"))) {
                  
                    //screenshot
                    $ThemeName = $file;
                    //get the screenshot if it exist
                    if (is_file($path . $file."/images/screenshot.png")) {
                       $screenshot = $file."/images/screenshot.png";
                    } else {
                      $screenshot = '';
                    }

                    $tmpContent = file_get_contents($path . $file."/template.php");
                    
                    preg_match_all('/@(.*):(.*)(.\s)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER);
                    $Datablocks = $tmpArr[1];
                    $datafields = $tmpArr[2];
                    $totalBlocks = count($Datablocks);
                    for ($x = 0;$x < $totalBlocks;$x++) {
                      if ((strtolower(trim($datafields[$x])) <> 'template.php') && (strtolower(trim($Datablocks[$x])) <> 'file')) {
                          $fileInfo[] =  trim($Datablocks[$x])." : ".trim($datafields[$x]);
                      }
                    }              
                    $themeInfo['themename'] = $ThemeName;					
					$themeInfo['screenshot'] = $screenshot;
					$themeInfo['info'] = $fileInfo;
                    $themeList[] = $themeInfo;
					unset($fileInfo);
                } 
            }
        }
		
  header('Content-type: application/json');
 header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
 header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past


 echo json_encode($themeList);
?>