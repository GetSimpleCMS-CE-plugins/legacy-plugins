<?php
/****************************************************
*
* @File: 			template.php
* @Package:		Dominion IT Converted Packages
* @Action:		Guitar hero theme
* @License: Free for all. Just keep to orig Authors license
* @Website : www.dominion-it.co.za
* @Converter : Dominion IT
* @Date : 28 Sep 2010
*****************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Arnaud Valle
http://arnaudvalle.free.fr/

Licensed under the Creative Commons Attribution 3.0 Unported (http://creativecommons.org/licenses/by/3.0/)
You are free to copy, distribute, adapt the work, but you must keep a link of some sort to me (in the footer or source).

Title : GUITARhero
Version: 1.0
Released: 20070924

-->

<html lang="en-GB" xmlns="http://www.w3.org/1999/xhtml">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
         <?php get_header(); ?>
         <meta name="robots" content="index, follow" />
		<link rel="stylesheet" href="<?php get_theme_url(); ?>/style.css" type="text/css" />
		<title><?php get_page_clean_title(); ?> | <?php get_site_name(); ?>, <?php get_component('tagline'); ?></title>
	</head>
	
	<body id="<?php get_page_slug(); ?>">
	
		<div id="container">
			
			<div id="header">			
				<h1><span><?php get_site_name(); ?></h1>
			</div>
			
			<div id="sidebar">
			
				<div id="nav">
					<ul>
						<?php get_navigation(return_page_slug()); ?>
					</ul>	
				</div>
				
				<div id="shows">
	  			  <?php get_component('sidebar');	?>
				</div>				
				
			</div>			
			
			<div id="main">
			
				<div class="divider"></div>
				
				<h2><?php get_page_title(); ?></h2>
				<p>
					<?php get_page_content(); ?>
				</p>

				
				<div class="divider"></div>
			</div>	
			
			<div id="footer">	
                <p ><?php echo date('Y'); ?> <strong><?php get_site_name(); ?></strong><br/>
				&copy; 2007 Website.com. <a href="http://www.flashmint.com/show-type-flash.html">Flash Templates</a> by <a href="http://www.flashmint.com/">FlashMint</a>
                <br/>Converted by <a href="http://www.dominion-it.co.za">Dominion IT</a>
                </p>
		<div class="clear"></div>
		
		<?php get_footer(); ?>
                
			</div>
			
		</div>
	</body>
</html>