<?php

/*
Plugin Name: GetSimple Status Messages
Description: Print status messages in the admin section of GetSimple
Version: 0.1
Author: Rogier Koppejan
*/

# get correct id for plugin
$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
  $thisfile,
  'Status Messages',
  '0.1',
  'Rogier Koppejan',
  '#',
  'Print status messages in the admin section of GetSimple'
);


/*******************************************************
 * @function display_message
 * @action display status messages in back-end plugin pages
 * @param $msg (string) - The message to print
 * @param $success (bool) - If TRUE, display as update, else as error
 */
function display_message($msg, $success) {
  if (isset($msg)) {
    ?>
    <script type="text/javascript">
      $(function() {
        $('div.bodycontent').before('<div class="<?php echo $success ? 'updated' : 'error'; ?>" style="display:block;">'+
          <?php echo json_encode($msg); ?>+'</div>');
        $(".updated, .error").fadeOut(500).fadeIn(500);
      });
    </script>
    <?php
  }
}


?>
