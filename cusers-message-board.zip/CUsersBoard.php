<?php
/*
  Plugin Name: (Centralised Users) Message Board
  Description: Provides a message board.
  Author:		   Lawrence Okoth-Odida
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# constants
define('CUBOARDVERSION',  '1.0');

# register plugin
register_plugin(
  $thisfile,									                  
  'CUsers Message Board',							         
  CUBOARDVERSION, 										          
  'Lawrence Okoth-Odida',						            
  'http://lokida.co.uk/', 											
  'Provides a message board.',    
  'plugins', 									                 
  'get_CU_board_admin'				
);

# load i18n
i18n_merge('CUsers') || i18n_merge('CUsers','en_US');
i18n_merge('CUsersBoard')	|| i18n_merge('CUsersBoard','en_US');

# loads board theme
#add_action('theme-header',		'get_CU_board_theme');
add_action('theme-header',		'get_CU_board_title');
#add_action('content-top',		'get_CU_board_search');

# activate actions 
add_action('content-bottom',	'get_CUsersBoard');
add_action('search-index',    'CUBoardSearchIndex');
add_filter('search-item',     'CUBoardSearchItem');
add_filter('search-display',  'CUBoardSearchDisplay');
add_action('plugins-sidebar',	'createSideMenu', array($thisfile,'CUsers Message Board'));

# i18n search
#require_once(GSPLUGINPATH.'CUsersBoard/include/search.class.php');

# front-end functions
function get_CUsersBoard() {
  $CU_board_settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
    if(isset($CU_board_settings['page_slug']) && return_page_slug()==$CU_board_settings['page_slug']) {
    require_once(GSPLUGINPATH.'CUsersBoard/include/display.class.php');
    $board = new CUBoardDisplay;
    $board->getBoard();
  }
}

function get_CU_board_title() {
  require_once(GSPLUGINPATH.'/CUsersBoard/include/search.php');
  global $SITEURL;
  $CU_board_settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
  if(!empty($CU_board_settings)) {
    // constants
    define('CUBOARDSLUG',     $CU_board_settings['page_slug']);
    define('CUBOARDDOMAIN',   $CU_board_settings['domain']);
    define('CUBOARDFAQS',     $CU_board_settings['faqs']);
    define('CUBOARDRULES',    $CU_board_settings['rules']);
    define('CUBOARDTHEME',    $CU_board_settings['theme']);
    define('CUBOARDTIME',	    $CU_board_settings['time']);
    define('CUBOARDDATE',	    $CU_board_settings['date']);
    define('CUBOARDTPP',	    $CU_board_settings['topics_per_page']);
    define('CUBOARDPPP',	    $CU_board_settings['posts_per_page']);
    define('CUBOARDCSSPATH',  GSPLUGINPATH.'/CUsersBoard/theme/'.CUBOARDTHEME.'/css/');
    define('CUBOARDJSPATH',   GSPLUGINPATH.'/CUsersBoard/theme/'.CUBOARDTHEME.'/js/');
    define('CUBOARDIMGPATH',  GSPLUGINPATH.'/CUsersBoard/theme/'.CUBOARDTHEME.'/img/');
    
    // load css files
    if(file_exists(CUBOARDCSSPATH)) {
      foreach(glob(CUBOARDCSSPATH.'*') as $css) { 
        echo '<link href="'.$SITEURL.'plugins/CUsersBoard/theme/'.CUBOARDTHEME.'/css/'.end(explode('/', $css)).'?v=1.0" rel="stylesheet" media="screen">';
      }
    }
    
    // load javascript files
    if(file_exists(CUBOARDJSPATH)) {
      foreach(glob(CUBOARDJSPATH.'*') as $js) { 
        echo '<script type="text/javascript" src="'.$SITEURL.'plugins/CUsersBoard/theme/'.CUBOARDTHEME.'/js/'.end(explode('/', $js)).'"></script>';
      }
    }
  }
  
  if(isset($CU_board_settings['page_slug']) && return_page_slug()==$CU_board_settings['page_slug']) {
    require_once(GSPLUGINPATH.'CUsersBoard/include/display.class.php');
    end($_GET);
    if(key($_GET)=='page') prev($_GET);
    $display = new CUBoardDisplay;
    echo '<title>'.$display->getTitle(key($_GET), current($_GET), 'full').'</title>';
  }
}

function get_CU_board_url($page, $id=null) {
  require_once(GSPLUGINPATH.'CUsersBoard/include/display.class.php');
  $display = new CUBoardDisplay;
  return $display->getURL($page, $id);
}

function get_CU_board_admin() {
  require_once(GSPLUGINPATH.'/CUsers/include/tables.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/validation.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/users.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/forms.class.php');
	require_once(GSPLUGINPATH.'/CUsers/include/common.php');
	require_once(GSPLUGINPATH.'/CUsers/include/display.class.php');
  require_once(GSPLUGINPATH.'CUsersBoard/include/admin.php');
}

?>