<?php

class CUBoardDisplay {
  public $pages;
  public $crumbs;
  public function __construct() {
    // declares page titles for most pages and adds them to the breadcrumb array in the getBreadcrumb() function
	$this->pages = array(
	                // menu items
	                 'id'=>array(
                           'slug'		=> 'id',
                       'title'	=>	i18n_r('CUsersBoard/HOME'),
                       ),
                   'members'=>array(
                           'slug'		=> 'members',
                       'title'	=>	i18n_r('CUsersBoard/MEMBERS'),
                       ),
                   'search'=>array(
                           'slug'		=> 'search',
                       'title'	=>	i18n_r('CUsersBoard/SEARCH'),
                       ),
                   'faqs'=>array(
                           'slug'		=> 'faqs',
                       'title'	=>	i18n_r('CUsersBoard/FAQS'),
                       ),
                   'rules'=>array(
                           'slug'		=> 'rules',
                       'title'	=>	i18n_r('CUsersBoard/RULES'),
                       ),
                   'help'=>array(
                           'slug'		=> 'help',
                       'title'	=>	i18n_r('CUsersBoard/HELP'),
                       ),
                  // topic related links
                   'create-topic'=>array(
                           'slug'		=> 'create-topic',
                       'title'	=>	i18n_r('CUsersBoard/NEW_TOPIC'),
                       ),
                   'edit-topic'=>array(
                           'slug'		=> 'edit-topic',
                       'title'	=>	i18n_r('CUsersBoard/EDIT_TOPIC'),
                       ),
                   'delete-topic'=>array(
                           'slug'		=> 'delete-topic',
                       'title'	=>	i18n_r('CUsersBoard/DELETE_TOPIC'),
                       ),
                  // post related links
                   'quote-post'=>array(
                           'slug'		=> 'quote-post',
                       'title'	=>	i18n_r('CUsersBoard/QUOTE_POST'),
                       ),
                   'edit-post'=>array(
                           'slug'		=> 'edit-post',
                       'title'	=>	i18n_r('CUsersBoard/EDIT_POST'),
                       ),
                   'delete-post'=>array(
                           'slug'		=> 'delete-post',
                       'title'	=>	i18n_r('CUsersBoard/DELETE_POST'),
                       ),
                   'error'=>array(
                           'slug'		=> 'error',
                           'title'	=>	i18n_r('CUsersBoard/PAGE_NOT_FOUND'),
                       ),
                  // cpanel
                    'cpanel'=>array(
                           'slug'		=> 'cpanel',
                           'title'	=>	i18n_r('CUsersBoard/CPANEL'),
                       ),
                    'edit-user'=>array(
                           'slug'		=> 'edit-user',
                           'title'	=>	i18n_r('CUsersBoard/EDIT_USER'),
                       ),
                    'edit-forums'=>array(
                           'slug'		=> 'edit-forums',
                           'title'	=>	i18n_r('CUsersBoard/EDIT_FORUMS'),
                       ),
                    'edit-faqs'=>array(
                           'slug'		=> 'edit-faqs',
                           'title'	=>	i18n_r('CUsersBoard/EDIT_FAQS'),
                       ),
                    'edit-rules'=>array(
                           'slug'		=> 'edit-rules',
                           'title'	=>	i18n_r('CUsersBoard/EDIT_RULES'),
                       ),
                    'edit-censors'=>array(
                           'slug'		=> 'edit-censors',
                           'title'	=>	i18n_r('CUsersBoard/CENSORS'),
                       ),
                    'pms-config'=>array(
                           'slug'		=> 'pms-config',
                           'title'	=>	i18n_r('CUsersBoard/PMS_CONFIG'),
                       ),
                    'theme'=>array(
                           'slug'		=> 'theme',
                           'title'	=>	i18n_r('CUsersBoard/THEME'),
                       ),
                    'edit-theme'=>array(
                           'slug'		=> 'edit-theme',
                           'title'	=>	i18n_r('CUsersBoard/EDIT_THEME'),
                       ),
                    'file'=>array(
                           'slug'		=> 'file',
                           'title'	=>	i18n_r('CUsers/EDIT').' '.(isset($_GET['file']) ? $_GET['file'] : ''),
                       ),
                  // user panel
	               );
  }
  public function getURL($page=null, $id=null) {
    global $SITEURL;
    $settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
    end($_GET);
    
    $customUrlList = explode("\n", $settings['urls']);
    $customURLs = array();
    foreach ($customUrlList as $customURL) {
      $exploded = explode(" == ", $customURL);
      $customURLs[trim(str_replace("\"", "", reset($exploded)))] = trim(str_replace("\"", "", end($exploded)));
    }
    
      if(isset($customURLs[$page])) $url = $settings['domain'].$customURLs[$page]; // custom urls
      elseif($page=='id' || $page=='home') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'];
      }
      elseif($page=='members') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&members';
      }
      elseif($page=='search') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&search';
      }
      elseif($page=='faqs') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&faqs';
      }
      elseif($page=='rules') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&rules';
      }
      elseif($page=='help') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&help';
      }
      elseif($page=='category') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&category='.$id;
      }
      elseif($page=='forum') {
        $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$id, "DM_SINGLE");
        $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$forum['forum_category'], "DM_SINGLE");
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&category='.$category['id'].'&forum='.$id;
      }
      elseif($page=='create-topic') {
          $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$_GET['forum'], "DM_SINGLE");
      $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$forum['forum_category'], "DM_SINGLE");
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&category='.$category['id'].'&forum='.$forum['id'].'&create-topic';
      }
      elseif($page=='topic') {
        $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$id, "DM_SINGLE");
        $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$topic['topic_forum'], "DM_SINGLE");
      $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$forum['forum_category'], "DM_SINGLE");
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&category='.$category['id'].'&forum='.$forum['id'].'&topic='.$id;
      }
      elseif($page=='edit-post' || $page=='quote-post' || $page=='delete-post') {
        if (empty($id)) $id = '0';
        $post = DM_query("SELECT * FROM CU_board_posts WHERE id = $id", "DM_SINGLE");
        $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$post['post_topic'], "DM_SINGLE");
        $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$topic['topic_forum'], "DM_SINGLE");
        $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$forum['forum_category'], "DM_SINGLE");
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&category='.$category['id'].'&forum='.$forum['id'].'&topic='.$topic['id'].'&'.$page.'='.$id;
      }
      elseif($page=='cpanel' || $page =='feature') {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&cpanel';
      }
      elseif($page=='edit-user' || $page=='edit-forums' || $page=='edit-faqs' || $page=='edit-rules' || $page=='censors' || $page=='ban' || $page=='pms-config' || $page=='theme' || $page=='select-theme' || $page=='edit-theme') {
       $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&cpanel&'.$page.(is_numeric($id) ? '='.$id : '');  
      }
      else {
        $url = $SITEURL.'index.php?id='.$settings['page_slug'].'&'.$page;
        //$url = $SITEURL.'index.php?id='.$settings['page_slug'];
      }
    
    if(!$page) {
      return $_SERVER['REQUEST_URI'];
    }
    else {
      return $url;
    }
  }
/*
  public function getTitle($page, $id, $type) {
    if(return_page_slug()==CUBOARDSLUG) {
     
        if(isset($this->pages[$page])) {
          $title = $this->pages[$page]['title'];
          $fullTitle = return_page_title().' &bull; '.$title;
        }
        else {
          $title = i18n_r('CUsersBoard/PAGE_NOT_FOUND');
          $fullTitle = return_page_title().' &bull; '.$title;
        }
      
    }
    switch($type) {
      case 'full':
        return $fullTitle;
      break;
      default:
        return $title;
    }
  }
*/

  
  public function getBreadcrumb($div=' ') {
    global $pages;
    $settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
    $trail = '';
    $crumbs = 	array();
    foreach ($_GET as $page=>$id) {
	  
	  $crumbs[$page]['slug'] =  $page;
	  $crumbs[$page]['id']   =  (empty($id) ? null : $id ); // gives the value of the id if it is set
	  
	  if(isset($this->pages[$page]['title'])) $crumbs[$page]['title'] = $this->pages[$page]['title'];
	  else $crumbs[$page]['title'] = $page;
	  
	  if($page=='category') {
	    $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$id, "DM_SINGLE");
	    $crumbs[$page]['title'] = $category['category_name'];
		$crumbs[$page]['id']   =  $id;
      }
	  elseif($page=='forum') {
	    $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$id, "DM_SINGLE");
	    $crumbs[$page]['title'] = $forum['forum_name'];
		$crumbs[$page]['id']   =  $id;
      }
	  elseif($page=='topic') {
	    $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$id, "DM_SINGLE");
	    $crumbs[$page]['title'] = $topic['topic_subject'];
		$crumbs[$page]['id']   =  $id;
      }
	}
	  
    $end = (array_key_exists('page', $crumbs) ? count($crumbs)-1 : count($crumbs));
    $i=0;
    
    $this->crumbs = $crumbs;
	
    foreach ($crumbs as $crumb) {
      if($crumb['slug']!='page') {
        $i++;
        $trail .= '<a href="'.self::getURL($crumb['slug'], $crumb['id']).'" class="breadcrumb">'.$crumb['title'].'</a>';
        if($i!=$end) {
          $trail .= $div;
        }
      }
    }
	
    return $trail;
  }
  
  public function getTitle($page, $id, $type) {
    self::getBreadcrumb($div=' ');
    if(return_page_slug()==CUBOARDSLUG) {
     
        if(isset($this->crumbs[$page])) {
          $title = $this->crumbs[$page]['title'];
          $fullTitle = return_page_title().' &bull; '.$title;
        }
        else {
          $title = i18n_r('CUsersBoard/PAGE_NOT_FOUND');
          $fullTitle = return_page_title().' &bull; '.$title;
        }
      
    }
    switch($type) {
      case 'full':
        return $fullTitle;
      break;
      default:
        return $title;
    }
  }
  
  public function getBoard() {
    // board settings
    $CU_board_settings = $settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
    global $SITEURL;
    if(!empty($CU_board_settings) && isset($CU_board_settings['page_slug']) && (return_page_slug()==$CU_board_settings['page_slug'])) {
    
    // constants
    
    $topic_orders = array(i18n_r('CUsersBoard/TOPICS'), i18n_r('CUsersBoard/STICKIES'), i18n_r('CUsersBoard/ANNOUNCEMENTS'));
    $topic_statuses = array(i18n_r('CUsersBoard/OPEN'), i18n_r('CUsersBoard/CLOSED'));

    // header
      $menuLinks = array('home', 'members', 'faqs', 'rules', 'search', 'help', 'cpanel');
      $headerTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/header.php');
      $s = preg_match('#<!--menu-->(.*?)<!--/menu-->#s', $headerTemplate, $display); // loads menu template
      $displayHeader = str_replace('{url:home}', get_CU_board_url('home', null), $display[1]);
      foreach ($menuLinks as $menuLink) {
        $displayHeader = str_replace('{'.$menuLink.'}', i18n_r('CUsersBoard/'.strtoupper($menuLink)), $displayHeader);
        $displayHeader = str_replace('{url:'.$menuLink.'}', get_CU_board_url($menuLink, null), $displayHeader);
      }
      
      $signin_form = '<form method="post">'.CUForms::signIn(true).'</form>'; 
      if(CUSession::status()) {
        $signin_form .= '<span class="links"><a href="'.get_CU_board_url('user-panel', null).'">'.i18n_r('CUsersBoard/USER_PANEL').'</a></span>';
        $signin_form .= (function_exists('get_CU_pms') ? ' | <span><a href="'.get_CU_board_url('pms', null).'">'.i18n_r('CU_pms/PRIVATE_MESSAGES').' '.(CU_newest_pms()>0 ? '(<strong>'.CU_newest_pms().'</strong>)': '').'</a></span>' : '');
      }
      $current_time_msg = i18n_r('CUsersBoard/CURRENT_TIME').' <strong>'.date(CUBOARDTIME.' '.CUBOARDDATE, time()).'</strong>';
      
      $headerTemplate = preg_replace('#<!--menu-->(.*?)<!--/menu-->#s', $displayHeader, $headerTemplate);
      
      
      $displayHeader = str_replace('{form}', $signin_form, $headerTemplate);
      $displayHeader = str_replace('{time}', $current_time_msg, $displayHeader);
      
      // fixes page id
      end($_GET);
      if(key($_GET)=='page') prev($_GET);
      $pageID = key($_GET);
      if($pageID=='id') $pageID = 'home';
      
      $displayHeader = str_replace('{page}', $pageID, $displayHeader);
      $displayHeader = preg_replace('#\{breadcrumbs\=\"(.+)\"\}#iUs', self::getBreadcrumb('$1'), $displayHeader);
      
      // only shows cpanel for admins and mods
      if(!(CUSession::status() && ($_SESSION['CUser']['user_level']==2 || $_SESSION['CUser']['user_level']==1))) {
        $displayHeader = preg_replace('#<!--admin-->(.*?)<!--/admin-->#s', '', $displayHeader);
      }
      
      echo $displayHeader;

	  // body
		end($_GET);
		
		// home
		if(isset($_GET['id']) && (key($_GET)=='id')) {
      $statistics = i18n_r('CUsersBoard/STATS');
      $created = i18n_r('CUsersBoard/BOARD_CREATED').' '.date(CUBOARDDATE, $settings['board_date']);
      $users = i18n_r('CUsersBoard/CURRENTLY_HAVE').' '.count(DM_query("SELECT * FROM CU_users")).' '.i18n_r('CUsersBoard/USERS_REGISTERED');
      $topics = i18n_r('CUsersBoard/USERS_MADE').' '.count(DM_query("SELECT * FROM CU_board_posts")).' '.strtolower(i18n_r('CUsersBoard/POSTS_IN')).' '.count(DM_query("SELECT * FROM CU_board_topics")).' '.strtolower(i18n_r('CUsersBoard/TOPICS'));
      $newest_user = DM_query("SELECT * FROM CU_users ORDER BY id DESC", "DM_SINGLE");
      $user = new CUser($newest_user['id']);
      $newUser = i18n_r('CUsersBoard/NEW_USER').' '.$user->getName();
      
      $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
      foreach ($categories as $category) {
        $categoryTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/category.php');
        $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']." ORDER BY forum_order ASC");
        if (!empty($forums)) {
          $s = preg_match('#<!--forum-->(.*?)<!--/forum-->#s', $categoryTemplate, $display); // loads forum template
          $displayForum = $displayForums = '';
          foreach ($forums as $forum) {
            $displayForum = str_replace('{url:forum}', get_CU_board_url('forum', $forum['id']), $display[1]);
            $displayForum = str_replace('{forum}', $forum['forum_name'], $displayForum);
            $displayForum = str_replace('{description}', $forum['forum_description'], $displayForum);
            $displayForum = str_replace('{topics}', count(DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id'])), $displayForum);
            
            // last post
            $latestPost = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id']." ORDER BY topic_latest DESC", "DM_SINGLE");
            if(!empty($latestPost)) {
              $latestPoster = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$latestPost['id']." ORDER BY post_date DESC", "DM_SINGLE");
              $latestPoster = new CUser($latestPoster['post_by']);
              $latestPostMsg = '<a href="'.get_CU_board_url('topic', $latestPost['id']).'">'.$latestPost['topic_subject'].'</a> '.date('@ '.CUBOARDTIME.' '.CUBOARDDATE, $latestPost['topic_latest']).'<br>'.$latestPoster->getName();
              $displayForum = str_replace('{lastpost}', $latestPostMsg, $displayForum);
            }
            else $displayForum = str_replace('{lastpost}', '', $displayForum);
            
            $displayForums .= $displayForum;
          }
        }
        else {
          $s = preg_match('#<!--no forum-->(.*?)<!--/no forum-->#s', $categoryTemplate, $display); // loads no forum template
          $displayForums = str_replace('{noforum}', i18n_r('CUsersBoard/NO_FORUMS'), $display[1]);
        }
        
        $categoryTemplate = preg_replace('#<!--forums-->(.*?)<!--/forums-->#s', $displayForums, $categoryTemplate);
        
        $displayCategory = str_replace('{url:category}', get_CU_board_url('category', $category['id']), $categoryTemplate);
        $displayCategory = str_replace('{title:category}', $category['category_name'], $displayCategory);
        $displayCategory = str_replace('{title:forum}', i18n_r('CUsersBoard/FORUMS'), $displayCategory);
        $displayCategory = str_replace('{title:topics}', i18n_r('CUsersBoard/TOPICS'), $displayCategory);
        $displayCategory = str_replace('{title:lastpost}', i18n_r('CUsersBoard/LAST_POST'), $displayCategory);
        echo $displayCategory;
      }
      
      
      // statistics
      $homeTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/home.php');
      $displayHome = str_replace('{title:statistics}', i18n_r('CUsersBoard/STATS'), $homeTemplate);
      $displayHome = str_replace('{created}', $created, $displayHome);
      $displayHome = str_replace('{users}', $users, $displayHome);
      $displayHome = str_replace('{topics}', $topics, $displayHome);
      $displayHome = str_replace('{newuser}', $newUser, $displayHome);
      echo $displayHome;
    }
    
    // user panel
		if(isset($_GET['user-panel'])) {
      $userPanelTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
      $userPanelTemplate = str_replace('{title}', i18n_r('CUsersBoard/USER_PANEL'), $userPanelTemplate);
      $userPanelTemplate = str_replace('{content}', '<tbody><tr><td class="row_2">'.CUForms::editUserDetails(true).'</td></tr></tbody>', $userPanelTemplate);
      $userPanelTemplate = str_replace('{headers}', '', $userPanelTemplate);
      $userPanelTemplate = str_replace('{pagination}', '', $userPanelTemplate);
      echo $userPanelTemplate;
    }
		
		// members
		if(isset($_GET['members'])) {
      // load template
      $membersTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
		  $all_users = DM_query("SELECT * FROM CU_users");
		  $users = CUPagination::query($all_users, CUBOARDPPP, null);
		  // configures pagination
      $membersTemplate = str_replace('{pagination}', CUPagination::getNav(get_CU_board_url('members', null), $key='page', ceil(count($all_users)/CUBOARDPPP)), $membersTemplate);
      
      // heading
      $membersTemplate = str_replace('{title}', i18n_r('CUsersBoard/MEMBERS'), $membersTemplate);
      $headers = '<thead>
                    <th>'.i18n_r('CUsers/USER_DISPLAY').'</th>
                    <th>'.i18n_r('CUsersBoard/POSTS').'</th>
                    <th>'.i18n_r('CUsers/USER_EMAIL').'</th>
                    <th>'.i18n_r('CUsers/USER_DATE').'</th>
                    <th>'.i18n_r('CUsers/USER_LEVEL').'</th>
                  </thead>';
      $membersTemplate = str_replace('{headers}', $headers, $membersTemplate);
      
      $i=1;
      $displayMember = $displayMembers = '';
      foreach ($users as $user) {
        if($i>2) $i=1;
        $details = new CUser($user['id']);
        $displayMember = '
          <tr class="row_'.$i.'">
            <td>'.$details->getName().'</td>
            <td>'.count(DM_query("SELECT * FROM CU_board_posts WHERE post_by = ".$user['id'])).'</td>
            <td>'.$details->getEmail(true).'</td>
            <td>'.$details->getLevel(true).'</td>
            <td>'.date(CUBOARDDATE, $details->getDate()).'</td>
          </tr>';
         $displayMembers .= $displayMember;
        $i++;
      }
      $membersTemplate = preg_replace('#<!--tbody-->(.*?)<!--/tbody-->#s', $displayMembers, $membersTemplate);
      echo $membersTemplate;
    }
		
		// search
		if(isset($_GET['search'])) {
      $searchTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
      $searchTemplate = str_replace('{title}', i18n_r('CUsersBoard/SEARCH'), $searchTemplate);
      if (function_exists('return_i18n_search_results')) {
        // search query
        if(!empty($_POST['search']) || isset($_GET['page'])) {
          // stored $_POST variable in $_SESSION so that it can be kept across pages
          if(!empty($_POST['search'])) {
            $_SESSION['CUser']['board']['search'] = $_POST;
            $_SESSION['CUser']['board']['search']['time'] = $_POST['time'];
          }
          if(isset($_GET['page'])) { 
            $_POST = $_SESSION['CUser']['board']['search'];
          }
          
          // validation rules
          $validation_rules = array(
            'words' => array(
              'required'		=> true,
              'min_length'	=> 5,
            ),
            'startdate' => array(
              'required'	=> true,
            ),
            'enddate' => array(
              'required'	=> true,
            ),
          );
          $validator = new CUValidator($_POST, $validation_rules);
          if(!empty($_POST['search'])) {
            if (!$validator->validate()) {
              // Get errors from validator
              $errors = $validator->get_errors();
             
              // Return errors
              $pagination = '';
              $search_results = $validator->print_errors();
            }
            elseif((time()-$_SESSION['CUser']['board']['search']['time'])>30) {
              $tag_types = array('type', 'author', 'forum');
              $tags = array();
              foreach ($tag_types as $tag) {
                if(!empty($_POST[$tag])) $tags[] = $_POST[$tag];
              }
              
              $order = $_POST['sort_order'].$_POST['sort_by'];
              
              // fixes enddate
              if($_POST['enddate']==date('Y-m-d')) $_POST['enddate'] = date('c');

              // no forums selected
              if(empty($_POST['forum'])) {
                if(empty($_SESSION['CUser']['board']['search']['query'])) { $_SESSION['CUser']['board']['search']['query'] = return_i18n_search_results($tags, $words=$_POST['words'], $first=0, $max=9999, $order, $lang=null); }
                $all_results = $_SESSION['CUser']['board']['search']['query'];
              }
              else {
                $tag_types = array('type', 'author');
                $tags = array();
                foreach ($tag_types as $tag) {
                  if(!empty($_POST[$tag])) $tags[] = $_POST[$tag];
                }
                unset($tags[2]); // removes the array given in $_POST['forum']
                if(count($_POST['forum']<2)){
                  $all_results_array = array();
                  $all_results = return_i18n_search_results(array_merge($tags, array($_POST['forum'][0])), $words=$_POST['words'], $first=0, $max=9999, $order, $lang=null);
                }
                else {
                  $i=0;
                  foreach ($_POST['forum'] as $selectedForum) {
                    $all_results_array[] = return_i18n_search_results(array_merge($tags, array($selectedForum)), $words=$_POST['words'], $first=0, $max=9999, $order, $lang=null);
                    if($i>0) $all_results = array_merge($all_results_array[$i-1], $all_results_array[$i]);
                    $i++;
                  }
                }
              }
              
              foreach ($all_results['results'] as $key=>$entry) {
                // filter the query
                // min/max replies
                if(isset($_POST['replies']) && is_numeric($_POST['replies'])) {
                  if($_POST['min_max_replies']=='max') {
                    if($entry->replies>=$_POST['replies']) unset($all_results['results'][$key]);
                  }
                  elseif($_POST['min_max_replies']=='min') {
                    if($entry->replies<=intval($_POST['replies'])) unset($all_results['results'][$key]);
                  }
                }
                // dates
                if(isset($_POST['startdate']) && isset($_POST['enddate'])) {
                  $entryDate = ($entry->post_date=='' ? $entry->post_date : $entry->topic_date);
                  if($entryDate<=strtotime($_POST['startdate']) || $entryDate>=strtotime($_POST['enddate'])) unset($all_results['results'][$key]);
                }
                
                
              }
              
              $paginationTemplate = preg_match('#<!--pagination-->(.*?)<!--/pagination-->#s', $searchTemplate, $display);
              $pagination = str_replace('{pagination}', CUPagination::getNav(get_CU_board_url('search', null), $key='page', ceil(count($all_results['results'])/CUBOARDTPP)), $display[1]);
              
              $results = CUPagination::query($all_results['results'], CUBOARDTPP, null);
              $search_results = '';
              if(!empty($results)) {
                
                $i=1;
                #unset($results[0]);
                $search_results .= '<tbody>';
                foreach ($results as $key=>$entry) {
                
                  if($i>2) $i=1;
                  if($_POST['type']=='topics') {
                    $search_results .= '<tr>
                                          <td class="row_'.$i.'">
                                          <a href="'.get_CU_board_url('topic', $entry->topic_id).'"><h3>'.$entry->title.'</h3></a></td>
                                        </tr>';
                  }
                  elseif($_POST['type']=='posts') {
                    $search_results .= '<tr class="row_'.$i.'">
                                          <td>
                                            <h3><a href="">'.$entry->author.'</a></h3>
                                          </td>
                                          <td>
                                            <h3><a href="">'.$entry->title.'</a></h3>
                                            '.CU_filter($entry->content).'
                                          </td>
                                        </tr>';
                  }
                  $i++;
                }
                $search_results .= '    </tbody>';
              }
              else {
                $pagination = '';
                $search_results = '<div>'.i18n_r('CUsers/NO_RESULTS').'</div>';
              }
            }
            else {
              // need to wait up to 30 seconds
              $pagination = '';
              $search_results = '<div>'.i18n_r('CUsers/YOU_MUST_WAIT').' '.(30-(time()-$_SESSION['CUser']['board']['search']['time'])).' '.strtolower(i18n_r('CUsers/SECS_TO_SEARCH')).'.</div>';
            }
            $headers = '';
            $content = $search_results;
          }
        }
        // form
        else {
          $select_forums = '';
          $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
          foreach ($categories as $category) {
            $select_forums .= '<option disabled="disabled">'.$category['category_name'].'</option>'."\n";
            $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']." ORDER BY forum_order ASC");
            foreach ($forums as $forum) {
              $select_forums .= '<option value="forum'.$forum['id'].'">&rarr; '.$forum['forum_name'].'</option>'."\n";
            }
          }
          $headers = $pagination = '';
          $content = '<div class="searchForm">
                      <thead>
                        <tr>
                          <th width="50%">'.i18n_r('CUsers/SEARCH_KEYWORD').'</th>
                          <th width="50%">'.i18n_r('CUsers/SEARCH_USERS').'</th>
                        </tr>
                      </thead>
                        <form method="post">
                        <tbody>
                        <tr>
                          <td>
                            <input type="text" name="words"/><br />
                            <input type="radio" checked="checked" name="type" value="posts"> '.i18n_r('CUsersBoard/ENTIRE_POST').' 
                            <input type="radio" name="type" value="topics"> '.i18n_r('CUsersBoard/TOPIC_ONLY').'
                        </td>
                        <td>
                          <input type="text" name="author"/>
                        </td>
                        </tr>
                      </tbody>
                      <thead>
                        <tr>
                          <th colspan="2">'.i18n_r('CUsers/OPTIONS').'</th>
                        </tr>
                      </thead>
                        <tbody>
                          <tr>
                            <td>
                            <div class="select multiple"><select name="forum[]" multiple>'.$select_forums.'</select></div>
                          </td>
                          <td>
                            <section>
                              <div class="select" style="display: inline;"><select name="min_max_replies">
                                <option value="max">'.i18n_r('CUsers/MAX').'</option>
                                <option value="min">'.i18n_r('CUsers/MIN').'</option>
                              </select></div> 
                              <input type="text" name="replies" size="1"/> '.strtolower(i18n_r('CUsersBoard/REPLIES')).'
                            </section>
                            
                            <section>
                              '.i18n_r('CUsersBoard/POSTS_BETWEEN').'<br />
                              <input type="date" name="startdate" value="'.date('Y-m-d', time()-(60*60*24)).'">
                              <input type="date" name="enddate" value="'.date('Y-m-d').'">
                              <input type="hidden" name="time" value="'.time().'">
                            </section>
                            
                            <section>
                              <div class="select"><select name="sort_by">
                                <option value="author">'.i18n_r('CUsers/SORT_BY').' '.i18n_r('CUsersBoard/AUTHOR').'</option>
                                <option value="created">'.i18n_r('CUsers/SORT_BY').' '.i18n_r('CUsersBoard/DATE').'</option>
                                <option value="topic_forum">'.i18n_r('CUsers/SORT_BY').' '.i18n_r('CUsersBoard/FORUM').'</option>
                              </select></div>
                              <input type="radio" name="sort_order" value="+"> '.i18n_r('CUsers/ASC').' 
                              <input type="radio" checked="checked" name="sort_order" value="-"> '.i18n_r('CUsers/DESC').'
                            </section>
                            
                            <input type="submit" name="search" style="clear: both;" value="'.i18n_r('CUsers/SEARCH').'"/>
                          </td>
                          </tr>
                        </tbody>
                        </form>
                        </div>';
        }
      }
      else {
        $headers = $pagination = '';
        $content = i18n_r('CUsers/NEED_I18N_SEARCH');
      }
      $searchTemplate = preg_replace('#<!--pagination-->(.*?)<!--/pagination-->#s', $pagination, $searchTemplate);
      $searchTemplate = str_replace('{headers}', $headers, $searchTemplate);
      $searchTemplate = preg_replace('#<!--tbody-->(.*?)<!--/tbody-->#s', '<tr><td class="row_1">'.$content.'</td></tr>', $searchTemplate);
      echo $searchTemplate;
    }
		
		// faqs/rules/help
		if(isset($_GET['faqs']) || isset($_GET['rules']) || isset($_GET['help'])) {
      // load template
      $template = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
      $template = str_replace('{title}', i18n_r('CUsersBoard/'.strtoupper(key($_GET))), $template);
		  $template = preg_replace('#<!--pagination-->(.*?)<!--/pagination-->#s', '', $template);
      $template = str_replace('{headers}', '', $template);
      switch (key($_GET)) {
        case 'faqs':  $content = CU_filter(CUBOARDFAQS); break;
        case 'rules': $content = CU_filter(CUBOARDRULES); break;
        default: $content = '';
      }
      $template = preg_replace('#<!--tbody-->(.*?)<!--/tbody-->#s', $content, $template);
      echo $template;
    }
    
		// private messages
		if(isset($_GET['pms']))                                   echo get_CU_pms();
		
		// category
		if(isset($_GET['category']) && (key($_GET)=='category')) {
      $category = DM_query("SELECT * FROM CU_board_categories WHERE id = ".$_GET['category'], "DM_SINGLE");
      
      $categoryTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/category.php');
      $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']." ORDER BY forum_order ASC");
      if (!empty($forums)) {
        $s = preg_match('#<!--forum-->(.*?)<!--/forum-->#s', $categoryTemplate, $display); // loads forum template
        $displayForum = $displayForums = '';
        foreach ($forums as $forum) {
          $displayForum = str_replace('{url:forum}', get_CU_board_url('forum', $forum['id']), $display[1]);
          $displayForum = str_replace('{forum}', $forum['forum_name'], $displayForum);
          $displayForum = str_replace('{description}', $forum['forum_description'], $displayForum);
          $displayForum = str_replace('{topics}', count(DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id'])), $displayForum);
          
          // last post
          $latestPost = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id']." ORDER BY topic_latest DESC", "DM_SINGLE");
          if(!empty($latestPost)) {
            $latestPoster = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$latestPost['id']." ORDER BY post_date DESC", "DM_SINGLE");
            $latestPoster = new CUser($latestPoster['post_by']);
            $latestPostMsg = '<a href="'.get_CU_board_url('topic', $latestPost['id']).'">'.$latestPost['topic_subject'].'</a> '.date('@ '.CUBOARDTIME.' '.CUBOARDDATE, $latestPost['topic_latest']).'<br>'.$latestPoster->getName();
            $displayForum = str_replace('{lastpost}', $latestPostMsg, $displayForum);
          }
          else $displayForum = str_replace('{lastpost}', '', $displayForum);
          
          $displayForums .= $displayForum;
        }
      }
      else {
        $s = preg_match('#<!--no forum-->(.*?)<!--/no forum-->#s', $categoryTemplate, $display); // loads no forum template
        $displayForums = str_replace('{noforum}', i18n_r('CUsersBoard/NO_FORUMS'), $display[1]);
      }
      
      $categoryTemplate = preg_replace('#<!--forums-->(.*?)<!--/forums-->#s', $displayForums, $categoryTemplate);
      
      $displayCategory = str_replace('{url:category}', get_CU_board_url('category', $category['id']), $categoryTemplate);
      $displayCategory = str_replace('{title:category}', $category['category_name'], $displayCategory);
      $displayCategory = str_replace('{title:forum}', i18n_r('CUsersBoard/FORUMS'), $displayCategory);
      $displayCategory = str_replace('{title:topics}', i18n_r('CUsersBoard/TOPICS'), $displayCategory);
      $displayCategory = str_replace('{title:lastpost}', i18n_r('CUsersBoard/LAST_POST'), $displayCategory);
      echo $displayCategory;
    }
    
		// forum
		if(isset($_GET['forum']) && !isset($_GET['topic']) && (key($_GET)=='forum' || key($_GET)=='page')) {
      $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$_GET['forum'], "DM_SINGLE");
      
      // load template
      $forumTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/forum.php');
      $announcements = DM_query("SELECT * FROM CU_board_topics WHERE topic_order = 2 ORDER BY topic_latest DESC");
      $all_topics = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$_GET['forum']." ORDER BY topic_order DESC, topic_latest DESC");
      if(!empty($all_topics)) {
        $i=0;
        foreach ($all_topics as $topic) {
          if($topic['topic_order']==2) unset($all_topics[$i]);
          $i++;
        }
      }
      $all_topics = array_merge($announcements, $all_topics);
      $topics = CUPagination::query($all_topics, CUBOARDTPP, null);
      
      $forumTemplate = str_replace('{pagination}', CUPagination::getNav(get_CU_board_url('forum', $_GET['forum']), $key='page', ceil(count($all_topics)/CUBOARDTPP)), $forumTemplate);
      $forumTemplate = str_replace('{url:newtopic}', get_CU_board_url('create-topic', null), $forumTemplate);
      $forumTemplate = str_replace('{newtopic}', i18n_r('CUsersBoard/NEW_TOPIC'), $forumTemplate);
      $forumTemplate = str_replace('{title:views}', i18n_r('CUsersBoard/VIEWS'), $forumTemplate);
      $forumTemplate = str_replace('{title:replies}', i18n_r('CUsersBoard/REPLIES'), $forumTemplate);
      
      if (!empty($topics)) {
        $s = preg_match('#<!--topic-->(.*?)<!--/topic-->#s', $forumTemplate, $display); // loads topic template
        $displayTopic = $displayTopics = $currentTopicOrder = '';
        foreach ($topics as $topic) {
          
          $url		= get_CU_board_url('topic', $topic['id']);
          $posts		= DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']." ORDER BY post_date DESC");
          $replies	= count($posts)-1;
          $poster		= new CUser($posts[0]['post_by']);
          $author		= new CUser($topic['topic_by']);
          $poster		= new CUser($posts[0]['post_by']);
          $time		= date(CUBOARDTIME.' '.CUBOARDDATE, $posts[0]['post_date']);
        
          // subject details
          $displayTopic = str_replace('{url:topic}', get_CU_board_url('topic', $topic['id']), $display[1]);
          $displayTopic = str_replace('{topic}', $topic['topic_subject'], $displayTopic);
          $displayTopic = str_replace('{type}', ($topic['topic_order']!=0 ? $topic_orders[$topic['topic_order']] : ''), $displayTopic);
          if($topic['topic_order']==0) $displayTopic = preg_replace('#<!--type-->(.*?)<!--/type-->#s', '', $displayTopic);
          $displayTopic = str_replace('{author}', $author->getName(), $displayTopic);
          
          // views
          $displayTopic = str_replace('{views}', $topic['topic_views'], $displayTopic);
          
          // replies
          $posts = count(DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']));
          $displayTopic = str_replace('{replies}', ($posts<2 ? 0 : $posts-1), $displayTopic);
          
          // last post
          $displayTopic = str_replace('{lastpost}', $time, $displayTopic);
          $displayTopic = str_replace('{poster}', $poster->getName(), $displayTopic);
          
          // mod options
          if(CUSession::status() && ($_SESSION['CUser']['user_level']==1 || $_SESSION['CUser']['user_level']==2 || $_SESSION['CUser']['user_id']==$topic['topic_by'])) {
            $post = DM_query("SELECT id, post_date FROM CU_board_posts WHERE post_topic = ".$topic['id']." ORDER BY post_date ASC", "DM_SINGLE");
            $options = '<a href="'.get_CU_board_url('edit-post', $post['id']).'" class="edit"></a>';
          }
          else $options = '';
          
          $displayTopics .= str_replace('{mod}', $options, $displayTopic);
        }
      }
      else {
        $s = preg_match('#<!--no topic-->(.*?)<!--/no topic-->#s', $forumTemplate, $display); // loads no forum template
        $displayTopics = str_replace('{noforum}', i18n_r('CUsersBoard/NO_FORUMS'), $display[1]);
      }
      
      $forumTemplate = preg_replace('#<!--topics-->(.*?)<!--/topics-->#s', $displayTopics, $forumTemplate);
      
      $displayForum = str_replace('{url:forum}', get_CU_board_url('forum', $forum['id']), $forumTemplate);
      $displayForum = str_replace('{title:forum}', $forum['forum_name'], $displayForum);
      $displayForum = str_replace('{title:topic}', i18n_r('CUsersBoard/TOPICS'), $displayForum);
      $displayForum = str_replace('{title:topics}', i18n_r('CUsersBoard/TOPICS'), $displayForum);
      $displayForum = str_replace('{title:lastpost}', i18n_r('CUsersBoard/LAST_POST'), $displayForum);
      echo $displayForum;
    }
		
    // topic
		if(isset($_GET['topic']) && (key($_GET)=='topic' || key($_GET)=='page')) {
      $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$_GET['topic'], "DM_SINGLE");
      
      // show topic
      if(empty($_POST['preview']) && empty($_POST['post_reply'])) {
        // update the view count
        CUTable::updateRecord('CU_board_topics', $_GET['topic'], array('topic_views'=>($topic['topic_views']+1)));
        
        // load template
        $forumTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/topic.php');
        $all_posts = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$_GET['topic']." ORDER BY post_date ASC");
        $posts = CUPagination::query($all_posts, CUBOARDPPP, null);
        
        $forumTemplate = str_replace('{pagination}', CUPagination::getNav(get_CU_board_url('topic', $_GET['topic']), $key='page', ceil(count($all_posts)/CUBOARDPPP)), $forumTemplate);
        
        // heading
        $forumTemplate = str_replace('{url:newtopic}', get_CU_board_url('create-topic', $_GET['forum']), $forumTemplate);
        $forumTemplate = str_replace('{newtopic}', i18n_r('CUsersBoard/NEW_TOPIC'), $forumTemplate);
        $forumTemplate = str_replace('{postreply}', i18n_r('CUsersBoard/POST_REPLY'), $forumTemplate);
        $forumTemplate = str_replace('{preview}', i18n_r('CUsers/PREVIEW'), $forumTemplate);
        $forumTemplate = str_replace('{title:topic}', $topic['topic_subject'], $forumTemplate);
        $forumTemplate = str_replace('{title:author}', i18n_r('CUsers/AUTHOR'), $forumTemplate);
        $forumTemplate = str_replace('{title:content}', i18n_r('CUsers/CONTENT'), $forumTemplate);
        
        if (!empty($posts)) {
          $displayPosts = '';
          $s = preg_match('#<!--post-->(.*?)<!--/post-->#s', $forumTemplate, $display); // loads topic template
          $i=0; $row = 1;
          foreach ($posts as $post) {
            if($row>2) $row=1; // used for row1/row2 styling
            $url		= get_CU_board_url('topic', $topic['id']);
            $posts		= DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']." ORDER BY post_date DESC");
            $replies	= count($posts)-1;
            $poster		= new CUser($posts[0]['post_by']);
            $author		= new CUser($post['post_by']);
          
            // profile
            $displayPost = str_replace('{url:topic}', get_CU_board_url('topic', $topic['id']), $display[1]);
            $displayPost = str_replace('{topic}', $topic['topic_subject'], $displayPost);
            $displayPost = str_replace('{author}', $author->getName(), $displayPost);
            $displayPost = str_replace('{label:posts}', i18n_r('CUsersBoard/POSTS'), $displayPost);
            $displayPost = str_replace('{posts}', count(DM_query("SELECT * FROM CU_board_posts WHERE post_by = ".$post['post_by'])), $displayPost);
            $displayPost = str_replace('{label:level}', i18n_r('CUsers/USER_LEVEL'), $displayPost);
            $displayPost = str_replace('{level}', $author->getLevel(true), $displayPost);
            $displayPost = str_replace('{label:registered}', i18n_r('CUsers/USER_DATE'), $displayPost);
            $displayPost = str_replace('{registered}', date(CUBOARDDATE, $author->getDate()), $displayPost);
            
            $avatar = $author->getAvatar(null);
            if(!empty($avatar)) $displayPost = str_replace('{url:avatar}', $author->getAvatar(), $displayPost);
            else                             $displayPost = str_replace('{url:avatar}', CUBOARDTHEME, $displayPost);
            
            $displayPost = str_replace('{row}', 'row_'.$row, $displayPost);
              // hooks for custom fields
            
            // content
            $displayPost = str_replace('{post}', CU_filter($post['post_content']), $displayPost);
            
            // signature
            $displayPost = str_replace('{signature}', CU_filter($author->getSignature()), $displayPost);
            
            // mod options
              $s = preg_match('#<!--options-->(.*?)<!--/options-->#s', $displayPost, $options);
              if (CUSession::status()) {
                // edit
                  $optionEdit = preg_match('#<!--edit-->(.*?)<!--/edit-->#s', $options[1], $op);
                  $edit = str_replace('{url:edit}', get_CU_board_url('edit-post', $post['id']), $op[1]);
                  $edit = str_replace('{edit}', i18n_r('CUsersBoard/EDIT'), $edit);
                // quote
                  $optionQuote = preg_match('#<!--quote-->(.*?)<!--/quote-->#s', $options[1], $op2);
                  $quote = str_replace('{url:quote}', get_CU_board_url('quote-post', $post['id']), $op2[1]);
                  $quote = str_replace('{quote}', i18n_r('CUsersBoard/QUOTE'), $quote);
                // delete 
                  $optionDelete = preg_match('#<!--delete-->(.*?)<!--/delete-->#s', $options[1], $op3);
                  $delete = str_replace('{url:delete}', get_CU_board_url('delete-post', $post['id']), $op3[1]);
                  $delete = str_replace('{delete}', i18n_r('CUsersBoard/DELETE'), $delete);
                
                if ($_SESSION['CUser']['user_level']==1 || $_SESSION['CUser']['user_level']==2 || $_SESSION['CUser']['user_id']==$post['post_by']) {
                  $displayOptions = $edit.$quote.$delete;
                }
                else $displayOptions = $quote;
              }
              else $displayOptions = '';
              $displayPost = preg_replace('#<!--options-->(.*?)<!--/options-->#s', ($topic['topic_status']==1 ? '' : $displayOptions), $displayPost);
              $displayPosts .= $displayPost;
              $row++;
          }
        }
        else {
          $s = preg_match('#<!--no topic-->(.*?)<!--/no topic-->#s', $forumTemplate, $display); // loads no forum template
          $displayTopics = str_replace('{nopost}', i18n_r('CUsersBoard/NO_POSTS'), $display[1]);
        }
        
        $forumTemplate = preg_replace('#<!--posts-->(.*?)<!--/posts-->#s', $displayPosts, $forumTemplate);
        if(!CUSession::status() || $topic['topic_status']==1) $forumTemplate = preg_replace('#<!--post reply-->(.*?)<!--/post reply-->#s', '', $forumTemplate);
        echo $forumTemplate;
      
      }
      else {
        // validation rules
        $validation_rules = array(
          'post_content' => array(
            'required'		=> true,
            'min_length'	=> 10
          ),
        );
        $validator = new CUValidator($_POST, $validation_rules);
        // preview
        if(!empty($_POST['preview']) || !$validator->validate()) {
          $previewTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
          
          $previewTemplate = str_replace('{title}', i18n_r('CUsers/PREVIEW'), $previewTemplate);
          
          $previewTemplate = str_replace('{headers}', '', $previewTemplate);
          
          if (!$validator->validate()) CU_msg_update($validator->print_errors(), $success=FALSE);
          $post_content = $_POST['post_content'];
          
          // page content
            $content = '<div class="content">'.CU_filter($post_content).'</a>
                        <form class="bbcode" method="post" action="">
                          <textarea name="post_content">'.$post_content.'</textarea>
                          <input type="submit" name="preview" value="'.i18n_r('CUsers/PREVIEW').'" />
                          <input type="submit" name="post_reply" value="'.i18n_r('CUsersBoard/POST_REPLY').'" />
                        </form>';
          
          $previewTemplate = str_replace('{content}', $content, $previewTemplate);
          echo $previewTemplate;
        }
        
        // post reply
        elseif(!empty($_POST['post_reply']) && $validator->validate()) {
          $clean_data = $validator->get_fields();
          createRecord('CU_board_posts', array(
            'post_content'    => $clean_data['post_content'],
            'post_date'       => time(),
            'post_topic'      => $topic['id'],
            'post_by'         => $_SESSION['CUser']['user_id'],
            'post_update'     => time(),
            'post_update_by'  => $_SESSION['CUser']['user_id'],
          ));
          CUTable::updateRecord('CU_board_topics', $topic['id'], array('topic_latest'=>time()));
          CU_msg_update(i18n_r('CUsersBoard/SUCCESS_POST'), $success=TRUE);
          CUTable::refreshIndex();
          CU_redirect(get_CU_board_url('topic', $topic['id']), 3000);
        }
      }
    }
		  // create topic / quote post / edit post
		  if(isset($_GET['edit-post']) && (key($_GET)=='edit-post') || isset($_GET['quote-post']) && (key($_GET)=='quote-post') || isset($_GET['create-topic']) && (key($_GET)=='create-topic')) {
      
        $post = DM_query("SELECT * FROM CU_board_posts WHERE id = ".end($_GET), "DM_SINGLE");
        if(!empty($post)) {
          $firstPostCheck = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$_GET['topic']." ORDER BY post_date ASC", "DM_SINGLE");
          $firstPost = ($post['id']==$firstPostCheck['id'] ? true : false);
          $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$post['post_topic'], "DM_SINGLE");
        }
        
        if((isset($firstPost) && $firstPost==true) || isset($_GET['create-topic'])) {
          if(!isset($_GET['create-topic'])) {
            $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$post['post_topic'], "DM_SINGLE");
            $topic_subject  = (isset($_POST['topic_subject']) ? $_POST['topic_subject'] : $topic['topic_subject']);
            $topic_forum    = (isset($_POST['topic_forum']) ? $_POST['topic_forum'] : $topic['topic_forum']);
            $topic_order    = (isset($_POST['topic_order']) ? $_POST['topic_order'] : $topic['topic_order']);
            $topic_status   = (isset($_POST['topic_status']) ? $_POST['topic_status'] : $topic['topic_status']);
          }
          else {
            $topic_subject  = (isset($_POST['topic_subject']) ? $_POST['topic_subject'] : '');
            $topic_forum    = (isset($_POST['topic_forum']) ? $_POST['topic_forum'] : '');
            $topic_order    = (isset($_POST['topic_order']) ? $_POST['topic_order'] : '');
            $topic_status   = (isset($_POST['topic_status']) ? $_POST['topic_status'] : '');
          }
          
          if(CUSession::getPerm(array(1, 2))) {
            $select_topic_order = '';
            foreach($topic_orders as $key=>$value) {
              $select_topic_order .= '<option '.($topic_order==$key ? 'selected="selected"' : '').' value="'.$key.'">'.$value.'</option>';
            }
            $select_topic_status = '';
            foreach($topic_statuses as $key=>$value) {
              $select_topic_status .= '<option '.($topic_status==$key ? 'selected="selected"' : '').' value="'.$key.'">'.$value.'</option>';
            }
            
            $select_topic_forum = '';
            $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
            if(!empty($categories)) {
              foreach($categories as $category) {
                $select_topic_forum .= '<option disabled="disabled">'.$category['category_name'].'</option>';
                $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']." ORDER BY forum_order ASC");
                if(!empty($forums)) { foreach ($forums as $forum) {
                  $select_topic_forum .= '<option '.($topic_forum==$forum['id'] ? 'selected="selected"' : '').' value="'.$forum['id'].'">&rarr; '.$forum['forum_name'].'</option>';
                } }
              }
            }

            $modOptions = '<label>'.i18n_r('CUsersBoard/TOPIC_ORDER').'</label>
                              <div class="select"><select name="topic_order">'.$select_topic_order.'</select></div>
                            <label>'.i18n_r('CUsersBoard/TOPIC_STATUS').'</label>
                              <div class="select"><select name="topic_status">'.$select_topic_status.'</select></div>
                            <label>'.i18n_r('CUsersBoard/FORUM').'</label>
                              <div class="select"><select name="topic_forum">'.$select_topic_forum.'</select></div>';
            if(isset($_GET['quote-post'])) $modOptions = '';
          }
          else $modOptions = '';  
        }
        
        // validation rules
          $validation_rules = array(
            'topic_subject' => array(
              'required'		=> true,
              'min_length'	=> 5
            ),
            'post_content' => array(
              'required'		=> true,
              'min_length'	=> 10
            ),
          );
        if(isset($_POST)) $validator = new CUValidator($_POST, $validation_rules);
        
        if($_SERVER['REQUEST_METHOD']!='POST' || !empty($_POST['preview']) || !$validator->validate()) {
          
          $previewTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
          
          // title
          if(isset($_GET['create-topic'])) $previewTemplate = str_replace('{title}', i18n_r('CUsersBoard/NEW_TOPIC'), $previewTemplate);
          if(isset($_GET['edit-post'])) $previewTemplate = str_replace('{title}', i18n_r('CUsers/PREVIEW'), $previewTemplate);
          if(isset($_GET['quote-post'])) $previewTemplate = str_replace('{title}', i18n_r('CUsers/PREVIEW'), $previewTemplate);
          $previewTemplate = str_replace('{headers}', '', $previewTemplate);
          
          if (!$validator->validate()) CU_msg_update($validator->print_errors(), $success=FALSE);
          if(isset($_GET['create-topic'])) $post_content = (isset($_POST['post_content']) ? $_POST['post_content'] : '');
          if(isset($_GET['edit-post'])) $post_content = (isset($_POST['post_content']) ? $_POST['post_content'] : $post['post_content']);
          if(isset($_GET['quote-post'])) {
            $user = new CUser($post['post_by']);
            $post_content = (isset($_POST['post_content']) ? $_POST['post_content'] : '[quote='.$user->getName().']'.$post['post_content'].'[/quote]');
          }
          
          // page content
            $content = '<tr>
                          <td>
                            <div class="content">'.CU_filter($post_content).'</a>
                            <form class="bbcode" method="post" action="">
                              '.((isset($firstPost) && $firstPost==true && isset($_GET['edit-post'])) || isset($_GET['create-topic']) ? '<input type="text" name="topic_subject" value="'.$topic_subject.'">': '').'
                              <textarea name="post_content">'.$post_content.'</textarea>
                              '.(isset($modOptions) ? $modOptions : '').'
                              <input type="submit" name="preview" value="'.i18n_r('CUsers/PREVIEW').'" />
                              <input type="submit" name="post_reply" value="'.i18n_r('CUsersBoard/POST_REPLY').'" />
                            </form>
                            </div>
                          </td>
                        </tr>';
          $previewTemplate = preg_replace('#<!--pagination-->(.*?)<!--/pagination-->#s', '', $previewTemplate);
          $previewTemplate = str_replace('{content}', $content, $previewTemplate);
          if(!(isset($_GET['quote-post']) && $topic['topic_status']==1)) echo $previewTemplate;
        }
        // post reply
        elseif(!empty($_POST['post_reply']) && $validator->validate()) {
          $clean_data = $validator->get_fields();
          unset($clean_data['post_reply']);
          
          if(isset($_GET['edit-post'])) {
            if(isset($clean_data['topic_subject'])) {
              $array = array('topic_subject', 'topic_order', 'topic_forum', 'topic_status');
              $query = array();
              foreach ($array as $item) {
                if(isset($clean_data[$item])) $query[$item] = $clean_data[$item];
              }
              CUTable::updateRecord('CU_board_topics', $topic['id'], $query);
            }
            $query = array();
            $query['post_content'] = $clean_data['post_content'];
            $query['post_update'] = time();
            $query['post_update_by'] = $_SESSION['CUser']['user_id'];
            CUTable::updateRecord('CU_board_posts', $post['id'], $query);
          }
          elseif(isset($_GET['quote-post'])) {
            $clean_data['post_topic'] = $_GET['topic'];
            $clean_data['post_date'] = $clean_data['post_update'] = time();
            $clean_data['post_by'] = $clean_data['post_update_by'] = $_SESSION['CUser']['user_id'];
            createRecord('CU_board_posts', $clean_data);
          }
          elseif(isset($_GET['create-topic'])) {

            $clean_data['post_date'] = $clean_data['post_update'] = time();
            $clean_data['post_by'] = $clean_data['post_update_by'] = $_SESSION['CUser']['user_id'];
            
            $time = time();
            $poster = $_SESSION['CUser']['user_id'];
            createRecord('CU_board_topics', array(
                                              'topic_subject' => $clean_data['topic_subject'],
                                              'topic_date'    => $time,
                                              'topic_latest'  => $time,
                                              'topic_views'   => 0,
                                              'topic_forum'   => $clean_data['topic_forum'],
                                              'topic_by'      => $poster,
                                              'topic_order'   => ((isset($_POST['topic_order']))? $_POST['topic_order'] : 0),
                                              'topic_status'  => ((isset($_POST['topic_status']))? $_POST['topic_status'] : 0),
                                            ));
            $topic = DM_query("SELECT * FROM CU_board_topics WHERE topic_by = ".$_SESSION['CUser']['user_id']." ORDER BY id DESC", "DM_SINGLE");
            
            createRecord('CU_board_posts', array(
                                             'post_content'   => $clean_data['post_content'],
                                             'post_date'      => $time,
                                             'post_topic'     => $topic['id'],
                                             'post_by'        => $poster,
                                             'post_update'    => $time,
                                             'post_update_by' => $poster,
                                           ));
            
          }
          CU_msg_update(i18n_r('CUsersBoard/SUCCESS_POST'), $success=TRUE);
          CUTable::refreshIndex();
          CU_redirect(get_CU_board_url('topic', (isset($_GET['topic']) ? $_GET['topic'] : $topic['id'])), 3000);
        }
        // redirect
        else CU_redirect(get_CU_board_url('topic', $_GET['topic']), 0);
      }
		  
		  // delete post
		  if(isset($_GET['delete-post']) && (key($_GET)=='delete-post')) {
        $post = DM_query("SELECT * FROM CU_board_posts WHERE id = ".$_GET['delete-post'], "DM_SINGLE");
        if(!empty($post)) {
          $title = $this->pages[key($_GET)]['title'];
          $topic = DM_query("SELECT * FROM CU_board_topics WHERE id = ".$post['post_topic'], "DM_SINGLE");
          $forum = DM_query("SELECT * FROM CU_board_forums WHERE id = ".$topic['topic_forum'], "DM_SINGLE");
              
          if($_SERVER['REQUEST_METHOD']!='POST') {
            $content = '<p>'.i18n_r('CUsersBoard/CONFIRM_POST_DELETE').'</p>
                        <form method="post"><input type="submit" name="delete" value="'.i18n_r('CUsers/DELETE').'"/></form>';
            $deleteTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
            $deleteTemplate = str_replace('{title}', $title, $deleteTemplate);
            $deleteTemplate = str_replace('{headers}', '', $deleteTemplate);
            $deleteTemplate = str_replace('{content}', $content, $deleteTemplate);
            echo $deleteTemplate;
          }          
          else {
            // check post type
            $posts = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']." ORDER BY post_date DESC");
            if($post['id']==$posts[0]['id'] && count($posts)>1) {
              // latest post, so update the topic_latest field of the topic
              DM_deleteRecord('CU_board_posts', $post['id']);
              CUTable::updateRecord('CU_board_topics', $topic['id'], array('topic_latest'=>$posts[1]['id']));
              CU_msg_update(i18n_r('CUsersBoard/SUCCESS_POST_DELETE'), $success=TRUE);
              CU_redirect(get_CU_board_url('topic', $topic['id']), 3000);
            }
            elseif($post['id']==$posts[count($posts)-1]['id']) {
              // first post, so delete the topic
              foreach ($posts as $p) DM_deleteRecord('CU_board_posts', $p['id']);
              DM_deleteRecord('CU_board_topics', $topic['id']);
              CU_msg_update(i18n_r('CUsersBoard/SUCCESS_DELETE_TOPIC'), $success=TRUE);
              CU_redirect(get_CU_board_url('forum', $forum['id']), 3000);
            }
            else {
              // any regular post
              DM_deleteRecord('CU_board_posts', $post['id']);
              CU_msg_update(i18n_r('CUsersBoard/SUCCESS_POST_DELETE'), $success=TRUE);
                CU_redirect(get_CU_board_url('topic', $topic['id']), 3000);
            }
            CUTable::refreshIndex();
          }
        }
      }
      
		// cpanel
		if(isset($_GET['cpanel']) && CUSession::status()) {
      require_once(GSPLUGINPATH.'CUsersBoard/include/cpanel.php');
      
      $cpanelTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/page.php');
      $cpanelTemplate = str_replace('{title}', $title, $cpanelTemplate);
      $cpanelTemplate = str_replace('{pagination}', '', $cpanelTemplate);
      $cpanelTemplate = str_replace('{content}', '<tbody><tr><td class="row_1" style="width: 150px;">'.$nav.'</td><td class="row_2">'.$content.'</td></tr></tbody>', $cpanelTemplate);
      $cpanelTemplate = str_replace('{headers}', '', $cpanelTemplate);
      echo '<div class="cpanel">'.$cpanelTemplate.'</div>';
    }
	  
	  // footer
      $footerTemplate = file_get_contents(GSPLUGINPATH.'CUsersBoard/theme/'.CUBOARDTHEME.'/templates/footer.php');
      $footerTemplate = str_replace('{version}', CUBOARDVERSION, $footerTemplate);
      echo $footerTemplate;
	}
	// no settings exist
	else echo '<p>'.i18n_r('CUsersBoard/NO_SETTINGS').'</p>';

  }
} ?>	