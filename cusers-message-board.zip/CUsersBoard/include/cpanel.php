<?php
/* control panel for admins and mods
 *
 */

$nav = '<ul class="cpanelNav">';
$nav_links = '';
if($_SESSION['CUser']['user_level']==2) { // admins
  $nav_links = array('feature', 'edit-user', 'edit-forums', 'edit-faqs', 'edit-rules', 'censors', 'ban', 'pms-config', 'theme'=>array('edit-theme'));
}
if($_SESSION['CUser']['user_level']==1) { // mods
  $nav_links = array('edit-user');
}
		  
// navigation
foreach ($nav_links as $link=>$item) {
  if(!is_array($item)) $nav .='<li class="'.$item.'"><a href="'.self::getURL($item, null).'">'.i18n_r('CUsersBoard/'.strtoupper(str_replace('-', '_', $item))).'</a></li>';
  else {
    $nav .= '<li class="'.$link.'"><a href="'.self::getURL($link, null).'">'.i18n_r('CUsersBoard/'.strtoupper(str_replace('-', '_', $link))).'</a><ul>';
    foreach ($item as $it) $nav .='<li class="'.$it.'"><a href="'.self::getURL($it, null).'">'.i18n_r('CUsersBoard/'.strtoupper(str_replace('-', '_', $it))).'</a></li>';
    $nav .= '</ul></li>';
  }
}
$nav .= '</ul>';
		  
		  // pages
		  
        if($_SESSION['CUser']['user_level']==1) {
          $title = i18n_r('CUsers/NO_PERMISSION'); // added in case a mod tries to access the other pages
          $content = '';
        }
         
		    // feature settings
		    if(key($_GET)=='cpanel' && ($_SESSION['CUser']['user_level']==2)) {
			  $title = i18n_r('CUsersBoard/FEATURE');
			  
			  if($_SERVER['REQUEST_METHOD']!='POST') {
          foreach ($settings as $setting=>$val) $field[$setting]['value'] = $val;
          foreach ($field as $name=>$array)     $field[$name]['status'] = 'success';
			  }
			  else {
			    foreach ($_POST as $newSetting=>$val) $field[$newSetting]['value'] = $val;
          foreach ($field as $name=>$array)     $field[$name]['status'] = 'success';
				
          // validation
			    $validation_rules = array(
			       'board_name' => array(
				    'required'		=> true,
				   ),
				   'topics_per_page' => array(
				    'required'		=> true,
					'numeric'		=> true,
				   ),
				   'posts_per_page' => array(
				    'required'		=> true,
           'numeric'		=> true,
           ),
          );
          $validator = new CUValidator($_POST, $validation_rules);
          if(!empty($_POST['save'])) {
            if (!$validator->validate()) {
              // Get errors from validator
              $errors = $validator->get_errors();
            
            // styles each field that has an error
            foreach ($errors as $name=>$error) {
              $field[$name]['status'] = 'error';
            }
             
              // Return errors
              $validator->print_errors();
            }
            else {
              $clean_data = $validator->get_fields();
            unset($clean_data['save']);
            CUTable::updateRecord('CU_board_settings', $settings['id'], $clean_data);
            CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
            CUTable::refreshIndex();
            }
          }
			  }
        
        $slugField = '<div class="select"><select name="page_slug">';
        global $pagesArray; // pulls array of pages from Matrix (for the page slug)
        foreach ($pagesArray as $slug=>$fields) {
          $slugField .= '<option value="'.$slug.'" '.($field['page_slug']['value']==$slug ? 'selected="selected"' : '').'>'.$slug.'</option>';
        }
        $slugField .= '</select></div>';
			  
		      $content = '<form method="post">

              <label>'.i18n_r('CUsers/PAGE').'</label>
                '.$slugField.'
							<label>'.i18n_r('CUsers/DOMAIN').'</label>
							  <input type="text" class="'.$field['domain']['status'].'" name="domain" value="'.$field['domain']['value'].'"/>
							<label>'.i18n_r('CUsers/URLS').'</label>
							  <textarea type="text" class="'.$field['urls']['status'].'" name="urls">'.$field['urls']['value'].'</textarea>
							<label>'.i18n_r('CUsersBoard/TOPICS_PER_PAGE').'</label>
							  <input type="text" class="'.$field['topics_per_page']['status'].'" name="topics_per_page" value="'.$field['topics_per_page']['value'].'"/>
							<label>'.i18n_r('CUsersBoard/POSTS_PER_PAGE').'</label>
							  <input class="" type="text" class="'.$field['posts_per_page']['status'].'" name="posts_per_page" value="'.$field['posts_per_page']['value'].'"/>
							<label>'.i18n_r('CUsersBoard/TIME').'</label>
							  <div class="select '.$field['time']['status'].'"><select name="time">
							    <option disabled>'.i18n_r('CUsers/CURRENT').': '.date($field['time']['value'], time()).'</option>
								<option value="h:i A e">'.date('h:i A e', time()).'</option>
								<option value="h:i a e">'.date('h:i a e', time()).'</option>
								<option value="H:i e">'.date('H:i e', time()).'</option>
							  </select></div>
							<label>'.i18n_r('CUsersBoard/DATE').'</label>
							  <div class="select '.$field['date']['status'].'"><select name="date">
							    <option disabled>'.i18n_r('CUsers/CURRENT').': '.date($field['date']['value'], time()).'</option>
								<option value="d-m-Y">'.date('d-m-Y', time()).'</option>
								<option value="d/m/Y">'.date('d/m/Y', time()).'</option>
								<option value="d M Y">'.date('d M Y', time()).'</option>
							  </select></div>
							<input type="submit" class="tagbtn4" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						  </form>';
			  
		    }
			
			// edit users
      if(isset($_GET['edit-user']) || isset($_GET['cpanel']) && $_SESSION['CUser']['user_level']==1) {
        if(isset($_GET['edit-user']) && !is_numeric($_GET['edit-user']) || isset($_GET['cpanel']) && $_SESSION['CUser']['user_level']==1) {
            $all_users = DM_query("SELECT * FROM CU_users");
            $i=0;
            foreach ($all_users as $u) {
              if($_SESSION['CUser']['user_level']==1 && ($u['user_level']==1 || $u['user_level']==2)) unset($all_users[$i]);
              $i++;
            }
            $users = CUPagination::query($all_users, CUBOARDPPP, null);
            $members = '';
        
                $i=1;
                foreach ($users as $user) {
                if($i>2) $i=1;
                $details = new CUser($user['id']);
                $members .= '<tr class="row_'.$i.'">
                             <td><a href="'.get_CU_board_url('edit-user', $user['id']).'">'.$details->getName().'</a></td>
                             <td>'.count(DM_query("SELECT * FROM CU_board_posts WHERE post_by = ".$user['id'])).'</td>
                             <td>'.$details->getEmail(true).'</td>
                             <td>'.$details->getLevel(true).'</td>
                             <td>'.date(CUBOARDDATE, $details->getDate(true)).'</td>
                           </tr>';
              $i++;
              }
        
            $content = '<div class="paginate">'.CUPagination::getNav(get_CU_board_url('edit-user', null), $key='page', ceil(count($all_users)/CUBOARDPPP)).'</div>
                      <table>
                  <tbody>
                    '.$members.'
                  </tbody>
                  </table>';
          $title = i18n_r('CUsersBoard/EDIT_USER');
        }
        else {
          $title = $content = i18n_r('CUsersBoard/NOEXIST_USER');
          $user = DM_query("SELECT * FROM CU_users WHERE id = ".$_GET['edit-user'], "DM_SINGLE");
          if(!empty($user)) {
            $profile = new CUser($user['id']);
            $title = $profile->getName();
            $content = '';
            $field = array();
            
            if($_SERVER['REQUEST_METHOD']!='POST') {
              foreach ($user as $setting=>$value) {
                $field[$setting]['value'] = $value;
                $field[$setting]['status']	= 'success';
              }
              foreach ($field as $name=>$array) $field[$name]['status'] = 'success';
            }
            else {
              foreach ($user as $setting=>$value) {
                if(isset($_POST[$setting])) {
                  $field[$setting]['value'] = $_POST[$setting]; 
                }
                else {
                  $field[$setting]['value'] = $value;
                }
                $field[$setting]['status']	= 'success';
              }
              if(!empty($_POST['save'])) {
              // validation rules
                $validation_rules = array(
                    'user_display' 		=> array(
                      'alpha_num'     => true,
                      'user_match'	=> array(array('user_display', 'user_name'), $field['user_display']['value'], $user['id']),
                    ),
                    'user_email'		=> array(
                      'required'   	=> true,
                      'email'		 	=> true,
                      'user_match'	=> array('user_email', $field['user_email']['value'], $user['id']),
                    ),
                    'user_avatar'		=> array(
                      'img'		 	=> true,
                    ),
                );
                $validator = new CUValidator($_POST, $validation_rules);
                if (!$validator->validate()) {
                  // Get errors from validator
                  $errors = $validator->get_errors();
            
                  // styles each field that has an error
                  foreach ($errors as $name=>$error) $field[$name]['status'] = 'error';
                  // Return errors
                  $validator->print_errors();
                }
                else {
                  
                  $clean_data = $validator->get_fields();
                  unset($clean_data['save']);
                  CUTable::updateRecord('CU_users', $user['id'], $clean_data);
                  CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
                  CUTable::refreshIndex();
                }
              }
            }
            $level_select = '';
            $user_levels = new CUser(null);
            foreach ($user_levels->levels as $key=>$level) {
              $level_select .= '<option value="'.$key.'" '.($field['user_level']['value']==$key ? 'selected="selected"' : '').' '.(($_SESSION['CUser']['user_level']==1 && (($key==1) || ($key==2))) ? 'disabled="disabled"' : '').'>'.$level['title'].'</option>';
            }
            $content = '<form class="bbcode" method="post">
                          <label>'.i18n_r('CUsers/USER_DISPLAY').'</label>
                            <input type="text" name="user_display" value="'.$field['user_display']['value'].'"/>
                          <label>'.i18n_r('CUsers/USER_LEVEL').'</label>
                            <div class="select"><select '.(($_SESSION['CUser']['user_id']==$user['id'] || ($_SESSION['CUser']['user_level']==1 && ($user['user_level']==1 || $user['user_level']==2))) ? 'disabled="disabled"' : '').' name="user_level">
                      '.$level_select.'
                    </select></div>
                  <label>'.i18n_r('CUsers/USER_EMAIL').'</label>
                      <input type="text" name="user_email" value="'.$field['user_email']['value'].'"/>
                  <label>'.i18n_r('CUsers/USER_AVATAR').'</label>
                      <input type="text" name="user_avatar" value="'.$field['user_avatar']['value'].'"/>
                  <label>'.i18n_r('CUsers/USER_SIGNATURE').'</label>
                      <textarea type="text" name="user_signature">'.$field['user_signature']['value'].'</textarea>
                  <label>'.i18n_r('CUsers/USER_IP').'</label>
                      <input type="text" disabled="disabled" value="'.$user['user_ip'].'"/>
                  <input type="submit" class="tagbtn4" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
                  </form>';
          }
        }
      }
			
			// edit-forums
		    if(key($_GET)=='edit-forums' && ($_SESSION['CUser']['user_level']==2)) {
          $title = i18n_r('CUsersBoard/EDIT_FORUMS');
          $content = '<div class="edit-forums">
                      <form class="categories" method="post">
                        <input type="submit" class="add" name="new_category" value="'.i18n_r('CUsersBoard/NEW_CATEGORY').'"/><input type="submit" class="reorder" name="reorder_categories" value="'.i18n_r('CUsersBoard/REORDER_CATEGORIES').'"/>
                      </form>';
          // main
          if($_SERVER['REQUEST_METHOD']!='POST') {
            $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
            if(!empty($categories)) {
              $content .= '<ul>';
              foreach ($categories as $category) {
                $content .= '<li>'.$category['category_name'].'
                              <form class="category" method="post">
                                <input type="hidden" name="category_id" value="'.$category['id'].'" />
                                <input type="hidden" name="category_name" value="'.$category['category_name'].'" />
                                <input type="hidden" name="category_order" value="'.$category['category_order'].'" />
                                <input type="submit" class="add" name="new_forum" value="'.i18n_r('CUsersBoard/NEW_FORUM').'"/>
                                <input type="submit" class="edit" name="edit_category" value="'.i18n_r('CUsersBoard/EDIT_CATEGORY').'"/>
                                <input type="submit" class="delete" name="delete_category" value="'.i18n_r('CUsersBoard/DELETE_CATEGORY').'"/>
                              </form>';
                $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']);
                if(!empty($forums)) {
                  $content .= '<ul>';
                  foreach ($forums as $forum) {
                    $content .= '<li>'.$forum['forum_name'].'
                                   <form class="forum" method="post">
                                     <input type="hidden" name="forum_category" value="'.$category['id'].'" />
                                     <input type="hidden" name="forum_id" value="'.$forum['id'].'" />
                                     <input type="hidden" name="forum_name" value="'.$forum['forum_name'].'" />
                                     <input type="hidden" name="forum_description" value="'.$forum['forum_description'].'" />
                                     <input type="submit" class="edit" name="edit_forum" value="'.i18n_r('CUsersBoard/EDIT_FORUM').'"/>
                                     <input type="submit" class="delete" name="delete_forum" value="'.i18n_r('CUsersBoard/DELETE_FORUM').'"/>
                                   </form>
                                 </li>';
                  }
                  $content .= '</ul>';
                }
                $content .= '</li>';
              }
              $content .= '</ul>
                           </div>';
            }
            else {
              $content .= '<td>'.i18n_r('CUsersBoard/NO_CATEGORIES').'</td>';
            }  
          }
          // new category || edit category
          elseif(!empty($_POST['new_category']) || !empty($_POST['edit_category'])) {
            $title          = (!empty($_POST['new_category']) ? i18n_r('CUsersBoard/NEW_CATEGORY') : i18n_r('CUsersBoard/EDIT_CATEGORY'));
            $category_name  = (!empty($_POST['new_category']) ? '' : $_POST['category_name']);
            $content = '<form method="post">
                          <label>'.$title.'</label>
                            <input type="text" name="category_name" value="'.$category_name.'"/>
                            '.(!empty($_POST['new_category']) ? '' : '<input type="hidden" name="category_id" value="'.$_POST['category_id'].'"/><input type="hidden" name="category_order" value="'.$_POST['category_order'].'"/>').'
                            
                            <input type="submit" '.(!empty($_POST['new_category']) ? 'name="create_new_category" value="'.i18n_r('CUsers/CREATE') : 'name="save_category" value="'.i18n_r('CUsers/SAVE')).'"/>
                        </form>';
          }
            // create
            elseif(!empty($_POST['create_new_category'])) {
              $title = i18n_r('CUsersBoard/CATEGORY_CREATED');
              $content = i18n_r('CUsersBoard/CHANGES_SUCCESSFULL');
              
              // finds the latest category so that we can get the category order
              $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order DESC", "DM_SINGLE");
              unset($_POST['create_new_category']);
              $_POST['category_order'] = ((!empty($categories))? ($categories['category_order'])+1 : 0 );

              // creates the category and redirects
              createRecord('CU_board_categories', $_POST);
              CU_redirect(get_CU_board_url('edit-forums', null), 3000);
            }
            
            // edit
            elseif(!empty($_POST['save_category'])) {
              $title = i18n_r('CUsersBoard/CATEGORYED_EDITED');
              $content = i18n_r('CUsersBoard/CHANGES_SUCCESSFULL');
              
              unset($_POST['save_category']);
              CUTable::updateRecord('CU_board_categories', $_POST['category_id'], $_POST);
              CUTable::refreshIndex();
              CU_redirect(get_CU_board_url('edit-forums', null), 3000);
            }
          
          // reorder categories
          elseif(!empty($_POST['reorder_categories'])) {
            $title = i18n_r('CUsersBoard/REORDER_CATEGORIES');
            $content = '';
            $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
            if(!empty($categories)) {
              $content .= '<div class="reorder-forums"><form class="category" method="post"><ul class="sortable">';
              foreach ($categories as $category) {
                $content .= '<li class="category">'.$category['category_name'].'<input type="hidden" name="category_'.$category['id'].'" value="'.$category['id'].'" /></li>';
                $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$category['id']);
                if(!empty($forums)) {
                  foreach ($forums as $forum) {
                    $content .= '<li class="forum">'.$forum['forum_name'].'<input type="hidden" name="forum_'.$forum['id'].'" value="'.$forum['id'].'||::||'.$forum['forum_category'].'" /></li>';
                  }
                }
              }
              $content .= '</ul><input type="submit" name="confirm_order" class="reorder" value="'.i18n_r('CUsersBoard/REORDER_CATEGORIES').'"></form>
                           </div>
                           <script>
                             $(".sortable").sortable();
                           </script>';
            }
          }
          
            // reorder categories
            elseif(!empty($_POST['confirm_order'])) {
              $title = i18n_r('CUsersBoard/REORDER_CATEGORIES');
              reset($_POST);
              if(substr(key($_POST), 0, 9)!='category_') {
                $content = i18n_r('CUsersBoard/NO_CATEGORY_FIRST_ENTRY');
                CU_redirect(get_CU_board_url('edit-forums', null), 3000);
              }
              else {
                $content = '';
                $categories = $forums = array();
                $category_id = null;
                $i=$s=0;
                foreach ($_POST as $key=>$entry) {
                  if (substr($key, 0, 9)=='category_') {
                    $category_id = substr($key, 9);
                    $categories[$category_id]          = $i;
                    $i++;
                  }
                  if (substr($key, 0, 6)=='forum_')    {
                    $forums[substr($key, 6)]['order']    = $s;
                    $forums[substr($key, 6)]['category'] = $category_id;
                    $s++;
                  }
                }
                foreach($categories as $key=>$order) CUTable::updateRecord('CU_board_categories', $key, array('category_order'=>$order));
                foreach($forums as $key=>$order)     CUTable::updateRecord('CU_board_forums', $key, array('forum_order'=>$order['order'], 'forum_category'=>$order['category']));
                $content = i18n_r('CUsersBoard/REORDER_SUCCESSFULL');
                CUTable::refreshIndex();
                CU_redirect(get_CU_board_url('edit-forums', null), 3000);
              }
            }
          
          // delete category || delete forum
          elseif(!empty($_POST['delete_category']) || !empty($_POST['delete_forum'])) {
            $title   = (!empty($_POST['delete_category']) ? i18n_r('CUsersBoard/DELETE_CATEGORY') : i18n_r('CUsersBoard/DELETE_FORUM'));
            $content = (!empty($_POST['delete_category']) ? i18n_r('CUsersBoard/DELETE_CATEGORY_CONFIRM').'<br/>'.$_POST['category_name'].'<br/>' : i18n_r('CUsersBoard/DELETE_FORUM_CONFIRM').'<br/>'.$_POST['forum_name'].'<br/>').'
                        <form method="post">
                          <input type="hidden" name="'.(!empty($_POST['delete_category']) ? 'category' : 'forum').'_id" value="'.(!empty($_POST['delete_category']) ? $_POST['category_id'] : $_POST['forum_id']).'">
                          <input type="submit" name="confirm_delete" value="'.i18n_r('CUsersBoard/DELETE').'">
                        </form>';
          }
          
            // confirm delete
            elseif(!empty($_POST['confirm_delete'])) {
              $title   = i18n_r('CUsersBoard/DELETE_SUCCESSFULL');
              $content = i18n_r('CUsersBoard/CHANGES_SUCCESSFULL');
              
              // delete category
              if(isset($_POST['category_id'])) {
                $forums = DM_query("SELECT * FROM CU_board_forums WHERE forum_category = ".$_POST['category_id']);
                if(!empty($forums)) {
                  foreach ($forums as $forum) {
                    $topics = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id']);
                    if(!empty($topics)) {
                      foreach ($topics as $topic) {
                        $posts = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']);
                        if(!empty($posts)) {
                          foreach ($posts as $post) DM_deleteRecord('CU_board_posts', $post['id']);
                        }
                        DM_deleteRecord('CU_board_topics', $topic['id']);
                      }
                    }
                    DM_deleteRecord('CU_board_forums', $forum['id']);
                  }
                }
                DM_deleteRecord('CU_board_categories', $_POST['category_id']);
              }
              
              // delete forum
              if(isset($_POST['forum_id'])) {
                $topics = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$_POST['forum_id']);
                if(!empty($topics)) {
                  foreach ($topics as $topic) {
                    $posts = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']);
                    if(!empty($posts)) {
                      foreach ($posts as $post) DM_deleteRecord('CU_board_posts', $post['id']);
                    }
                    DM_deleteRecord('CU_board_topics', $topic['id']);
                  }
                }
                DM_deleteRecord('CU_board_forums', $_POST['forum_id']);   
              }
              CU_redirect(get_CU_board_url('edit-forums', null), 3000);
            }
          
          // new forum || edit forum
          elseif(!empty($_POST['new_forum']) || !empty($_POST['edit_forum'])) {
            $title = (!empty($_POST['new_forum']) ? i18n_r('CUsersBoard/NEW_FORUM') : i18n_r('CUsersBoard/EDIT_FORUM'));
            $forum_name         = (!empty($_POST['new_forum']) ? '' : $_POST['forum_name']);
            $forum_description  = (!empty($_POST['new_forum']) ? '' : $_POST['forum_description']);
            $categories = DM_query("SELECT * FROM CU_board_categories ORDER BY category_order ASC");
            $category_select = '';
            foreach ($categories as $category) $category_select .= '<option value="'.$category['id'].'" '.((isset($_POST['category_id']) && $_POST['category_id']==$category['id']) || (isset($_POST['forum_category']) && $_POST['forum_category']==$category['id']) ? 'selected="selected"' : '').'>'.$category['category_name'].'</option>'; 
            $content = '<form method="post">
                          <label>'.i18n_r('CUsersBoard/FORUM_NAME').'</label>
                            <input type="text" name="forum_name" value="'.$forum_name.'"/>
                            '.(!empty($_POST['new_forum']) ? '' : '<input type="hidden" name="forum_id" value="'.$_POST['forum_id'].'"/>').'
                          <label>'.i18n_r('CUsersBoard/FORUM_CATEGORY').'</label>
                            <div class="select"><select name="forum_category">'.$category_select.'</select></div>
                          <label>'.i18n_r('CUsersBoard/FORUM_DESCRIPTION').'</label>
                            <textarea type="text" name="forum_description">'.$forum_description.'</textarea>
                            <input type="submit" '.(!empty($_POST['new_forum']) ? 'name="create_new_forum" value="'.i18n_r('CUsers/CREATE') : 'name="save_edit_forum" value="'.i18n_r('CUsers/SAVE')).'"/>
                        </form>';
          }
          
            // creates the forum
            elseif(!empty($_POST['create_new_forum'])) {
              $title = i18n_r('CUsersBoard/NEW_FORUM');
              
              // finds the latest forum so that we can get the forum order
              $forums = DM_query("SELECT * FROM CU_board_forums ORDER BY forum_order DESC", "DM_SINGLE");
              unset($_POST['create_new_forum']);
              $_POST['forum_order'] = ((!empty($forums))? ($forums['forum_order'])+1 : 0 );
              
              // creates the forum and redirects
              createRecord('CU_board_forums', $_POST);
              $content = i18n_r('CUsersBoard/NEW_FORUM_SUCCESSFUL');
              CU_redirect(get_CU_board_url('edit-forums', null), 3000);
            }
            
            // edits the forum
            elseif(!empty($_POST['save_edit_forum'])) {
              $title = i18n_r('CUsersBoard/EDIT_FORUM');
              unset($_POST['save_edit_forum']);
              CUTable::updateRecord('CU_board_forums', $_POST['forum_id'], $_POST);
              CUTable::refreshIndex();
              $content = i18n_r('CUsersBoard/CHANGES_SUCCESSFUL');
              CU_redirect(get_CU_board_url('edit-forums', null), 3000);
            }          
        }
			
			// edit-faqs
		    if(key($_GET)=='edit-faqs' && ($_SESSION['CUser']['user_level']==2)) {
			  $field = array();
			  if($_SERVER['REQUEST_METHOD']!='POST') {
			    $field['faqs']['value']		= $settings['faqs'];
			  }
			  else {
			    if(!empty($_POST['save'])) {
			      // validation rules
			      $validation_rules = array();
				  $validator = new CUValidator($_POST, $validation_rules);
				  $clean_data = $validator->get_fields();
				
				  $field['faqs']['value']		= $clean_data['faqs'];
				
				  CUTable::updateRecord('CU_board_settings', $settings['id'], $clean_data);
          CUTable::refreshIndex();
				  CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
				}
			  }
		      $content = '<form class="bbcode" method="post">
			                <textarea type="text" name="faqs">'.$field['faqs']['value'].'</textarea>
							<input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						  </form>';
			  $title = i18n_r('CUsersBoard/EDIT_FAQS');
		    }
			
			// edit-rules
		    if(key($_GET)=='edit-rules' && ($_SESSION['CUser']['user_level']==2)) {
			  $field = array();
			  if($_SERVER['REQUEST_METHOD']!='POST') {
			    $field['rules']['value']		= $settings['rules'];
			  }
			  else {
			    if(!empty($_POST['save'])) {
			      // validation rules
			      $validation_rules = array();
            $validator = new CUValidator($_POST, $validation_rules);
            $clean_data = $validator->get_fields();
          
            $field['rules']['value']		= $clean_data['rules'];
          
            CUTable::updateRecord('CU_board_settings', $settings['id'], $clean_data);
            CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
            CUTable::refreshIndex();
          }
			  }
		      $content = '<form class="bbcode" method="post">
			                <textarea type="text" name="rules">'.$field['rules']['value'].'</textarea>
							<input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						  </form>';
			  $title = i18n_r('CUsersBoard/EDIT_RULES');
		    }
			
			// ban
		  if(key($_GET)=='ban' && ($_SESSION['CUser']['user_level']==2)) {
			  $CU_settings = DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
			  
			  $field = array();
			  if($_SERVER['REQUEST_METHOD']!='POST') {
			    $field['ban_list']['value']		= $CU_settings['ban_list'];
			  }
        else {
			    if(!empty($_POST['save'])) {
			      // validation rules
			      $validation_rules = array();
            $validator = new CUValidator($_POST, $validation_rules);
            $clean_data = $validator->get_fields();
          
            $field['ban_list']['value']		= $clean_data['ban_list'];
          
            CUTable::updateRecord('CU_settings', $CU_settings['id'], $clean_data);
            CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
            CUTable::refreshIndex();
          }
			  }
		      $content = '<form class="" method="post">
			                <textarea type="text" name="ban_list">'.$field['ban_list']['value'].'</textarea>
							<input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						  </form>';
			  $title = i18n_r('CUsersBoard/BAN');
		  }
			
			// censors
		  if(key($_GET)=='censors' && ($_SESSION['CUser']['user_level']==2)) {
			  $CU_settings = DM_query("SELECT * FROM CU_settings ORDER BY id DESC", "DM_SINGLE");
			  
			  $field = array();
			  if($_SERVER['REQUEST_METHOD']!='POST') {
			    $field['censor_list']['value']		= $CU_settings['censor_list'];
			  }
			  else {
			    if(!empty($_POST['save'])) {
			      // validation rules
			      $validation_rules = array();
            $validator = new CUValidator($_POST, $validation_rules);
            $clean_data = $validator->get_fields();
          
            $field['censor_list']['value']		= $clean_data['censor_list'];
          
            CUTable::updateRecord('CU_settings', $CU_settings['id'], $clean_data);
            CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
            CUTable::refreshIndex();
          }
			  }
		      $content = '<form class="" method="post">
			                <textarea type="text" name="censor_list">'.$field['censor_list']['value'].'</textarea>
							<input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						  </form>';
			  $title = i18n_r('CUsersBoard/CENSORS');
		  }
			
			// pm config
		  if(key($_GET)=='pms-config' && ($_SESSION['CUser']['user_level']==2)) {
        if(function_exists('get_CU_pms')) {
          $CU_pms_settings = DM_query("SELECT * FROM CU_pms_settings ORDER BY id DESC", "DM_SINGLE");
          
          $field = array();
          if($_SERVER['REQUEST_METHOD']!='POST') {
            foreach ($CU_pms_settings as $setting=>$value) {
            $field[$setting]['value']		= $value;
            $field[$setting]['status']	= 'success';
          }
          }
          else {
            if(!empty($_POST['save'])) {
              // validation rules
              $validation_rules = array(
              'pm_max'		=>	array('required'=>true, 'numeric'=>true),
              'pm_length'		=>	array('required'=>true, 'numeric'=>true),
              'pm_domain'		=>	array('required'=>true, 'min_length'=>7),
              );
              $validator = new CUValidator($_POST, $validation_rules);
              
              foreach ($_POST as $setting=>$value) {
                $field[$setting]['value'] = $value;
              $field[$setting]['status']	= 'success';
              }
              
              if (!$validator->validate()) {
                // Get errors from validator
                $errors = $validator->get_errors();
              
              // styles each field that has an error
              foreach ($errors as $name=>$error) {
                $field[$name]['status'] = 'error';
              }
               
                // Return errors
                $validator->print_errors();
              }
              else {
                $clean_data = $validator->get_fields();
                unset($clean_data['save']);
              
                CUTable::updateRecord('CU_pms_settings', $CU_pms_settings['id'], $clean_data);
                CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
                CUTable::refreshIndex();
              }
            }
          }
            $content = '<form class="" method="post">
                        <label>'.i18n_r('CU_pms/PM_MAX').'</label>
                          <input type="text" class="'.$field['pm_max']['status'].'" name="pm_max" value="'.$field['pm_max']['value'].'"/>
                <label>'.i18n_r('CU_pms/PM_LENGTH').'</label>
                          <input type="text" class="'.$field['pm_length']['status'].'" name="pm_length" value="'.$field['pm_length']['value'].'"/>
                <label>'.i18n_r('CU_pms/DOMAIN').'</label>
                          <input type="text" class="'.$field['domain']['status'].'" name="domain" value="'.$field['domain']['value'].'"/>
                <input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
                </form>';
          $title = i18n_r('CUsersBoard/PMS');
        }
        else {
          $title = i18n_r('CUsersBoard/PMS_CONFIG');
          $content = i18n_r('CUsers/NEED_CUPMS');
        }
		  }
      
			
			// theme
		  if(key($_GET)=='theme' && ($_SESSION['CUser']['user_level']==2)) {
			  if(!defined('CUTHEMEPATH')) define('CUTHEMEPATH', GSPLUGINPATH.'/CUsersBoard/theme/');
		      if(file_exists(CUTHEMEPATH)) {
			    $themes = array();
			    foreach(glob(CUTHEMEPATH.'*') as $theme) {
				  $name = end(explode('/', $theme));
				  $themes[] = $name;
				}
		      
			    $theme_preview = $themes_dropdown = '';
			    foreach ($themes as $theme) {
			      $themes_dropdown .= ($settings['theme']==$theme ? '<option value="'.$theme.'" selected="selected">'.$theme.'</option>' : '<option value="'.$theme.'">'.$theme.'</option>');
			    }
			    $theme_preview = '<img class="preview" src="'.(file_exists(CUTHEMEPATH.$settings['theme'].'/img/preview.png') ? $SITEURL.'plugins/CUsersBoard/theme/'.$settings['theme'].'/img/preview.png' : $SITEURL.'plugins/CUsersBoard/img/nopreview.png').'"/>';
			    
				if($_SERVER['REQUEST_METHOD']=='POST') {
				  if(!empty($_POST['save'])) {
				    unset($_POST['save']);
            CUTable::updateRecord('CU_board_settings', $settings['id'], $_POST);
            CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
            CUTable::refreshIndex();
				  }
			  }
			  
			    $content = '<form method="post">
			                  <label>'.i18n_r('CUsersBoard/SELECT_THEME').'</label>
			                    <div class="select"><select name="theme">'.$themes_dropdown.'</select></div>
						      <label>'.i18n_r('CUsersBoard/PREVIEW').'</label>
							    '.$theme_preview.'
							  <input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
						    </form>';
			  }
			  else $content = i18n_r('CUsersBoard/NO_EXIST_THEME');
			  $title = i18n_r('CUsersBoard/THEME');
			}
			
			if(isset($_GET['edit-theme']) && ($_SESSION['CUser']['user_level']==2)) {
			  if(!defined('CUTHEMEPATH')) define('CUTHEMEPATH', GSPLUGINPATH.'/CUsersBoard/theme/'.CUBOARDTHEME.'/templates/');
		      if(file_exists(CUTHEMEPATH)) {
			    $files = array();
          
          // template files
			    foreach(glob(CUTHEMEPATH.'*') as $filename) $files[] = end(explode('/', $filename));
          // css files
          if(file_exists(CUBOARDCSSPATH)) foreach(glob(CUBOARDCSSPATH.'*') as $css) $files[] = end(explode('/', $css));
				
				$file_menu = '<ul class="template-files">';
				foreach ($files as $file) {
				  $name = reset(explode('.', $file));
				  $file_menu .= '<li><a href="'.self::getURL('edit-theme').'&file='.$file.'">'.$file.'</a></li>';
				  
				}
				$file_menu .= '</ul>';
				
				
				if(isset($_GET['file'])) {
				
        $ext = end(explode('.', $_GET['file']));
				$path = 'plugins/CUsersBoard/theme/'.CUBOARDTHEME.'/'.($ext=='php'? 'templates' : $ext).'/'.$_GET['file'];
                $template = fopen($path, "r+"); 
                $size = filesize($path);
				
				// just opened the page (not via POST)
		        if(empty($_POST['save']) && empty($_POST['undo'])) {
			      $field_content = filter_var(fread($template, $size), FILTER_SANITIZE_SPECIAL_CHARS);
				  if(empty($_SESSION['CU_board_options']['undo'][$_GET['file']])) $_SESSION['CU_board_options']['undo'][$_GET['file']] = $field_content;
		        }
				// undo
				elseif(!empty($_POST['undo']) && !empty($_SESSION['CU_board_options']['undo'][$_GET['file']])) {
				  $field_content = $_SESSION['CU_board_options']['undo'][$_GET['file']];
				  fwrite(fopen($path, "w"), html_entity_decode($field_content));
			      CU_msg_update(i18n_r('CUsersBoard/UNDO_SUCCESS'), $success=TRUE);
		        }
				// save
		        elseif(!empty($_POST['save'])) {
				  $_SESSION['CU_board_options']['undo'][$_GET['file']] = fread($template, $size);
			      $field_content = filter_var($_POST['template'], FILTER_SANITIZE_SPECIAL_CHARS);
			      fwrite(fopen($path, "w"), html_entity_decode($_POST['template']));
			      CU_msg_update(i18n_r('CUsers/CHANGES_SUCCESSFULL'), $success=TRUE);
				  
		        }
				
				if(isset($_SESSION['CU_board_options']['undo'][$_GET['file']]) && ($_SESSION['CU_board_options']['undo'][$_GET['file']]!=$field_content)) {
				  $undo = '<input type="submit" name="undo" value="'.i18n_r('CUsers/UNDO').'">';
				}
				else $undo = '';
		
		        fclose($template);
				
			  
			    $content = '<div>
				              
				              '.$file_menu.'
							  <h3>'.$_GET['file'].' ('.$path.')</h3>
			                    <form class="html" method="post">
								  <textarea type="text" name="template">'.$field_content.'</textarea>
								  <input type="submit" class="save" name="save" value="'.i18n_r('CUsers/SAVE').'">
								  '.$undo.'
								</form>
							  
                            </div>';
				}
				else {
				  $content = $file_menu;
				}
			  }
			  else $content = i18n_r('CUsersBoard/NO_EXIST_TEMPLATES');
			  $title = i18n_r('CUsersBoard/EDIT_THEME');
			}
?>