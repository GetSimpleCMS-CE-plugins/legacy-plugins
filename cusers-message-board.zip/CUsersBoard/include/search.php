<?php

function getCUBoardItems() {
  global $CUBoardItems;
  $forums = DM_query("SELECT * FROM CU_board_forums");
  if(!empty($forums)) {
    foreach ($forums as $forum) {
      $topics = DM_query("SELECT * FROM CU_board_topics WHERE topic_forum = ".$forum['id']);
      if(!empty($topics)) {
        foreach ($topics as $topic) {
          $topic_id = $topic['id'];
          $topic_subject = $topic['topic_subject'];
          $topic_forum = $topic['topic_forum'];
          $topic_date = $topic['topic_date'];
          $posts = DM_query("SELECT * FROM CU_board_posts WHERE post_topic = ".$topic['id']);
          $author = DM_query("SELECT * FROM CU_users WHERE id = ".$topic['topic_by'], "DM_SINGLE");
          $replies = (count($posts)>0 ?count($posts)-1 : 0);
          $CUBoardItems['topic'.$topic['id']] = array(
                                                      'title'         => $topic['topic_subject'],
                                                      'topic_id'      => $topic_id,
                                                      'description'   => $topic['topic_subject'],
                                                      'date'          => date('j F Y', $topic['topic_date']),
                                                      'tags'          => array('topics', 'CUBoardTopic', 'forum'.$forum['id']),
                                                      'author'        => (empty($author['user_display'])? $author['user_name'] : $author['user_display']),
                                                      'replies'       => $replies,
                                                      'topic_date'    => $topic_date,
                                                      'topic_forum'   => $topic_forum,
                                                    );
          if(!empty($posts)) {
            foreach ($posts as $post) {
              $author = DM_query("SELECT * FROM CU_users WHERE id = ".$post['post_by'], "DM_SINGLE");
              $CUBoardItems['post'.$post['id']] = array(
                                                        'title'         => 'Re: '.$topic_subject,
                                                        'topic_id'      => $topic_id,
                                                        'post_id'       => $post['id'],
                                                        'description'   => $post['post_content'],
                                                        'date'          => date('j F Y', $post['post_date']),
                                                        'tags'          => array('posts', 'CUBoardPost', 'forum'.$forum['id']),
                                                        'author'        => (empty($author['user_display'])? $author['user_name'] : $author['user_display']),
                                                        'replies'       => $replies,
                                                        'post_date'     => $post['post_date'],
                                                        'topic_date'    => $topic_date,
                                                        'topic_forum'   => $topic_forum,
                                                      );
            }
          }
        }
      }
    }
  }
}



function CUBoardSearchIndex() {
  global $CUBoardItems;

  // for each item call i18n_search_index_item($id, $language, $creDate, $pubDate, $tags, $title, $content)
  foreach ($CUBoardItems as $id => $item) {
    $date = strtotime($item['date']);
    $tags = array('posts', 'CUBoard');
    // make sure to use a unique prefix for the id
    // the creation date and publishing dates are UNIX timestamps
    // title and description are texts with no HTML tags or HTML entities
    // you can combine the text of multiple fields for the title or content
    // the only difference between title and content is that words in the title count more
    i18n_search_index_item('isd:'.$id, null, $date, $date, array_merge($item['tags'], array($item['author'])), $item['title'].' '.$item['author'], $item['description']);
  }
}

function CUBoardSearchItem($id, $language, $creDate, $pubDate, $score) {

  if (!class_exists('CUBoardSearchResultItem')) {

    // a class for returning all properties of an item of this plugin
    class CUBoardSearchResultItem extends I18nSearchResultItem {
		
      protected $data = null;
      // this is the only function you need to implement
      protected function get($name) {
        global $CUBoardItems;
        if (!$this->data) {
          // lazy loading data of the item - normally this would involve reading a file
          $this->data = $CUBoardItems[substr($this->id,4)];
          if (!$this->data) return null;
        }
        switch ($name) {
          case 'title': return $this->data['title'];
          case 'description': return $this->data['description'];
          case 'content': return '<p>' . htmlspecialchars($this->data['description']) . '</p>';
          case 'link': return null; 
          default: return @$this->data[$name]; 
        }
      }
    }

  }

  if (substr($id,0,4) == 'isd:') {
    // return the result item, if it is an item of our plugin
    return new CUBoardSearchResultItem($id, $language, $creDate, $pubDate, $score);
  }
  // item is not from our plugin - maybe from another plugin
  return null;
}

function CUBoardSearchDisplay($item, $showLanguage, $showDate, $dateFormat, $numWords) { /*
  // uncomment the following line to see the default rendering
  //return false;
  if (substr($item->id,0,4) == 'isd:') {
?>
    <h3><?php echo htmlspecialchars($item->title); ?></h3>
    <p><?php echo CU_filter($item->description); ?> Registered <?php echo $item->registered; ?> kg</p>
<?php
    return true;
  }
  // item is not from our plugin - maybe from another plugin*/
  return false;
}



// dummy items for this plugin - normally these would be files on disk
$CUBoardItems = array();
getCUBoardItems();
        
?>