<?php
// initialisation
  // checks for absent files and tables then creates them
  
    // creating the pages
      // 'board' - if CU_board_settings doesn't exist, or if it DOES and the slug is set to board, ensure that board.xml exists.
      $CU_board_settings = DM_query("SELECT * FROM CU_board_settings ORDER BY id DESC", "DM_SINGLE");
      if((!isset($CU_board_settings['page_slug']) || $CU_board_settings['page_slug']=='board') && !file_exists(GSDATAPAGESPATH.'board.xml')) {
        $xml = new DOMDocument();
        $xml_page = $xml->createElement('item');
        $pageDetails = array(
                         'pubDate'    =>date('r'),
                         'creDate'    =>date('r'),
                         'title'      =>'CU Message Board',
                         'template'   =>'template.php',
                         'url'        =>'board',
                         'menuOrder'  =>0,
                         'menuStatus' =>'',
                         'content'    =>'',
                         'parent'     =>'',
                       );
        foreach ($pageDetails as $item=>$value) {
          $field = $xml->createElement($item);
          $field->nodeValue = $value;
          $xml_page->appendChild($field);
        }
        $xml->appendChild($xml_page);
        $xml->save(GSDATAPAGESPATH.'board.xml');
      }
      
      // variables
global 		$SITEURL;


$tables = array(
	'CU_board_settings'=>array(
		'board_name'=>array(
			'name' => 'board_name',
			'type' => 'textlong'
		),
		'board_date'=>array(
			'name' => 'board_date',
			'type' => 'int'
		),
		'page_slug'=>array(
			'name' => 'page_slug',
			'type' => 'pages'
		),
		'domain'=>array(
			'name' => 'domain',
			'type' => 'textlong'
		),
		'rules'=>array(
			'name' => 'rules',
			'type' => 'textlong'
		),
		'faqs'=>array(
			'name' => 'faqs',
			'type' => 'textlong'
		),
		'topics_per_page'=>array(
			'name' => 'topics_per_page',
			'type' => 'int'
		),
		'posts_per_page'=>array(
			'name' => 'posts_per_page',
			'type' => 'int'
		),
		'time'=>array(
			'name' => 'time',
			'type' => 'textlong'
		),
		'date'=>array(
			'name' => 'date',
			'type' => 'textlong'
		),
		'theme'=>array(
			'name' => 'theme',
			'type' => 'slug'
		),
		'urls'=>array(
			'name' => 'urls',
			'type' => 'textlong'
		),
		'other'=>array(
			'name' => 'other',
			'type' => 'textlong'
		),
	),
	'CU_board_categories'=>array(
		'category_name'=>array(
			'name' => 'category_name',
			'type' => 'textlong'
		),
		'category_order'=>array(
			'name' => 'category_order',
			'type' => 'textlong'
		)
	),
	'CU_board_forums'=>array(
		'forum_name'=>array(
			'name' => 'forum_name',
			'type' => 'textlong'
		),
		'forum_description'=>array(
			'name' => 'forum_description',
			'type' => 'textlong'
		),
		'forum_category'=>array(
			'name' => 'forum_category',
			'type' => 'int'
		),
		'forum_order'=>array(
			'name' => 'forum_order',
			'type' => 'int'
		)
	),
	'CU_board_topics'=>array(
		'topic_subject'=>array(
			'name' => 'topic_subject',
			'type' => 'textlong'
		),
		'topic_date'=>array(
			'name' => 'topic_date',
			'type' => 'int'
		),
		'topic_latest'=>array(
			'name' => 'topic_latest',
			'type' => 'int'
		),
		'topic_views'=>array(
			'name' => 'topic_views',
			'type' => 'int'
		),
		'topic_forum'=>array(
			'name' => 'topic_forum',
			'type' => 'int'
		),
		'topic_by'=>array(
			'name' => 'topic_by',
			'type' => 'int'
		),
		'topic_order'=>array(
			'name' => 'topic_order',
			'type' => 'int'
		),
		'topic_status'=>array(
			'name' => 'topic_status',
			'type' => 'int'
		)
	),
	'CU_board_posts'=>array(
		'post_content'=>array(
			'name' => 'post_content',
			'type' => 'textlong'
		),
		'post_date'=>array(
			'name' => 'post_date',
			'type' => 'int'
		),
		'post_topic'=>array(
			'name' => 'post_topic',
			'type' => 'int'
		),
		'post_by'=>array(
			'name' => 'post_by',
			'type' => 'int'
		),
		'post_update'=>array(
			'name' => 'post_update',
			'type' => 'int'
		),
		'post_update_by'=>array(
			'name' => 'post_update_by',
			'type' => 'int'
		)
	)
);
$data = array(
	'CU_board_settings'	=>array(
		'board_name'		=>'Your GetSimple Board',
		'board_date'		=>time(),
		'page_slug'			=>'board',
		'domain'			=>$SITEURL.'index.php?id=board',
		'rules'				=>'',
		'faqs'				=>'',
		'topics_per_page'	=>10,
		'posts_per_page'	=>10,
		'time'				=>'h:i A',
		'date'				=>'d-m-Y',
		'theme'				=>'Innovation',
    'urls'				=>'',
		'other'				=>'',
	),
	'CU_board_categories'=>array(
		'category_name'		=>	'Your first category',
		'category_order'	=>	0
	),
	'CU_board_forums'=>array(
		'forum_name'		=>'Your first forum',
		'forum_description'	=>'Your first forum description.',
		'forum_category'	=>0,
		'forum_order'		=>0
	),
	'CU_board_topics'=>array(
		'topic_subject'		=>'Your first topic',
		'topic_date'		=>time(),
		'topic_latest'		=>time(),
		'topic_views'		=>0,
		'topic_forum'		=>0,
		'topic_by'			=>0,
		'topic_order'		=>0,
		'topic_status'		=>0
	),
	'CU_board_posts'=>array(
		'post_content'		=>'Your first post, in your first topic, in your first forum on your first GetSimple board.',
		'post_date'			=>time(),
		'post_topic'		=>0,
		'post_by'			=>0,
		'post_update'		=>time(),
		'post_update_by'	=>0,
	)
);



// navigation
global $SITEURL;
if(!defined('CUBOARDADMINURL')) define('CUBOARDADMINURL', $SITEURL.'admin/load.php?id=CUsersBoard');
end($_GET);
echo '<h3 class="floated">';
    if(key($_GET)=='id') echo 'CUsers: Message Board';
    else echo i18n_r('CUsers/'.strtoupper(key($_GET)));
echo '</h3>
      <div class="edit-nav">
        <a href="'.CUBOARDADMINURL.'&setup">'.i18n_r('CUsers/SETUP').'</a>
        <a href="'.CUBOARDADMINURL.'">'.i18n_r('CUsers/HOME').'</a>
        <div class="clear"></div>
      </div>
      <div style="clear: both"></div>';
      
if(key($_GET)=='id') {
  echo '<table>
          <tbody>
            <tr>
              <th style="width: 100px;"><a href="'.CUBOARDADMINURL.'&setup">'.i18n_r('CUsers/SETUP').'</a></th>
              <td>'.i18n_r('CUsersBoard/SETUP_DESCRIPTION').'</td>
            </tr>
          </tbody>
        </table>';
}
      
if(isset($_GET['setup'])) {
  $setupMsgs = array();
  CUTable::createTable($tables, $data);
  
     // perform queries to see if the tables were successfully created and populated
    foreach ($tables as $table=>$fields) {
      if(tableExists($table)) $setupMsgs['success'][] = '<strong>'.$table.'</strong> '.strtolower(i18n_r('CUsers/TABLE').' '.i18n_r('CUsers/SUCCESSFULLY_CREATED')).'.';
      else                $setupMsgs['error'][]   = '<strong>'.$table.'</strong> '.strtolower(i18n_r('CUsers/TABLE').' '.i18n_r('CUsers/NOT_SUCCESSFULLY_CREATED')).'.';
    }
    
  // display results of setup
  echo '<ul>';
  foreach ($setupMsgs as $set=>$msgs) {
    if(!empty($set)) { 
      echo '<li>'.i18n_r('CUsers/'.strtoupper($set)).':<ul>';
        foreach ($msgs as $msg) echo '<li>'.$msg.'</li>';
      echo '</ul></li>';
    }
  }
  echo '</ul>';
  getCUError(i18n_r('CUsers/SETUP_SUCCESS'), 'updated', false);
}
?>