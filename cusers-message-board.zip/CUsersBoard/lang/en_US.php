<?php
$i18n = array(
  // general terms
    'FORUM'		=>	'Forum',
  
  // titles
  'VIEW_CATEGORY'	=>	'View category',
  'VIEW_FORUM'		=>	'View forum',
  'VIEW_TOPIC'		=>	'View topic',
  'EDIT_TOPIC'		=>	'Editing topic',
  'DELETE_TOPIC'		=>	'Deleting topic',
  'EDIT_POST'		=>	'Editing post',
  'QUOTE_POST'		=>	'Quoting post',
  'DELETE_POST'		=>	'Deleting post',
  'PAGE_NOT_FOUND'	=>	'Page not found',
  
  // links
  'HOME'	=>	'Home',
  'MEMBERS'	=>	'Members',
  'SEARCH'	=>	'Search',
  'FAQS'	=>	'FAQs',
  'RULES'	=>	'Rules',
  'HELP'	=>	'Help',
  'CPANEL'	=>	'CPanel',
  
  // user panel
  'USER_PANEL'	=>	'User Panel',
  'BASIC'	=>	'Basic',
  
  // category
  'NO_CATEGORIES'	=>	'No categories exist.',
  
  // search (forum specific)
  'ENTIRE_POST' => 'Entire post',
  'TOPIC_ONLY' => 'Topic titles only',
  'POSTS_BETWEEN' => 'Posts between',
  
  // forum
  'STICKY'	=>	'Sticky',
  'STICKIES'	=>	'Stickies',
  'ANNOUNCEMENT'	=>	'Announcement',
  'ANNOUNCEMENTS'	=>	'Announcements',
  'FORUMS'	=>	'Forums',
  'TOPICS'	=>	'Topics',
  'VIEWS'	=>	'Views',
  'REPLIES'	=>	'Replies',
  'LAST_POST'	=>	'Last Post',
  'NEW_TOPIC'	=>	'Create Topic',
  'NO_FORUMS'  => 'No forums exist.',
  
  // topic
  'TOPIC_SUBJECT'	=>	'Subject',
  'POST_CONTENT'	=>	'Content',
  'TOPIC_ORDER'	=>	'Type',
  'TOPIC_STATUS'	=>	'Status',
    'OPEN'	=>	'Open',
    'CLOSED'	=>	'Closed',
  'AUTHOR'	=>	'Author',
  'LEVEL'	=>	'Level',
  'POST'	=>	'Post',
  'POSTS'	=>	'Posts',
  'EMAIL'	=>	'Email',
  'SUCCESS_POST'	=>	'Post successfully submitted.',
  'CONFIRM_POST_DELETE'	=>	'Are you sure that you wish to delete this post?',
  'SUCCESS_POST_DELETE'	=>	'Post successfully deleted.',
  
  // statistics
  'STATS'	=>	'Statistics',
  'BOARD_CREATED'	=>	'Board created',
  'CURRENTLY_HAVE'	=>	'We currently have',
  'USERS_REGISTERED'	=>	'users registered',
  'USERS_MADE'	=>	'Our users have made',
  'POSTS_IN'	=>	'Posts in',
  'NEW_USER'	=>	'Our newest user is',
  
  // button labels
  'QUOTE'	=>	'Quote',
  'EDIT'	=>	'Edit',
  'DELETE'	=>	'Delete',
  'PREVIEW'	=>	'Preview',
  'POST_REPLY'	=>	'Post Reply',
  
  // cpanel
  'FEATURE'	=>	'Feature Settings',
	'DOMAIN'	=>	'Domain',
	'TOPICS_PER_PAGE'	=>	'Topics per page',
	'POSTS_PER_PAGE'	=>	'Posts per page',
	'TIME'	=>	'Time',
	'DATE'	=>	'Date',
  'EDIT_USER'	=>	'Edit User(s)',
  'EDIT_FORUMS'	=>	'Edit Forums',
    'REORDER_CATEGORIES'	=>	'Reorder Categories',
    'NO_CATEGORY_FIRST_ENTRY'	=>	'All forums must have a corresponding category.',
    'REORDER_SUCCESSFULL'	=>	'Categories and forums reordered successfully.',
  'EDIT_FAQS'	=>	'Edit FAQs',
  'EDIT_RULES'	=>	'Edit Rules',
  'CENSORS'	=>	'Edit Censor list',
  'BAN'	=>	'IP Ban Members',
  'PMS_CONFIG'	=>	'PM Configuration',
  'THEME'	=>	'Theme',
    'SELECT_THEME'	=>	'Select theme',
    'EDIT_THEME'	=>	'Edit Template Files',
  
  // errors
  'NO_SETTINGS'	=>	'This board does not have correctly configured settings.',
  
  // general
  'CURRENT_TIME'	=>	'Current time is',

  // admin
    'SETUP_DESCRIPTION'		  =>	'Performs initial configuration for this message board. <strong>You must go here if you have just installed the plugin.</strong>',
  
);
?>