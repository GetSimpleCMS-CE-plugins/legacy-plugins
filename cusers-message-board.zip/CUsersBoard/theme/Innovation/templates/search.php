<?php 
$search_page = '

<!--page-->
<div class="table_wrap">
  <table>
  <form method="post">
    <thead>
	  <tr>
	    <th colspan="2">'.$title.'</th>
	  </tr>
	</thead>
	<thead>
	  <tr>
	    <th width="50%">Search by Keyword</th>
      <th width="50%">Search by Username</th>
	  </tr>
	</thead>
    <tbody>
	  <tr>
	    <td>
        <input type="text" name="words"/>
		    <input type="radio" checked="checked" name="type" value="posts"> search entire post <br>
        <input type="radio" name="type" value="topics"> search topic titles only
		</td>
		<td>
		  <input type="text" name="author"/>
		</td>
	  </tr>
	</tbody>
	<thead>
	  <tr>
	    <th colspan="2">Options</th>
	  </tr>
	</thead>
    <tbody>
	  <tr>
	    <td>
		  <div class="select multiple"><select name="forum[]" multiple>'.$select_forums.'</select></div>
		</td>
		<td>
      <div class="select"><select name="min_max_replies">
        <option value="max">'.$labels['max-replies'].'</option>
        <option value="min">'.$labels['min-replies'].'</option>
      </select></div>
      <input type="text" name="replies"/>'.$labels['replies'].'
      '.$labels['find-posts-between'].'<br>
      <input type="date" name="startdate" value="'.date('Y-m-d', time()-(60*60*24)).'">
      <input type="date" name="enddate" value="'.date('Y-m-d').'">
      <input type="hidden" name="time" value="'.time().'">
      <br/><br/>
      <div class="select"><select name="sort_by">
        <option value="author">'.i18n_r('CU_board/SORT_BY').' '.i18n_r('CU_board/AUTHOR').'</option>
        <option value="created">'.i18n_r('CU_board/SORT_BY').' '.i18n_r('CU_board/DATE').'</option>
        <option value="topic_forum">'.i18n_r('CU_board/SORT_BY').' '.i18n_r('CU_board/FORUM').'</option>
      </select></div>
      <input type="radio" name="sort_order" value="+"> asc <br>
      <input type="radio" checked="checked" name="sort_order" value="-">desc
      
      
		  <input type="submit" name="search" value="'.$labels['search'].'"/>
		</td>
	  </tr>
	</tbody>
  </form>
  </table>
</div>
<!--/page-->

'
?>