<!--forum-->
<div class="pagination">
  {pagination}
  <div class="right">
    <a href="{url:newtopic}" class="newTopic submit">{newtopic}</a>
  </div>
</div>
<div class="table forum">
  <table> 
    <!--forum header-->
    <thead>
      <tr>
        <th colspan="100%"><a href="{url:forum}">{title:forum}</a></th>
      </tr>
    </thead>
    <thead>
      <tr>
        <th width="60%">{title:topic}</th>
        <th>{title:views}</th>
        <th>{title:replies}</th>
        <th width="30%">{title:lastpost}</th>
        <th></th>
      </tr>
    </thead>
    <!--/forum header-->
    
    
    <tbody class="topics">
    <!--topics-->
    
      <!--topic-->
      <tr>
        <td class="row_1">
          <h3><!--type--><span class="type">{type}</span><!--/type--> <a href="{url:topic}">{topic}</a></h3>
          <p>{author}</p>
        </td>
        <td class="row_2">{views}</td>
        <td class="row_1">{replies}</td>
        <td class="row_1">{lastpost}<br />{poster}</td>
        <td class="row_2">{mod}</td>
      </tr>
      <!--/topic-->
      <!--no topic-->
      <tr>
        <td class="row_1" colspan="100%">{notopic}</td>
      </tr>
      <!--/no topic-->
      
    <!--/topics-->
    </tbody>
    
    
  </table>
</div>
<div class="pagination">{pagination}</div>
<!--/forum-->