<!--page-->
<!--pagination-->
<div class="pagination">
  {pagination}
</div>
<!--/pagination-->
<div class="table">
  <table> 
    <!--page header-->
    <thead>
      <tr>
        <th colspan="100%">{title}</th>
      </tr>
    </thead>
    {headers}
    <!--/page header-->
    <tbody>
    <!--tbody-->
      {content} 
    <!--/tbody-->
    </tbody>
  </table>
</div>
<!--pagination-->
<div class="pagination">
  {pagination}
</div>
<!--/pagination-->
<!--/page-->