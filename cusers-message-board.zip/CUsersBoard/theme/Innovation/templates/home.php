<!--header/-->

<!--categories/-->

<!--statistics-->
<div class="table">
  <table>
    <thead>
	  <tr>
	    <th colspan="100%">{title:statistics}</th>
	  </tr>
	</thead>
    <tbody>
	  <tr>
	    <td class="row_1">
        <ul class="stats">
          <li class="created">{created}</li>
          <li class="users">{users}</li>
          <li class="topics">{topics}</li>
          <li class="new_user">{newuser}</li>
        </ul>
      </td>
	  </tr>
	</tbody>
  </table>
</div>
<!--/statistics-->
