  <!--footer-->
  <footer>
    (C) Footer | Powered by CUsers Message Board Version {version}
  </footer>
  <!--/footer-->
</div>
<!--/message board-->