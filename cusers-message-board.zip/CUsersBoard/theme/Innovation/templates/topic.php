<!--topic-->
<div class="pagination">
  {pagination}
  <div class="right">
    <a href="{url:newtopic}" class="newTopic submit">{newtopic}</a>
    <a href="#postreply" class="postReply submit">{postreply}</a>
  </div>
</div>

<div class="clear"></div>
<div class="table">
  <table> 
    <!--topic header-->
    <thead>
      <tr>
        <th colspan="100%"><a href="{url:forum}">{title:topic}</a></th>
      </tr>
    </thead>
    <thead>
      <tr>
        <th style="width:150px;">{title:author}</th>
        <th>{title:content}</th>
      </tr>
    </thead>
    <!--/topic header-->
    
    <!--posts-->
    <tbody>
      <!--post-->
      <tr>
        <td class="{row} profile">
          <!--profile-->
          <h3><a href="{url:author}">{author}</a></h3>
          <img class="avatar" src="{url:avatar}"/><br>
          {label:posts}: {posts}<br>
          {label:level}: {level}<br>
          {label:registered}: {registered}<br>
          <!--/profile-->
        </td>
        <td class="{row}">
          <div class="options">
          <!--options-->
            <!--edit-->
            <a href="{url:edit}" class="edit submit"><span>{edit}</span></a>
            <!--/edit-->
            <!--quote-->
            <a href="{url:quote}" class="quote submit"><span>{quote}</span></a>
            <!--/quote-->
            <!--delete-->
            <a href="{url:delete}" class="delete submit"><span>{delete}</span></a>
            <!--/delete-->
          <!--/options-->
          </div>
          <div class="post">{post}</div>
          <div class="signature">{signature}</div>
        </td>
      </tr>
      <!--/post-->
      <!--no post-->
      <tr>
        <td class="row_1" colspan="100%">{nopost}</td>
      </tr>
      <!--/no post-->
    </tbody>
    <!--/posts-->
    <!--post reply-->
    <tbody>
      <tr>
        <th colspan="100%" class="thead_1">{postreply}</th>
      </tr>
      <tr>
        <td colspan="100%" class="row_1">
          <form method="post" class="bbcode">
            <textarea name="post_content"></textarea>
            <input type="submit" name="post_reply" value="{postreply}"/>
            <input type="submit" name="preview" value="{preview}"/>
          </form>
        </td>
      </tr>
      </td>
    </tbody>
    <!--/post reply-->
  </table>
</div>
<div class="pagination">{pagination}</div>
<div class="clear"></div>
<!--/topic-->