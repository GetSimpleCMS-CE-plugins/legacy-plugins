<div class="messageBoard" id="{page}">
  <!--header-->
  <header>
    <span class="tagline">Just another GetSimple message board</span>
    <!--menu-->
    <ul class="menu">
      <li class="home">   <a href="{url:home}">{home}</a></li>
      <li class="members"><a href="{url:members}">{members}</a></li>
      <li class="faqs">   <a href="{url:faqs}">{faqs}</a></li>
      <li class="rules">  <a href="{url:rules}">{rules}</a></li>
      <li class="search"> <a href="{url:search}">{search}</a></li>
      <!--admin-->
      <li class="cpanel"> <a href="{url:cpanel}">{cpanel}</a></li>
      <!--/admin-->
    </ul>
    <!--/menu-->
    <!--user panel-->
    <section class="userPanel">
      <div class="left">{form}</div>
      <div class="right">{time}</div>
    </section>
    <!--/user panel-->
    <div class="breadcrumbs">{breadcrumbs=" > "}</div>
    <div class="clear"></div>
  </header>
  <!--/header-->