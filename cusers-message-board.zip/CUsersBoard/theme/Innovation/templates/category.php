<!--category-->
<div class="table">
  <table> 
    <!--category header-->
    <thead>
      <tr>
        <th colspan="100%"><a href="{url:category}">{title:category}</a></th>
      </tr>
    </thead>
    <thead>
      <tr>
        <th width="60%">{title:forum}</th>
        <th width="10%">{title:topics}</th>
        <th width="30%">{title:lastpost}</th>
      </tr>
    </thead>
    <!--/category header-->
    
    <!--forums-->
    <tbody>
      <!--forum-->
      <tr>
        <td class="row_1">
          <h3><a href="{url:forum}">{forum}</a></h3>
          <p>{description}</p>
        </td>
        <td class="row_2">{topics}</td>
        <td class="row_1">{lastpost}</td>
      </tr>
      <!--/forum-->
      <!--no forum-->
      <tr>
        <td class="row_1" colspan="100%">{noforum}</td>
      </tr>
      <!--/no forum-->
    </tbody>
    <!--/forums-->
    
  </table>
</div>
<!--/category-->