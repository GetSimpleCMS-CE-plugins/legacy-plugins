/* initialises the board's main CSS/jQuery features */
  $(document).ready(function(){
    $(".thead_1 .toggle_vis").click(function(){
      $(this).closest("table").find("tbody, .thead_2, .thead_3").toggle();
      $(this).toggleClass("open").toggleClass("closed");
    });
    $(".messageBoard#faqs h1, .messageBoard#faqs h2, .messageBoard#faqs h3, .messageBoard#faqs h4, .messageBoard#faqs h5, .messageBoard#faqs h6").addClass("closed").closest("li").children().not("h1, h2, h3, h4, h5, h6").hide();
    $(".messageBoard#faqs h1, .messageBoard#faqs h2, .messageBoard#faqs h3, .messageBoard#faqs h4, .messageBoard#faqs h5, .messageBoard#faqs h6").click(function(){
      $(this).closest("li").children().not("h1, h2, h3, h4, h5, h6").stop().slideToggle();
      $(this).toggleClass("open").toggleClass("closed");
    });
    $(".bbcode textarea").markItUp(myBBCodeSettings);
    $(".html textarea").markItUp(myHtmlSettings);
    $(".theme-tabs").liteTabs();
    $(".sortable").sortable();
  });