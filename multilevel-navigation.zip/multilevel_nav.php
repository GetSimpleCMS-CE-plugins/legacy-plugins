<?php
/*
Plugin Name: Multilevel Navigation
Description: Nested DIV`s width DOM-classes like "menuitem_lvl_1", "menuitem_lvl_2", etc. Use get_navigation_ml() instead get_navigation();
Version: 1.01
Author: Vladimir Mosharov
Author URI: mailto:mosharov@yandex.ru
*/
$thisfile=basename(__FILE__, ".php");

register_plugin(
	$thisfile,
	'Multilevel Menu',
	'1.01',
	'Vladimir Mosharov',
	'mailto:mosharov@yandex.ru',
	'Nested DIV`s width DOM-classes like "menuitem_lvl_1", "menuitem_lvl_2", etc. Use get_navigation_ml() instead get_navigation()',
	'theme', 
	'get_navigation_ml($currentpage)'
);

	function get_navigation_ml($currentpage){
		global $pagesArray;
		$pagesSorted = subval_sort($pagesArray,'menuOrder');
		$srcArr = array();
		if(count($pagesSorted) != 0){
			$j = 0;
			for($i = 0; $i < count($pagesSorted); $i++){
				if ($pagesSorted[$i]['menuStatus'] == 'Y'){
					$srcArr[$j]['slug'] = $pagesSorted[$i]['slug'];
					$srcArr[$j]['parent'] = $pagesSorted[$i]['parent'];
					$srcArr[$j]['url'] = $pagesSorted[$i]['url'];
					$srcArr[$j]['menu'] = $pagesSorted[$i]['menu'];
					$j++;
				}
			}
		}
		mln_build_menu($srcArr, '', 1, $currentpage);
	}
	function mln_build_menu($srcArr, $cur_itm, $lvl, $currentpage){
		foreach($srcArr as $sa){
			if($sa['parent'] == $cur_itm){
				if($currentpage == $sa['url']){
					echo '<div class="menuitem_lvl_'.$lvl.' current active">';
				}
				else{
					echo '<div class="menuitem_lvl_'.$lvl.'">';
				}
				echo '<a href="'.find_url($sa['url'],$sa['parent']).'">'.strip_decode($sa['menu']).'</a>';
					$lvl++;
					mln_build_menu($srcArr, $sa['slug'], $lvl, $currentpage);
					$lvl--;
				echo '</div>';
			}
		}
	}
?>