<?php

/*
Plugin Name: Link Manager
Description: Manage a collection of links
Version: 1.1.1
Author: Rogier Koppejan
Author URI: http://rxgr.nl/getsimple/
*/


# get correct id for plugin
$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
  $thisfile,
  'Link Manager',
  '1.1.1',
  'Rogier Koppejan',
  'http://rxgr.nl/getsimple/',
  'Manage a collection of links',
  'plugins',
  'lm_main'
);


# hooks
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Link Manager'));
add_action('header', 'lm_header_include');
add_filter('content', 'lm_filter');

# language
i18n_merge('link_manager') || i18n_merge('link_manager', 'en_US');

# definitions
define('LM_DATA', GSDATAOTHERPATH . 'links.xml');
define('LM_BACKUP', GSBACKUPSPATH . 'other/links.xml');
define('LM_INC_PATH', GSPLUGINPATH . 'link_manager/inc/');
define('LM_TEMPLATE_PATH', GSPLUGINPATH . 'link_manager/template/');

# includes
require_once(LM_INC_PATH . 'functions.php');
require_once(LM_INC_PATH . 'panel.php');


/*******************************************************
 * @function lm_main
 * @action back-end main function; select action to take
 */
function lm_main() {
  if (isset($_POST['link'])) {
    lm_save_link();
    lm_admin_panel();
  } elseif (isset($_POST['order'])) {
    lm_save_order();
    lm_admin_panel();
  } elseif (isset($_GET['delete'])) {
    lm_delete_link($_GET['delete']);
    lm_admin_panel();
  } elseif (isset($_GET['edit'])) {
    lm_edit_link($_GET['edit']);
  } elseif (isset($_GET['undo'])) {
    lm_undo();
    lm_admin_panel();
  } else {
    lm_admin_panel();
  }
}


/*******************************************************
 * @function lm_filter
 * @action front-end function; insert links into content
 */
function lm_filter($content) {
  if (preg_match('/\(%\s*links\s*%\)/', $content)) {
    $html = lm_to_html();
    $content = preg_replace('/\(%\s*links\s*%\)/', $html, $content);
  }
  return $content;
}


/*******************************************************
 * @function lm_list_links
 * @action front-end function; add links to template
 */
function lm_list_links() {
  $html = lm_to_html();
  if (!empty($html))
    echo $html;
}


?>
