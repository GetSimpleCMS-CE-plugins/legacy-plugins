# GS Fancy URLs on IIS Windows Server

by [richjenks.com](http://richjenks.com)

This server configuration file will allow the use of Fancy URLs in a GetSimple CMS installation running on IIS7.0, e.g. "domain.com/about" rather than "domain.com/index.php?id=about".

## Installation

1. Extract web.config into the root of your GetSimple installation
2. In GetSimple settings, enable Fancy URLs

## Troubleshooting

- If you are prompted to overwrite an existing file you should cancel and add integrate the config manually
- If you are implemeting this in a GS installation inside another GS installation you will need to rename the rewrite rule on line 7
- Contact me via [richjenks.com](http://richjenks.com) if you have any problems

## Changes

### v3

- Now supports pages with parent pages (Permalink Structure: `%parent%/%slug/%`)

### v2

- Stopped directives being inherited
- Cut extension down to one file
- Made compatible with GS installations inside other GS installations