<?php

  /*****************************************************************
   **                                                             **
   **             ___________________________________             **
   **            |                                   |            **
   **            |   [SimonStenhouse.NET] Download   |            **
   **            |___________________________________|            **
   **                                                             **
   **                                                             **
   *****************************************************************/
	 
   // This is used to display a leech attempt message.  Modify as needed.

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Simon Stenhouse - Leech Attempt</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<style type="text/css">
			* {
				margin: 0px;
				padding: 0px;
				font-size: 12px;
				font-family: Verdana; }
			img {	border: 0px; }
			.title {
				display: inline;
				padding: 5px 15px 5px 10px;
				font-size: 14px;
				line-height: 24px;
				font-weight: bold;
				color: #FFFFFF;
				background-color: #3399FF;
				border-bottom: 1px solid #FFFFFF;
				border-right: 1px solid #FFFFFF; }
			.subtitle	{
				padding: 5px 10px;
				color: #FFFFFF;
				background-color: #3399FF; }
			.subtitle a, .subtitle a:hover {
				font-size: 10px;
				color: #FFFFFF;
				text-decoration: none; }
			.entry {
				padding: 5px;
				color: #000000;
				background-color: #F6F6F6;
				border: 1px solid #3399FF; }
			.container { display: block; width: 20em; }
			.left { float: left; }
			.right { float: right; }
			.simon { font-size: 30px; color: #000000; }
			.stenhouse { font-size: 30px; color: #3399FF; }
			#frame {
				position: relative;
				margin: 0px auto;
				padding: 10px 0px;
			 	width: 21em;
				height: 100%; }
		</style>
	</head>
	<body>
		<div id="frame">
			<div><span class="simon">Simon</span><span class="stenhouse">Stenhouse</span></div><br />
			<div class="title">Leech Attempt</div>
			<div class="subtitle">&nbsp;</div>
			<div class="entry">
				Either a referer was not sent or it was from another domain. The attempt has been logged and action will be taken if necessary.<br /><br />Please be aware that download applications that hide referers, such as GetRight, GoZilla! and Download Accelerator Plus, will prevent you from downloading files here.<br /><br />It is recommended that you disable the download managers and use your browsers in-built downloader.
			</div>
			<div class="subtitle"><a href="http://www.simonstenhouse.net/" target="_blank" title="SimonStenhouse.NET">&copy;2005 Simon Stenhouse</a></div>
		</div>
	</body>
</html>