<?php

  /*****************************************************************
   **                                                             **
   **             ___________________________________             **
   **            |                                   |            **
   **            |   [SimonStenhouse.NET] Download   |            **
   **            |___________________________________|            **
   **                                                             **
   **                                                             **
   *****************************************************************/

   // This a Usage example for the Download script.
   // NOTE: The include must come before any output.
   // NOTE: You only need to include the download script if you plan
   //       on using the 'size' and 'count' feature.

include_once('download.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
        <head>
                <title>Simon Stenhouse - Download Usage Example</title>
                <meta http-equiv="content-type" content="text/html; charset=utf-8" />
                <style type="text/css">
                        * {
                                margin: 0px;
                                padding: 0px;
                                font-size: 12px;
                                font-family: Verdana; }
                        a {
                                color: #3399FF;
                                text-decoration: none; }
                        img {        border: 0px; }
                        .title {
                                display: inline;
                                padding: 5px 15px 5px 10px;
                                font-size: 14px;
                                line-height: 24px;
                                font-weight: bold;
                                color: #FFFFFF;
                                background-color: #3399FF;
                                border-bottom: 1px solid #FFFFFF;
                                border-right: 1px solid #FFFFFF; }
                        .subtitle        {
                                padding: 5px 10px;
                                color: #FFFFFF;
                                background-color: #3399FF; }
                        .subtitle a, .subtitle a:hover {
                                font-size: 10px;
                                color: #FFFFFF; }
                        .entry {
                                padding: 5px;
                                color: #000000;
                                background-color: #F6F6F6;
                                border: 1px solid #3399FF; }
                        .container { display: block; width: 20em; }
                        .left { float: left; }
                        .right { float: right; }
                        .simon { font-size: 30px; color: #000000; }
                        .stenhouse { font-size: 30px; color: #3399FF; }
                        #frame {
                                position: relative;
                                margin: 0px auto;
                                padding: 10px 0px;
                                 width: 21em;
                                height: 100%; }
                </style>
        </head>
        <body>
                <div id="frame">
                        <div><a href="http://www.simonstenhouse.net/index.php?area=projects"><span class="simon">Simon</span><span class="stenhouse">Stenhouse</span></a></div><br />
                        <div class="title">Download Usage Example</div>
                        <div class="subtitle">Download 1.1</div>
                        <div class="entry">
                                <div class="container">
                                        <div class="left">File:</div><div class="right"><a href="download.php?download1.1.zip">download1.1.zip</a></div><br />
                                        <div class="left">Size:</div><div class="right"><?php echo download_size('download1.1.zip'); ?></div><br />
                                        <div class="left">Counter:</div><div class="right"><?php echo download_count('download1.1.zip'); ?></div><br />
                                </div>
                        </div>
                        <div class="subtitle">Statistics 1.1</div>
                        <div class="entry">
                                <div class="container">
                                        <div class="left">File:</div><div class="right"><a href="download.php?statistics1.1.zip">statistics1.1.zip</a></div><br />
                                        <div class="left">Size:</div><div class="right"><?php echo download_size('statistics1.1.zip'); ?></div><br />
                                        <div class="left">Counter:</div><div class="right"><?php echo download_count('statistics1.1.zip'); ?></div><br />
                                </div>
                        </div>
                        <div class="subtitle">Statistics2Flash 1.0</div>
                        <div class="entry">
                                <div class="container">
                                        <div class="left">File:</div><div class="right"><a href="download.php?statistics2flash1.0.zip">statistics2flash1.0.zip</a></div><br />
                                        <div class="left">Size:</div><div class="right"><?php echo download_size('statistics2flash1.0.zip'); ?></div><br />
                                        <div class="left">Counter:</div><div class="right"><?php echo download_count('statistics2flash1.0.zip'); ?></div><br />
                                </div>
                        </div>
                        <div class="subtitle"><a href="http://www.simonstenhouse.net/" target="_blank" title="SimonStenhouse.NET">&copy;2005 Simon Stenhouse</a></div>
                </div>
        </body>
</html>