<?php

include_once('downloads/download.php');
/*
Plugin Name: Downloads Manager
Hides the actual location of your files and Keeps Count of Downloads
Version: 1.0
Author : Prasoon Gupta (prepared a Get-Simple Plugin)
Author URI: http://www.computerplanetindia.com/
Original Author : Simon Stenhouse
Website: http://www.simonstenhouse.net/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Downloads Manager', 	
	'1.0', 		
	'Prasoon Gupta',
	'http://www.computerplanetindia.com/', 
	'Hides the actual location of your files and Keeps Count of Downloads',
	'plugin',
	'downloads_init'  //main_function
);

# activate filter
add_action('index-pretemplate','inc_core_func'); 

add_filter('content','download_file_size');
add_filter('content','download_file_count');
add_filter('content','download_link');
# add a link in the admin tab 'theme'
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Downloads Manager How-To'), 'downloads_init');

function show_files() {
	echo "fruuooou";
}

# functions
function inc_core_func() {
	global $thisfile;
	echo "<?php include_once('/plugins/downloads/download.php');?>";
}

function downloads_init() {
	   global $SITEURL;
	$path =  '../data/uploads/data';
	$path2 = '../data/uploads/xjo056';
	if(!is_dir($path)){
		mkdir($path, 0777, true);
		mkdir($path2, true);
	}
echo "<h2>Download Manager</h2>
<p>Author : <a href=\"http://www.computerplanetindia.com\">Prasoon Gupta</a> | Credits : <a href=\"http://www.simonstenhouse.net/\">Simon Stenhouse</a></p>
<h3>What it does ?</h3>
<p>If you want to provide some Downloading stuff from your website, and are concerned about</p>
<ul>
  <li>Preventing Leeching of files from your server</li>
  <li>Hiding the actual location of your files </li>
  <li>Keep Count of the number of Downloads</li>
  <li>Logging the Downloads with details IP Address/Date/Time of each download</li>
</ul>
<p>Then this is the right Module for you. There is a easy way to use this module, though in alpha stage, if some contributors join we can add separate file browser for the Download Files, to enable easy uplaoding and easy linking.</p>

<h3>DEMO : <a href=\"http://localhost/samrik/index.php?id=friend-foe-faith\">http://localhost/samrik/index.php?id=friend-foe-faith</a> Click on Download ePub edition</h3>


<h3>How to use ?</h3>
<p>After <strong>Activating</strong> the plugin, it generates TWO Folder in the Site's <strong>'data\uploads'</strong> folder with the required permissions, </p>
<ol>
  <li>DATA : The Logs of Downloads, Hacking and Leech attempts are saved here</li>
  <li>xjo056 (Naam mein kya rakha hai!) : This folder contains your files to be Downloaded.</li>
</ol>
<p>Reason for chosing the UPLOAD folder is that you can access it from FILES tab in ADMIN Panel. The Plugin works on FILENAME, so you need to use the proper Filenames in your Page Code. Upload your files in <strong>'xjo056'</strong> folder</p>
<p>Plugin provides 3 Tags you can use in your Page Source :</p>
<ul>
  <li>{downloadlink_[yourfile]} - Provides the link to Download. You can post the link like this also 'plugins/downloads/download.php?[yourfile]'</li>
  <li>{filesize_[yourfile]} - Gives the File Size of the file specified.</li>
  <li>{filecount_[yourfile]} - gives the Number of Times the file was downloaded</li>
</ul>
<p>Example Usage</p>
<pre>&lt;a href=&quot;{downloadlink_[yourfile]}&quot; &gt; <a href=\"{downloadlink_[Yourfilename]}\">Download [yourfile]</a> &lt;/a&gt;&lt;br /&gt;
   &lt;b&gt;File Size: &lt;/b&gt;{filesize_[Yourfilename]} &lt;br /&gt;     
 &lt;b&gt;Download Count: &lt;/b&gt;{filecount_[Yourfilename]}</pre>
<h3>Download Logs</h3>
<ul>
  <li><a href=\"../data/uploads/data/download.dat\">Downloads</a></li>
  <li><a href=\"../data/uploads/data/hack.dat\">Hack attempts</a></li>
  <li><a href=\"../data/uploads/data/leech.dat\">Leech Attempts</a></li>
</ul>
<p><a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/2.5/in/deed.en_US\"><img alt=\"Creative Commons License\" style=\"border-width:0\" src=\"http://i.creativecommons.org/l/by-nc-sa/2.5/in/88x31.png\" /></a><br />
<span xmlns:dct=\"http://purl.org/dc/terms/\" href=\"http://purl.org/dc/dcmitype/InteractiveResource\" property=\"dct:title\" rel=\"dct:type\">Downloads Management Plugin for Get-Simple</span> by <a xmlns:cc=\"http://creativecommons.org/ns#\" href=\"http://www.computerplanetindia.com\" property=\"cc:attributionName\" rel=\"cc:attributionURL\">Prasoon Gupta</a> is licensed under a <a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/2.5/in/deed.en_US\">Creative Commons Attribution-NonCommercial-ShareAlike 2.5 India License</a>.<br />
Based on a work at <a xmlns:dct=\"http://purl.org/dc/terms/\" href=\"http://www.simonstenhouse.net/\" rel=\"dct:source\">http://www.simonstenhouse.net/</a>.</p>";
}

function download_file_size($content) {
	$found = preg_match_all('/\{filesize_(.*?)\}/', $content, $match);
		for ($i=0; $i<=$found; $i++)
		{
			$file = '';
		if (isset($match[1][$i]))
		{
                    $file = $match[1][$i];

		}
		else
		{
                    return $content;
		}

		$code = download_size($file);

		$content = preg_replace('/\{filesize_'.$file.'\}/', $code, $content);
	}

	return $content;
	}

function download_file_count($content) {
	$found = preg_match_all('/\{filecount_(.*?)\}/', $content, $match);
		for ($i=0; $i<=$found; $i++)
		{
		$file = '';
		if (isset($match[1][$i]))
		{
                    $file = $match[1][$i];

		}
		else
		{
                    return $content;
		}

		$code = download_count($file);

		$content = preg_replace('/\{filecount_'.$file.'\}/', $code, $content);
	}

	return $content;
	}

function download_link($content) {
	$found = preg_match_all('/\{downloadlink_(.*?)\}/', $content, $match);
		for ($i=0; $i<=$found; $i++)
		{
			$file = '';
		if (isset($match[1][$i]))
		{
                    $file = $match[1][$i];

		}
		else
		{
                    return $content;
		}

		$code = 'plugins/downloads/download.php?'.$file;

		$content = preg_replace('/\{downloadlink_'.$file.'\}/', $code, $content);
	}

	return $content;
	}

?>