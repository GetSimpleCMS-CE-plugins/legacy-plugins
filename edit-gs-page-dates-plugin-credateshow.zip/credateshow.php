<?php
/*
CreDateShow - plugin for GetSimple CMS (3.3+)
Makes GS special page creation date field editable

IceDaddy plugin
* (modified version of pubdatefix plugin by Carlos)

Helper functions / template tags:
 - get_page_create_date([dateformat], [echo])
 - return_page_create_date([dateformat])

A new editable Creation Date field and Publish Date field is displayed in page options.
If the date/time entered is invalid, it will be saved as the current datetime ("now").

Default date[time] editing format is 'Y-m-d H:i' (for e.g. 2015-12-31 23:59)
You can define your custom format in your site's gsconfig.php file.
Some examples:

 define('CREDATEFORMAT','Y/m/d H.i'); // ==> 2015/12/31 23.59
 define('CREDATEFORMAT','Y-m-d');     // ==> 2015-12-31
 ...
*/

define('CREDATESHOWVERSION', '1.0');

// register plugin
$thisfile = basename(__FILE__, ".php");
register_plugin(
	$thisfile,
	'creDateShow',
	CREDATESHOWVERSION,
	'IceDaddy',
	'http://www.icedaddy.net/',
	'Makes creDate and pubDate fields editable',
	'',
	''
);

add_action('changedata-save', 'credateshow_save');
if (basename($_SERVER['PHP_SELF']) == 'edit.php') {
	i18n_merge($thisfile, $LANG) || (strlen($LANG) > 2 && i18n_merge($thisfile, substr($LANG,0,2))) || i18n_merge($thisfile, 'en');
	add_action('edit-extras','credateshow_edit'); 
}

function get_page_create_date($i = "l, F jS, Y - g:i A", $echo=true) {
	if ($echo)
		echo return_page_create_date($i);
	else
		return return_page_create_date($i);
}

function return_page_create_date($i = "l, F jS, Y - g:i A") {
	global $data_index;
	global $TIMEZONE;
	if ($TIMEZONE != '') {
		if (function_exists('date_default_timezone_set')) {
		date_default_timezone_set($TIMEZONE);
		}
	}
	if (isset($data_index->creDate)) {
		return date($i, strtotime($data_index->creDate));
	} else {
		return date($i, strtotime($data_index->pubDate));
	}
}

function credateshow_save() {
	global $xml;
	// creation date
	if (isset($_POST['credateshow']) && strval(strtotime($_POST['credateshow']))!='') {
		unset($xml->creDate);
		$xml->addChild('creDate', date('r',strtotime($_POST['credateshow'])));
	}
	// publish date
	if (isset($_POST['pubdateshow']) && strval(strtotime($_POST['pubdateshow']))!='') {		
		unset($xml->pubDate);
		$xml->addChild('pubDate', date('r',strtotime($_POST['pubdateshow'])));
	}
}

function credateshow_edit() {
	global $data_edit;
	$format = credateshow_format();
	echo '<div class="leftopt"><p>';
	echo '<label for="credateshow">',i18n_r('credateshow/CREDATE'),':</label>';
	echo '<input class="text short" id="credateshow" name="credateshow" type="text" value="';
	if (isset($data_edit->creDate)) {
		echo date($format, strtotime($data_edit->creDate));
	}
	echo '" placeholder="',date($format, strtotime(date('r'))),'" />';

	echo '<label for="pubdateshow">',i18n_r('credateshow/PUBDATE'),':';
	if (isset($data_edit->pubDate)) {
		echo ' &nbsp; (Last: '.date($format, strtotime($data_edit->pubDate)).')</label>';
	}
	echo '<input class="text short" id="pubdateshow" name="pubdateshow" type="text" value="';
	echo '" placeholder="',date($format, strtotime(date('r'))),'" />';

	echo '</p></div>';
	echo '<div class="clear"></div>';

	// backend last saved:
    if (isset($data_edit->creDate)) {
		$pubDate = $data_edit->creDate;
    }
}

function credateshow_format() {
	return defined('CREDATEFORMAT') ? CREDATEFORMAT : 'Y-m-d H:i';
}

function credateshow_footer() {
	$start = 1; // week starts on Monday
	$lg = 'en'; // fallback to English
	$format = credateshow_format();
}
