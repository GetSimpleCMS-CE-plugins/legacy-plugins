<?php
$i18n = array(
  "CREDATE" => "Creation Date",
  "PUBDATE" => "Publish Date"
);
