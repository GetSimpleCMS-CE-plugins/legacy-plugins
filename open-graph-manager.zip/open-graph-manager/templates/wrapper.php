<div class="ogm">
    <?php echo $this->section('content'); ?>
</div>