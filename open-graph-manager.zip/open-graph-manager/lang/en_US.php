<?php
$i18n = array (
    "OGM_OPTIONS"                           	=>	"Options",
    "OGM_TEXT_INTRODUCTION"                     =>	"Add all social media data as needed!",
    "OGM_HEADLINE_GENERAL_CONFIGURATION"        =>  "General Options",
    "OGM_HEADLINE_FACEBOOK_CONFIGURATION"       =>  "Facebook Options",
    "OGM_HEADLINE_TWITTER_CONFIGURATION"        =>  "Twitter Options",
    "OGM_GENERAL_AUTHOR"                        =>  "Author",
    "OGM_GENERAL_PUBLISHER"                     =>  "Publisher",
    "OGM_GENERAL_IMAGE_PATH"                    =>  "Image path (no Leading slash)",
    "OGM_LABEL_FACEBOOK_PAGE_ID"                =>  "Facebook Page (e.g. facebook.com/pageName)",
    "OGM_LABEL_FACEBOOK_ADMINS"                 =>  "Facebook ID",
    "OGM_LABEL_TWITTER_SITE"                    =>  "Twitter Site (e.g. twitter.com/siteName)",
    "OGM_LABEL_TWITTER_CREATOR"                 =>  "Twitter Author (e.g. twitter.com/authorName)",
    "OGM_BUTTON_SAVE"                           =>  "Save data",
    "OGM_CONFIGURATION"                         =>  "Configuration",
    "OGM_SAVE_SUCCESS"                          =>  "Options saved!",
);