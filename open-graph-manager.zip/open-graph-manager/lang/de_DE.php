<?php
$i18n = array (
    "OGM_OPTIONS"                           	=>	"Einstellungen",
    "OGM_TEXT_INTRODUCTION"                     =>	"Fügen Sie ihre Zugangsdaten ein!",
    "OGM_HEADLINE_GENERAL_CONFIGURATION"        =>  "Allgemeine Einstellungen",
    "OGM_HEADLINE_FACEBOOK_CONFIGURATION"       =>  "Facebook Einstellungen",
    "OGM_HEADLINE_TWITTER_CONFIGURATION"        =>  "Twitter Einstellungen",
    "OGM_GENERAL_AUTHOR"                        =>  "Autor",
    "OGM_GENERAL_PUBLISHER"                     =>  "Publizist",
    "OGM_GENERAL_IMAGE_PATH"                    =>  "Bildpfad (kein führender Slash)",
    "OGM_LABEL_FACEBOOK_PAGE_ID"                =>  "Facebook Seite (z.B.: facebook.com/seitenName)",
    "OGM_LABEL_FACEBOOK_ADMINS"                 =>  "Facebook ID",
    "OGM_LABEL_TWITTER_SITE"                    =>  "Twitter Seite (z.B.: twitter.com/seitenName)",
    "OGM_LABEL_TWITTER_CREATOR"                 =>  "Twitter Author (e.g. twitter.com/autorenName)",
    "OGM_BUTTON_SAVE"                           =>  "Einstellungen speichern",
    "OGM_CONFIGURATION"                         =>  "Konfiguration",
    "OGM_SAVE_SUCCESS"                          =>  "Einstellungen wurden gespeichert!",
);