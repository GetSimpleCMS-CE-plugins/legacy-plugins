<?php
/**
 * Finnish Language File 
 *
 * Version:			GetSimple 3.1
 * Translated: October 11th 2012 by Jonne Komulainen (jonne@jontse.fi | http://jonne.jontse.fi/ )
 * @package GetSimple                                                              
 * @subpackage Language
 */
 
$i18n = array (
	"LASTTWEET_MENUTITLE"  =>  "Last tweet Asetukset",
	"LASTTWEET_TITLE"      =>  "LastTweet",
	"LASTTWEET_DESC_SHORT" =>  "The lasttweet(s) plugin",
	"LASTTWEET_DESC_LONG"  =>  "LastTweets plugin, Lisää twitter-tunnuksesi ja twiittausten määrä.",
	"TWITTER_ERROR"	       =>  "Epäkelpo twitter-tunnus, tarkista tunnuksesi, tunnuksessa vähintään kolme merkkiä?",
	"NUMTWEETS_ERROR"      =>  "Twiittien määrä vähintään yksi, enintään 9.",
	"TWITTER_ACCOUNT"      =>  "Twitter-tunnus",
	"LOCALE"               =>  "Kieli korvaaa",
	"NUM_TWEETS"           =>  "Näytettävien twiittien määrä",
	"DTM_LESS_ONE_MIN"     =>  "alle minuutti sitten.",
	"DTM_ABOUT_ONE_MIN"    =>  "noin minuutti sitten.",
	"DTM_MINUTES"          =>  "minuuttia sitten.",
	"DTM_ABOUT_ONE_HOUR"   =>  "noin tunti sitten.",
	"DTM_ABOUT"            =>  "noin",
	"DTM_HOURS_AGO"        =>  "tuntia sitten.",
	"DTM_ONE_DAY_AGO"      =>  "eilen.",
	"DTM_DAYS_AGO"         =>  "päivää sitten.",
	"MAX_CACHETIME"        =>  "Välimuistin aika (sekunneissa.  '0' = ei välimuistia)",
	"OAUTH_ACCESS_TOKEN"   =>  "OAUTH ACCESS TOKEN arvo dev.twitter.com",
	"OAUTH_ACCESS_TOKEN_SECRET" =>  "OAUTH ACCESS TOKEN SECRET arvo dev.twitter.com",
	"CONSUMER_KEY"         =>  "CONSUMER KEY arvo dev.twitter.com",
	"CONSUMER_SECRET"      =>  "CONSUMER SECRET arvo dev.twitter.com",
	"OAUTH_DESC"           =>  "Tässä plug-in, tällä hetkellä käytämme sovellus todennusta Twitter.
                               Saada se vauhtiin joudut seuraavasti kerran:",
	"OAUTH_DESC_ONE"       =>  "Luo uusi Twitter Application tässä: <a href='https://dev.twitter.com/apps/new'> dev.twitter.com </ a>, kirjaudu sisään ja seuraa ohjeita, käyttäen sopivista kenttien arvot.",
	"OAUTH_DESC_TWO"       =>  "Kun olet valmis luomaan app, löydät painikkeet, joita tarvitset välilehti "Tiedot"",
	"OAUTH_DESC_THREE"     =>  "Kopioi ja liitä avaimet kentät",
	"OAUTH_DESC_FOUR"      =>  "Tästä lähtien voit tunnistaa itsesi näillä näppäimillä joka kerta pyyntö on tehty päivitetty tweetit"

);