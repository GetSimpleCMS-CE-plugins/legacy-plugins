<?php
/**
 * Dutch Language File 
 *
 * Version:			GetSimple 3.1
 *
 * @package GetSimple                                                              
 * @subpackage Language
 */
 
$i18n = array (
	"LASTTWEET_MENUTITLE"  =>  "Configuratie laatste tweet",
	"LASTTWEET_TITLE"      =>  "Laatste Tweet",
	"LASTTWEET_DESC_SHORT" =>  "De laatste Tweet plugin",
	"LASTTWEET_DESC_LONG"  =>  "Parameters voor de laatste tweet plugin, voor nu slechts een gebruikers naam, en het aantal tweets, alsmede de maximale tijd om te cachen",
	"TWITTER_ERROR"	       =>  "Deze Twitter gebruikers naam lijkt niet valide?",
	"NUMTWEETS_ERROR"      =>  "Het aantal Tweets is gelimiteerd, tussen de 1 en 9",
	"TWITTER_ACCOUNT"      =>  "Twitter gebruikers name",
	"NUM_TWEETS"           =>  "Aantal tweets",
	"DTM_LESS_ONE_MIN"     =>  "minder als 1 min. geleden.",
	"DTM_ABOUT_ONE_MIN"    =>  "ca. 1 min. geleden.",
	"DTM_MINUTES"          =>  "minuten geleden.",
	"DTM_ABOUT_ONE_HOUR"   =>  "ca. 1 uur geleden.",
	"DTM_ABOUT"            =>  "ca.",
	"DTM_HOURS_AGO"        =>  "uren geleden.",
	"DTM_ONE_DAY_AGO"      =>  "1 dag geleden.",
	"DTM_DAYS_AGO"         =>  "dagen geleden.",
	"MAX_CACHETIME"        =>  "Maximale cache tijd (in sec. '0' = geen cache)",
	"OAUTH_ACCESS_TOKEN"   =>  "OAUTH ACCESS TOKEN, waarde van dev.twitter.com",
	"OAUTH_ACCESS_TOKEN_SECRET" =>  "OAUTH ACCESS TOKEN SECRET, waarde van dev.twitter.com",
	"CONSUMER_KEY"         =>  "CONSUMER KEY waarde van dev.twitter.com",
	"CONSUMER_SECRET"      =>  "CONSUMER SECRET waarde van dev.twitter.com",
	"OAUTH_DESC"           =>  "Op dit moment gebruikt deze plug-in de app based authentication van Twitter. 
	                            Om het het werkend te krijgen, volg de onderstaande stappen (eenmalige setup)",
	"OAUTH_DESC_ONE"       =>  "Maak hier een application aan:<a href='https://dev.twitter.com/apps/new'>dev.twitter.com</a>, log in, volg de instructies en vul het formulier in.",
	"OAUTH_DESC_TWO"       =>  "Na het aanmaken vanb de applicatie, vind je de benodigde keys op het tabblad 'Details'",
	"OAUTH_DESC_THREE"     =>  "Kopieer deze en vul ze in in de onderstaande velden.",
	"OAUTH_DESC_FOUR"      =>  "Vanaf nu gebruik je deze toegangs gegevens om de nieuwe tweets op te halen bij Twitter."
);