<?php
/**
* Italian Language File for Last Tweet Plugin 
* Version: GetSimple 3.1
* Date: 27.05.2012
* Traductors: Jacopo Dal Pozzo (http://jacopodalpozzo.altervista.org)
* @package GetSimple                                                              
* @subpackage Language
**/
 
$i18n = array (
	"LASTTWEET_MENUTITLE"  =>  "Configurazione di Last Tweet",
	"LASTTWEET_TITLE"      =>  "Last Tweet",
	"LASTTWEET_DESC_SHORT" =>  "La plugin per visualizzare l'ultimo(i) tweet",
	"LASTTWEET_DESC_LONG"  =>  "Impostazioni della plugin per gli ultimi tweets inviati, solo inserendo il nome dell'account e il numero di tweets da visualizzare.",
	"TWITTER_ERROR"	       =>  "L'account Twitter non sembra valido, o � pi� piccolo di 3 caratteri?",
	"NUMTWEETS_ERROR"      =>  "Il numero dei tweets visualizzati deve essere tra 1 e 9",
	"TWITTER_ACCOUNT"      =>  "Nome account Twitter",
	"LOCALE"               =>  "Lingua sovrascrivere",
	"NUM_TWEETS"           =>  "Numero di tweets da visualizzare",
	"DTM_LESS_ONE_MIN"     =>  "meno di un minuto fa.",
	"DTM_ABOUT_ONE_MIN"    =>  "circa un minuto fa.",
	"DTM_MINUTES"          =>  "minuti fa.",
	"DTM_ABOUT_ONE_HOUR"   =>  "circa un ora fa.",
	"DTM_ABOUT"            =>  "circa",
	"DTM_HOURS_AGO"        =>  "ora fa.",
	"DTM_ONE_DAY_AGO"      =>  "un giorno fa.",
	"DTM_DAYS_AGO"         =>  "giorni fa.",
	"MAX_CACHETIME"        =>  "Tempo massimo di cache (in sec. '0' = senza cache)",
	"OAUTH_ACCESS_TOKEN"   =>  "OAUTH ACCESS TOKEN value from dev.twitter.com",
	"OAUTH_ACCESS_TOKEN_SECRET" =>  "OAUTH ACCESS TOKEN SECRET value from dev.twitter.com",
	"CONSUMER_KEY"         =>  "CONSUMER KEY value from dev.twitter.com",
	"CONSUMER_SECRET"      =>  "CONSUMER SECRET value from dev.twitter.com",
	"OAUTH_DESC"           =>  "In this plug-in, for the moment we use app based authentication from Twitter. 
	                            To get it up and running you will have to follow these steps once:",
	"OAUTH_DESC_ONE"       =>  "Create a new Twitter Application here: <a href='https://dev.twitter.com/apps/new'>dev.twitter.com</a>, log in and follow the instructions, using apropriate values for the fields.",
	"OAUTH_DESC_TWO"       =>  "After you have finished creation of the app, you will find the keys you need on the tab 'Details'",
	"OAUTH_DESC_THREE"     =>  "Copy and paste the keys in the fields below",
	"OAUTH_DESC_FOUR"      =>  "From now on, you will identify yourself with these keys every time a request has been made for an update on the tweets"

);