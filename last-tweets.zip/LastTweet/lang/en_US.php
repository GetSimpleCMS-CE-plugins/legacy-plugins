<?php
/**
 * English Language File 
 *
 * Version:			GetSimple 3.1
 *
 * @package GetSimple                                                              
 * @subpackage Language
 */
 
$i18n = array (
	"LASTTWEET_MENUTITLE"  =>  "Last tweet config",
	"LASTTWEET_TITLE"      =>  "LastTweet",
	"LASTTWEET_DESC_SHORT" =>  "The lasttweet(s) plugin",
	"LASTTWEET_DESC_LONG"  =>  "Settings for the lasttweets plugin, just the accountname and number of tweets for now.",
	"TWITTER_ERROR"	       =>  "Twitter account seems not to be valid, at least 3 characters?",
	"NUMTWEETS_ERROR"      =>  "Number of tweets should be between 1 and 9",
	"TWITTER_ACCOUNT"      =>  "Twitter Account name",
	"NUM_TWEETS"           =>  "Number of tweets to show",
	"DTM_LESS_ONE_MIN"     =>  "less than a minute ago.",
	"DTM_ABOUT_ONE_MIN"    =>  "about a minute ago.",
	"DTM_MINUTES"          =>  "minutes ago.",
	"DTM_ABOUT_ONE_HOUR"   =>  "about an hour ago.",
	"DTM_ABOUT"            =>  "about",
	"DTM_HOURS_AGO"        =>  "hours ago.",
	"DTM_ONE_DAY_AGO"      =>  "one day ago.",
	"DTM_DAYS_AGO"         =>  "days ago.",
	"MAX_CACHETIME"        =>  "Maximum time to cache (in sec.  '0' = no cache)",
	"OAUTH_ACCESS_TOKEN"   =>  "OAUTH ACCESS TOKEN value from dev.twitter.com",
	"OAUTH_ACCESS_TOKEN_SECRET" =>  "OAUTH ACCESS TOKEN SECRET value from dev.twitter.com",
	"CONSUMER_KEY"         =>  "CONSUMER KEY value from dev.twitter.com",
	"CONSUMER_SECRET"      =>  "CONSUMER SECRET value from dev.twitter.com",
	"OAUTH_DESC"           =>  "In this plug-in, for the moment we use app based authentication from Twitter. 
	                            To get it up and running you will have to follow these steps once:",
	"OAUTH_DESC_ONE"       =>  "Create a new Twitter Application here: <a href='https://dev.twitter.com/apps/new'>dev.twitter.com</a>, log in and follow the instructions, using apropriate values for the fields.",
	"OAUTH_DESC_TWO"       =>  "After you have finished creation of the app, you will find the keys you need on the tab 'Details'.",
	"OAUTH_DESC_THREE"     =>  "Copy and paste the keys in the fields below.",
	"OAUTH_DESC_FOUR"      =>  "From now on, you will identify yourself with these keys every time a request has been made for an update on the tweets."
);