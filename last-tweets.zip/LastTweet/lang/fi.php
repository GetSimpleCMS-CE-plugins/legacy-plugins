<?php
/**
 * Finnish Language File 
 *
 * Version:			GetSimple 3.1
 * Translated: October 11th 2012 by Jonne Komulainen (jonne@jontse.fi | http://jonne.jontse.fi/ )
 * @package GetSimple                                                              
 * @subpackage Language
 */
 
$i18n = array (
	"LASTTWEET_MENUTITLE"  =>  "Last tweet Asetukset",
	"LASTTWEET_TITLE"      =>  "LastTweet",
	"LASTTWEET_DESC_SHORT" =>  "The lasttweet(s) plugin",
	"LASTTWEET_DESC_LONG"  =>  "LastTweets plugin, Lisää twitter-tunnuksesi ja twiittausten määrä.",
	"TWITTER_ERROR"	       =>  "Epäkelpo twitter-tunnus, tarkista tunnuksesi, tunnuksessa vähintään kolme merkkiä?",
	"NUMTWEETS_ERROR"      =>  "Twiittien määrä vähintään yksi, enintään 9.",
	"TWITTER_ACCOUNT"      =>  "Twitter-tunnus",
	"LOCALE"               =>  "Kieli korvaaa",
	"NUM_TWEETS"           =>  "Näytettävien twiittien määrä",
	"DTM_LESS_ONE_MIN"     =>  "alle minuutti sitten.",
	"DTM_ABOUT_ONE_MIN"    =>  "noin minuutti sitten.",
	"DTM_MINUTES"          =>  "minuuttia sitten.",
	"DTM_ABOUT_ONE_HOUR"   =>  "noin tunti sitten.",
	"DTM_ABOUT"            =>  "noin",
	"DTM_HOURS_AGO"        =>  "tuntia sitten.",
	"DTM_ONE_DAY_AGO"      =>  "eilen.",
	"DTM_DAYS_AGO"         =>  "päivää sitten.",
	"MAX_CACHETIME"        =>  "Välimuistin aika (sekunneissa.  '0' = ei välimuistia)"
);