<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}
/**
 * Function file used by the GetSimple Last Tweet Plugin.
 */
 
 # twitter API lib, thanks to: James Mallison <me@j7mbo.co.uk>, http://github.com/j7mbo/twitter-api-php
 require_once('TwitterAPIExchange.php');
 
 # main function to call the last tweets
function show_tweets($overwrite_cache) {
  $tweets = get_tweet_data($overwrite_cache);
  echo format_tweets($tweets);
}
# parse raw json into a nice array
function parse_json_data($json_data) {
  $l_tweets = array();
  foreach ($json_data as $tweet) {
    $bool_media = false;
    $media_container = '';
    $datetime = niceTime(strtotime(str_replace("+0000", "", $tweet->created_at)));
    $tweet_text = $tweet->text;
    // check if any entites exist and if so, replace them with hyperlinkes
    if (!empty($tweet->entities->urls) || !empty($tweet->entities->hashtags) || !empty($tweet->entities->user_mentions)
        || !empty($tweet->entities->media)) {
      foreach ($tweet->entities->urls as $url) {
        $find = $url->url;
        $replace = '<a href="'.$find.'" target="_new">'.get_long_url($find).'</a>';
        $tweet_text = str_replace($find,$replace,$tweet_text);
      }
      foreach ($tweet->entities->hashtags as $hashtag) {
        $find = '#'.$hashtag->text;
        $replace = '<a href="http://twitter.com/#!/search/%23'.$hashtag->text.'" target="_new">'.$find.'</a>';
        $tweet_text = str_replace($find,$replace,$tweet_text);
      }
      foreach ($tweet->entities->user_mentions as $user_mention) {
        $find = "@".$user_mention->screen_name;
        $replace = '<a href="http://twitter.com/'.$user_mention->screen_name.'" target="_new">'.$find.'</a>';
        $tweet_text = str_ireplace($find,$replace,$tweet_text);
      }
      if (!empty($tweet->entities->media)) {
        $bool_media = true;
        foreach ($tweet->entities->media as $media_data) {
          $find = $media_data->url; 
          $replace = '<a href="'.$media_data->media_url.'" target="_new">'.$media_data->display_url.'</a>';   
          $tweet_text = str_replace($find,$replace,$tweet_text);      
          $media_container = '
            <div>
              <a class="accordion-toggle" data-toggle="collapse" href="#'.$media_data->id_str.'">view photo</a>
            </div>
            <div id="'.$media_data->id_str.'" class="accordion-body collapse">
              <div class="accordion-inner">
                <a href="'.$media_data->media_url.'" target="_new"><img src="'.$media_data->media_url.'" /></a>
              </div>
            </div>';
        }
      }
    }
    $l_tweets[] = array('text'=>$tweet_text, 'datetime'=>$datetime, 'media_to_show'=>$bool_media, 'media_container'=>$media_container);
  }
  return $l_tweets;
}
function format_tweets($tweets) {
  foreach($tweets as $t) {
    echo '
          <div class="lasttweet">
           '. $t['text'] .'
            <div class="datetime">
             <span>'. $t['datetime'] .'</span>
            </div>
         ';
    if ($t['media_to_show']) {
      echo $t['media_container'];
    }
    echo  '</div>
    ';  
  } 
}
function get_tweet_data($overwrite_cache) {
  $config = get_config_data();
  $tweets = array();
  # check the datetime stamp of the cached file
  if ($overwrite_cache <> 1 AND checkCachedFile($config['cachetime'])) {
    echo '<!-- tweet information from cache -->';
    $rawdata = file_get_contents(LT_CACHEFILE);
    $tweets = unserialize($rawdata);
  } else {
    echo '<!-- tweet information from twitter, non-cached -->';
    $settings = array(
      'oauth_access_token' => $config['oauth_access_token'],
      'oauth_access_token_secret' => $config['oauth_access_token_secret'],
      'consumer_key' => $config['consumer_key'],
      'consumer_secret' => $config['consumer_secret']
    );
    # define the api url
	$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
    $getfield = '?username='.$config["account"].'&count='.$config["numtweets"];
    $requestMethod = 'GET';
    $twitter = new TwitterAPIExchange($settings);
    $data = $twitter->setGetfield($getfield)
            ->buildOauth($url, $requestMethod)
            ->performRequest();
    $json = json_decode($data);
    # get tweet array
    $tweets = parse_json_data($json);
    # write back to cache
    write_tweets_to_cache($tweets);
  }
  echo '<!-- returning: ' . count($tweets) . ' tweets in an array-->';
  return $tweets;
} 
 
# write back the new tweet data into cache, catch some possible errors
function write_tweets_to_cache($tweets) {
  # check LT_CACHEDIR directory existence
  if (!file_exists(LT_CACHEDIR)) {
    echo '<p style="color:#cc0000;"><b>'. 'directory does not exist, trying to create' .'</b></p>';
    if (!mkdir(LT_CACHEDIR)) {
      echo '<p style="color:#cc0000;"><b>'. 'unable to create cache directory' .'</b></p>';
    } else {
      echo '<p style="color:#669933;"><b>'. 'created ' . LT_CACHEDIR .'</b></p>';
    }
  }
  # write
  if (!file_put_contents(LT_CACHEFILE, serialize($tweets))) {
    echo '<p style="color:#cc0000;"><b>'. i18n_r('CHMOD_ERROR') .'</b></p>';
  }
}
 
# get file, if exists, get data
function get_config_data() {
  if (file_exists(LT_DATA)) {
	  $data = @getXML(LT_DATA);
	  $accountname = $data->accountname;
	  $num_tweets = $data->numtweets;
	  $max_cachetime = $data->max_cachetime;
	  $oauth_access_token = $data->oauth_access_token;
	  $oauth_access_token_secret = $data->oauth_access_token_secret;
	  $consumer_key = $data->consumer_key;
	  $consumer_secret = $data->consumer_secret;
  } else {
	  $accountname = '';
	  $num_tweets = '1';
	  $max_cachetime = '60';
	  $oauth_access_token = '';
	  $oauth_access_token_secret = '';
	  $consumer_key = '';
	  $consumer_secret = '';
  }
  return array('account'=>$accountname, 'numtweets'=>$num_tweets, 'cachetime'=>$max_cachetime,
    'oauth_access_token'=>$oauth_access_token, 'oauth_access_token_secret'=>$oauth_access_token_secret, 'consumer_key'=>$consumer_key, 
	'consumer_secret'=>$consumer_secret);
}
 
# save config data
function lt_save_cfg() {
  $account = safe_slash_html($_POST['accountname']);
  # check twitter account
  $numTweets = isset($_POST['num_tweets']) ? intval($_POST['num_tweets']) : 1;
  $caching = isset($_POST['max_cachetime']) ? intval($_POST['max_cachetime']) : 60;
  $oauth_access_token = isset($_POST['oauth_access_token']) ? safe_slash_html($_POST['oauth_access_token']) : '';
  $oauth_access_token_secret = isset($_POST['oauth_access_token_secret']) ? safe_slash_html($_POST['oauth_access_token_secret']): '';
  $consumer_key = isset($_POST['consumer_key']) ? safe_slash_html($_POST['consumer_key']): '';
  $consumer_secret = isset($_POST['consumer_secret']) ? safe_slash_html($_POST['consumer_secret']): '';
  
	$xml = @new SimpleXMLElement('<item></item>');
	$xml->addChild('accountname', $account);
	$xml->addChild('numtweets', $numTweets);
	$xml->addChild('max_cachetime', $caching);
	$xml->addChild('oauth_access_token', $oauth_access_token);
	$xml->addChild('oauth_access_token_secret', $oauth_access_token_secret);
	$xml->addChild('consumer_key', $consumer_key);
	$xml->addChild('consumer_secret', $consumer_secret);
	if (! $xml->asXML(LT_DATA)) {
		echo '<p style="color:#cc0000;"><b>'. i18n_r('CHMOD_ERROR') .'</b></p>';
	} else {
		echo '<p style="color:#669933;"><b>'. i18n_r('SETTINGS_UPDATED') .'</b></p>';
	}
}
 
 
# return 1 if the cached file is still within $maxTime, else return 0
function checkCachedFile($maxTime) {
  # check if file $tweet_cache exist
  if (file_exists(LT_CACHEFILE)) {
    $diff =  time() - filemtime(LT_CACHEFILE);
    echo '<!-- age: ' . $diff . '-->';
    if ($diff < $maxTime) {
      echo '<!-- cached file is still valid. -->';
      return 1;
    }
    return 0;
  } else {
    return 0;
  }
}
# call to get a nice date time string
function niceTime($time) {
  $delta = time() - $time;
  if ($delta < 60) {
    return i18n_r('LastTweet/DTM_LESS_ONE_MIN');
  } else if ($delta < 120) {
    return i18n_r('LastTweet/DTM_ABOUT_ONE_MIN');
  } else if ($delta < (45 * 60)) {
    return floor($delta / 60).' '.i18n_r('LastTweet/DTM_MINUTES');
  } else if ($delta < (90 * 60)) {
    return i18n_r('LastTweet/DTM_ABOUT_ONE_HOUR');
  } else if ($delta < (24 * 60 * 60)) {
    return i18n_r('LastTweet/DTM_ABOUT').' '. floor($delta / 3600).' '.i18n_r('LastTweet/DTM_HOURS_AGO');
  } else if ($delta < (48 * 60 * 60)) {
    return i18n_r('LastTweet/DTM_ONE_DAY_AGO');
  } else {
    return floor($delta / 86400) . ' ' . i18n_r('LastTweet/DTM_DAYS_AGO');
  }
}
# uses www.longurlplease.com to expand a short url, returns input if no data
function get_long_url($short_url) {
  if(!function_exists('curl_init')) {
    echo 'function curl_init does not exist, returning short url';
    return $short_url;
  }
  $ch = curl_init("http://www.longurlplease.com/api/v1.1?q=".$short_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
  $curlresult = curl_exec($ch);
  curl_close($ch);
  $data = json_decode($curlresult, true);
  if (strlen($data[$short_url]) > 0) {
    $long_url = $data[$short_url];
  } else {
    $long_url = $short_url;
  }
  # strip http or https from the beginning, ala twitter themself
  if (substr($long_url, 0, 7) == "http://") {
    $long_url = substr($long_url, 7);
  } else if (substr($long_url, 0, 8) == "https://") {
    $long_url = substr($long_url, 8);
  }
  if (substr($long_url, 0, 4) == "www.") {
    $long_url = substr($long_url, 4);
  }
  # shorten it a bit more if necessary
  return substr($long_url, 0, 27);
}
?>