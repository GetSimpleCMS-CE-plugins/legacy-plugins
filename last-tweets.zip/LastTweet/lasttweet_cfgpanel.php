<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

/**
 * Configuration panel used by the GetSimple Last Tweet Plugin.
 */
 
 function tl_cfg_panel() {
  $config = get_config_data();
  ?>
  
  <h3><?php i18n('LastTweet/LASTTWEET_TITLE'); ?></h3>
	<p><?php i18n('LastTweet/LASTTWEET_DESC_LONG'); ?></p>
  
  <form method="post" action="<?php	echo $_SERVER ['REQUEST_URI']?>">
	<p><label for="twitter" ><?php i18n('LastTweet/TWITTER_ACCOUNT'); ?></label>
  <input id="twitter" name="accountname" class="text" style="width: 100px;" value="<?php echo $config['account']; ?>" type="text" /></p>
  <p><label for="num_tweets" ><?php i18n('LastTweet/NUM_TWEETS'); ?></label>
  <input id="num_tweets" name="num_tweets" class="text" style="width: 100px;" value="<?php echo $config['numtweets']; ?>" type="text" /></p>
  <p><label for="max_cachetime" ><?php i18n('LastTweet/MAX_CACHETIME'); ?></label>
  <input id="max_cachetime" name="max_cachetime" class="text" style="width: 100px;" value="<?php echo $config['cachetime']; ?>" type="text" /></p>
    <p><?php i18n('LastTweet/OAUTH_DESC'); ?></p>
	<ul>
	  <li><?php i18n('LastTweet/OAUTH_DESC_ONE'); ?></li>
	  <li><?php i18n('LastTweet/OAUTH_DESC_TWO'); ?></li>
	  <li><?php i18n('LastTweet/OAUTH_DESC_THREE'); ?></li>
	  <li><?php i18n('LastTweet/OAUTH_DESC_FOUR'); ?></li>
	</ul>
  <p><label for="oauth_access_token" ><?php i18n('LastTweet/OAUTH_ACCESS_TOKEN'); ?></label>
  <input id="oauth_access_token" name="oauth_access_token" class="text" style="width: 500px;" value="<?php echo $config['oauth_access_token']; ?>" type="text" /></p>
 <p><label for="oauth_access_token_secret" ><?php i18n('LastTweet/OAUTH_ACCESS_TOKEN_SECRET'); ?></label>
  <input id="oauth_access_token_secret" name="oauth_access_token_secret" class="text" style="width: 500px;" value="<?php echo $config['oauth_access_token_secret']; ?>" type="text" /></p>
 <p><label for="consumer_key" ><?php i18n('LastTweet/CONSUMER_KEY'); ?></label>
  <input id="consumer_key" name="consumer_key" class="text" style="width: 500px;" value="<?php echo $config['consumer_key']; ?>" type="text" /></p>
 <p><label for="consumer_secret" ><?php i18n('LastTweet/CONSUMER_SECRET'); ?></label>
  <input id="consumer_secret" name="consumer_secret" class="text" style="width: 500px;" value="<?php echo $config['consumer_secret']; ?>" type="text" /></p>

	<p><input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="save" /></p>
    <p>  
		 <h3>sample output:</h3>
		 <?php show_tweets(true); ?>
		</p>
	</form>
  
  <?php
  }



?>
