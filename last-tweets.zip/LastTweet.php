<?php
/*
  Plugin Name: Last Tweet
  Description: Echos the last published tweet(s) from twitter
  Version: 1.2
  Author: Frank Prins
  Author URI: http://www.frankprins.nl
*/

# get the correct id for this plugin
$this_ltfile=basename(__FILE__, ".php");
# add the plugin's language file
i18n_merge('LastTweet') || i18n_merge('LastTweet', 'en_US');


# register plugin into GetSimple
register_plugin(
	$this_ltfile, 
	i18n_r('LastTweet/LASTTWEET_TITLE'), 	
	'1.2', 		
	'Frank Prins',
	'http://www.frankprins.nl/', 
	i18n_r('LastTweet/LASTTWEET_DESC_SHORT'),
	'plugins',
	'tweet_main'  
);

# register the css, and queue it for use
register_style('lasttweet', $SITEURL.'plugins/'.$this_ltfile.'/lasttweet.css', GSVERSION, 'screen');
queue_style('lasttweet',GSBOTH);
# register some twitter bootstrap js
queue_script('jquery',GSFRONT);
register_script('lasttweetjs', $SITEURL.'plugins/'.$this_ltfile.'/js/bootstrap-collapse.js', '2.0.4', FALSE);
queue_script('lasttweetjs',GSFRONT);

# admin hooks 
add_action('plugins-sidebar','createSideMenu',array($this_ltfile, i18n_r('LastTweet/LASTTWEET_MENUTITLE')));

# definitions
define('LT_INCLUDE', GSPLUGINPATH . 'LastTweet/');
define('LT_DATA', GSDATAOTHERPATH . 'lasttweets/LastTweetSettings.xml');
define('LT_CACHEDIR', GSDATAOTHERPATH . 'lasttweets/');
define('LT_CACHEFILE', LT_CACHEDIR . 'LastTweetCache');
# includes
require_once(LT_INCLUDE . 'lasttweet_functions.php');
require_once(LT_INCLUDE . 'lasttweet_cfgpanel.php');

# get config file path
$tweetcfg_file=GSDATAOTHERPATH .'lasttweets/LastTweetSettings.xml';
$tweet_cache=GSDATAOTHERPATH .'lasttweets/LastTweetCache';

# main function
function tweet_main() {
  if (isset($_POST['save'])) {
    lt_save_cfg();
    tl_cfg_panel();
  } else {
    tl_cfg_panel();
  }
}
	
?>