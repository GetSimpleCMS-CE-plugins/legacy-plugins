<!DOCTYPE HTML>
<html>
   <head>
      <title>Reveal e-mail</title>
      <style>
        html,body{
            height:100%;
            width:100%;
            margin:0;
        }
        body{
            display:flex;
        }
        .centered{
            margin:auto;
        }
   </style>
      <script src='https://www.google.com/recaptcha/api.js' async defer></script>
     <script>
function onSubmit(token) {
   document.getElementById("captcha-form").submit();
}
      </script>


   </head>
   <body>


<?php
require_once("recaptcha_library.php");
require_once('keys');

if (checkpost() && checkhuman($_recaptcha_mailhide_private_key)) {
    $mail=showmail($_recaptcha_mailhide_private_key,$_GET['mail']);
    print("<div class=\"centered\"><pre>".$mail."</pre></div>");
    
} else {
    ?>

     <form id='captcha-form' class="centered" action="" method="POST">
           <button class="g-recaptcha" data-sitekey="<?php echo $_recaptcha_mailhide_public_key; ?>" data-callback='onSubmit'>Reveal e-mail</button>
         </form>  
<?php
         }
?>
   </body>
</html>
