This plugin scan the content page (not header and footer) for email addresses like mailto links or simple mails and hides them by crypting and transforming in an url opening the recaptcha_check.php page.
The recapctcha_check.php page check if visitor is human or bot and, if human, decrypt and show the mail.

BE CAREFUL: recaptcha_check.php MUST be directly available to browser, for this reason this plugin has an .htaccess file allowing access to recaptcha_check.php only. Be sure your webserver can access recaptcha_check.php .

IT DOESN'T SAVE THE PAGE WITH HIDED MAILS, this is to help editor users inserting simple mail links.



INSTRUCTIONS
************
Unzip, set the keys file and activate

Set the keys file
#################
Ask Google recaptcha service for keys:
Go to https://www.google.com/recaptcha/admin#list , login and choose invisible recaptcha

you must set the public and private keys in recaptcha_mailhide/keys file containing the keys given from google:
<?php
$_recaptcha_mailhide_public_key="";
$_recaptcha_mailhide_private_key="";
?>



