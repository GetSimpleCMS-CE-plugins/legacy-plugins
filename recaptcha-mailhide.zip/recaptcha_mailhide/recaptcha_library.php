<?php

function checkpost()
{
    if ($_SERVER["REQUEST_METHOD"] == "POST")
         return true;
}

/**
 * Contact Google servers to check captcha
 * 
 * @param string $privkey
 * @return bool true or false
 */
function checkhuman($privkey){
    $preurl = 'https://www.google.com/recaptcha/api/siteverify?secret=';
    $posturl = '&response=' . $_POST['g-recaptcha-response'] . '&remoteip=' . $_SERVER['REMOTE_ADDR'];
    $response = file_get_contents($preurl . $privkey . $posturl);
    $responseDecoded = json_decode($response); 
    if ($responseDecoded->success == true)
        return true;
    else
        return false;
}


/**
 * Crypto functions
 */
/**
 * Crypt payload with key
 * 
 * @param string $payload
 * @param string $key
 * @return string crypted payload
 */
function encrypt($key, $payload)
{
    $iv = mcrypt_create_iv(IV_SIZE, MCRYPT_DEV_URANDOM);
    $crypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $payload, MCRYPT_MODE_CBC, $iv);
    $combo = $iv . $crypt;
    $combo=bin2hex($combo);
    $garble = base64_encode($combo);
    return $garble;
}

/**
 * Decrypt garble with given key
 * 
 * @param string $key
 * @param string $garble
 * @return string decripted payload
 */
function decrypt($key, $garble)
{
    $combo = base64_decode($garble);
    $combo=hex2bin($combo);
    $iv = substr($combo, 0, IV_SIZE);
    $crypt = substr($combo, IV_SIZE, strlen($combo)-IV_SIZE);
    $payload = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $crypt, MCRYPT_MODE_CBC, $iv);
    return $payload;
}

/**
 * adjust key size that should be 16Byte for aes 128
 * 
 *  @param string $key
 *  @return string 16 bytes key
 */
function adjustkeysize($key){
    if (strlen($key != 16)) {
        if (strlen($key)) {
            $ky = substr($key, 0, 16);
        } else {
            $ky = str_pad($key, 16, "\0");
        }
    }
    return $ky;
}

/**
 * Create url with encrypted email
 * 
 * @param string $privkey key to use
 * @param string $email email to encrypt and encode
 * @return string url with encrypted email
 */
function recaptcha_mailhide_url($privkey, $email)
{
    if ( !defined('IV_SIZE')){define('IV_SIZE', mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));}
    $privkey=adjustkeysize($privkey);
    $encmail = encrypt($privkey, $email);
    $urlencmail="/plugins/recaptcha_mailhide/recaptcha_check.php?mail=".urlencode($encmail);
    
    return $urlencmail;
    
}

/**
 * Decrypt and sohw encrypted mail
 * 
 * @param string $privkey - key tu use
 * @param string $encmail - crypted mail
 * @return string - clear text mail
 */
function showmail($privkey, $encmail){
    if ( !defined('IV_SIZE')){define('IV_SIZE', mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));}
    $privkey=adjustkeysize($privkey);
    $encmail = urldecode($encmail);
    $decmail = decrypt($privkey, $encmail);
    $unpademail=preg_replace('/\0/','',$decmail);
    
    return $unpademail;
    
}


/**
 * Main recaptcha mailhide plugin function, it change mails and mailto links in links with crypted args 
 * 
 * @param string $content - full content of the page
 * @return string
 */
function recaptcha_mailhide($content){
    $content=mailto_strip($content);
    
    $mailPattern="/[\._a-zA-Z0-9\!\#\&\$\%\'\*\+\/\=\?\^_\`\{\|\}\(\)\~-]+@[\._a-zA-Z0-9-]+/i";
    preg_match_all($mailPattern, $content, $matches);
    foreach ($matches[0] as $mail) {
        $email = _recaptcha_replace($mail); 
        $content = str_replace($mail, $email, $content);
    }
    
    return $content;
}

/**
 * Catch all mailto links, crypt, encode in url and return content
 * 
 * @param string $content
 * @return string
 */
function mailto_strip($content){
    $mailtopattern="/<a href\=\"mailto:.*?<\/a>/";
    $mailPattern="/(?<=\<a href=\"mailto:)(.*)(?=\">)/";
    $mailOnlyPattern="/mailto:([^\?]*)/";
    $textpattern="/(?<=\>)(.*)(?=\<\/a\>)/";
    
    preg_match_all($mailtopattern, $content, $matches);
    
    foreach ($matches[0] as $mailto){
        preg_match($mailPattern, $mailto, $mail); /*get mail with params */
        preg_match($textpattern, $mailto, $text);
        $mail=$mail[0];
        $mailonly=$mail;
        $text=$text[0];
        if (preg_match('/\?/',$mail)){
            preg_match($mailOnlyPattern, $mailto, $mailonly); /* mail without params */
            $mailonly=$mailonly[1];
        }
        $text=str_replace($mailonly, "[ Reveal this email ]", $text); /* if mail == text or mail included in text => replace, else text=text */
        $email = _recaptcha_replace($mail, $text );
        $content=str_replace($mailto,$email,$content);
    }
    return $content;
}

/**
 * Build the url to click to reveal e-mail
 * 
 * @param string $privkey
 * @param string $email
 * @param string $text
 * @return string url
 */
function recaptcha_mailhide_html_customLink($privkey, $email, $text=""){
    $url = recaptcha_mailhide_url($privkey, $email);
    
    if (empty($text)){
        if ( preg_match('/\?/',$email)){
            $mailOnlyPattern="/(.*)(?=\?)/"; /*email without params */
            preg_match($mailOnlyPattern,$email,$emailOnly);
            $email=$emailOnly[1];
        }
        return  "<a href='" . $url ."' onclick=\"window.open('" . $url ."', '', 'toolbar=0,         scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=200'); return false;\" title=\"Reveal this e-mail  address\">[ Reveal this e-mail ]</a>";
    }else{
        return  "<a href='" . $url ."' onclick=\"window.open('" . $url ."', '', 'toolbar=0,         scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=200'); return false;\" title=\"Reveal this e-mail  address\">".$text."</a>"; 
    }
}


/**
 * Check if email could be encrypted
 * 
 * @param string $match - email to crypt
 * @param string $text
 * @return string url
 */
function _recaptcha_replace($match, $text=""){
    global  $_recaptcha_mailhide_private_key;
    
    $match=str_replace("&amp;","&",$match); /* due to getsimple htmltoentities conversion */
    
    if ( empty($_recaptcha_mailhide_private_key) ||
        !function_exists('mcrypt_encrypt')) {
            
            if (!function_exists('mcrypt_encrypt')){
                error_log('Address cannot be hidden because Mcrypt is not installed.');
            }else{
                error_log("Address cannot be hidden because the reCAPTCHA Mailhide keys are missing.");
            }
            
            $email = "<span id=\"mailhideerror\" style=\"color:#ff0000;\">email cannot be shown due to an error, please contact the site administrator, email in the footer.</span>";
            
        } else {
            $email=recaptcha_mailhide_html_customLink($_recaptcha_mailhide_private_key,$match,$text );
        }
        return $email; /* only for mailto_strip */
}






?>