<?php
/*
Plugin Name: Invisible Recaptcha Mailhide
Description: Replace all email addresses with invisible recaptchas 
Version: 2.0.0
Author: Matteo Brutti
Author URI: http://google.com 
Author email: backit.webdev@gmail.com 
Thanks to: drupal mailhide module https://www.drupal.org/project/recaptcha 
*/


# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
   $thisfile, 
   'Invisible Recaptcha Mailhide',
   '2.0.0',
   'Backit',
   '',
   'Finds email addresses in content and hides them using invisible recaptcha, instructions in the readme file',
   'recaptcha_mailhide'
);




/*
 * MAIN
 */
$key_file='plugins/recaptcha_mailhide/keys';
$recaptchalib='plugins/recaptcha_mailhide/recaptcha_library.php';

if ( is_readable($recaptchalib)){ 
   if ( !is_readable($key_file)) $_recaptcha_mailhide_public_key = $_recaptcha_mailhide_private_key = "";
   else require_once $key_file;
   
   require_once $recaptchalib;
   /* pass $content variable to recaptcha_mailhide function, it must return something (content) */
   add_filter('content','recaptcha_mailhide'); 
}



?>
