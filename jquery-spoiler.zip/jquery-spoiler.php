<?php
$thisfile=basename(__FILE__, ".php");


register_plugin(
	$thisfile, 
	'JQuery Spoiler Plugin', 	
	'1.0', 		
	'Nonix',
	'http://nonix.ru/', 
	'Just type: [spoiler] [title] spoiler title [/title] spoiler content [/spoiler] in "content" area and You will see nice JQuery spoiler. JQ must be loaded at "head" of page.',
	'theme',
	''  
);

$c = 0;

add_filter('content','replaceSpoilers'); 
add_action('theme-footer','js'); 

function replaceSpoilers($content) {
	
	$line = preg_replace_callback(
        '/\[spoiler\].*?\[title\](.*?)\[\/title\](.*?)\[\/spoiler\]/s',
        function ($m) {		
		global $c;
		$c++;
            return '<a class="jquery-spoiler-title" id="jquery-spoiler-title-'.$c.'" href="#">'.$m[1].'</a><div id="jquery-spoiler-body-'.$c.'" class="jquery-spoiler-body">'.$m[2].'</div>';//($m[0]);
        },
        $content
    );
	
	print $line;
}


function js() {
	print '
	<script>
	$(document).ready( function (){
		$(".jquery-spoiler-body").css({"display":"none"});
		$(".jquery-spoiler-title").css({"display":"block"});		
		$(".jquery-spoiler-title").click( function () {
			$("#"+ "jquery-spoiler-body-" + this.id.split("-")[3]).slideToggle("slow");
		return false;
		});
	});
	</script>
	';
}

?>