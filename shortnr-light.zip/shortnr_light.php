<?php
/*
Plugin Name: Shortnr Light
Description: Run your own URL shortener, because everything you do not host yourself will never truly be yours.
Version: 1
Author: Martijn van der Ven
Author URI: http://zegnat.net/
*/

# Plugin setup.
$thisfile = basename(__FILE__, '.php');
register_plugin(
	$thisfile,
	'Shortnr Light',
	'1',
	'Martijn van der Ven',
	'http://zegnat.net/',
	'Run your own URL shortener, because everything you do not host yourself will never truly be yours.',
	'plugins',
	'shortnr_light'
);
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Shortnr'));
if (basename($_SERVER['PHP_SELF']) == 'index.php' && isset($base) && $base === TRUE) {
	if (preg_match('/\/_\/([0-9A-HJ-NP-Z_a-km-z]+)\/?$/', $_SERVER['REQUEST_URI'], $matches)) {
		if (file_exists(GSDATAOTHERPATH.'shortnr_light.xml')) {
			$readFrom = getXML(GSDATAOTHERPATH.'shortnr_light.xml');
			$sendTo = $readFrom->xpath('//short[.=\''.$matches[1].'\']/..');
			if (count($sendTo) == 1) {
				$sendTo[0]->clicks++;
				$readFrom->asXML(GSDATAOTHERPATH.'shortnr_light.xml');
				redirect((string)$sendTo[0]->long);
			}
		}
	}
} else if (basename($_SERVER['PHP_SELF']) == 'load.php') {
	if ($_GET['id'] == 'shortnr_light') {
		register_style('shortnr_light_css', $SITEURL.$GSADMIN.'/load.php?id=shortnr_light_css', 1, 'screen');
		queue_style('shortnr_light_css', GSBACK);
		if (isset($_GET['delete']) && strlen(trim($_GET['delete'])) > 0 && preg_match('/[0-9A-HJ-NP-Z_a-km-z]/', trim($_GET['delete']))) {
			$toDelete = trim($_GET['delete']);
			if (file_exists(GSDATAOTHERPATH.'shortnr_light.xml')) {
				$deleteFrom = getXML(GSDATAOTHERPATH.'shortnr_light.xml');
				$deleteThis = $deleteFrom->xpath('//short[.=\''.$toDelete.'\']/..');
				if ($deleteThis) {
					unset($deleteThis[0][0]);
					if (!$deleteFrom->asXML(GSDATAOTHERPATH.'shortnr_light.xml')) {
						$error = i18n_r('CHMOD_ERROR');
					} else {
						$success = '<b>/_/'.$toDelete.'</b> has been removed.';
					}
				} else {
					$error = 'No such link was found.';
				}
			} else {
				$error = 'No such link was found.';
			}
		}
		if (isset($_POST['shortnr_url']) && strlen(trim($_POST['shortnr_url'])) > 0) {
			$url = $_POST['shortnr_url'];
			if (!preg_match('/^[a-z0-1]+:/i', $url)) $url = 'http://'.$url;
			if (file_exists(GSDATAOTHERPATH.'shortnr_light.xml')) {
				$urlTo = getXML(GSDATAOTHERPATH.'shortnr_light.xml');
			} else {
				$urlTo = @new SimpleXMLElement('<shortnr></shortnr>');
				$urlToChild = $urlTo->addChild('config');
				$urlToChild->addChild('count',-1);
				$urlTo->addChild('urls');
			}
			$urlTo->config->count++;
			$urlToChild = $urlTo->urls;
			$urlToChild = $urlToChild->addChild('url');
			$urlToChild->addChild('short', NewBase60($urlTo->config->count));
			$urlToChild->addChild('long', $url);
			$urlToChild->addChild('clicks', 0);
			if (!$urlTo->asXML(GSDATAOTHERPATH.'shortnr_light.xml')) {
				$error = i18n_r('CHMOD_ERROR');
			} else {
				$success = 'Shortnd a URL.';
			}
#			echo '<pre>',var_dump($urlTo),'</pre>';
		}
	} else if ($_GET['id'] == 'shortnr_light_css?v=1') {
		header("Content-Type: text/css; charset=utf-8"); ?>
#maincontent .main{-moz-box-shadow:none;-webkit-box-shadow:none;background:none;border:none;box-shadow:none;margin:0;padding:0}#shortnr,#shortnr-main{-moz-box-shadow:rgba(0,0,0,0.06) 0 0 4px;-webkit-box-shadow:rgba(0,0,0,0.06) 0 0 4px;background:#FFF;border:1px solid #C8C8C8;box-shadow:rgba(0,0,0,0.06) 0 0 4px;margin:0 0 30px;padding:20px}
#shortnr #shortnr_url{width:80%}#shortnr #shortnr_go{width:15%;background:#B3C262;float:right}
<?php
		die();
	}
}
function NewBase60($in) {
	// See: http://tantek.pbworks.com/w/page/19402946/NewBase60
	if (!is_int($in)) $in = intval($in);
	$out = '';
	$modifier = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ_abcdefghijkmnopqrstuvwxyz';
	$base = strlen($modifier);
	if ($in == 0) { return $modifier[0]; }
	while ($in > 0) {
		$mod = $in % $base;
		$out = $modifier[$mod] . $out;
		$in = ($in - $mod) / $base;
	}
	return $out;
}
function shortnr_light(){ ?>
	<div id="shortnr">
		<form action="load.php?id=shortnr_light" method="post">
			<input type="text" class="text" id="shortnr_url" name="shortnr_url" placeholder="http://…">
			<input type="submit" class="text" id="shortnr_go" name="shortnr_go" value="Shortn!">
		</form>
	</div>
<?php
	if (file_exists(GSDATAOTHERPATH.'shortnr_light.xml')) {
		echo '<div id="shortnr-main"><h3>Previously created</h3><table class="highlight"><tr><th>Short</th><th>Long</th><th style="text-align: right;">Clicks</th><th></th></tr>';
		$URLs = getXML(GSDATAOTHERPATH.'shortnr_light.xml');
		if ($URLs->urls->count() > 0){
			foreach ($URLs->urls->url as $URL) {
				echo '<tr><td>/_/'.$URL->short.'</td><td>'.$URL->long.'</td><td style="text-align: right;"><span>'.$URL->clicks.'</span></td><td class="delete"><a class="delconfirm" href="load.php?id=shortnr_light&amp;delete='.$URL->short.'" title="Delete short URL: /_/'.$URL->short.'">×</a></td></tr>';
			}
		}
		echo '</table></div>';
	}
} ?>