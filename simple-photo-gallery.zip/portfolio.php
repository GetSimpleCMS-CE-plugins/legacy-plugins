<?php

/*
Plugin Name: GetSimple Portfolio
Description: Portfolio manager
Version: 0.8
Author: arse.bandit
Website: http://supaweb.ru

Install: copy this file to GetSimple plugins folder. 
Usage: Upload files in Files page in default folder /data/uploads/
Back-End: Point your browser to plugins page. In sidebar you will see Portfolio link. There you can create portfolio folders and uploading files to this folders.
Front-End: In template editor place where you want this string <?php portfolio_site_view(); ?>.
In Slug/URL of gallery page in Pages section write name of gallery folder made with Back-End of this plugin. 

*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
  $thisfile,
  'Портфолио',
  '0.8',
  'arse.bandit',
  'http://supaweb.ru',
  'Менеджер портфолио',
  'plugins',
  'portfolio_admin'
);

# hooks
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Portfolio'));

# definitions
define('GSDATAPHOTOPATH', GSDATAPATH . 'photo/');


############################### ADMIN FUNCTIONS ################################


/*******************************************************
 * @function news_admin
 * @action create, edit and delete news articles
*/
function portfolio_admin() {
  if (!file_exists(GSDATAPHOTOPATH)) {
    mkdir(GSDATAPHOTOPATH);
    $ht = fopen(GSDATAPHOTOPATH.'.htaccess', "w");
    fwrite($ht, "Allow from all");
    fclose ($ht);
    portfolio_overview();
  } elseif (isset($_GET['getphoto'])) {
  	$folder = $_GET['getphoto'];
    get_photo($folder);
  } elseif (isset($_GET['import'])) {
  	$folder = $_GET['folder'];
    import($folder);
  } elseif (isset($_GET['create'])) {
    get_folder_name();
  } elseif (isset($_GET['delete'])) {
  	if(isset($_GET['folder'])){
  	  $file = $_GET['delete'];
  	  $folder = $_GET['folder'];
  	  delete_photo($folder,$file);
  	} else {
	    $folder = $_GET['delete'];
	    delete_folder($folder);
    }
  } elseif (isset($_GET['open'])) {
  	$folder = $_GET['open'];
    photos_overview($folder);
  } elseif (isset($_POST['submit'])) {
    create_folder();
  } else {
    portfolio_overview();
  }
}


/*******************************************************
 * @function portfolio_overview
 * @action list portfolio folders
*/
function portfolio_overview() {
  global $SITEURL;
  $galleries = get_galleries();
  ?>
  <label>Портфолио</label>
  <div class="edit-nav" >
    <a href="load.php?id=portfolio&create">Новая галерея</a>
    <div class="clear"></div>
  </div>
  <?php
  if (!empty($galleries)) {
    echo '<table class="highlight">';
    foreach ($galleries as $gallery) {
      $title = $gallery;
      ?>
      <tr>
        <td>
          <a href="load.php?id=portfolio&open=<?php echo $title; ?>" title="Открыть папку <?php echo $title; ?>">
            <?php echo $title; ?>
          </a>
        </td>
        <td style="text-align: right;">
          <span><?php echo $date; ?></span>
        </td>
        <td class="delete">
          <a href="load.php?id=portfolio&delete=<?php echo $title; ?>" title="Удалить папку <?php echo $title; ?>?">
            X
          </a>
        </td>
      </tr>
      <?php
    }
    echo '</table>';
  }  
  $data = array('ея','еи','ей');
  $num = count($galleries);
  $res = $data[0];
  
  if($num%10 > 1 && $num%10<5) $res = $data[1];
  if($num%10 > 4 || $num%10==0) $res = $data[2];
  if($num%100>10 && $num%100<20) $res = $data[2];

  echo '<p><b>' . count($galleries) . '</b> галер'.$res.'</p>';
}

/*******************************************************
 * @function photos_overview
 * @action list photos from specified folder
*/
function photos_overview($folder) {
	global $SITEURL;
  $photos = get_photos($folder);
  $available_photos = available_photos();
  ?>
  <label><a href="load.php?id=portfolio">Портфолио &rarr;</a> <?php echo $folder; ?></label>
  <?php 
  	if(!empty($available_photos)){
  ?>
	  <div class="edit-nav" >
	    <a href="load.php?id=portfolio&import&folder=<?php echo $folder; ?>">Импортировать фотографии</a>
	    <div class="clear" style="overflow:hidden;clear:both;"></div>
	  </div>
  <?php 
    echo '<label>Фотографии доступные для импорта ('.sizeof($available_photos).')</label><br><table class="highlight">';
    foreach ($available_photos as $av_photo) {
      $title = $av_photo;
      ?>
      <tr>
        <td>
          <img src="<?php echo $SITEURL.'data/thumbs/thumbnail.'.$title; ?>">
        </td>
        <td class="delete">
          <a href="load.php?id=portfolio&delete=<?php echo $title; ?>" title="Удалить файл <?php echo $title; ?>?">
            X
          </a>
        </td>
      </tr>
      <?php
    }
    echo '</table>';
  }  
  
  
  if (!empty($photos)) {
    echo '<div class="clear"></div><label>Фотографии в галерее ('.sizeof($photos).')</label><br><table class="highlight">';
    foreach ($photos as $photo) {
      $title = $photo;
      ?>
      <tr>
        <td>
          <img src="<?php echo $SITEURL.'data/thumbs/thumbnail.'.$title; ?>">
        </td>
        <td class="delete">
          <a href="load.php?id=portfolio&delete=<?php echo $title; ?>&folder=<?php echo $folder; ?>" title="Удалить файл <?php echo $title; ?>?">
            X
          </a>
        </td>
      </tr>
      <?php
    }
    echo '</table>';
  }  
  $data = array('ия','ии','ий');
  $num = count($photos);
  $res = $data[0];
  
  if($num%10 > 1 && $num%10<5) $res = $data[1];
  if($num%10 > 4 || $num%10==0) $res = $data[2];
  if($num%100>10 && $num%100<20) $res = $data[2];

  echo '<p><b>' . count($photos) . '</b> фотограф'.$res.'</p>';
}



/*******************************************************
 * @function get_folder_name
 * @action geting name for portfolio folder
*/
function get_folder_name() {
	?>
	<div>
		<span>Имя папки</span>
		<form action="load.php?id=portfolio" method="post">
			<input type="text" name="folder" />
			<input name="submit" type="submit" value="Создать папку" />
		</form>
	</div>
	<?php
}


/*******************************************************
 * @function create_folder
 * @action geting name for portfolio folder
*/
function create_folder() {
	$folder = $_POST['folder'];
	mkdir(GSDATAPHOTOPATH.$folder);
	echo '<div class="updated">Все получилось детка. Папка '.$folder.' удачно создана.</div>';
	portfolio_overview();
}


/*******************************************************
 * @function delete_folder
 * @action deleting portfolio folder
*/
function delete_folder($folder) {
	if(rmdir(GSDATAPHOTOPATH.$folder)){
		echo '<div class="updated">Все получилось детка. Папка '.$folder.' удалена безвозвратно.</div>';
		portfolio_overview();
	} else {
		echo '<div class="error">Не получается удалить. Папка '.$folder.' не пустая.</div>';
		portfolio_overview();
	}
}


/*******************************************************
 * @function delete_file
 * @action deleting photo from portfolio folder
*/
function delete_photo($folder,$file) {
	if(unlink(GSDATAPHOTOPATH.$folder.'/'.$file)){
		echo '<div class="updated">Все получилось детка. Файл '.$file.' удален безвозвратно.</div>';
		photos_overview($folder);
	} else {
		echo '<div class="error">Что-то не получилось. Файл '.$file.' не удаляется.</div>';
		photos_overview($folder);
	}
}


############################### SITE FUNCTIONS #################################

/*******************************************************
 * @function portfolio_site_view
 * @action show images from specified folder
*/
function portfolio_site_view() {
	global $SITEURL;
	if(isset($_GET['id'])){
		$folder = $_GET['id'];
		$photos = get_photos($folder);
		echo '<div class="gallery">';
		foreach ($photos as $photo){
			echo '<img src="'.$SITEURL.'data/photo/'.$folder.'/'.$photo.'">';
		}
		echo '</div>';
	}
}

############################## HELPER FUNCTIONS ################################


/*******************************************************
 * @function get_galleries
 * @returns returns all galleries in GSDATAPHOTOPATH
*/
function get_galleries() {
  $galleries = array();
  $dirs = getFiles(GSDATAPHOTOPATH);
  foreach ($dirs as $dir) {
    if (is_dir(GSDATAPHOTOPATH . $dir) && $dir != "." && $dir != "..") {
      $galleries[] = $dir;
    }
  }
  krsort($galleries);
  return $galleries;
}


/*******************************************************
 * @function get_photos
 * @returns returns all photos in GSDATAPHOTOPATH/gallery_folder
*/
function get_photos($folder) {
	$photos = array();
	$files = getFiles(GSDATAPHOTOPATH.$folder);
	foreach ($files as $file) {
	  if (is_file(GSDATAPHOTOPATH.$folder.'/'.$file) && $file != "." && $file != "..") {
	    $photos[] = $file;
	  }
	}
	krsort($photos);
	return $photos;
}


/*******************************************************
 * @function availabale_photos
 * @returns returns list of all photos in GSDATAUPLOADPATH
*/
function available_photos() {
	$avail_photos = array();
	$files = getFiles(GSDATAUPLOADPATH);
	foreach ($files as $file) {
	  if (is_file(GSDATAUPLOADPATH.'/'.$file) && $file != "." && $file != ".." && $file != ".DS_Store" && $file != ".htaccess") {
	    $avail_photos[] = $file;
	  }
	}
	krsort($avail_photos);
	return $avail_photos;
}


/*******************************************************
 * @function import photos
 * @returns import all photos in GSDATAUPLOADPATH
*/
function import($folder) {
	$photo_import = available_photos();
	$destination_folder = $folder;
	foreach ($photo_import as $photo){
		if(!rename(GSDATAUPLOADPATH.$photo, GSDATAPHOTOPATH.$destination_folder.'/'.$photo)) {
		        echo "Ошибка перемещения файла $photo...<br />\n";
		    }
	}
	photos_overview($destination_folder);
}


?>
