<?php
/*
Plugin Name: Mp3 Player Ultimate
Description: Mp3 player placed where tag specifies. 
Version: 0.2
GS : 3.0
Author: Johannes Pretorius
Author URI: http://www.dominion-it.co.za/
*/



class DominionMp3Player {   
   
   private $ap_playerID=1;  //this is used per player that gets generated per 
                           //conent create call. Note plugins alters this as they 
						   //create players if required.
  private $activeExtendFileName = '';
  private $activeExtendClassName = '';  
  
  private $dominion_mp3player_extentions;						   
   
  public function replaceTagsinContent($content){   
     $cfgPath = GSPLUGINPATH.'dominion-mp3player/mp3playersettings.cfg';
	 $cfgSettings = parse_ini_file($cfgPath);
	 //error_log(print_r($cfgSettings,true));
	$bgColor = $cfgSettings['bgcolor'];
	$this->activeExtendFileName = $cfgSettings['player'];
	$this->activeExtendClassName = $cfgSettings['playerclass'];

		$tmpContent = $content;
		preg_match_all('/\(%(.*)mp3(.*):(.*)%\)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER);
		
		$AlltoReplace = $tmpArr[count($tmpArr)-1];
		$totalToReplace = count($AlltoReplace);
		for ($x = 0;$x < $totalToReplace;$x++) {
		   $targetMp3= str_replace('&nbsp;',' ',$AlltoReplace[$x]);
		   $targetMp3 = trim($targetMp3);
		   
		   $targetFiles = explode(';',$targetMp3);  //for multiple files
		   
		  $adTeks = $this->playerAdd($targetFiles,$bgColor,$this->ap_playerID);
		  $targetMp3= str_replace('/','\/',$targetMp3);
		  $tmpContent = preg_replace("/\(%(.*)mp3(.*):(.*)$targetMp3(.*)%\)/i",$adTeks,$tmpContent);
		}
		
	  return $tmpContent;  
  } 
  
   private function playerAdd($targetFile,$bgColor){
        global $SITEURL;
		// Get next player ID 
		/*Multi player control contributed by alienee2 (http://get-simple.info/forum/post/15791/#p15791)*/
        require_once(GSPLUGINPATH.'dominion-mp3player/plugins/'.$this->activeExtendFileName);
		
        $pluginBasePath = $SITEURL."/plugins/dominion-mp3player/player/";
		foreach ($targetFile as $theFile) {
          if (file_exists(GSDATAUPLOADPATH."$theFile")) {
			 $targetFiles[] = $SITEURL."data/uploads/$theFile";
          }
		}  
		$options['bgcolor'] = $bgColor;
		$class = $this->activeExtendClassName;
		$mp3player = @new $class();
		return  $mp3player->AddPlayer($pluginBasePath,$targetFiles,$options,$this->ap_playerID);
   }
   
   public function getPluginsInfo(){
      $files = scandir(GSPLUGINPATH.'dominion-mp3player/plugins/');
	  
	  foreach ($files as $file){
	    if (pathinfo($file, PATHINFO_EXTENSION) == 'mp3reg') {
		  $regInfo = parse_ini_file(GSPLUGINPATH.'dominion-mp3player/plugins/'.$file);
		  $this->dominion_mp3player_extentions[] = $regInfo;
		}
	  }
	  return $this->dominion_mp3player_extentions;
   }
   
   public function Mp3_Player_PageHeaderFiles($pluginPath){
      $cfgPath = GSPLUGINPATH.'dominion-mp3player/mp3playersettings.cfg';
	  $cfgSettings = parse_ini_file($cfgPath);
	  $this->activeExtendFileName = $cfgSettings['player'];
	  $this->activeExtendClassName = $cfgSettings['playerclass'];
	  if ($cfgSettings['usejquery'] == '1') {
	    ?>
		<script type="text/javascript" src="<?php echo $pluginPath; ?>/jquery-1.6.2.min.js"></script>    
		<?php
	  }
      require_once(GSPLUGINPATH.'dominion-mp3player/plugins/'.$this->activeExtendFileName);
      $class = $this->activeExtendClassName;
		$mp3player = @new $class();
		$mp3player->Player_Extention_Header($pluginPath);
		unset($mp3player);
   }

}

?>