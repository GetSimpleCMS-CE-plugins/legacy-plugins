<?php
/*

Plugin Name: Mp3 Player Ultimate
Description: Mp3 player placed where tag specifies. 
Version: 0.2e
GS : 3.0
Author: Johannes Pretorius
Author URI: http://www.dominion-it.co.za/

*/
require_once(GSPLUGINPATH.'dominion-mp3player/dominion-mp3player.php');
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Mp3 Player Ultimate', 	# Title of plugin
	'0.2e', 		# Version of plugin
	'Johannes Pretorius',	# Author of plugin
	'http://www.dominion-it.co.za/', 	# Author URL
	'Place mp3 player inside of page contents in specific TAGS. Thanks to alienee2 (Marc) for all the help.', 	# Plugin Description
	'plugins', 	# Page type of plugin
	'dominion_mp3player_show_config'  	# Function that displays content
);

# activate filter
add_filter('content','dominion_mp3player_tags'); 
add_action('theme-header','dominion_mp3player_set_headers');
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Mp3 Player Ultimate'));

function dominion_mp3player_tags($contents){
   $mp3 = @new DominionMp3Player();
   
   //error_log(print_r($mp3->getPluginsInfo(),true));
   return $mp3->replaceTagsinContent($contents);
    
}

function dominion_mp3player_set_headers(){
  global $SITEURL;
  $pluginPath = $SITEURL."plugins/dominion-mp3player/player/";
  $mp3 = @new DominionMp3Player();
  $mp3->Mp3_Player_PageHeaderFiles($pluginPath);
  unset($mp3);
}
function dominion_mp3player_show_config(){
    $mp3 = @new DominionMp3Player();
	$plugins =  $mp3->getPluginsInfo();
	 global $SITEURL;
	 $screenshotpath = $SITEURL."plugins/dominion-mp3player/plugins/screenshots/";
	 $savePath = GSPLUGINPATH.'dominion-mp3player/mp3playersettings.cfg';
    if(isset($_POST['stoor']) && $_POST['stoor'] == 'Save') {
            
            $color  = $_POST['kleur'] ;
			$player  = $_POST['playertouse'];
			$usejquery = isset($_POST['usejquery'])?'1':'0';
			foreach ($plugins as $extend){
			  if ( $extend['filename'] == $player) {
			    $playerclass  = $extend['classname'] ;     
			  }
			}
			
            $filePointer = fopen($savePath,"w");
            fwrite($filePointer,"bgcolor=$color \n\r");
			fwrite($filePointer,"player=$player \n\r");
			fwrite($filePointer,"playerclass=$playerclass \n\r");
			fwrite($filePointer,"playerclass=$playerclass \n\r");
			fwrite($filePointer,"usejquery=$usejquery \n\r");
            fclose($filePointer);
            unset($tmpS,$filePointer);    
			$usejquery =  isset($_POST['usejquery'] )?'checked="checked"':'';
    }    else {
      if (is_file($savePath )) {
	    $cfgSettings = parse_ini_file($savePath );
		$player  = $cfgSettings['player'];
	    $color = $cfgSettings['bgcolor'];
        $usejquery =  ($cfgSettings['usejquery'] == '1')?'checked="checked"':'';
      } else {
        $color = '#FFFFFF';
		$usejquery = '';
      }
      
    }
	reset($plugins);
	$players = "";
	
	foreach ($plugins as $extend){
	   $name = $extend['name'];
	   $descr = $extend['description'];
	   $scfreenshot = $extend['screenshot'];
	   if ($scfreenshot != '') {
	     $scfreenshot = $screenshotpath.$scfreenshot;
	  }	 
	   $filename = $extend['filename'];
	   $classname = $extend['classname'];
	   
	   
	   $descr = str_replace("'",'',$descr);
	   $selected =  ($player == $filename)?"selected='selected'":'';
	   
	  $players .= "<option $selected value='$filename' scr='$scfreenshot' descr='$descr'>$name</option>";
	}
    
?>
<form action="<?php	echo $_SERVER ['REQUEST_URI']?>"  method="post" id="management">
  <p>How  to use the plugin : <br/>Just add anywhere in your page  the following tag  (% mp3:dirname/filename %) <br/>
     or (% mp3:filename %) if directly under Uploads  where the filename is the <br/>
	 name of the MP3 file you have uploaded (note it can be case sensitive). <br/>
	 For example if I have uploaded My personal Song.mp3 to the mp3 directory under <br/>
	 uploads then the tag will be <br/><b>(% mp3:mp3/My personal Song.mp3 %)</b>.
	 <br/><br/>Also NOTE : If you want to put in multiple files in 1 player (playlist)<br/> seperate file names with <b>;</b><br/>
	 For example : (% mp3:mp3/My personal Song.mp3;mp3/OtherSong.mp3;mp3/Another One.mp3 %)<br/><br/>
     Version 0.2e</p>
 <p>
 Use jQuery : <input type='checkbox' name='usejquery' value='1' <?php echo $usejquery; ?>><br/>
 Background color : <input type='text' name='kleur' value='<?php echo $color; ?>'> (hex color)<br/>
    Player to Use : <select name='playertouse' id='playertouse'><?php echo $players;?></select></br>
	
    <input type='submit' name='stoor' value='Save'>
	<span id='playerinfo'><span><br/></p>
	
</form>
<script>
 $('#playertouse').change(function() {
   var scr = $("#playertouse option:selected").attr('scr');
   var descr = $("#playertouse option:selected").attr('descr');
   if (scr != ''){
    $('#playerinfo').html('<p><img src="'+scr+'"><br/>'+descr+'</p>');
   } else {
     $('#playerinfo').html('<p>'+descr+'</p>');
   }	
});
var scr = $("#playertouse option:selected").attr('scr');
   var descr = $("#playertouse option:selected").attr('descr');
   if (scr != ''){
    $('#playerinfo').html('<p><img src="'+scr+'"><br/>'+descr+'</p>');
   } else {
     $('#playerinfo').html('<p>'+descr+'</p>');
   }	
</script>

<?php
}