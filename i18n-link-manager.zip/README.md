i18n_link_manager
=================

Manage a collection of links (I18N enabled)


INSTALATION

Download the latest version, unzip the downloaded file and copy its contents to your plugins folder.
