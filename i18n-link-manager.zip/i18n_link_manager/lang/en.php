<?php

/**
 * I18N Link Manager plugin English language file by Lev Barsov
 */


$i18n = array(
);

?>
