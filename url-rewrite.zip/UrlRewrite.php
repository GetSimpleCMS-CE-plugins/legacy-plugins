<?php
/*
Plugin Name: Url Rewrite
Description: remove .htm from slug
Version: 1.1
Author: Viktor Tassi
Author URI:
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Url Rewrite',
	'1.1',
	'Viktor Tassi',
	'',
	'Remove .htm from url',
	'theme',
	'hello_world_show'  
);

# functions
add_filter( 'indexid', 'htmfilter' );
function htmfilter($id){
         $id= str_replace(".html","",$id);
         $id= str_replace(".htm","",$id);
         return $id;
}

?>