<?php
/*
Plugin Name: Pajax
Description: Loads a page via ajax.
Version: 1.0.2
Author: Eric Wooley
Author URI: http://www.ericwooley.com/
*/
include_once('../admin/inc/common.php');
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
# register plugin
register_plugin(
	$thisfile, //Plugin id
	'Thajax', 	//Plugin name
	'1.0.2', 		//Plugin version
	'Eric Wooley',  //Plugin author
	'http://www.ericwooley.com/', //author website
	'Theme editor ajax save', //Plugin description
	'theme', //page type - on which admin tab to display
	'Thajax'  //main function (administration)
);

# add a link in the admin tab 'theme'
add_action('theme-sidebar','createSideMenu', array($thisfile,'Thajax Theme Editor (ajax)'));
add_action('admin-pre-header','ThajaxRequest');



#these are straight from theme-edit.php
register_script('codemirror', $SITEURL.'admin/template/js/codemirror/lib/codemirror-compressed.js', '0.2.0', FALSE);
register_script('codemirror-search', $SITEURL.'admin/template/js/codemirror/lib/searchcursor.js', '0.2.0', FALSE);
register_script('codemirror-search-cursor', $SITEURL.'admin/template/js/codemirror/lib/search.js', '0.2.0', FALSE);
register_script('codemirror-dialog', $SITEURL.'admin/template/js/codemirror/lib/dialog.js', '0.2.0', FALSE);
register_script('codemirror-folding', $SITEURL.'admin/template/js/codemirror/lib/foldcode.js', '0.2.0', FALSE);

register_style('codemirror-css',$SITEURL.'admin/template/js/codemirror/lib/codemirror.css','screen',FALSE);
register_style('codemirror-theme',$SITEURL.'admin/template/js/codemirror/theme/default.css','screen',FALSE);
register_style('codemirror-dialog',$SITEURL.'admin/template/js/codemirror/lib/dialog.css','screen',FALSE);

queue_script('codemirror', GSBACK);
queue_script('codemirror-search', GSBACK);
queue_script('codemirror-search-cursor', GSBACK);
queue_script('codemirror-dialog', GSBACK);
queue_script('codemirror-folding', GSBACK);


queue_style('codemirror-css', GSBACK);
queue_style('codemirror-theme', GSBACK);
queue_style('codemirror-dialog', GSBACK);







function Thajax(){
	global $SITEURL, $TEMPLATE;
	include(GSPLUGINPATH."Thajax/fromTheme-edit.php");
?>
<script type="text/javascript" src="<?php echo $SITEURL.'plugins/Thajax/js/shortcut.js' ?>">
</script>
<script>
window.onload = function() {
	  var foldFunc = CodeMirror.newFoldFunction(CodeMirror.braceRangeFinder);
	  function keyEvent(cm, e) {
	    if (e.keyCode == 81 && e.ctrlKey) {
	      if (e.type == "keydown") {
	        e.stop();
	        setTimeout(function() {foldFunc(cm, cm.getCursor().line);}, 50);
	      }
	      return true;
	    }
	  }
	  function toggleFullscreenEditing()
	    {
	        var editorDiv = $('.CodeMirror-scroll');
	        if (!editorDiv.hasClass('fullscreen')) {
	            toggleFullscreenEditing.beforeFullscreen = { height: editorDiv.height(), width: editorDiv.width() }
	            editorDiv.addClass('fullscreen');
	            editorDiv.height('100%');
	            editorDiv.width('100%');
	            editor.refresh();
	        }
	        else {
	            editorDiv.removeClass('fullscreen');
	            editorDiv.height(toggleFullscreenEditing.beforeFullscreen.height);
	            editorDiv.width(toggleFullscreenEditing.beforeFullscreen.width);
	            editor.refresh();
	        }
	    }
      var editor = CodeMirror.fromTextArea(document.getElementById("codetext"), {
        lineNumbers: true,
        matchBrackets: true,
        indentUnit: 4,
        indentWithTabs: true,
        enterMode: "keep",
        tabMode: "shift",
        theme:'default',
    	onGutterClick: foldFunc,
    	extraKeys: {"Ctrl-Q": function(cm){foldFunc(cm, cm.getCursor().line);},
    				"F11": toggleFullscreenEditing, "Esc": toggleFullscreenEditing},
        onCursorActivity: function() {
		   	editor.setLineClass(hlLine, null);
		   	hlLine = editor.setLineClass(editor.getCursor().line, "activeline");
		}
      	});
     var hlLine = editor.setLineClass(0, "activeline");





     function loadSelectedFile(){
     	//$(this).after('<span class="pajaxSaving"> Saving... <img height=10 src="<?php echo $SITEURL.'/plugins/pajax/img/bar-spin-small.gif' ?>" /></span>');
		editor.setValue("Loading Page...");
		if($("#theme-folder").length > 0)
	    	var wd = $("#selectTemplate").serialize();
	    else
	    	var wd = $("#selectTemplate").serialize() + "&t=<?php echo tsl($TEMPLATE); ?>";
		$.ajax({
				url: window.location,
				data: wd,
				success: function(data) {
				    editor.setValue(data);
				    if($("#theme-folder").length > 0)
				    	$("#edited_file").val($("#theme-folder").val()+'/'+$("#theme_files").val());
				    else
				    	$("#edited_file").val("<?php echo tsl($TEMPLATE); ?>"+$("#theme_files").val());
				},
				failure: function(data) {
					editor.setValue("Could Not load page please try refreshing the page: "+data);
				}
		});
     }

    loadSelectedFile();
    $("#selectTemplate").submit(function(){
		loadSelectedFile();
		return false;
	});


    function savePage(){
    	var writeData = $("#ThemeEditor").serialize()+"&submitsave=pleaseDo&content="+escape(editor.getValue());
		//alert(writeData);
		//var writeData = $("#ThemeEditor").serialize();
		$.ajax({
				url: window.location,
				data: writeData,
				type:'POST',
				success: function(data) {
				    $(".saveMessage").html(data);
				    $(".saveMessage").fadeIn('slow', function(){
				    	$(".saveMessage").fadeOut(3000);	
				    });
				},
				failure: function(data) {
					
				}
		});

    }
	$("#ThemeEditor").submit(function(){
		savePage();
		return false;
	});

		shortcut.add("Ctrl+Q",function() {
			
		    savePage();
		    return false;
		});


}




</script>
		<h3><?php i18n('EDIT_THEME'); ?></h3>
		<form method="get" id="selectTemplate" accept-charset="utf-8" >
		<p><?php echo $theme_options; ?><?php echo $theme_templates; ?>&nbsp;&nbsp;&nbsp;<input class="submit" type="submit" name="s" value="<?php i18n('EDIT'); ?>" /></p>
		</form>
		
		<p style="height: 25px;"><span class="saveMessage" style="display: none;"></span></p>
		<?php $content = file_get_contents(GSTHEMESPATH . tsl($TEMPLATE) . $TEMPLATE_FILE); ?>
		<textarea name="content" id="codetext" wrap='off' ><?php echo htmlentities($content, ENT_QUOTES, 'UTF-8'); ?></textarea>
		<form id="ThemeEditor" action="<?php myself(); ?>?id=Thajax&t=<?php echo $TEMPLATE; ?>&amp;f=<?php echo $TEMPLATE_FILE; ?>" method="post" >
			<input id="nonce" name="nonce" type="hidden" value="<?php echo get_nonce("save"); ?>" />
			
			<input type="hidden" value="<?php echo tsl($TEMPLATE) . $TEMPLATE_FILE; ?>" id="edited_file" name="edited_file" />
			<?php exec_action('theme-edit-extras'); ?>
			<p id="submit_line" >
				<span><input class="submit" type="submit" name="submitsave" value="<?php i18n('BTN_SAVECHANGES'); ?>" /></span> &nbsp;&nbsp;<?php i18n('OR'); ?>&nbsp;&nbsp; <a class="cancel" href="theme-edit.php?cancel"><?php i18n('CANCEL'); ?></a> - or press Ctrl+Q to save
			</p>
			<p style="height:25px; "><span class="saveMessage" style="display: none;"></span></p>
		</form>
	
<?php
}
function ThajaxRequest(){
if(!isAjax() || $_GET['id'] != "Thajax") return;
include_once(GSPLUGINPATH."Thajax/fromTheme-edit.php");
global $SITEURL, $TEMPLATE;
	# check for form submission
	if(isset($_POST['submitsave'])){
		# check for csrf
		if (!defined('GSNOCSRF') || (GSNOCSRF == FALSE) ) {
			$nonce = $_POST['nonce'];
			if(!check_nonce($nonce, "save")) {
				die("CSRF detected!");
			}
		}
		# save edited template file
		
		$SavedFile = explode("/", $_POST['edited_file']);
		if($SavedFile[1] == "Default Template")
			$SavedFile[1] = "template.php";
		$SavedFile = implode('/', $SavedFile);
		if(!file_exists(GSTHEMESPATH . $SavedFile))
			die("Could not open file: ".GSTHEMESPATH . $SavedFile);
		$FileContents = get_magic_quotes_gpc() ? stripslashes($_POST['content']) : $_POST['content'];
		$fh = fopen(GSTHEMESPATH . $SavedFile, 'w') or die("Could not open file: ".GSTHEMESPATH . $SavedFile);
		fwrite($fh, $FileContents);
		fclose($fh);
		$success = sprintf(i18n_r('TEMPLATE_FILE'), $SavedFile);
		//echo "<!-- $FileContents -->";		
		die($success);
	}
	else{
		if($_GET['f'] == "Default Template")
			$f = "template.php";
		else
			$f = $_GET['f'];
		$content = file_get_contents(GSTHEMESPATH . $_GET['t'].'/'.$f);
		die($content);
		
	}
}

# checks if the request is an ajax request.
if(!function_exists(isAjax)){
	function isAjax() {
		return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
		($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'));
	}
}