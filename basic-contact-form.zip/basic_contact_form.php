<?php
# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, //Plugin id
	'Basic contact form', 	//Plugin name
	'1.0', 		//Plugin version
	'three am',  //Plugin author
	'http://www.threeamdesign.com.au/', //author website
	'Processes simple contact form submissions', //Plugin description
	'theme', //page type - on which admin tab to display
	'basic_contact_form_admin'  //main function (administration)
);

# add a link in the admin tab 'theme'
add_action('theme-sidebar', 'createSideMenu', array($thisfile, 'Basic Contact Settings'));

# functions
function basic_contact_form_settings($set = null) {
	$file = GSDATAOTHERPATH .'basic_contact_form_settings.xml';
	if (!file_exists($file)) {
		$settings = new SimpleXMLElement('<settings></settings>');
		if (!XMLsave($settings, $file))
			return;
	}
	elseif (!($settings = getXML($file)) && !is_object($settings))
		return;
	if ($set === null)
		return $settings;
	foreach ($set as $node => $val)
		if (is_array($val)) {
			unset($settings->$node);
			$vals = array_filter($val, 'basic_contact_form_ds');
			foreach ($vals as $val)
				$settings->addChild($node, $val);
		}
		elseif (strlen($val = basic_contact_form_ds($val)))
			$settings->$node = $val;
		else
			unset($settings->$node);
	return XMLsave($settings, $file);
}

function basic_contact_form_valid_email(&$address) {
	if (function_exists('filter_var')) {
		if ($temp = filter_var($address, FILTER_VALIDATE_EMAIL))
			$address = $temp;
		return (bool) $temp;
	}
	$user = '[A-Z\d_\-.+\^!#\$%&*\/=?`|{}~\']+';
	$domain = '(?:[A-Z\d]+(?:\-+[A-Z\d]+)*\.)*[A-Z]{2,}';
	$ipv4 = '(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}';
	$ipv6 = '(?![\dA-F:]+?::(?'.'>[\dA-F:]+)(?<=:))(?![\dA-F:]*?:{3})(?![\dA-F:]*?::[\dA-F:]*?::)[\dA-F]{1,4}(?::[\dA-F]{0,4}){1,7}';//excludes local addresses beggining with ::
	return preg_match("/^$user@(?:$domain|\[(?:$ipv4|$ipv6)\])$/i", $address);
}

function basic_contact_form_ds($input, $allow_linebreaks = null) {
	if ((string) $input == '')
		return '';
	if ($allow_linebreaks) {
		$placeholder = '~~EOL~~';
		$input = preg_replace('/\r?\n|\r/', $placeholder, $input);
	}
	$input = preg_replace('/[\s\x00-\x1F\xA0]+/', ' ', $input);
	if ($allow_linebreaks) {
		$input = preg_replace('/ ?' . preg_quote($placeholder, '/') . ' ?/', PHP_EOL, $input);
		$input = preg_replace('/'. preg_quote(PHP_EOL, '/') .'{3,}/', PHP_EOL.PHP_EOL, $input);
	}
	return trim($input);
}

function basic_contact_form_admin() {
	if ($_POST && !basic_contact_form_settings($_POST)) {?>
		<div class="error">Your settings could not be saved</div>
	<?php }
	$settings = basic_contact_form_settings();
	if (!isset($settings)) {
		?>
		<div class="error">Settings data could not be loaded.</div>
		<?php
		return; 
	}
	?>
	<h3>Contact Form Settings</h3>
	<form action="<?php	echo htmlspecialchars($_SERVER['REQUEST_URI']);?>" method="post">
		<p><label>Subject<br /><input name="subject" value="<?php echo htmlspecialchars(@$settings->subject);?>" /></label></p>
		<p><label>Submission recipient<br /><input name="recipient" value="<?php echo htmlspecialchars(@$settings->recipient);?>" /></label></p>
		<p><label>Email field (must match the <code>name</code> attribute)<br /><input name="email_field" value="<?php echo htmlspecialchars(@$settings->email_field);?>" /></label></p>
		<p><label>Required fields (must match the <code>name</code> attributes)</label>
		<?php if (@$settings->required_fields) foreach ($settings->required_fields as $required_field) {?>
			<input name="required_fields[]" value="<?php echo htmlspecialchars($required_field);?>" /><br />
		<?php }?>
		<input type="button" id="add-req-field" value="Add a required field" /></p>
		<p><input type="submit" value="Save" /></p>
	</form>
	<script type="text/javascript">
		$(function() {
			$('#add-req-field').click(function() {
				$(this).before('<input type="text" name="required_fields[]" /><br />').prev().prev().focus();
			});
		});
	</script>
	<?php
}

function basic_contact_form_process() {
	if (
		!$_POST ||
		!is_object($settings = basic_contact_form_settings()) ||
		!isset($settings->email_field, $settings->recipient, $settings->subject)
	)
		return;
	
	$errors = array();
	
	$sender = trim(@$_POST["{$settings->email_field}"]);
	if (!basic_contact_form_valid_email($sender))
		$errors[] = 'That does not appear to be a valid email address.';
	
	unset($_POST['x'], $_POST['y']);//image submit
	foreach ($_POST as $k => $v)
		if (strlen($v = basic_contact_form_ds($v, true)))
			$_POST[$k] = $v;
		else
			unset($_POST[$k]);
	if (@$settings->required_fields)
		foreach ($settings->required_fields as $required_field)
			if (!isset($_POST["$required_field"])) {
				$errors[] = 'You have not completed all required fields.';
				break;
			}
	
	if (!$errors) {
		$headers  = "From: {$settings->recipient}\r\n";
		$headers .= "Reply-To: $sender\r\n";
		$headers .= "Return-Path: {$settings->recipient}\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/plain; charset=UTF-8\r\n";
		
		$message = '';
		foreach ($_POST as $k => $v)
			$message .= wordwrap(str_replace('_', ' ', $k), 75, "\n", true). "\n"
				. wordwrap(" $v", 75, " \n", true). "\n\n";
		if (!mail($settings->recipient, '=?UTF-8?B?'.base64_encode($settings->subject).'?=', $message, $headers))
			$errors[] = 'The messge failed to send please try again later.';
	}
	
	if ($errors) {
		echo '<ul class="contact-error">';
		foreach ($errors as $error)
			echo "<li>$error</li>";
		echo '</ul>';
	}
	else {
		echo '<p class="contact-success">Your message has been sent.</p>';
		$_POST = array();
	}
}