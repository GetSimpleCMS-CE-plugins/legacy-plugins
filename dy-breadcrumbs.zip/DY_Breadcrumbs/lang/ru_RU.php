<?php
/**
 * Russian Language File for DY Breadcrumbs
**/

$i18n = array(
  'DY_BREADCRUMBS_PLUGIN_DESCRIPTION' => '«Хлебные крошки» для веб-сайта',
  'DY_BREADCRUMBS_HOME'               => 'Главная'
);