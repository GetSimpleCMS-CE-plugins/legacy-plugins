<?php
/**
 * English Language File for DY Breadcrumbs
**/

$i18n = array(
  'DY_BREADCRUMBS_PLUGIN_DESCRIPTION' => 'Breadcrumbs navigation for web-site',
  'DY_BREADCRUMBS_HOME'               => 'Home'
);