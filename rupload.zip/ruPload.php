<?php
define('GSNOUPLOADIFY', 1);

$thisfile = basename(__FILE__, ".php");
register_plugin(
	$thisfile,
	'ruPload',
	'1.2.2',
	'opiums',
	'http://opiums.eu',
	ruPload::locale('pluginDesc'),
	'files',
	'ruPload::help'
);
add_action('files-sidebar', 'createSideMenu', array($thisfile, ruPload::locale('uploadStr')));
add_action('footer', 'ruPload::footer');

class ruPload{
	public static $rupload = true; // Использовать собственный обработчик? | Use your own handler?
	public static $upform = true; // Скрывать форму uploadform? | Hide uploadform?
	public static $translit = true; // Транслитировать русские имена файлов при загрузке? | Translate Russian filenames on upload?
	
	public static $local = array(
		'ru_RU' => array(
			'pluginDesc' => 'Замена flash загрузчика uploadify. <a href="load.php?id=ruPload">Документация</a>.',
			'CssFile' => 'Загрузка файлов ruPload. Выберите или перетащите файлы для загрузки.',
			'dragDropStr' => 'Перетащите для загрузки',
			'cancelStr' => 'Отменить',
			'doneStr' => 'Готово',
			'multiDragErrorStr' => 'Только один файл за раз!',
			'extErrorStr' => 'Ошибка! Разрешено загружать:',
			'sizeErrorStr' => 'Ошибка! Максимальный размер:',
			'uploadErrorStr' => 'Загрузка не удалась!',
			'uploadStr' => 'Загрузка файлов ruPload',
			'replaceFile' => 'Файл \'+ file + \' уже существует, заменить?',
			'notifyOk' => 'Загрузка файла(ов):',
			'file' => 'Файл',
			'exiReplace' => 'существует, не замненен!',
			'packetUpd' => 'Пакетная загрузка массивом данных доступна только через обработчик от GetSimple!',
		),
		'en_US' => array(
			'pluginDesc' => 'Replacing the uploadify flash loader. <a href="load.php?id=ruPload">Documentation</a>.',
			'CssFile' => 'Loading files ruPload. Select or drag & drop files to upload.',
			'dragDropStr' => 'Drag & drop to upload',
			'cancelStr' => 'Cancel',
			'doneStr' => 'Done',
			'multiDragErrorStr' => 'Only one file at a time!',
			'extErrorStr' => 'Error! Allowed to upload:',
			'sizeErrorStr' => 'Error! Maximum size:',
			'uploadErrorStr' => 'Upload failed!',
			'uploadStr' => 'Loading you files by ruPload',
			'replaceFile' => 'File \'+ file + \' already exists, replace?',
			'notifyOk' => 'Upload file(s)',
			'file' => 'File',
			'exiReplace' => 'exists, is not replaced!',
			'packetUpd' => 'Batch loading with an array of data is available only through the handler from GetSimple!',
		)
	);
	
	public static function locale($val){
		global $LANG;
		$lang = (string)$LANG;
		$loclang = (!empty($lang) && in_array($lang, array_keys(self::$local))) ? $lang : array_keys(self::$local)[1]; // 'en_US';
		return self::$local[$loclang][$val];
	}
	
	public static function help(){
		global $LANG;
		if($LANG == 'ru_RU'){
			?>
			<h2>ruPload - замена flash загрузчика uploadify</h2>
			<p>С уходом флеш плеера стало проблематично использовать swf файлы в браузере, поэтому был разработан этот плагин, который предназначен для полной замены "родного" загрузчика uploadify.</p>
			<p>Плагин может использовать как собственный обработчик, так и от GetSimple CMS, для переключения измените настройки в 19 строке файла <b><?=__FILE__?></b>. В качестве загрузчика используется <a href="http://hayageek.com/docs/jquery-upload-file.php" target="_blank">jQuery Upload File Plugin</a>.</p>
			<?="<p>В настоящий момент используется: <b>".(self::$rupload ? "собственный обработчик" : "обработчик от GetSimple")."</b>.</p>"?>
			<h3>Особенности</h3>
			<ul>
			<li>Плагин активируется на вкладке "Файлы" и на текущей странице с документацией.</li>
			<li>После открытия страницы с файлами происходит загрузка списка файлов в кэш, для сравнения.</li>
			<li>Если вы получаете уведомление об ошибке что файл существует и не заменён то обновите страницу (произошло расхождения кэша и текущего списка файлов).</li>
			<li>Если вы получаете вопрос о замене файла, но его уже не существует то обновите страницу (произошло расхождения кэша и текущего списка файлов).</li>
			<li>Обработчик от GetSimple производит замену файлов с одинаковыми именами без вопросов и уведомлений.</li>
			</ul>
			<?php
		}else{
			?>
			<h2>ruPload - replacement of flash uploadify loader</h2>
			<p>With the departure of the flash player, it became problematic to use swf files in the browser, so this plugin was developed, which is designed to completely replace the "native" uploadify uploader.</p>
			<p>The plugin can use both its own handler and from GetSimple CMS, to switch, change the settings in the 19th line of the file <b><?=__FILE__?></b>. Used as a loader <a href="http://hayageek.com/docs/jquery-upload-file.php" target="_blank">jQuery Upload File Plugin</a>.</p>
			<?="<p>Currently in use: <b>".(self::$rupload ? "own handler" : "handler from GetSimple")."</b>.</p>"?>
			<h3>Peculiarities</h3>
			<ul>
			<li>The plugin is activated on the "Files" tab and on the current documentation page.</li>
			<li>After opening the page with files, the list of files is loaded into the cache for comparison.</li>
			<li>If you receive a notification about an error that the file exists and has not been replaced, then refresh the page (there was a discrepancy between the cache and the current list of files).</li>
			<li>If you get a question about replacing a file, but it no longer exists, then refresh the page (there was a discrepancy between the cache and the current list of files).</li>
			<li>The GetSimple handler replaces files with the same name without any questions or notifications.</li>
			</ul>
			<?php
		}
	}

	public static function footer(){
		global $path, $SESSIONHASH;
		$requestf = basename($_SERVER['PHP_SELF']);
		if($requestf == 'upload.php' || (isset($_GET['id']) && $_GET['id'] == 'ruPload')){
			if(self::$upform) echo '<style>.uploadform{display:none;}</style>'.PHP_EOL;
			?>
<style>.ajax-file-upload-statusbar{border:1px solid #00626f;max-width:100%;margin-top:5px;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;padding:5px}.ajax-file-upload-filename{max-width:200px;height:auto}.ajax-file-upload-filesize{width:50px;height:auto;margin:0 5px 5px 0;display:inline-block;vertical-align:middle}.ajax-file-upload-progress{margin:5px 5px 5px 0;position:relative;width:180px;border:1px solid #ddd;padding:1px;border-radius:3px;display:inline-block;color:#fff}.ajax-file-upload-bar{background-color:#00626f;width:0;height:16px;border-radius:3px;color:#fff}.ajax-file-upload-percent{position:absolute;display:inline-block;top:3px;left:48%}.ajax-file-upload-red{-moz-box-shadow:inset 0 39px 0 -24px #e67a73;-webkit-box-shadow:inset 0 39px 0 -24px #e67a73;box-shadow:inset 0 39px 0 -24px #e67a73;background-color:#e4685d;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;display:inline-block;color:#fff;font-family:arial;font-size:12px;font-weight:400;padding:3px 7px;text-decoration:none;text-shadow:0 1px 0 #b23e35;cursor:pointer;vertical-align:top;margin:5px 0 5px 0}.ajax-file-upload-green{background-color:#77b55a;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;margin:0;padding:0;display:inline-block;color:#fff;font-family:arial;font-size:13px;font-weight:400;padding:4px 15px;text-decoration:none;cursor:pointer;text-shadow:0 1px 0 #5b8a3c;vertical-align:top}.ajax-file-upload{font-family:Arial,Helvetica Neue,Helvetica,sans-serif;font-size:12px;font-weight:700;cursor:pointer!important;margin:0 0 5px 0;display:inline-block;border:1px solid #e8e8e8;color:#afc5cf;text-decoration:none;border-radius:3px;-webkit-border-radius:3px;-moz-border-radius:3px;padding:5px 15px 5px 15px;background:#182227;-webkit-transition:all .2s ease-in-out;-moz-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out}.ajax-file-upload:hover{cursor:pointer;color:#fff}.ajax-file-upload input[type=file]{opacity:0!important}.ajax-file-upload input[type=file]::before{cursor:pointer;content:'<?=self::locale('CssFile')?>';visibility:hidden;-webkit-user-select:none;outline:0}.ajax-upload-dragdrop{border:2px dotted #a5a5c7;max-width:100%;color:#dadce3;text-align:center;vertical-align:middle;padding:0}.state-hover{border:2px solid #a5a5c7}</style>
<script type="text/javascript">
var formruPload, dataruPload, ruPloadtime=5000, ruPloadCheck=true;
!function(e){"function"==typeof define&&define.amd?define(["jquery"],e):"object"==typeof module&&module.exports?module.exports=function(t,r){return void 0===r&&(r="undefined"!=typeof window?require("jquery"):require("jquery")(t)),e(r),r}:e(jQuery)}(function(e){"use strict";function t(t){var r=t.data;t.isDefaultPrevented()||(t.preventDefault(),e(t.target).closest("form").ajaxSubmit(r))}function r(t){var r=t.target,a=e(r);if(!a.is("[type=submit],[type=image]")){var n=a.closest("[type=submit]");if(0===n.length)return;r=n[0]}var i=r.form;if(i.clk=r,"image"===r.type)if(void 0!==t.offsetX)i.clk_x=t.offsetX,i.clk_y=t.offsetY;else if("function"==typeof e.fn.offset){var o=a.offset();i.clk_x=t.pageX-o.left,i.clk_y=t.pageY-o.top}else i.clk_x=t.pageX-r.offsetLeft,i.clk_y=t.pageY-r.offsetTop;setTimeout(function(){i.clk=i.clk_x=i.clk_y=null},100)}function a(){if(e.fn.ajaxSubmit.debug){var t="[jquery.form] "+Array.prototype.join.call(arguments,"");window.console&&window.console.log?window.console.log(t):window.opera&&window.opera.postError&&window.opera.postError(t)}}var n=/\r?\n/g,i={};i.fileapi=void 0!==e('<input type="file">').get(0).files,i.formdata=void 0!==window.FormData;var o=!!e.fn.prop;e.fn.attr2=function(){if(!o)return this.attr.apply(this,arguments);var e=this.prop.apply(this,arguments);return e&&e.jquery||"string"==typeof e?e:this.attr.apply(this,arguments)},e.fn.ajaxSubmit=function(t,r,n,s){function u(r){var a,n,i=e.param(r,t.traditional).split("&"),o=i.length,s=[];for(a=0;a<o;a++)i[a]=i[a].replace(/\+/g," "),n=i[a].split("="),s.push([decodeURIComponent(n[0]),decodeURIComponent(n[1])]);return s}function c(r){function n(e){var t=null;try{e.contentWindow&&(t=e.contentWindow.document)}catch(e){a("cannot get iframe.contentWindow document: "+e)}if(t)return t;try{t=e.contentDocument?e.contentDocument:e.document}catch(r){a("cannot get iframe.contentDocument: "+r),t=e.document}return t}function i(){function t(){try{var e=n(v).readyState;a("state = "+e),e&&"uninitialized"===e.toLowerCase()&&setTimeout(t,50)}catch(e){a("Server abort: ",e," (",e.name,")"),s(L),j&&clearTimeout(j),j=void 0}}var r=p.attr2("target"),i=p.attr2("action"),o=p.attr("enctype")||p.attr("encoding")||"multipart/form-data";w.setAttribute("target",m),l&&!/post/i.test(l)||w.setAttribute("method","POST"),i!==f.url&&w.setAttribute("action",f.url),f.skipEncodingOverride||l&&!/post/i.test(l)||p.attr({encoding:"multipart/form-data",enctype:"multipart/form-data"}),f.timeout&&(j=setTimeout(function(){T=!0,s(A)},f.timeout));var u=[];try{if(f.extraData)for(var c in f.extraData)f.extraData.hasOwnProperty(c)&&(e.isPlainObject(f.extraData[c])&&f.extraData[c].hasOwnProperty("name")&&f.extraData[c].hasOwnProperty("value")?u.push(e('<input type="hidden" name="'+f.extraData[c].name+'">',k).val(f.extraData[c].value).appendTo(w)[0]):u.push(e('<input type="hidden" name="'+c+'">',k).val(f.extraData[c]).appendTo(w)[0]));f.iframeTarget||h.appendTo(D),v.attachEvent?v.attachEvent("onload",s):v.addEventListener("load",s,!1),setTimeout(t,15);try{w.submit()}catch(e){document.createElement("form").submit.apply(w)}}finally{w.setAttribute("action",i),w.setAttribute("enctype",o),r?w.setAttribute("target",r):p.removeAttr("target"),e(u).remove()}}function s(t){if(!x.aborted&&!X){if((O=n(v))||(a("cannot access response document"),t=L),t===A&&x)return x.abort("timeout"),void S.reject(x,"timeout");if(t===L&&x)return x.abort("server abort"),void S.reject(x,"error","server abort");if(O&&O.location.href!==f.iframeSrc||T){v.detachEvent?v.detachEvent("onload",s):v.removeEventListener("load",s,!1);var r,i="success";try{if(T)throw"timeout";var o="xml"===f.dataType||O.XMLDocument||e.isXMLDoc(O);if(a("isXml="+o),!o&&window.opera&&(null===O.body||!O.body.innerHTML)&&--C)return a("requeing onLoad callback, DOM not available"),void setTimeout(s,250);var u=O.body?O.body:O.documentElement;x.responseText=u?u.innerHTML:null,x.responseXML=O.XMLDocument?O.XMLDocument:O,o&&(f.dataType="xml"),x.getResponseHeader=function(e){return{"content-type":f.dataType}[e.toLowerCase()]},u&&(x.status=Number(u.getAttribute("status"))||x.status,x.statusText=u.getAttribute("statusText")||x.statusText);var c=(f.dataType||"").toLowerCase(),l=/(json|script|text)/.test(c);if(l||f.textarea){var p=O.getElementsByTagName("textarea")[0];if(p)x.responseText=p.value,x.status=Number(p.getAttribute("status"))||x.status,x.statusText=p.getAttribute("statusText")||x.statusText;else if(l){var m=O.getElementsByTagName("pre")[0],g=O.getElementsByTagName("body")[0];m?x.responseText=m.textContent?m.textContent:m.innerText:g&&(x.responseText=g.textContent?g.textContent:g.innerText)}}else"xml"===c&&!x.responseXML&&x.responseText&&(x.responseXML=q(x.responseText));try{M=N(x,c,f)}catch(e){i="parsererror",x.error=r=e||i}}catch(e){a("error caught: ",e),i="error",x.error=r=e||i}x.aborted&&(a("upload aborted"),i=null),x.status&&(i=x.status>=200&&x.status<300||304===x.status?"success":"error"),"success"===i?(f.success&&f.success.call(f.context,M,"success",x),S.resolve(x.responseText,"success",x),d&&e.event.trigger("ajaxSuccess",[x,f])):i&&(void 0===r&&(r=x.statusText),f.error&&f.error.call(f.context,x,i,r),S.reject(x,"error",r),d&&e.event.trigger("ajaxError",[x,f,r])),d&&e.event.trigger("ajaxComplete",[x,f]),d&&!--e.active&&e.event.trigger("ajaxStop"),f.complete&&f.complete.call(f.context,x,i),X=!0,f.timeout&&clearTimeout(j),setTimeout(function(){f.iframeTarget?h.attr("src",f.iframeSrc):h.remove(),x.responseXML=null},100)}}}var u,c,f,d,m,h,v,x,y,b,T,j,w=p[0],S=e.Deferred();if(S.abort=function(e){x.abort(e)},r)for(c=0;c<g.length;c++)u=e(g[c]),o?u.prop("disabled",!1):u.removeAttr("disabled");(f=e.extend(!0,{},e.ajaxSettings,t)).context=f.context||f,m="jqFormIO"+(new Date).getTime();var k=w.ownerDocument,D=p.closest("body");if(f.iframeTarget?(b=(h=e(f.iframeTarget,k)).attr2("name"))?m=b:h.attr2("name",m):(h=e('<iframe name="'+m+'" src="'+f.iframeSrc+'" />',k)).css({position:"absolute",top:"-1000px",left:"-1000px"}),v=h[0],x={aborted:0,responseText:null,responseXML:null,status:0,statusText:"n/a",getAllResponseHeaders:function(){},getResponseHeader:function(){},setRequestHeader:function(){},abort:function(t){var r="timeout"===t?"timeout":"aborted";a("aborting upload... "+r),this.aborted=1;try{v.contentWindow.document.execCommand&&v.contentWindow.document.execCommand("Stop")}catch(e){}h.attr("src",f.iframeSrc),x.error=r,f.error&&f.error.call(f.context,x,r,t),d&&e.event.trigger("ajaxError",[x,f,r]),f.complete&&f.complete.call(f.context,x,r)}},(d=f.global)&&0==e.active++&&e.event.trigger("ajaxStart"),d&&e.event.trigger("ajaxSend",[x,f]),f.beforeSend&&!1===f.beforeSend.call(f.context,x,f))return f.global&&e.active--,S.reject(),S;if(x.aborted)return S.reject(),S;(y=w.clk)&&(b=y.name)&&!y.disabled&&(f.extraData=f.extraData||{},f.extraData[b]=y.value,"image"===y.type&&(f.extraData[b+".x"]=w.clk_x,f.extraData[b+".y"]=w.clk_y));var A=1,L=2,F=e("meta[name=csrf-token]").attr("content"),E=e("meta[name=csrf-param]").attr("content");E&&F&&(f.extraData=f.extraData||{},f.extraData[E]=F),f.forceSync?i():setTimeout(i,10);var M,O,X,C=50,q=e.parseXML||function(e,t){return window.ActiveXObject?((t=new ActiveXObject("Microsoft.XMLDOM")).async="false",t.loadXML(e)):t=(new DOMParser).parseFromString(e,"text/xml"),t&&t.documentElement&&"parsererror"!==t.documentElement.nodeName?t:null},_=e.parseJSON||function(e){return window.eval("("+e+")")},N=function(t,r,a){var n=t.getResponseHeader("content-type")||"",i=("xml"===r||!r)&&n.indexOf("xml")>=0,o=i?t.responseXML:t.responseText;return i&&"parsererror"===o.documentElement.nodeName&&e.error&&e.error("parsererror"),a&&a.dataFilter&&(o=a.dataFilter(o,r)),"string"==typeof o&&(("json"===r||!r)&&n.indexOf("json")>=0?o=_(o):("script"===r||!r)&&n.indexOf("javascript")>=0&&e.globalEval(o)),o};return S}if(!this.length)return a("ajaxSubmit: skipping submit process - no element selected"),this;var l,f,d,p=this;"function"==typeof t?t={success:t}:"string"==typeof t||!1===t&&arguments.length>0?(t={url:t,data:r,dataType:n},"function"==typeof s&&(t.success=s)):void 0===t&&(t={}),l=t.method||t.type||this.attr2("method"),(d=(d="string"==typeof(f=t.url||this.attr2("action"))?e.trim(f):"")||window.location.href||"")&&(d=(d.match(/^([^#]+)/)||[])[1]),t=e.extend(!0,{url:d,success:e.ajaxSettings.success,type:l||e.ajaxSettings.type,iframeSrc:/^https/i.test(window.location.href||"")?"javascript:false":"about:blank"},t);var m={};if(this.trigger("form-pre-serialize",[this,t,m]),m.veto)return a("ajaxSubmit: submit vetoed via form-pre-serialize trigger"),this;if(t.beforeSerialize&&!1===t.beforeSerialize(this,t))return a("ajaxSubmit: submit aborted via beforeSerialize callback"),this;var h=t.traditional;void 0===h&&(h=e.ajaxSettings.traditional);var v,g=[],x=this.formToArray(t.semantic,g,t.filtering);if(t.data){var y=e.isFunction(t.data)?t.data(x):t.data;t.extraData=y,v=e.param(y,h)}if(t.beforeSubmit&&!1===t.beforeSubmit(x,this,t))return a("ajaxSubmit: submit aborted via beforeSubmit callback"),this;if(this.trigger("form-submit-validate",[x,this,t,m]),m.veto)return a("ajaxSubmit: submit vetoed via form-submit-validate trigger"),this;var b=e.param(x,h);v&&(b=b?b+"&"+v:v),"GET"===t.type.toUpperCase()?(t.url+=(t.url.indexOf("?")>=0?"&":"?")+b,t.data=null):t.data=b;var T=[];if(t.resetForm&&T.push(function(){p.resetForm()}),t.clearForm&&T.push(function(){p.clearForm(t.includeHidden)}),!t.dataType&&t.target){var j=t.success||function(){};T.push(function(r,a,n){var i=arguments,o=t.replaceTarget?"replaceWith":"html";e(t.target)[o](r).each(function(){j.apply(this,i)})})}else t.success&&(e.isArray(t.success)?e.merge(T,t.success):T.push(t.success));if(t.success=function(e,r,a){for(var n=t.context||this,i=0,o=T.length;i<o;i++)T[i].apply(n,[e,r,a||p,p])},t.error){var w=t.error;t.error=function(e,r,a){var n=t.context||this;w.apply(n,[e,r,a,p])}}if(t.complete){var S=t.complete;t.complete=function(e,r){var a=t.context||this;S.apply(a,[e,r,p])}}var k=e("input[type=file]:enabled",this).filter(function(){return""!==e(this).val()}).length>0,D="multipart/form-data",A=p.attr("enctype")===D||p.attr("encoding")===D,L=i.fileapi&&i.formdata;a("fileAPI :"+L);var F,E=(k||A)&&!L;!1!==t.iframe&&(t.iframe||E)?t.closeKeepAlive?e.get(t.closeKeepAlive,function(){F=c(x)}):F=c(x):F=(k||A)&&L?function(r){for(var a=new FormData,n=0;n<r.length;n++)a.append(r[n].name,r[n].value);if(t.extraData){var i=u(t.extraData);for(n=0;n<i.length;n++)i[n]&&a.append(i[n][0],i[n][1])}t.data=null;var o=e.extend(!0,{},e.ajaxSettings,t,{contentType:!1,processData:!1,cache:!1,type:l||"POST"});t.uploadProgress&&(o.xhr=function(){var r=e.ajaxSettings.xhr();return r.upload&&r.upload.addEventListener("progress",function(e){var r=0,a=e.loaded||e.position,n=e.total;e.lengthComputable&&(r=Math.ceil(a/n*100)),t.uploadProgress(e,a,n,r)},!1),r}),o.data=null;var s=o.beforeSend;return o.beforeSend=function(e,r){t.formData?r.data=t.formData:r.data=a,s&&s.call(this,e,r)},e.ajax(o)}(x):e.ajax(t),p.removeData("jqxhr").data("jqxhr",F);for(var M=0;M<g.length;M++)g[M]=null;return this.trigger("form-submit-notify",[this,t]),this},e.fn.ajaxForm=function(n,i,o,s){if(("string"==typeof n||!1===n&&arguments.length>0)&&(n={url:n,data:i,dataType:o},"function"==typeof s&&(n.success=s)),n=n||{},n.delegation=n.delegation&&e.isFunction(e.fn.on),!n.delegation&&0===this.length){var u={s:this.selector,c:this.context};return!e.isReady&&u.s?(a("DOM not ready, queuing ajaxForm"),e(function(){e(u.s,u.c).ajaxForm(n)}),this):(a("terminating; zero elements found by selector"+(e.isReady?"":" (DOM not ready)")),this)}return n.delegation?(e(document).off("submit.form-plugin",this.selector,t).off("click.form-plugin",this.selector,r).on("submit.form-plugin",this.selector,n,t).on("click.form-plugin",this.selector,n,r),this):this.ajaxFormUnbind().on("submit.form-plugin",n,t).on("click.form-plugin",n,r)},e.fn.ajaxFormUnbind=function(){return this.off("submit.form-plugin click.form-plugin")},e.fn.formToArray=function(t,r,a){var n=[];if(0===this.length)return n;var o,s=this[0],u=this.attr("id"),c=t||void 0===s.elements?s.getElementsByTagName("*"):s.elements;if(c&&(c=e.makeArray(c)),u&&(t||/(Edge|Trident)\//.test(navigator.userAgent))&&(o=e(':input[form="'+u+'"]').get()).length&&(c=(c||[]).concat(o)),!c||!c.length)return n;e.isFunction(a)&&(c=e.map(c,a));var l,f,d,p,m,h,v;for(l=0,h=c.length;l<h;l++)if(m=c[l],(d=m.name)&&!m.disabled)if(t&&s.clk&&"image"===m.type)s.clk===m&&(n.push({name:d,value:e(m).val(),type:m.type}),n.push({name:d+".x",value:s.clk_x},{name:d+".y",value:s.clk_y}));else if((p=e.fieldValue(m,!0))&&p.constructor===Array)for(r&&r.push(m),f=0,v=p.length;f<v;f++)n.push({name:d,value:p[f]});else if(i.fileapi&&"file"===m.type){r&&r.push(m);var g=m.files;if(g.length)for(f=0;f<g.length;f++)n.push({name:d,value:g[f],type:m.type});else n.push({name:d,value:"",type:m.type})}else null!==p&&void 0!==p&&(r&&r.push(m),n.push({name:d,value:p,type:m.type,required:m.required}));if(!t&&s.clk){var x=e(s.clk),y=x[0];(d=y.name)&&!y.disabled&&"image"===y.type&&(n.push({name:d,value:x.val()}),n.push({name:d+".x",value:s.clk_x},{name:d+".y",value:s.clk_y}))}return n},e.fn.formSerialize=function(t){return e.param(this.formToArray(t))},e.fn.fieldSerialize=function(t){var r=[];return this.each(function(){var a=this.name;if(a){var n=e.fieldValue(this,t);if(n&&n.constructor===Array)for(var i=0,o=n.length;i<o;i++)r.push({name:a,value:n[i]});else null!==n&&void 0!==n&&r.push({name:this.name,value:n})}}),e.param(r)},e.fn.fieldValue=function(t){for(var r=[],a=0,n=this.length;a<n;a++){var i=this[a],o=e.fieldValue(i,t);null===o||void 0===o||o.constructor===Array&&!o.length||(o.constructor===Array?e.merge(r,o):r.push(o))}return r},e.fieldValue=function(t,r){var a=t.name,i=t.type,o=t.tagName.toLowerCase();if(void 0===r&&(r=!0),r&&(!a||t.disabled||"reset"===i||"button"===i||("checkbox"===i||"radio"===i)&&!t.checked||("submit"===i||"image"===i)&&t.form&&t.form.clk!==t||"select"===o&&-1===t.selectedIndex))return null;if("select"===o){var s=t.selectedIndex;if(s<0)return null;for(var u=[],c=t.options,l="select-one"===i,f=l?s+1:c.length,d=l?s:0;d<f;d++){var p=c[d];if(p.selected&&!p.disabled){var m=p.value;if(m||(m=p.attributes&&p.attributes.value&&!p.attributes.value.specified?p.text:p.value),l)return m;u.push(m)}}return u}return e(t).val().replace(n,"\r\n")},e.fn.clearForm=function(t){return this.each(function(){e("input,select,textarea",this).clearFields(t)})},e.fn.clearFields=e.fn.clearInputs=function(t){var r=/^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i;return this.each(function(){var a=this.type,n=this.tagName.toLowerCase();r.test(a)||"textarea"===n?this.value="":"checkbox"===a||"radio"===a?this.checked=!1:"select"===n?this.selectedIndex=-1:"file"===a?/MSIE/.test(navigator.userAgent)?e(this).replaceWith(e(this).clone(!0)):e(this).val(""):t&&(!0===t&&/hidden/.test(a)||"string"==typeof t&&e(this).is(t))&&(this.value="")})},e.fn.resetForm=function(){return this.each(function(){var t=e(this),r=this.tagName.toLowerCase();switch(r){case"input":this.checked=this.defaultChecked;case"textarea":return this.value=this.defaultValue,!0;case"option":case"optgroup":var a=t.parents("select");return a.length&&a[0].multiple?"option"===r?this.selected=this.defaultSelected:t.find("option").resetForm():a.resetForm(),!0;case"select":return t.find("option").each(function(e){if(this.selected=this.defaultSelected,this.defaultSelected&&!t[0].multiple)return t[0].selectedIndex=e,!1}),!0;case"label":var n=e(t.attr("for")),i=t.find("input,select,textarea");return n[0]&&i.unshift(n[0]),i.resetForm(),!0;case"form":return("function"==typeof this.reset||"object"==typeof this.reset&&!this.reset.nodeType)&&this.reset(),!0;default:return t.find("form,input,label,select,textarea").resetForm(),!0}})},e.fn.enable=function(e){return void 0===e&&(e=!0),this.each(function(){this.disabled=!e})},e.fn.selected=function(t){return void 0===t&&(t=!0),this.each(function(){var r=this.type;if("checkbox"===r||"radio"===r)this.checked=t;else if("option"===this.tagName.toLowerCase()){var a=e(this).parent("select");t&&a[0]&&"select-one"===a[0].type&&a.find("option").selected(!1),this.selected=t}})},e.fn.ajaxSubmit.debug=!1});
!function(e){/*void 0==e.fn.ajaxForm&&e.getScript("https://cdn.jsdelivr.net/npm/jquery-form@4.2.2/dist/jquery.form.min.js");*/var a={};a.fileapi=void 0!==e("<input type='file'/>").get(0).files,a.formdata=void 0!==window.FormData,e.fn.uploadFile=function(t){function r(){D||(D=!0,function e(){if(w.sequential||(w.sequentialCount=99999),0==x.length&&0==F.length)w.afterUploadAll&&w.afterUploadAll(C),D=!1;else{if(F.length<w.sequentialCount){var a=x.shift();void 0!=a&&(F.push(a),a.removeClass(C.formGroup),a.submit())}window.setTimeout(e,100)}}())}function o(a,t,r){r.on("dragenter",function(a){a.stopPropagation(),a.preventDefault(),e(this).addClass(t.dragDropHoverClass)}),r.on("dragover",function(a){a.stopPropagation(),a.preventDefault();var r=e(this);r.hasClass(t.dragDropContainerClass)&&!r.hasClass(t.dragDropHoverClass)&&r.addClass(t.dragDropHoverClass)}),r.on("drop",function(r){r.preventDefault(),e(this).removeClass(t.dragDropHoverClass),a.errorLog.html("");var o=r.originalEvent.dataTransfer.files;!t.multiple&&o.length>1?t.showError&&e("<div class='"+t.errorClass+"'>"+t.multiDragErrorStr+"</div>").appendTo(a.errorLog):0!=t.onSelect(o)&&l(t,a,o)}),r.on("dragleave",function(a){e(this).removeClass(t.dragDropHoverClass)}),e(document).on("dragenter",function(e){e.stopPropagation(),e.preventDefault()}),e(document).on("dragover",function(a){a.stopPropagation(),a.preventDefault();var r=e(this);r.hasClass(t.dragDropContainerClass)||r.removeClass(t.dragDropHoverClass)}),e(document).on("drop",function(a){a.stopPropagation(),a.preventDefault(),e(this).removeClass(t.dragDropHoverClass)})}function s(e){var a=e/1024;return parseInt(a)>1024?(a/1024).toFixed(2)+" MB":a.toFixed(2)+" KB"}function i(a){var t,r,o=[],s=(o="string"==jQuery.type(a)?a.split("&"):e.param(a).split("&")).length,i=[];for(t=0;t<s;t++)o[t]=o[t].replace(/\+/g," "),r=o[t].split("="),i.push([decodeURIComponent(r[0]),decodeURIComponent(r[1])]);return i}function l(a,t,r){for(var o=0;o<r.length;o++)if(n(t,a,r[o].name))if(a.allowDuplicates||!d(t,r[o].name))if(-1!=a.maxFileSize&&r[o].size>a.maxFileSize)a.showError&&e("<div class='"+a.errorClass+"'><b>"+r[o].name+"</b> "+a.sizeErrorStr+s(a.maxFileSize)+"</div>").appendTo(t.errorLog);else if(-1!=a.maxFileCount&&t.selectedFiles>=a.maxFileCount)a.showError&&e("<div class='"+a.errorClass+"'><b>"+r[o].name+"</b> "+a.maxFileCountErrorStr+a.maxFileCount+"</div>").appendTo(t.errorLog);else{t.selectedFiles++,t.existingFileNames.push(r[o].name);var l=e.extend({},a),u=new FormData,p=a.fileName.replace("[]","");u.append(p,r[o]);var c=a.formData;if(c)for(var h=i(c),f=0;f<h.length;f++)h[f]&&u.append(h[f][0],h[f][1]);l.fileData=u;var w=new m(t,a),g="";g=a.showFileCounter?t.fileCounter+a.fileCounterStyle+r[o].name:r[o].name,a.showFileSize&&(g+=" ("+s(r[o].size)+")"),w.filename.html(g);var C=e("<form style='display:block; position:absolute;left: 150px;' class='"+t.formGroup+"' method='"+a.method+"' action='"+a.url+"' enctype='"+a.enctype+"'></form>");C.appendTo("body");var b=[];b.push(r[o].name),v(C,l,w,b,t,r[o]),t.fileCounter++}else a.showError&&e("<div class='"+a.errorClass+"'><b>"+r[o].name+"</b> "+a.duplicateErrorStr+"</div>").appendTo(t.errorLog);else a.showError&&e("<div class='"+a.errorClass+"'><b>"+r[o].name+"</b> "+a.extErrorStr+a.allowedTypes+"</div>").appendTo(t.errorLog)}function n(e,a,t){var r=a.allowedTypes.toLowerCase().split(/[\s,]+/g),o=t.split(".").pop().toLowerCase();return!("*"!=a.allowedTypes&&jQuery.inArray(o,r)<0)}function d(e,a){var t=!1;if(e.existingFileNames.length)for(var r=0;r<e.existingFileNames.length;r++)(e.existingFileNames[r]==a||w.duplicateStrict&&e.existingFileNames[r].toLowerCase()==a.toLowerCase())&&(t=!0);return t}function u(e,a){if(e.existingFileNames.length)for(var t=0;t<a.length;t++){var r=e.existingFileNames.indexOf(a[t]);-1!=r&&e.existingFileNames.splice(r,1)}}function p(e,a){if(e){a.show();var t=new FileReader;t.onload=function(e){a.attr("src",e.target.result)},t.readAsDataURL(e)}}function c(a,t){if(a.showFileCounter){var r=e(t.container).find(".ajax-file-upload-filename").length;t.fileCounter=r+1,e(t.container).find(".ajax-file-upload-filename").each(function(t,o){var s=e(this).html().split(a.fileCounterStyle),i=(parseInt(s[0]),r+a.fileCounterStyle+s[1]);e(this).html(i),r--})}}function h(t,r,o,s){var i="ajax-upload-id-"+(new Date).getTime(),d=e("<form method='"+o.method+"' action='"+o.url+"' enctype='"+o.enctype+"'></form>"),u="<input type='file' id='"+i+"' name='"+o.fileName+"' accept='"+o.acceptFiles+"'/>";o.multiple&&(o.fileName.indexOf("[]")!=o.fileName.length-2&&(o.fileName+="[]"),u="<input type='file' id='"+i+"' name='"+o.fileName+"' accept='"+o.acceptFiles+"' multiple/>");var p=e(u).appendTo(d);p.change(function(){t.errorLog.html("");o.allowedTypes.toLowerCase().split(",");var i=[];if(this.files){for(g=0;g<this.files.length;g++)i.push(this.files[g].name);if(0==o.onSelect(this.files))return}else{var u=e(this).val(),p=[];if(i.push(u),!n(t,o,u))return void(o.showError&&e("<div class='"+o.errorClass+"'><b>"+u+"</b> "+o.extErrorStr+o.allowedTypes+"</div>").appendTo(t.errorLog));if(p.push({name:u,size:"NA"}),0==o.onSelect(p))return}if(c(o,t),s.unbind("click"),d.hide(),h(t,r,o,s),d.addClass(r),o.serialize&&a.fileapi&&a.formdata){d.removeClass(r);var f=this.files;d.remove(),l(o,t,f)}else{for(var w="",g=0;g<i.length;g++)o.showFileCounter?w+=t.fileCounter+o.fileCounterStyle+i[g]+"<br>":w+=i[g]+"<br>",t.fileCounter++;if(-1!=o.maxFileCount&&t.selectedFiles+i.length>o.maxFileCount)return void(o.showError&&e("<div class='"+o.errorClass+"'><b>"+w+"</b> "+o.maxFileCountErrorStr+o.maxFileCount+"</div>").appendTo(t.errorLog));t.selectedFiles+=i.length;var C=new m(t,o);C.filename.html(w),v(d,o,C,i,t,null)}}),o.nestedForms?(d.css({margin:0,padding:0}),s.css({position:"relative",overflow:"hidden",cursor:"default"}),p.css({position:"absolute",cursor:"pointer",top:"0px",width:"100%",height:"100%",left:"0px","z-index":"100",opacity:"0.0",filter:"alpha(opacity=0)","-ms-filter":"alpha(opacity=0)","-khtml-opacity":"0.0","-moz-opacity":"0.0"}),d.appendTo(s)):(d.appendTo(e("body")),d.css({margin:0,padding:0,display:"block",position:"absolute",left:"-250px"}),-1!=navigator.appVersion.indexOf("MSIE ")?s.attr("for",i):s.click(function(){p.click()}))}function f(a,t){return this.statusbar=e("<div class='ajax-file-upload-statusbar'></div>").width(t.statusBarWidth),this.preview=e("<img class='ajax-file-upload-preview' />").width(t.previewWidth).height(t.previewHeight).appendTo(this.statusbar).hide(),this.filename=e("<div class='ajax-file-upload-filename'></div>").appendTo(this.statusbar),this.progressDiv=e("<div class='ajax-file-upload-progress'>").appendTo(this.statusbar).hide(),this.progressbar=e("<div class='ajax-file-upload-bar'></div>").appendTo(this.progressDiv),this.abort=e("<div>"+t.abortStr+"</div>").appendTo(this.statusbar).hide(),this.cancel=e("<div>"+t.cancelStr+"</div>").appendTo(this.statusbar).hide(),this.done=e("<div>"+t.doneStr+"</div>").appendTo(this.statusbar).hide(),this.download=e("<div>"+t.downloadStr+"</div>").appendTo(this.statusbar).hide(),this.del=e("<div>"+t.deleteStr+"</div>").appendTo(this.statusbar).hide(),this.abort.addClass("ajax-file-upload-red"),this.done.addClass("ajax-file-upload-green"),this.download.addClass("ajax-file-upload-green"),this.cancel.addClass("ajax-file-upload-red"),this.del.addClass("ajax-file-upload-red"),this}function m(a,t){var r=null;return(r=t.customProgressBar?new t.customProgressBar(a,t):new f(a,t)).abort.addClass(a.formGroup),r.abort.addClass(t.abortButtonClass),r.cancel.addClass(a.formGroup),r.cancel.addClass(t.cancelButtonClass),t.extraHTML&&(r.extraHTML=e("<div class='extrahtml'>"+t.extraHTML()+"</div>").insertAfter(r.filename)),"bottom"==t.uploadQueueOrder?e(a.container).append(r.statusbar):e(a.container).prepend(r.statusbar),r}function v(t,o,s,l,n,d){var h={cache:!1,contentType:!1,processData:!1,forceSync:!1,type:o.method,data:o.formData,formData:o.fileData,dataType:o.returnType,headers:o.headers,beforeSubmit:function(a,r,d){if(0!=o.onSubmit.call(this,l)){if(o.dynamicFormData){var p=i(o.dynamicFormData());if(p)for(var h=0;h<p.length;h++)p[h]&&(o.serialize&&void 0!=o.fileData?d.formData.append(p[h][0],p[h][1]):d.data[p[h][0]]=p[h][1])}return o.extraHTML&&e(s.extraHTML).find("input,select,textarea").each(function(a,t){o.serialize&&void 0!=o.fileData?d.formData.append(e(this).attr("name"),e(this).val()):d.data[e(this).attr("name")]=e(this).val()}),!0}return s.statusbar.append("<div class='"+o.errorClass+"'>"+o.uploadErrorStr+"</div>"),s.cancel.show(),t.remove(),s.cancel.click(function(){x.splice(x.indexOf(t),1),u(n,l),s.statusbar.remove(),o.onCancel.call(n,l,s),n.selectedFiles-=l.length,c(o,n)}),!1},beforeSend:function(e,t){for(var r in t.headers)e.setRequestHeader(r,t.headers[r]);s.progressDiv.show(),s.cancel.hide(),s.done.hide(),o.showAbort&&(s.abort.show(),s.abort.click(function(){u(n,l),e.abort(),n.selectedFiles-=l.length,o.onAbort.call(n,l,s)})),a.formdata?s.progressbar.width("1%"):s.progressbar.width("5%")},uploadProgress:function(e,a,t,r){r>98&&(r=98);var i=r+"%";r>1&&s.progressbar.width(i),o.showProgress&&(s.progressbar.html(i),s.progressbar.css("text-align","center"))},success:function(a,r,i){if(s.cancel.remove(),F.pop(),"json"==o.returnType&&"object"==e.type(a)&&a.hasOwnProperty(o.customErrorKeyStr)){s.abort.hide();var d=a[o.customErrorKeyStr];return o.onError.call(this,l,200,d,s),o.showStatusAfterError?(s.progressDiv.hide(),s.statusbar.append("<span class='"+o.errorClass+"'>ERROR: "+d+"</span>")):(s.statusbar.hide(),s.statusbar.remove()),n.selectedFiles-=l.length,void t.remove()}n.responses.push(a),s.progressbar.width("100%"),o.showProgress&&(s.progressbar.html("100%"),s.progressbar.css("text-align","center")),s.abort.hide(),o.onSuccess.call(this,l,a,i,s),o.showStatusAfterSuccess?(o.showDone?(s.done.show(),s.done.click(function(){s.statusbar.hide("slow"),s.statusbar.remove()})):s.done.hide(),o.showDelete?(s.del.show(),s.del.click(function(){u(n,l),s.statusbar.hide().remove(),o.deleteCallback&&o.deleteCallback.call(this,a,s),n.selectedFiles-=l.length,c(o,n)})):s.del.hide()):(s.statusbar.hide("slow"),s.statusbar.remove()),o.showDownload&&(s.download.show(),s.download.click(function(){o.downloadCallback&&o.downloadCallback(a,s)})),t.remove()},error:function(e,a,r){s.cancel.remove(),F.pop(),s.abort.hide(),"abort"==e.statusText?(s.statusbar.hide("slow").remove(),c(o,n)):(o.onError.call(this,l,a,r,s),o.showStatusAfterError?(s.progressDiv.hide(),s.statusbar.append("<span class='"+o.errorClass+"'>ERROR: "+r+"</span>")):(s.statusbar.hide(),s.statusbar.remove()),n.selectedFiles-=l.length),t.remove()}};o.showPreview&&null!=d&&"image"==d.type.toLowerCase().split("/").shift()&&p(d,s.preview),o.autoSubmit?(t.ajaxForm(h),x.push(t),r()):(o.showCancel&&(s.cancel.show(),s.cancel.click(function(){x.splice(x.indexOf(t),1),u(n,l),t.remove(),s.statusbar.remove(),o.onCancel.call(n,l,s),n.selectedFiles-=l.length,c(o,n)})),t.ajaxForm(h))}var w=e.extend({url:"",method:"POST",enctype:"multipart/form-data",returnType:null,allowDuplicates:!0,duplicateStrict:!1,allowedTypes:"*",acceptFiles:"*",fileName:"file",formData:!1,dynamicFormData:!1,maxFileSize:-1,maxFileCount:-1,multiple:!0,dragDrop:!0,autoSubmit:!0,showCancel:!0,showAbort:!0,showDone:!1,showDelete:!1,showError:!0,showStatusAfterSuccess:!0,showStatusAfterError:!0,showFileCounter:!0,fileCounterStyle:"). ",showFileSize:!0,showProgress:!1,nestedForms:!0,showDownload:!1,onLoad:function(e){},onSelect:function(e){return!0},onSubmit:function(e,a){},onSuccess:function(e,a,t,r){},onError:function(e,a,t,r){},onCancel:function(e,a){},onAbort:function(e,a){},downloadCallback:!1,deleteCallback:!1,afterUploadAll:!1,serialize:!0,sequential:!1,sequentialCount:2,customProgressBar:!1,abortButtonClass:"ajax-file-upload-abort",cancelButtonClass:"ajax-file-upload-cancel",dragDropContainerClass:"ajax-upload-dragdrop",dragDropHoverClass:"state-hover",errorClass:"ajax-file-upload-error",uploadButtonClass:"ajax-file-upload",dragDropStr:"<span><b>Drag &amp; Drop Files</b></span>",uploadStr:"Upload",abortStr:"Abort",cancelStr:"Cancel",deleteStr:"Delete",doneStr:"Done",multiDragErrorStr:"Multiple File Drag &amp; Drop is not allowed.",extErrorStr:"is not allowed. Allowed extensions: ",duplicateErrorStr:"is not allowed. File already exists.",sizeErrorStr:"is not allowed. Allowed Max size: ",uploadErrorStr:"Upload is not allowed",maxFileCountErrorStr:" is not allowed. Maximum allowed files are:",downloadStr:"Download",customErrorKeyStr:"jquery-upload-file-error",showQueueDiv:!1,statusBarWidth:400,dragdropWidth:400,showPreview:!1,previewHeight:"auto",previewWidth:"100%",extraHTML:!1,uploadQueueOrder:"top",headers:{}},t);this.fileCounter=1,this.selectedFiles=0;var g="ajax-file-upload-"+(new Date).getTime();this.formGroup=g,this.errorLog=e("<div></div>"),this.responses=[],this.existingFileNames=[],a.formdata||(w.dragDrop=!1),a.formdata&&1!==w.maxFileCount||(w.multiple=!1),e(this).html("");var C=this,b=e("<div>"+w.uploadStr+"</div>");e(b).addClass(w.uploadButtonClass),function a(){if(e.fn.ajaxForm){if(w.dragDrop){var t=e('<div class="'+w.dragDropContainerClass+'" style="vertical-align:top;"></div>').width(w.dragdropWidth);e(C).append(t),e(t).append(b),e(t).append(e(w.dragDropStr)),o(C,w,t)}else e(C).append(b);e(C).append(C.errorLog),w.showQueueDiv?C.container=e("#"+w.showQueueDiv):C.container=e("<div class='ajax-file-upload-container'></div>").insertAfter(e(C)),w.onLoad.call(this,C),h(C,g,w,b)}else window.setTimeout(a,10)}(),this.startUpload=function(){e("form").each(function(a,t){e(this).hasClass(C.formGroup)&&x.push(e(this))}),x.length>=1&&r()},this.getFileCount=function(){return C.selectedFiles},this.stopUpload=function(){e("."+w.abortButtonClass).each(function(a,t){e(this).hasClass(C.formGroup)&&e(this).click()}),e("."+w.cancelButtonClass).each(function(a,t){e(this).hasClass(C.formGroup)&&e(this).click()})},this.cancelAll=function(){e("."+w.cancelButtonClass).each(function(a,t){e(this).hasClass(C.formGroup)&&e(this).click()})},this.update=function(a){w=e.extend(w,a),a.hasOwnProperty("url")&&e("form").each(function(t,r){e(this).attr("action",a.url)})},this.enqueueFile=function(e){e instanceof File&&l(w,C,[e])},this.reset=function(e){C.fileCounter=1,C.selectedFiles=0,C.errorLog.html(""),0!=e&&C.container.html("")},this.remove=function(){C.container.html(""),e(C).remove()},this.createProgress=function(e,a,t){var r=new m(this,w);r.progressDiv.show(),r.progressbar.width("100%");var o="";return o=w.showFileCounter?C.fileCounter+w.fileCounterStyle+e:e,w.showFileSize&&(o+=" ("+s(t)+")"),r.filename.html(o),C.fileCounter++,C.selectedFiles++,w.showPreview&&(r.preview.attr("src",a),r.preview.show()),w.showDownload&&(r.download.show(),r.download.click(function(){w.downloadCallback&&w.downloadCallback.call(C,[e],r)})),w.showDelete&&(r.del.show(),r.del.click(function(){r.statusbar.hide().remove();var a=[e];w.deleteCallback&&w.deleteCallback.call(this,a,r),C.selectedFiles-=1,c(w,C)})),r},this.getResponses=function(){return this.responses};var x=[],F=[],D=!1;return this}}(jQuery);
$(document).ready(function(){
	$("#sb_ruPload").uploadFile({
		url:"upload.php<?=self::$rupload ? "?ruPload=true&" : "?"?>path=<?=$path;?>",
		returnType:"json",
		multiple:true,
		dragDrop:true,
		serialize:<?=self::$rupload ? "true" : "false"?>,
		showFileCounter:false,
		showStatusAfterError:false,
		statusBarWidth:212,
		dragdropWidth:220,
		fileName:"file",
		dragDropStr:"<span><b><?=self::locale('dragDropStr')?></b></span>",
		abortStr:"x",
		cancelStr:"<?=self::locale('cancelStr')?>",
		doneStr:"<?=self::locale('doneStr')?>",
		multiDragErrorStr:"<?=self::locale('multiDragErrorStr')?>",
		extErrorStr:"<?=self::locale('extErrorStr')?>",
		sizeErrorStr:"<?=self::locale('sizeErrorStr')?>",
		uploadErrorStr:"<?=self::locale('uploadErrorStr')?>",
		uploadStr:"<?=self::locale('uploadStr')?>",
		<?php if(self::$rupload){ ?>onLoad:getdataruPload(),
		onSubmit:function(files){
			formruPload = {hash:"<?=$SESSIONHASH;?>", allow:[]};
			$.each(files, function(index, file){
				$.each(dataruPload, function(key, row){
					if(file == row){
						var replaceFile = confirm('<?=self::locale('replaceFile')?>');
						if(replaceFile) formruPload.allow.push(file);
					}
				});
			});
		},
		dynamicFormData:function(){
			return formruPload;
		},<?php } ?>
		afterUploadAll:function(obj){
			var statusbars = obj.container[0].children;
			$.each($(statusbars), function(index, element){
				$(element).delay(index * 700).fadeOut(900);
				$('#loader').show();
			});
			getdataruPload();
			setTimeout(function(){
				$(statusbars).remove();
				$('#loader').fadeOut(500);
				$('#maincontent').load(location.href+' #maincontent > *');
			}, statusbars.length * 700);
		},
		<?php if(self::$rupload){ ?>onSuccess:function(files,data,xhr,pd){
			notifyOk('<strong><?=self::locale('notifyOk')?></strong> ' + data['success']).popit().removeit();
		},
		onError:function(files,status,errMsg,pd){
			notifyError('<strong><?=self::locale('notifyOk')?></strong> ' + errMsg).popit().removeit();
		}<?php } ?>
	});
	$("#sb_ruPload").on("mouseenter",function(){if(ruPloadCheck==true){getdataruPload();ruPloadCheck=false;ruPloadTimeOut();}});function ruPloadTimeOut(){setTimeout(function(){ruPloadCheck=true;},ruPloadtime)}
});
function getdataruPload(){
	$.ajax({
		url:"upload.php?ruPload=true&path=<?=$path;?>",
		dataType:"json",
		data:{file_exists:'all'},
		success:function(existed){
			dataruPload = existed;
		}
	});
}
</script>
			<?php
		}
	}
	
	public static function translit($value){
		if(!self::$translit) return $value;
		$converter = array(
			'а' => 'a',    'б' => 'b',    'в' => 'v',     'г' => 'g',    'д' => 'd',
			'е' => 'e',    'ё' => 'e',    'ж' => 'zh',    'з' => 'z',    'и' => 'i',
			'й' => 'y',    'к' => 'k',    'л' => 'l',     'м' => 'm',    'н' => 'n',
			'о' => 'o',    'п' => 'p',    'р' => 'r',     'с' => 's',    'т' => 't',
			'у' => 'u',    'ф' => 'f',    'х' => 'h',     'ц' => 'c',    'ч' => 'ch',
			'ш' => 'sh',   'щ' => 'sch',  'ь' => '',	  'ы' => 'y',	 'ъ' => '',
			'э' => 'e',    'ю' => 'yu',   'я' => 'ya',
		);
	 
		$value = mb_strtolower($value);
		$value = strtr($value, $converter);
		$value = mb_ereg_replace('[^-0-9_a-z]', '-', $value);
		$value = mb_ereg_replace('[-]+', '-', $value);
		$value = trim($value, '-');	
		return $value;
	}
}

if(isset($_GET['ruPload']) && $_GET['ruPload'] == 'true'){
	$GS_ADMIN = $_SERVER['DOCUMENT_ROOT'].dirname($_SERVER['PHP_SELF']).'/';
	if(!cookie_check()) die(header('HTTP/1.0 404 Not Found'));
	if(isset($_GET['path']) && !empty($_GET['path'])){
		$path = str_replace('../','', $_GET['path']);
		$path = tsl("../data/uploads/".$path);
		if(!path_is_safe($path,GSDATAUPLOADPATH)) die();
		$subPath = str_replace('../','', $_GET['path']);
		$subFolder = tsl($subPath);
	}else{ 
		$path = "../data/uploads/";
		$subPath = ''; 
		$subFolder = '';
	}
	
	if(isset($_GET['file_exists']) && $_GET['file_exists'] == 'all'){
		$dir = array_diff(scandir($path), array('..', '.', '.htaccess', 'web.config'));
		$files = array();
		foreach($dir as $file){ if(!is_dir($path.$file)) $files[] = $file; }
		header("Content-type: application/json; charset=utf-8");
		echo json_encode($files);
		exit();
	}
	
	if(isset($_FILES["file"])){
		$ret = array();
		$errors = array();
		$messages = array();
		$replace = false;
		if(!is_array($_FILES["file"]["name"])){
			if($_FILES["file"]["error"] > 0) $errors[] = i18n_r('ERROR_UPLOAD');
			else{
				$file = $_FILES["file"]["name"];
				$extension = pathinfo($file,PATHINFO_EXTENSION);
				if(getDef('GSUPLOADSLC',true)) $extension = lowercase($extension);
				$name = pathinfo($file,PATHINFO_FILENAME);
				$name = ruPload::translit($name);
				$name = clean_img_name(to7bit($name));
				$base = $name . '.' . $extension;
				$file_loc = $path . $base;
				
				if(file_exists($file_loc)){
					if(empty($_POST['allow'])) $errors[] = ruPload::locale('file').' <u>'.$base.'</u> '.ruPload::locale('exiReplace');
					else{
						foreach($_POST['allow'] as $allow){
							if($allow == $base) $replace = true;
							else	$errors[] = ruPload::locale('file').' <u>'.$base.'</u> '.ruPload::locale('exiReplace');
						}
					}
				}else $replace = true;
				
				if($replace){
					if(validate_safe_file($_FILES["file"]["tmp_name"], $_FILES["file"]["name"])){
						move_uploaded_file($_FILES["file"]["tmp_name"], $file_loc);
						if(defined('GSCHMOD')){
							chmod($file_loc, GSCHMOD);
						}else{
							chmod($file_loc, 0644);
						}
						exec_action('file-uploaded');

						require_once($GS_ADMIN.'inc/imagemanipulation.php');	
						genStdThumb($subFolder,$base);					
						$messages[] = i18n_r('FILE_SUCCESS_MSG').': <a href="'. $SITEURL .'data/uploads/'.$subFolder.$base.'">'. $SITEURL .'data/uploads/'.$subFolder.$base.'</a>';
					}else{
						$messages[] = $_FILES["file"]["name"] .' - '.i18n_r('ERROR_UPLOAD');
					}
				}
			}
		}else $errors[] = ruPload::locale('packetUpd');
		
		if(sizeof($messages) != 0){
			foreach($messages as $msg){
				$ret['success'] = $msg;
			}
			header("Content-type: application/json; charset=utf-8");
			echo json_encode($ret);
		}
		if(sizeof($errors) != 0){
			foreach($errors as $msg){
				$ret['jquery-upload-file-error'] = $msg;
			}
			header("Content-type: application/json; charset=utf-8");
			echo json_encode($ret);
		}
	}
	exit();
}
?>