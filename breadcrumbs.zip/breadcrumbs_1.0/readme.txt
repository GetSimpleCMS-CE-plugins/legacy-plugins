just put both breadcrumbs.php file and breadcrumbs folder in plugin folder

breadcrumbs folder contain breadcrumbs-setting.php file to save settings from admin.