News Manager RSS plugin for GetSimple CMS
=========================================

Allows you to serve your News Manager blog as an RSS feed.

Author: Reed Murphy <reed@reedmurphy.net>

