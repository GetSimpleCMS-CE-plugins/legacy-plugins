<?php
/**
 * English Language File for DY Lorem Ipsum
**/

$i18n = array(
  'DY_LOREMIPSUM_PLUGIN_DESCRIPTION' => 'Generates Lorem Ipsum text'
);
