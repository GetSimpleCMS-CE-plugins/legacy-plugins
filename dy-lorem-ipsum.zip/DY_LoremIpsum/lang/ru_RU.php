<?php
/**
 * Russian Language File for DY Lorem Ipsum
**/

$i18n = array(
  'DY_LOREMIPSUM_PLUGIN_DESCRIPTION' => 'Генерирует текст Lorem Ipsum'
);
