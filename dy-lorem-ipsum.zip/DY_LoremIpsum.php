<?php
/*
Plugin Name: DY Lorem Ipsum
Version: 1.0
Description: Generates Lorem Ipsum text
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY Lorem Ipsum',                   # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                  # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  i18n_r($thisfile . '/DY_LOREMIPSUM_PLUGIN_DESCRIPTION'),   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

require_once GSPLUGINPATH . 'DY_LoremIpsum' . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'LoremIpsum.class.php';

add_filter('content', 'dyLoremIpsumShortcode');

function dyLoremIpsumShortcode($content) {
  // (% dyLoremIpsum type:'paragraph' tag:'p' count:'10' lorem:'false' %)
  $pattern = '(\(%\s+dyLoremIpsum\s+(.*)\s+%\))';
  return preg_replace_callback($pattern, 'dyLoremIpsumCallback', $content);
}

function dyLoremIpsumCallback($matches) {
  if (isset($matches[1])) {
    preg_match("/type\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
    if (isset($tmp[2])) {
      # Set type
      $type = $tmp[2];
      # Get and set tag
      preg_match("/tag\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $tag = isset($tmp[2]) ? $tmp[2] : false;
      # Get and set count
      preg_match("/count\\s*:\\s*([\"'])([\d]*?)\\1/", $matches[1], $tmp);
      $count = isset($tmp[2]) ? $tmp[2] : 1;      
      # Get and set lorem
      preg_match("/lorem\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
      $lorem = (isset($tmp[2]) && $tmp[2] === 'true') ? true : false; 
      $lipsum = new DY_LoremIpsum\LoremIpsum();
      $lipsum->setStartOption($lorem);
      if ($type == 'word' || $type == 'w') {
        return $lipsum->words($count, $tag);
      } elseif ($type == 'sentence' || $type == 's') {
        return $lipsum->sentences($count, $tag);
      } elseif ($type == 'paragraph' || $type == 'p') {
        return $lipsum->paragraphs($count, $tag);
      }
    }
  }
}

?>