<?php
/*
Plugin Name: Plugin Reorder
Description: Allows admin to change the plugin loader order
Version: 1.0
Author: David Shaner
Author URI: http://www.shaner.us/
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Plugin Reorder', 	
	'1.0', 		
	'David Shaner',
	'http://www.shaner.us/', 
	'Allows admin to change the plugin loader order',
	'plugins',
	'plugin_reorder'  
);

# Get website URL
$website_xml = GSDATAOTHERPATH.'website.xml';
$x = getXML($website_xml);
$website = $x->SITEURL;

# Check to see if URL has trailing slash
$trailing_slash = substr($website,-1);

if($trailing_slash !== '/'){
    $website = $website.'/';
}

# Create Sidebar
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Reorder Plugins','plugin_reorder'));

# Plugin XML file
$plugin_xml = GSDATAOTHERPATH .'plugins.xml';
$plugin_reorder_xml = GSDATAOTHERPATH .'plugins_reorder.xml';

/**
 * Main Function
 */
function plugin_reorder(){
    global $website;
    
    register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', TRUE);
    queue_script('jquery',GSBACK);

    register_script('jqueryui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js', '1.8.18', TRUE);
    queue_script('jqueryui',GSBACK);

    register_script('plugin_reorder', $website.'plugins/plugin_reorder/js/plugin_reorder.js', '1.0', TRUE);
    queue_script('plugin_reorder',GSBACK); 
    
    plugin_get_xml();
}

/**
 * Read in XML File
 */
function plugin_get_xml(){
    global $plugin_xml, $plugin_reorder_xml, $plugin, $enabled, $website;
    /*
    if(file_exists($plugin_reorder_xml)){
        $x = getXML($plugin_reorder_xml);
        create_plugin_form($x);
    } else
    */
    if (file_exists($plugin_xml)) {
        $x = getXML($plugin_xml);
        create_plugin_form($x);
    } else {
        echo '<p style="color:#cc0000;"><b>There are no plugins to reorder.</b></p>';
    }

}

/**
 * Create the Plugin Reorder Form
 */
function create_plugin_form($x){
    
    if(isset($_POST['submit'])){
        $plugins = $_POST['plugin'];
        $status = $_POST['enabled'];
        
        save_plugin_xml($plugins,$status);
    }
    
    ?>
    <style type="text/css">
    #moveable{
        cursor:move;
    }
    .moveable{
        text-indent:10px;
        font-size:14px;
        font-weight:bold;
        font-family: Verdana, Arial, sans-serif;
        width:100%;
        height:30px;
        line-height:30px;
        background-color:#CF3805;
        color:#ffffff;
        border-bottom:1px double #ffffff;
    }
    </style>
    <h3>Plugin Reorder</h3>
    <form action="<?php	echo $_SERVER ['REQUEST_URI']?>" method="post">
    <div id="moveable">
        <?php
        foreach($x as $y){
            $plugin = $y->plugin;
            $enabled = $y->enabled;
        ?>
        <div class="moveable"><?php echo $plugin; ?>
            <input type="hidden" name="plugin[]" value="<?php echo $plugin; ?>"/>
            <input type="hidden" name="enabled[]" value="<?php echo $enabled; ?>"/>
        </div>
        <?php
        }
        ?>
    </div>
    <br/>
    <p><input type="submit" id="submit" class="submit" value="Save Plugin Order" name="submit" /></p>
    </form>
    
    <?php
}

/**
 * Save the Plugin XML
 */
function save_plugin_xml($plugins,$status){
    /*
    $time = time() - 60;
   // array_reverse($plugins);
    
    foreach($plugins as $plugin){
        
        if (touch(GSPLUGINPATH.$plugin, $time)) {
            echo '<p>'.$time.' '.$plugin . ' modification time has been changed to present time</p>';
        } else {
            echo 'Sorry, could not change modification time of ' . $plugin;
        }
        $time = $time - 60;
    }
    */
    /**/
    global $plugin_xml, $plugin_reorder_xml;
    /**/
    $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>'); 
  
    //$components = $xml->addChild('item');
    
    for($i=0; $i < count($plugins); $i++){
        $components = $xml->addChild('item');  
        $c_note = $components->addChild('plugin');
        $c_note->addCData($plugins[$i]);
        $c_note = $components->addChild('enabled');
        $c_note->addCData($status[$i]);  
        /*
		$xml->addChild('plugin', $plugins[$i]);
		$xml->addChild('enabled', $status[$i]);
        */
        
    }
    //$xml->closeChild('item');
    $success = XMLsave($xml, GSDATAOTHERPATH."plugins.xml");
    
    if($success === TRUE){
        echo '<p style="color:#669933;"><b>Plugin Orders Saved.</b></p>';
    }
    /**/
    /*
    $xml = @new SimpleXMLElement('<item></item>');
    
    for($i=0; $i < count($plugins); $i++){
		$xml->addChild('plugin', $plugins[$i]);
		$xml->addChild('enabled', $status[$i]);
    }
    
    if (! $xml->asXML($plugin_reorder_xml)) {
        $error = i18n_r('CHMOD_ERROR');
    } else {
        $x = getXML($plugin_reorder_xml);
        foreach($x as $y){
            $plugin = $y->plugin;
            $enabled = $y->enabled;
            echo '<p>'.$plugin.' - '.$enabled.'</p>';
        }
        echo '<p style="color:#669933;"><b>Plugin Orders Saved.</b></p>';
    }
    */
}

/**
 * Save XML File
 */
function save_xml($xml, $file) {
	$success = $xml->asXML($file) === TRUE;
	
	if (defined('GSCHMOD')) {
		return $success && chmod($file, GSCHMOD);
	} else {
		return $success && chmod($file, 0755);
	}
}
?>