<?php
/*
Plugin Name: Plugin Reorder
Description: Allows admin to change the plugin loader order
Version: 1.0
Author: David Shaner
Author URI: http://www.shaner.us/
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Plugin Reorder', 	
	'1.0', 		
	'David Shaner',
	'http://www.shaner.us/', 
	'Allows admin to change the plugin loader order',
	'plugins',
	'plugin_reorder'  
);

# Get website URL
$website_xml = GSDATAOTHERPATH.'website.xml';
$x = getXML($website_xml);
$website = $x->SITEURL;

# Check to see if URL has trailing slash
$trailing_slash = substr($website,-1);

if($trailing_slash !== '/'){
    $website = $website.'/';
}

# Create Sidebar
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Reorder Plugins','plugin_reorder'));
add_action('plugins-sidebar','createSideMenu',array($thisfile,'Create New Plugin XML','create_new_plugin_xml'));

# Plugin XML file
$plugin_xml = GSDATAOTHERPATH .'plugins.xml';

/**
 * Main Function
 */
function plugin_reorder(){
    global $website;
    
    register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
    queue_script('jquery',GSBACK);

    register_script('jqueryui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js', '1.8.18', FALSE);
    queue_script('jqueryui',GSBACK);

    register_script('plugin_reorder', $website.'plugins/plugin_reorder/js/plugin_reorder.js', '1.0', TRUE);
    queue_script('plugin_reorder',GSBACK);
    
    $action_url = $_SERVER['QUERY_STRING'];
    $action = explode('&',$action_url);
    $action = $action[1];
    
    switch($action){
        case 'plugin_reorder':
            plugin_get_xml();
            break;
        case 'create_new_plugin_xml':
            create_plugin_xml('','');
            break;
    }
    
    
}

/**
 * Read in XML File
 */
function plugin_get_xml(){
    global $plugin_xml, $plugin_reorder_xml, $plugin, $enabled, $website;
    $x = null;
    if (file_exists($plugin_xml)) {
        //$x = getXML($plugin_xml);
        create_plugin_form();
    } else {
        echo '<p style="color:#cc0000;"><b>There are no plugins to reorder.</b></p>';
    }
}

/**
 * Create the Plugin Reorder Form
 */
function create_plugin_form(){
    global $plugin_xml;
    
    if(isset($_POST['submit'])){
        $plugins = $_POST['plugin'];
        $status = $_POST['enabled'];
        
        create_plugin_xml($plugins,$status);
    }
    ?>
    <style type="text/css">
    #moveable{
        cursor:move;
    }
    .moveable{
        text-indent:10px;
        font-size:14px;
        font-weight:bold;
        font-family: Verdana, Arial, sans-serif;
        width:100%;
        height:30px;
        line-height:30px;
        background-color:#CF3805;
        color:#ffffff;
        border-bottom:1px double #ffffff;
    }
    </style>
    <h3>Plugin Reorder</h3>
    <p>Drag the plugins to the order you want them to display on the frontend</p>
    <form action="<?php	echo $_SERVER ['REQUEST_URI']?>" method="post">
    <div id="moveable">
        <?php
        $plugin = null;
        $enabled = null;
        $x = getXML($plugin_xml);
        foreach($x as $y){
            $plugin = $y->plugin;
            $enabled = $y->enabled;
        ?>
        <div class="moveable"><?php echo $plugin; ?>
            <input type="hidden" name="plugin[]" value="<?php echo $plugin; ?>"/>
            <input type="hidden" name="enabled[]" value="<?php echo $enabled; ?>"/>
        </div>
        <?php
        }
        ?>
    </div>
    <br/>
    <p><input type="submit" id="submit" class="submit" value="Save Plugin Order" name="submit" /></p>
    </form>
    
    <?php
}

/**
 * Create the Plugin XML
 */
function create_plugin_xml($plugins,$status){
    global $plugin_xml;
    if($plugins === ''){
        $plugins_dir = scandir(GSPLUGINPATH);
        foreach($plugins_dir as $plugin_php){
            if(substr($plugin_php,0-4) === '.php'){
                $plugins[] = $plugin_php;
                $status[] = 'true';
            }
        }
    }
    
    $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>'); 
    
    for($i=0; $i < count($plugins); $i++){
        $components = $xml->addChild('item');  
        $c_note = $components->addChild('plugin');
        $c_note->addCData($plugins[$i]);
        $c_note = $components->addChild('enabled');
        $c_note->addCData($status[$i]);  
    }
    $success = XMLsave($xml, GSDATAOTHERPATH."plugins.xml");
    
    if($success === TRUE){
        echo '<p style="color:#669933;"><b>File was saved.</b></p>';
    }
}

/**
 * Save XML File
 */
function save_xml($xml, $file) {
	$success = $xml->asXML($file) === TRUE;
	
	if (defined('GSCHMOD')) {
		return $success && chmod($file, GSCHMOD);
	} else {
		return $success && chmod($file, 0755);
	}
}
?>