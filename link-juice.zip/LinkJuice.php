<?php
/*
Plugin Name: Link Juice
Description: Enable 301 redirection to all 404 URIs and non-existing subdomains (when wildcard is enabled) to main page, which is set in config.
Version: 1.0
Author: Mariusz Jakubowski
Author URI: http://www.mjw.pl/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Link Juice', 	
	'1.0', 		
	'Mariusz Jakubowski',
	'http://www.mjw.pl/', 
	'Enable 301 redirection to all 404 URIs and non-existing subdomains (when wildcard is enabled) to main page, which is set in config.',
	'seo',
	''  
);

# activate filter
add_action('index-pretemplate','redirection'); 

# functions
function redirection() {

  $parsedUrl = parse_url(find_url('index', null));

  if ($parsedUrl['host'] != $_SERVER['HTTP_HOST']) {
      header ('HTTP/1.1 301 Moved Permanently');
      header ('Location: ' . find_url('index', null));
      die();      
  }
  
  if (return_page_slug() == '404') {
      header ('HTTP/1.1 301 Moved Permanently');
      header ('Location: ' . find_url('index', null)); 
      die();      
  }

}

?>