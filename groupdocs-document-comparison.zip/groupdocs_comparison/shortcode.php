<?php

$numMaps=0;

function addGroupDocsComparison($atts, $content = null) {
 extract(gdcomp_shortcode_atts(array(
    "id" => null,
    "width" => '500',
    "height" => '600',
	"embedkey" => null
  ), $atts));
  return '<div><iframe src="https://apps.groupdocs.com/document-comparison/embed/'.$embedkey.'/'.$id.'?quality=50&use_pdf=False&download=False&referer=getsimple/1.0" frameborder="0" width="'.$width.'" height="'.$height.'"></iframe></div>';
}
gdcomp_add_shortcode('GroupDocsComparison','addGroupDocsComparison', '[groupdocs id="" embedkey=""  width="" height="" /]');
