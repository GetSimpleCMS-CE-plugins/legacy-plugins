<?php
$basket_version = "1.2.4";
/*
Plugin Name: GetSimple Basket MOD
Description: Add cart to GetSimple CMS
Version: 1.2.4
Author: Makhonin Pavel + Andrejus Semionovas
Author URI: http://pigios-svetaines.eu/projects/eshop-ra
*/

$thisfile=basename(__FILE__, ".php");
$settings_file = realpath(dirname(__FILE__)) .'/basket_plugin/basket_settings.xml';
$settings_file = str_replace('\\','/',$settings_file);
global $discounts_file;
$discounts_file = realpath(dirname(__FILE__)) .'/basket_plugin/basket_discounts.xml';
$discounts_file = str_replace('\\','/',$discounts_file);
global $history_dir;
$history_dir = realpath(dirname(__FILE__)) .'/basket_plugin/history/';
$history_dir = str_replace('\\','/',$history_dir);
global $HasErrorCaptcha;
$HasErrorCaptcha = '';
global $captcha_dir;
$captcha_dir = $SITEURL.'plugins/basket_plugin/antispam/';
global $HasErrormail;
$HasErrormail = false;
global $hasError;
$hasError = array();
global $sort_history;
$sort_history = array();

if (!file_exists($settings_file)) {
	$settings_data = @new SimpleXMLExtended('<data></data>');
	$settings_data->addChild('admin_mail', serialize('test@test.ru'));
	$settings_data->addChild('price_field_name', serialize('price'));
	$settings_data->addChild('image_show', serialize('Y'));
	$settings_data->addChild('image_field_name', serialize('image'));
	$settings_data->addChild('letter_header', serialize('New order was maked'));
	$settings_data->addChild('ok_text', serialize('Your order was accepted. We will contact you soon'));
	$settings_data->addChild('basket_styles', serialize('position:fixed; top: 0; right: 0; padding: 10px; border: 1px solid silver; background: #fff; z-index: 1000'));
	$settings_data->addChild('currency', serialize('$'));
	$settings_data->addChild('basket_message_positions', serialize('M'));
	$settings_data->addChild('save_history', serialize('Y'));
	$settings_data->addChild('show_delivery', serialize('N'));
	$settings_data->addChild('delivery', serialize('Pickup,By post,Courier'));
	$settings_data->addChild('show_payment', serialize('N'));
	$settings_data->addChild('payment', serialize('Cash when pickup,Cash to courier,By Card when pickup,By Card to courier,Cash(on post)'));
	$settings_data->addChild('ajax', serialize('Y'));
	$settings_data->addChild('jquery_include', serialize('N'));
	$settings_data->addChild('show_history_to_user', serialize('Y'));
	$settings_data->addChild('use_discounts', serialize('Y'));
	$settings_data->addChild('allow_print', serialize('Y'));
	$settings_data->addChild('pretty_include', serialize('N'));
	$settings_data->addChild('buyer_mail', serialize('N'));
	$settings_data->addChild('related', serialize('N'));
	XMLsave($settings_data, $settings_file);
} elseif (!empty($_POST['basket_settings_change'])) {
	unlink($settings_file);
	$settings_data = @new SimpleXMLExtended('<data></data>');
	$settings_data->addChild('admin_mail', serialize($_POST['admin_mail']));
	$settings_data->addChild('price_field_name', serialize($_POST['price_field_name']));
	$settings_data->addChild('rebate_field_name', serialize($_POST['rebate_field_name']));
	$settings_data->addChild('percent_field_name', serialize($_POST['percent_field_name']));
	$settings_data->addChild('image_show', serialize($_POST['image_show']));
	$settings_data->addChild('image_field_name', serialize($_POST['image_field_name']));
	$settings_data->addChild('letter_header', serialize($_POST['letter_header']));
	$settings_data->addChild('ok_text', serialize($_POST['ok_text']));
	$settings_data->addChild('basket_styles', serialize($_POST['basket_styles']));
	$settings_data->addChild('currency', serialize($_POST['currency']));
	$settings_data->addChild('basket_message', serialize($_POST['basket_message']));
	$settings_data->addChild('basket_message_positions', serialize($_POST['basket_message_positions']));
	$settings_data->addChild('save_history', serialize($_POST['save_history']));
	$settings_data->addChild('show_delivery', serialize($_POST['show_delivery']));
	$settings_data->addChild('delivery', serialize($_POST['delivery']));
	$settings_data->addChild('show_payment', serialize($_POST['show_payment']));
	$settings_data->addChild('payment', serialize($_POST['payment']));
	$settings_data->addChild('ajax', serialize($_POST['ajax']));
	$settings_data->addChild('jquery_include', serialize($_POST['jquery_include']));
	$settings_data->addChild('show_history_to_user', serialize($_POST['show_history_to_user']));
	$settings_data->addChild('use_discounts', serialize($_POST['use_discounts']));
	$settings_data->addChild('allow_print', serialize($_POST['allow_print']));
	$settings_data->addChild('pretty_include', serialize($_POST['pretty_include']));
	$settings_data->addChild('basketshow', serialize($_POST['basketshow']));
	$settings_data->addChild('basketchilds', serialize($_POST['basketchilds']));
	$settings_data->addChild('basket_pages', serialize($_POST['basket_pages']));
	$settings_data->addChild('buyer_mail', serialize($_POST['buyer_mail']));
	$settings_data->addChild('related', serialize($_POST['show_related']));
	$settings_data->addChild('related_count', serialize($_POST['related_count']));
	XMLsave($settings_data, $settings_file);
} elseif (!empty($_POST['demo_spec_page'])) {
	$spec_page_file = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_basket-items.xml';
	$copy_path = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_basket-items.xml';
	copy(str_replace('\\','/',$spec_page_file), str_replace('\\','/',$copy_path));
	$spec_page_file2 = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_basket-items-with-discounts.xml';
	$copy_path2 = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_basket-items-with-discounts.xml';
	copy(str_replace('\\','/',$spec_page_file2), str_replace('\\','/',$copy_path2));
} elseif (!empty($_POST['demo_spec_laptop'])) {
	$spec_page_file = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_laptops-items.xml';
	$copy_path = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_laptops-items.xml';
	copy(str_replace('\\','/',$spec_page_file), str_replace('\\','/',$copy_path));
}
 elseif (!empty($_POST['demo_spec_tv'])) {
	$spec_page_file = realpath(dirname(__FILE__)) .'/basket_plugin/i18n_special_tv-items.xml';
	$copy_path = substr(dirname(__FILE__),0,-7).'/data/other/i18n_special_tv-items.xml';
	copy(str_replace('\\','/',$spec_page_file), str_replace('\\','/',$copy_path));
}

if (file_exists($settings_file)) {
	$xml = getXML($settings_file);
	global $basket_settings;
	$basket_settings['ADMIN_MAIL'] = unserialize($xml->admin_mail);
	$basket_settings['PRICE_FIELD_NAME'] = unserialize($xml->price_field_name);
	$basket_settings['REBATE_FIELD_NAME'] = unserialize($xml->rebate_field_name);
	$basket_settings['PERCENT_FIELD_NAME'] = unserialize($xml->percent_field_name);
	$basket_settings['IMAGE_SHOW'] = unserialize($xml->image_show);
	$basket_settings['IMAGE_FIELD_NAME'] = unserialize($xml->image_field_name);
	$basket_settings['LETTER_HEADER'] = unserialize($xml->letter_header);
	$basket_settings['OK_TEXT'] = unserialize($xml->ok_text);
	$basket_settings['BASKET_STYLES'] = unserialize($xml->basket_styles);
	$basket_settings['CURRENCY'] = unserialize($xml->currency);
	$basket_settings['BASKET_MESSAGE'] = unserialize($xml->basket_message);
	$basket_settings['BASKET_MESSAGE_POSITION'] = unserialize($xml->basket_message_positions);
	$basket_settings['SAVE_HISTORY'] = unserialize($xml->save_history);
	$basket_settings['SHOW_DELIVERY'] = unserialize($xml->show_delivery);
	$basket_settings['DELIVERY'] = explode(',',unserialize($xml->delivery));
	$basket_settings['SHOW_PAYMENT'] = unserialize($xml->show_payment);
	$basket_settings['PAYMENT'] = explode(',',unserialize($xml->payment));
	$basket_settings['AJAX'] = unserialize($xml->ajax);
	$basket_settings['JQUERY_INCLUDE'] = unserialize($xml->jquery_include);
	$basket_settings['SHOW_HISTORY_TO_USER'] = unserialize($xml->show_history_to_user);
	$basket_settings['USE_DISCOUNTS'] = unserialize($xml->use_discounts);
	$basket_settings['ALLOW_PRINT'] = unserialize($xml->allow_print);
	$basket_settings['PRETTY_INCLUDE'] = unserialize($xml->pretty_include);
	$basket_settings['BASKET_SHOW'] = unserialize($xml->basketshow);
	$basket_settings['BASKET_CHILDS'] = unserialize($xml->basketchilds);
	$basket_settings['BASKET_SHOW_PAGES'] = unserialize($xml->basket_pages);
	$basket_settings['BUYER_MAIL'] = unserialize($xml->buyer_mail);
	$basket_settings['SHOW_RELATED'] = unserialize($xml->related);
	if(isset($xml->related_count)) $basket_settings['RELATED_COUNT'] = unserialize($xml->related_count);
}

# language support
i18n_merge($thisfile, substr($LANG,0,2)) || i18n_merge($thisfile, $LANG) || i18n_merge($thisfile, 'en') || i18n_merge($thisfile, 'en_US');

register_plugin(
	$thisfile,
	$MESS['register_plugin_name'],
	$basket_version,
	'Makhonin Pavel + Andrejus Semionovas',
	'http://pigios-svetaines.eu/projects/eshop-ra',
	$MESS['register_plugin_desc'],
	'commerce', 
	'basket_settings_show'
);

global $plugin_info, $live_plugins;
$coomerce_tab = false;
$commerce_couter = 0;
foreach($plugin_info as $key=>$value) {
	if($value['page_type'] == "commerce") {
		if($live_plugins[$key.".php"] == "true") $commerce_couter++;
	}
}

// add some actions
if($commerce_couter == 1) {
	add_action('nav-tab','createNavTab',array('commerce',$thisfile,'Commerce'),'basket_settings_show');
}
add_action('commerce-sidebar','createSideMenu',array($thisfile,$MESS['tab_sidebar_settings_name'], 'settings'));

add_action('index-pretemplate','basket_logic');
add_action('theme-footer','basket_small_show');

if (isset($_GET['basket']) && $_GET['basket'] == 'Y') {
	add_action('index-pretemplate','set_basket_title');
	add_action('content-top','basket_big');
}

if (isset($basket_settings['SHOW_RELATED']) && $basket_settings['SHOW_RELATED'] == 'Y' ) {
	add_action('content-bottom','show_related_items');
}

if ($basket_settings['SAVE_HISTORY'] == 'Y') {
	add_action('admin-pre-header','history_logic');
	add_action('commerce-sidebar','createSideMenu',array($thisfile,$MESS['tab_sidebar_history_name'], 'history'));
}
if (isset($_GET['history']) && $_GET['history'] == 'Y' && $basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') {
	add_action('index-pretemplate','history_page_title');
	add_action('content-top','history_page');
}
if ($basket_settings['AJAX'] == 'Y') {
	add_action('theme-footer','ajax_basket');
	register_script('jqueryform', $SITEURL.'plugins/basket_plugin/js/jquery.form.min.js', '3.50',TRUE);
	queue_script('jqueryform', GSFRONT); 
}
if ($basket_settings['USE_DISCOUNTS'] == 'Y') {
	add_action('admin-pre-header','discounts_logic');
	add_action('commerce-sidebar','createSideMenu',array($thisfile,$MESS['tab_sidebar_discounts_name'], 'discounts'));
}
if ($basket_settings['PRETTY_INCLUDE'] == 'Y') {
	add_action('theme-footer','pretty_photo');
	register_script('prettyphoto', $SITEURL.'plugins/basket_plugin/js/jquery.prettyPhoto.js', '3.1.5',TRUE);
	queue_script('prettyphoto', GSFRONT);
	register_script('prettyload', $SITEURL.'plugins/basket_plugin/js/pretty_load.js', '3.1.5',TRUE);
	queue_script('prettyload', GSFRONT);
}
if ($basket_settings['JQUERY_INCLUDE'] == 'Y') {
	register_script('jquery_cloud', 'http://code.jquery.com/jquery-2.1.1.min.js', '2.1.1',FALSE);
	queue_script('jquery_cloud', GSFRONT);
}
if (file_exists(GSDATAOTHERPATH.'banklinks.xml')) $basket_settings['BASKET_BANK_LINKS'] = true;
else $basket_settings['BASKET_BANK_LINKS'] = false;

function basket_logic() {
	if (session_id() === "") {
	   session_start();
	}
	global $basket_settings; global $MESS; global $history_dir; global $discounts_file; global $SITEURL;
	global $language; global $HasErrorCaptcha; global $captcha_dir; global $HasErrormail; global $hasError;
	if(isset($_SESSION['BASKET']['DISCOUNT']['MESSAGE'])) $_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = '';
	if(basename(dirname($_SERVER['PHP_SELF'])) != 'admin') {
		if(isset($_SESSION['language'])) {
			$language = unserialize($_SESSION['language']);
		}
		else {
			$dir = GSUSERSPATH;
			if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
					while (($file = readdir($dh)) !== false) {
						if($file == "." ||  $file == ".." || is_dir($dir.'/'.$file) || $file == ".htaccess") { continue; }
						else {
							$ext = substr($file, strrpos($file, '.') + 1);
							if(in_array($ext, array("xml","XML"))) {
								$file_xml = getXML($dir.$file);
								if(isset($file_xml->PERMISSIONS->ADMIN) && $file_xml->PERMISSIONS->ADMIN != "") continue;
								else $language = substr($file_xml->LANG,0,2);
							}
						}
					}
				} 
				closedir($dh);
				$_SESSION['language'] = serialize($language);
			}
		} 
		if(isset($_GET['setlang'])) {
			$language = $_GET['setlang'];
			$_SESSION['language'] = serialize($language);
		}
		
		$location = 'plugins/basket_plugin';
		if(isset($language)) {
			if(strlen($language>2)) $language = substr(language,0,2);
		}
		$file_headers = @get_headers($location);
		if (stripos($file_headers[0],"404 Not Found") >0  || (stripos($file_headers[0], "302 Found") > 0 && stripos($file_headers[7],"404 Not Found") > 0)){
			include($location.'/lang/en.php');
		}
		else {
			include($location.'/lang/'.$language.'.php');
		}
	}

	// if form was submitted
	if (!empty($_POST)) {
		if (isset($_POST['order_submit']) && !empty($_POST['order_submit'])) {
			$Captcha = filter_var($_POST['captcha'], FILTER_SANITIZE_STRING);
			if (empty($Captcha) || $Captcha != $_SESSION['digit']) {
				$HasErrorCaptcha = "has-error";
			}
			else {
				$user_mail = filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL);
				$mail_part = explode("@",$user_mail);
				if(checkdnsrr(array_pop($mail_part),"MX")){
					$HasErrormail = false;
				} else {
					$HasErrormail = true;
				}
			}
			$counter = 1;
			$next_nr = 0;
				if ($handle = opendir($history_dir)) {
					while (false !== ($entry = readdir($handle))) {
						if ($entry != "." && $entry != "..") {
							$xmls = getXML($history_dir.$entry);
							if(!isset($xmls->order_nr)) {
								$xmls->addChild('order_nr', serialize($counter));
								XMLsave($xmls, $history_dir.$entry);
							}
							$get_nr = unserialize($xmls->order_nr);
							if($get_nr > $next_nr) $next_nr = $get_nr;
							$arFiles[] = array(
								"PATH" => $history_dir.$entry,
								"CREATED" => filectime($history_dir.$entry)
							);
							
							$counter++;
						}
					}
					closedir($handle);
					$basket_settings['ORDER_NR'] = $next_nr+1;
					unset($xmls);
				}
		}
	  if(empty($HasErrorCaptcha) && !$HasErrormail) {
		// check discount
		if (!empty($_POST['discount_input']) && !empty($_POST['discount_code'])) {
			if(isset($_SESSION['BASKET']['DISCOUNT']['MESSAGE'])) $_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = '';
			// check for illegal characters
			if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _.-]+$/u', $_POST['discount_code'])) {
				$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['bad_characters_exists'];
				$hasError[] = 'discount_code';
			}
			else {
			$sanitize = filter_var($_POST['discount_code'], FILTER_SANITIZE_STRING);
			$arDiscounts = getXML($discounts_file);
			if ($node = $arDiscounts->xpath("//discount[code='".$sanitize."']")) {
				if (intVal($node[0]->use) > 0) {
					$_SESSION['BASKET']['DISCOUNT']['CODE'] = $sanitize;
					$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] = 'Y';
					$_SESSION['BASKET']['DISCOUNT']['PERCENT'] = (int)$node[0]->value;
					$_SESSION['BASKET']['DISCOUNT']['SUM'] = ceil($_SESSION['BASKET']['SUM'] * ( 100 - (int)$node[0]->value ) / 100);
					$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_accepted'].' '.ceil($_SESSION['BASKET']['SUM'] * ( 100 - (int)$node[0]->value ) / 100).' '.$basket_settings['CURRENCY'].'. '.$MESS['cart_page_discount_persent'].' '.(int)$node[0]->value.'%';
				} else {
					unset($_SESSION['BASKET']['DISCOUNT']);
					$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_was_used'];
				}
			} else {
				unset($_SESSION['BASKET']['DISCOUNT']);
				$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['cart_page_discount_not_exists'];
			}
			}
		}
		// send a letter
		if (!empty($_POST['order_submit']) && 0 < count($_SESSION['BASKET']['ITEMS'])) {
			// check for illegal characters
			if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _.-]+$/u', $_POST['order_name'])) {
				$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['bad_characters_exists'];
				$hasError[] = 'order_name';
			}
			if (!preg_match('/^\+?\d+$/', $_POST['order_phone'])) {
				$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['bad_characters_exists'];
				$hasError[] = 'order_phone';
			}
			if(!empty($_POST['order_text'])) {
				if (!preg_match('/^[-\':,. \p{L}\p{N}]+$/u', $_POST['order_text'])) {
					$_SESSION['BASKET']['DISCOUNT']['MESSAGE'] = $MESS['bad_characters_exists'];
					$hasError[] = 'order_text';
				}
			}
			if(count($hasError) > 0) return;
			
			if (!empty($_POST['paymentgroup']) || !empty($_POST['banklinkgroup'])) {
				add_action('content-top','bank_payment');
				$basket_settings['WAIT_FOR_PAYMENT'] = true;
				return;
			}
			// some data
			$encode = 'UTF-8';
			if (!empty($_POST['order_delivery']) || !empty($_POST['order_payment'])) {
				$delivery = ''; $payment = '';
				if (!empty($_POST['order_delivery'])) {
					$delivery = '<p><strong>'.$MESS['in_letter_delivery_label'].'</strong> '.filter_var($_POST['order_delivery'], FILTER_SANITIZE_STRING).'</p>';
				}
				if (!empty($_POST['order_payment'])) {
					$payment = '<p><strong>'.$MESS['in_letter_payment_label'].'</strong> '.filter_var($_POST['order_payment'], FILTER_SANITIZE_STRING).'</p>';
				}
			}
			if (@$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] == 'Y') {
				$discount = '<p><strong>'.$_SESSION['BASKET']['DISCOUNT']['MESSAGE'].'</strong></p>';
				$discount .= '<p><strong>'.$MESS['in_letter_discount_was_used'].'</strong> <i>'.$_SESSION['BASKET']['DISCOUNT']['CODE'].'</i></p>';
				$arDiscounts = getXML($discounts_file);
				if ($node = $arDiscounts->xpath("//discount[code='".$_SESSION['BASKET']['DISCOUNT']['CODE']."']")) {
					$use = (int)$node[0]->use - 1;
					unset($node[0]->use);
					$node[0]->addChild('use',$use);
					XMLsave($arDiscounts, $discounts_file);
				}
			}
			// make order items to string
			$orderstring = '';
			foreach ($_SESSION['BASKET']['ITEMS'] as $arItem) {
				$item_price = number_format(str_replace(array(",", " "), array(".", ""), $arItem['PRICE']), 2, '.', '');
				if (strpos($arItem['LINK'], "?lang")===false || strpos($arItem['LINK'], "?setlang")===false) $arItem['LINK'] = $arItem['LINK']."?setlang=".$language;
				if (strpos($arItem['LINK'], $SITEURL)===false) $item_link = $SITEURL.str_replace("?lang", "?setlang", $arItem['LINK']);
				else $item_link = str_replace("?lang", "?setlang", $arItem['LINK']);
				$orderstring .= '
					<tr>
						<td><a href="'.$item_link.'" target="_blank">'.htmlspecialchars_decode($arItem['NAME']).'</a></td>
						<td style="text-align:right">'.$item_price.' '.$basket_settings['CURRENCY'].'</td>
						<td style="text-align:center">'.$arItem['QUANTITY'].'</td>
						<td style="text-align:right">'.number_format($arItem['QUANTITY'] * $item_price, 2, '.', '').' '.$basket_settings['CURRENCY'].'</td>
					</tr>
				';
			}
			
			// letter message
			if (@$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] == 'Y') $sum_total = number_format(str_replace(array(",", " "), array(".", ""), $_SESSION['BASKET']['DISCOUNT']['SUM']), 2, '.', '');
			else $sum_total = number_format(str_replace(array(",", " "), array(".", ""), $_SESSION['BASKET']['SUM']), 2, '.', '');
			$message = '
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
			<html xmlns="http:=//www.w3.org/1999/xhtml">
			<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>'.filter_var($_POST['order_name'], FILTER_SANITIZE_STRING).'</title></head><body>
				<p>'.date("d-m-Y (H:i:s)",time()).' '.$_SERVER['HTTP_HOST'].' '.$MESS['in_letter_order_was_created'].'</p>
				<p><strong>'.$MESS['history_page_insert_number'].':</strong> '.filter_var($basket_settings['ORDER_NR'], FILTER_SANITIZE_NUMBER_INT).'</p>
				<p><strong>'.$MESS['in_letter_user_name'].'</strong> '.filter_var($_POST['order_name'], FILTER_SANITIZE_STRING).'</p>
				<p><strong>'.$MESS['in_letter_user_phone'].'</strong> '.filter_var($_POST['order_phone'], FILTER_SANITIZE_STRING).'</p>
				<p><strong>'.$MESS['in_letter_user_email'].'</strong> '.filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL).'</p>
				'.@$delivery.@$payment.@$discount.'
				<p><strong>'.$MESS['in_letter_user_message'].'</strong> '.filter_var(trim($_POST['order_text']), FILTER_SANITIZE_STRING).'</p>
				<br />
				<h2>'.$MESS['in_letter_order_list_title'].'</h2>
				<table border="1" cellspacing="1" cellpadding="5" width="100%">
					<thead>
						<tr>
							<th>'.$MESS['table_name_column'].'</th>
							<th>'.$MESS['table_price_column'].'</th>
							<th>'.$MESS['table_quantity_column'].'</th>
							<th>'.$MESS['table_sum_column'].'</th>
						</tr>
					</thead>
					<tbody>
						'.$orderstring.'
					</tbody>
					<tfoot>
						<tr>
							<td colspan="4" align="right"><strong> '.$sum_total.' '.$basket_settings['CURRENCY'].'</strong></td>
						</tr>
					</tfoot>
				</table>
				<p><i>'.$MESS['order_status_desc'].'</i>'.$MESS['in_letter_click'].'<a href="'.$SITEURL.'order-info/?history=Y&order='.filter_var($basket_settings['ORDER_NR'], FILTER_SANITIZE_NUMBER_INT).'&user='.filter_var($_POST['order_name'], FILTER_SANITIZE_STRING).'&setlang='.$language.'">'.$MESS['in_letter_your_order'].'</a></p>
			</body></html>
			';
			// Create Page for Customer Order preview
			if (!file_exists(GSDATAPAGESPATH.'order-info.xml')) {
				$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
				$xml->addChild('pubDate', date(DATE_RFC2822));
				$dataval = $xml->addChild('title');
				$dataval->addCData("Order Info");
				$dataval = $xml->addChild('url');
				$dataval->addCData("[order-info");
				$dataval = $xml->addChild('meta');
				$dataval->addCData("");
				$dataval = $xml->addChild('metad');
				$dataval->addCData("");
				$dataval = $xml->addChild('menu');
				$dataval->addCData("");
				$dataval = $xml->addChild('menuOrder');
				$dataval->addCData("0");
				$dataval = $xml->addChild('menuStatus');
				$dataval->addCData("");
				$dataval = $xml->addChild('template');
				$dataval->addCData("template.php");
				$dataval = $xml->addChild('parent');
				$dataval->addCData("");
				$dataval = $xml->addChild('content');
				$dataval->addCData("");
				$dataval = $xml->addChild('private');
				$dataval->addCData("");
				$dataval = $xml->addChild('author');
				$dataval->addCData("basket_plugin_mod");
				$xml->asXML(GSDATAPAGESPATH.'order-info.xml'); 
			}
			// send a letters
			if(isset($MESS['LETTER_HEADER'])) $headtxt  = "=?utf-8?b?".base64_encode($MESS['LETTER_HEADER'])."?=";
			else $headtxt = $basket_settings['LETTER_HEADER'];
			$headers  = "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html  charset=utf-8\r\n";
			$headers .= "Content-Transfer-Encoding: 8bit\r\n";
			$headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
			$headers .= "From: \"".filter_var($_POST['order_name'], FILTER_SANITIZE_STRING)."\" <".filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL).">\r\n";
			$headers .= "X-Mailer: My Send E-mail\r\n";
			require_once(realpath(dirname(__FILE__)).'/basket_plugin/phpmailer/class.phpmailer.php');
				$mail = new PHPMailer;
				$mail->CharSet = "UTF-8";
				$mail->From = filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL);
				$mail->FromName = filter_var($_POST['order_name'], FILTER_SANITIZE_STRING);
				$mail->addAddress(filter_var($basket_settings['ADMIN_MAIL'], FILTER_SANITIZE_EMAIL), filter_var($_POST['order_name'], FILTER_SANITIZE_STRING));
				$mail->addReplyTo(filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL), filter_var($_POST['order_name'], FILTER_SANITIZE_STRING));
				$mail->isHTML(true);
				$mail->Subject = $MESS['in_letter_order_was_created'];
				$mail->Body = $message;
				$mail->setLanguage($language);
				if(!$mail->send()) {
					echo 'Message could not be sent.';
					echo 'Mailer Error: ' . $mail->ErrorInfo;
				} else {
					echo 'Message has been sent';
				}
			if (isset($basket_settings['BUYER_MAIL']) && $basket_settings['BUYER_MAIL'] == 'Y') {
				if(isset($MESS['LETTER_HEADER'])) $headtxt  = "=?utf-8?b?".base64_encode($MESS['LETTER_HEADER'])."?=";
				else $headtxt = $basket_settings['LETTER_HEADER'];
				$headers  = "MIME-Version: 1.0\r\n";
				$headers .= 'Message-ID: <' .filter_var($basket_settings['ORDER_NR'], FILTER_SANITIZE_NUMBER_INT). ">\r\n";
				$headers .= "Content-Type: text/html; charset=utf-8\r\n";
				$headers .= "Content-Transfer-Encoding: 8bit\r\n";
				$headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
				$headers .= "From: \"".filter_var($_POST['order_name'], FILTER_SANITIZE_STRING)."\" <".filter_var($basket_settings['ADMIN_MAIL'], FILTER_SANITIZE_EMAIL).">\r\n";
				$headers .= "X-Mailer: My Send E-mail\r\n";
				require_once(realpath(dirname(__FILE__)).'/basket_plugin/phpmailer/class.phpmailer.php');
				$mail = new PHPMailer;
				$mail->From = filter_var($basket_settings['ADMIN_MAIL'], FILTER_SANITIZE_EMAIL);
				$mail->FromName = filter_var($_POST['order_name'], FILTER_SANITIZE_STRING);
				$mail->addAddress(filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL), 'Customer');
				$mail->addReplyTo(filter_var($basket_settings['ADMIN_MAIL'], FILTER_SANITIZE_EMAIL), filter_var($_POST['order_name'], FILTER_SANITIZE_STRING));
				$mail->Subject = $MESS['in_letter_order_was_created'];
				$mail->Body    = $message;
				$mail->AltBody = $message;
				if(!$mail->send()) {
					echo 'Message could not be sent.';
					echo 'Mailer Error: ' . $mail->ErrorInfo;
				} else {
					echo 'Message has been sent';
				}
			}
			if ($basket_settings['SAVE_HISTORY'] == 'Y') {
				global $history_dir;
				$orderxml = @new SimpleXMLExtended('<data></data>');
				$file = $history_dir.date('d-m-Y_H-i-m',time()).'.xml';
				$orderxml->addChild('date', serialize(date('d-m-Y H:i:m',time())));
				$orderxml->addChild('name', serialize(filter_var($_POST['order_name'], FILTER_SANITIZE_STRING)));
				$orderxml->addChild('phone', serialize(filter_var($_POST['order_phone'], FILTER_SANITIZE_STRING)));
				$orderxml->addChild('email', serialize(filter_var($_POST['order_email'], FILTER_SANITIZE_EMAIL)));
				$orderxml->addChild('message', serialize(filter_var(str_replace('"', "'", $_POST['order_text']), FILTER_SANITIZE_STRING)));
				$orderxml->addChild('items', serialize(count($_SESSION['BASKET']['ITEMS'])));
				if (@$_SESSION['BASKET']['DISCOUNT']['ACCEPTED'] == 'Y') {
					$sum_total_discount = number_format(str_replace(array(",", " "), array(".", ""), $_SESSION['BASKET']['DISCOUNT']['SUM']), 2, '.', '');
					$sum_total = number_format(str_replace(array(",", " "), array(".", ""), $_SESSION['BASKET']['SUM']), 2, '.', '');
					$orderxml->addChild('sum', serialize('<s>'.$sum_total.'</s><span style="color:red;padding-left:10px;">'.$sum_total_discount.'</span>'));
				} else {
					$sum_total = number_format(str_replace(array(",", " "), array(".", ""), $_SESSION['BASKET']['SUM']), 2, '.', '');
					$orderxml->addChild('sum', serialize($sum_total));
				}
				$orderxml->addChild('status', serialize($MESS['history_status_default']));
				$orderxml->addChild('admin_message', serialize(''));
				$orderxml->addChild('order', htmlspecialchars('<table style="margin-bottom:0" class="order-table"><thead><tr><th>'.$MESS['table_name_column'].'</th><th>'.$MESS['table_price_column'].'</th><th>'.$MESS['table_quantity_column'].'</th><th>'.$MESS['table_sum_column'].'</th></tr></thead><tbody>'.$orderstring.'</tbody></table>'.@$delivery.@$payment.@$discount));
				$orderxml->addChild('order_nr', serialize($basket_settings['ORDER_NR']));
				XMLsave($orderxml, $file);
			}
			if(isset($MESS['OK_TEXT'])) $okTxt = $MESS['OK_TEXT'];
			else $okTxt = $basket_settings['OK_TEXT'];
			if ($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') {
				$arFiles = array();
				if ($handle = opendir($history_dir)) {
					while (false !== ($entry = readdir($handle))) {
						if ($entry != "." && $entry != "..") {
							$arFiles[] = array(
								"PATH" => $history_dir.$entry,
								"CREATED" => filectime($history_dir.$entry)
							);
						}
					}
					closedir($handle);
				}
				// clear data and session and make SUCESS TEXT for user
				$_SESSION['BASKET']['OK'] = $okTxt.'<br>'.$MESS['order_number'].' <strong style="font-size:large">'.$basket_settings['ORDER_NR'].'</strong>';
				if($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') $_SESSION['BASKET']['OK'] .= $MESS['order_status_desc'];
				unset($arFiles);
			} else {
				$_SESSION['BASKET']['OK'] = $okTxt;
			}
			unset($_SESSION['BASKET']['ITEMS']);
			unset($_SESSION['BASKET']['DISCOUNT']);
			unset($hasError); unset($_POST['order_name']); unset($_POST['order_phone']); unset($_POST['order_text']);
		}
		// add item to cart logic
		elseif(!empty($_POST['add_item']) && $_POST['quantity'] !== '0') {
			if(isset($_POST['id'])) {
				$item_id = trim(filter_var($_POST['id'], FILTER_SANITIZE_STRING));
				$item_id = stripslashes($item_id);
				$item_id = strip_tags($item_id);
				$item_id = htmlspecialchars($item_id);
				$is_page = isFile($item_id.".xml", GSDATAPAGESPATH);
				if($is_page) {
					$xml = getXML(GSDATAPAGESPATH.$item_id.".xml");
					$title = $xml->title;
					$link = $xml->url;
					$price = (string)$xml->$basket_settings['PRICE_FIELD_NAME'];
					if(isset($xml->$basket_settings['REBATE_FIELD_NAME']) && !empty($xml->$basket_settings['REBATE_FIELD_NAME'])) $rebate = $xml->$basket_settings['REBATE_FIELD_NAME'];
					if(isset($xml->$basket_settings['PERCENT_FIELD_NAME']) && !empty($xml->$basket_settings['PERCENT_FIELD_NAME'])) $ispercent = $xml->$basket_settings['PERCENT_FIELD_NAME'];
					if(isset($rebate) && isset($ispercent)) {
						$price = $price -(($price /100) * $rebate);
					} elseif(isset($rebate) && !isset($ispercent)) {
						$price = $price - $rebate;
					}
					$image = $xml->$basket_settings['IMAGE_FIELD_NAME'];
				} else return;
			} else return;
			if(isset($_POST['quantity']) && is_numeric($_POST['quantity']) && $_POST['quantity'] > 0) $quant = $_POST['quantity'];
			else $quant = 1;
			$_SESSION['BASKET']['ITEMS'][filter_var($_POST['id'], FILTER_SANITIZE_STRING)] = array(
			   "NAME" => htmlspecialchars($title),
			   "PRICE" => number_format($price, 2, '.', ' '),
			   "QUANTITY" => $quant,
			   "LINK" => urlencode($link)
			);
			if ($basket_settings['IMAGE_SHOW'] == 'Y' && !empty($image)) {
				$_SESSION['BASKET']['ITEMS'][filter_var($_POST['id'], FILTER_SANITIZE_STRING)]['IMAGE'] = htmlspecialchars($image);
			}
		} 
		// delete item from cart logic
		elseif (!empty($_POST['delete_item'])) {
			unset($_SESSION['BASKET']['ITEMS'][$_POST['id']]);
		}
		// change item quantity logic
		elseif (!empty($_POST['quantity_change'])) {
			if ($_POST['quantity_change'] > 0) {
				$_SESSION['BASKET']['ITEMS'][filter_var($_POST['id'], FILTER_SANITIZE_STRING)]['QUANTITY'] = filter_var($_POST['quantity_change'], FILTER_SANITIZE_NUMBER_INT);
			} else {
				unset($_SESSION['BASKET']['ITEMS'][$_POST['id']]);
			}
		}
		if (isset($_SESSION['BASKET']['ITEMS']) && 0 < count($_SESSION['BASKET']['ITEMS'])) {
			// get orders count and sum
			$_SESSION['BASKET']['SUM'] = 0;
			foreach ($_SESSION['BASKET']['ITEMS'] as $arItem) {
				$_SESSION['BASKET']['SUM'] = $_SESSION['BASKET']['SUM'] + (number_format(str_replace(array(",", " "), array(".", ""), $arItem['PRICE']), 2, '.', '') * $arItem['QUANTITY']);
			}
		}
	  }
	}
}

function basket_small_show() {
	global $basket_settings; global $MESS; global $url; global $parent;
	$is_special = strpos(get_page_meta_keywords(false), "_special");
	if(isset($basket_settings['BASKET_SHOW']) && $basket_settings['BASKET_SHOW'] == 1) {
		$show_pages_array = (isset($basket_settings['BASKET_SHOW_PAGES']) && !empty($basket_settings['BASKET_SHOW_PAGES'])) ? explode(',',$basket_settings['BASKET_SHOW_PAGES']) : "all";
	} else $show_pages_array = false;
	if(isset($basket_settings['BASKET_SHOW']) && $basket_settings['BASKET_SHOW'] == 1 && isset($basket_settings['BASKET_CHILDS']) && $basket_settings['BASKET_CHILDS'] && isset($basket_settings['BASKET_SHOW_PAGES']) && !empty($basket_settings['BASKET_SHOW_PAGES'])) {
		$show_pages_child = in_array($parent, $show_pages_array);
	} else $show_pages_child = false;
	if($show_pages_array === false || $show_pages_array == "all" || in_array($url, $show_pages_array) || $show_pages_child !== false || $is_special !== false) { ?>
	<div id="basket" <?php echo (!empty($_SESSION['BASKET']['ITEMS']) ? 'class="added"' : '') ?> style="<?php echo $basket_settings['BASKET_STYLES'] ?>" > <?php 
		// if cart has items
		if (!empty($_SESSION['BASKET']['ITEMS'])) {
			// show it to user ?>
			<a href="?basket=Y" title="<?php echo $MESS['cart_small_link_title'] ?>"><?php echo $MESS['cart_small_cart_items_message'] ?> - <?php echo count($_SESSION['BASKET']['ITEMS']).' '.$MESS['cart_small_cart_items_message_count'].' '.$MESS['cart_small_cart_items_sum'].' '.$_SESSION['BASKET']['SUM'].' '.$basket_settings['CURRENCY'] ?></a> <?php
		}
		// or show "empty" message
		else { 
			unset($_SESSION['BASKET']['SUM']);
			echo $MESS['cart_small_empty_basket_message'];
		}
		if ($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') { ?>
			<br><center><a href="?history=Y" title="<?php echo $MESS['show_history_link_text'] ?>"><?php echo $MESS['show_history_link_text'] ?></a></center> <?php
		} ?>
	</div> <?php
	}
}

// Set Title and clear page content
function set_basket_title() {
	global $title; global $content; global $MESS;
	$title = $MESS['cart_page_title'];
	$content = '';
}

function bank_payment() {
	global $MESS;
	$banklinks_data = getXML(GSDATAOTHERPATH.'banklinks.xml');
	if ($banklinks_data) {
		foreach ($banklinks_data->children() as $key) {
			$dirname = (string) $key->dirname;
			if($dirname == $_POST['banklinkgroup']) {
				$lib_path = (string) $key->libpath;
				$lib_class = (string) $key->libclass;
				continue;
			}
		}
	} else return;
	require_once(GSPLUGINPATH.$lib_path);
	?>
	<div class="banklink-payment">
		<fieldset>
			<legend><?php echo $MESS['banklink_form_text']?></legend>
			<?php
				call_user_func($lib_class); 
				?>
		</fieldset>
	</div> <?php
}

// show cart page
function basket_big() {
	global $basket_settings; global $MESS; global $discounts_file; global $language; global $HasErrorCaptcha; global $SITEURL;
	global $captcha_dir; global $HasErrormail; global $hasError;
	if(isset($basket_settings['WAIT_FOR_PAYMENT']) && $basket_settings['WAIT_FOR_PAYMENT']) return;
	if(!isset($language) && isset($_SESSION['language'])) {
		$language = unserialize($_SESSION['language']);
	}
	
	if ($basket_settings['SHOW_PAYMENT'] == 'Y' && $basket_settings['BASKET_BANK_LINKS']) {
		$banklinks_data = getXML(GSDATAOTHERPATH.'banklinks.xml');
		if ($banklinks_data) {
			$banks_info = array();
			$counter = 0;
			foreach ($banklinks_data->children() as $key) {
				$dirname = (string) $key->dirname;
				$banks_info[$counter]['DIR'] = $dirname;
				$banks_info[$counter]['ALT'] = (string) $key->title;
				if(file_exists('plugins/'.$dirname.'/lang/'.$language.'.php')) {
					$lang_vars = include 'plugins/'.$dirname.'/lang/'.$language.'.php';
					$banks_info[$counter]['DESC'] = $lang_vars['BANK_PAYMENT_DESC'];
				}
				else $banks_info[$counter]['DESC'] = "Banklink Payment";
				$banks_info[$counter]['IMG'] = (string) $key->image;
				$counter++;
				
			}
		}
	}
	// If we have SUCESS TEXT - show it to user
	if (isset($_SESSION['BASKET']['OK']) && 5 < strlen($_SESSION['BASKET']['OK'])):
		echo '<p style="color:green; font-weight:bold;">'.$_SESSION['BASKET']['OK'].'</p><hr />';
		if(isset($basket_settings['BUYER_MAIL']) && $basket_settings['BUYER_MAIL'] == 'Y') {
			echo '<p style="color:green; font-style: italic;">'.$MESS['order_check_mail'].'</p>';
		}
		unset($_SESSION['BASKET']['OK']);
	// if cart hasn't got items
	elseif (0 == @count($_SESSION['BASKET']['ITEMS'])):
		echo '<p>'.$MESS['cart_page_empty_basket_message'].'</p>';

	// show full cart page
	else:?>
		<?php if (@$basket_settings['ALLOW_PRINT'] == 'Y'):?>
			<script>
				function printBlock() {
				    productDesc = $('#big-basket').html();
				    $('body').addClass('printSelected');
				    $('body').append('<div class="printSelection">' + productDesc + '</div>');
				    window.print();
				    window.setTimeout(pageCleaner, 0);
				    return false;
				}
				function pageCleaner() {
				    $('body').removeClass('printSelected');
				    $('.printSelection').remove();
				}
			</script>
			<style>
				.printSelected {width: 60%; margin: 0 auto; border: 1px solid silver; padding: 20px; background: #fff}
				.printSelected div {display: none }
				.printSelected div.printSelection {display: block; }
				.printSelected div.printSelection div {display: block; }
				a.basket-print {float: right; text-decoration: none; color: #666; padding: 2px; border: 1px solid silver;}
				.printSelected a.basket-print {display: none;}
			</style>
			<a href="javascript:void(0)" class="basket-print" onclick="printBlock()"><?php echo $MESS['print_order']?></a>	
		<?php endif?>
		<div id="big-basket">
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'T'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>
			
			<h2><?php echo $MESS['cart_page_list_title']?></h2>
			<div class="basket-items-table">
				<div class="basket-table-row heading">
					<?php if($basket_settings['IMAGE_SHOW'] == 'Y'):?>
					<div class="basket-table-col"><?php echo $MESS['table_picture_column']?></div>
					<?php endif?>
					<div class="basket-table-col"><?php echo $MESS['table_name_column']?></div>
					<div class="basket-table-col"><?php echo $MESS['table_price_column']?></div>
					<div class="basket-table-col"><?php echo $MESS['table_quantity_column']?></div>
					<div class="basket-table-col"><?php echo $MESS['table_sum_column']?></div>
					<div class="basket-table-col"><?php echo $MESS['table_delete_column']?></div>
				</div>
				<?php foreach ($_SESSION['BASKET']['ITEMS'] as $key=>$arItem):?>
				<div class="basket-table-row">
					<?php if($basket_settings['IMAGE_SHOW'] == 'Y'):?>
					<div class="basket-table-col center">
						<?php if (!empty($arItem['IMAGE'])):?>
						<img src="<?php echo $arItem['IMAGE']?>" style="max-width:100px; max-height:100px" alt="<?php echo htmlspecialchars_decode($arItem['NAME'])?>" />
						<?php else:?>
						<?php echo $MESS['cart_page_no_picture_message']?>
						<?php endif?>
					</div>
					<?php endif?>
					<div class="basket-table-col item-link"><a href="<?php echo str_replace("?lang", "?setlang", $arItem['LINK'])?>" target="_blank" title="<?php echo htmlspecialchars_decode($arItem['NAME'])?>"><?php echo htmlspecialchars_decode($arItem['NAME'])?></a></div>
					<div class="basket-table-col item-price"><?php echo number_format((float)str_replace(array(",", " "), array(".", ""), $arItem['PRICE']), 2, '.', ''); ?> <?php echo $basket_settings['CURRENCY']?></div>
					<div class="basket-table-col center">
						<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" name="quantity_change" method="POST" class="change-form">
							<input type="hidden" name="id" value="<?php echo $key?>" />
							<input type="number" size="4" style="text-align: center; width: 50px" name="quantity_change" value="<?php echo $arItem['QUANTITY']?>" />
							<input type="submit" value="<?php echo $MESS['quantity_change_button']?>" />
						</form>
					</div>
					<div class="basket-table-col item-sum">
					<?php 
						$item_sum = number_format($arItem['QUANTITY'] * str_replace(array(",", " "), array(".", ""), $arItem['PRICE']), 2, '.', '');
						?>
						<strong><?php echo $item_sum?> <?php echo $basket_settings['CURRENCY']?></strong>
					</div>
					<div class="basket-table-col center">
						<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" name="delete_item" method="POST" class="delete-form">
							<input type="hidden" name="id" value="<?php echo $key?>" />
							<input type="submit" value="Х" name="delete_item" />
						</form>
					</div>
				</div>
				<?php endforeach?>
			</div>
			<div class="basket-items-table total">
				<div class="basket-table-row">
					<div class="full-width">
						<?php echo $MESS['cart_page_order_list_total']?> <strong><?php echo number_format($_SESSION['BASKET']['SUM'], 2, '.', ' '); ?> <?php echo $basket_settings['CURRENCY']?></strong>
					</div>
				</div>
			</div>
			
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'M'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>

			<?php if ($basket_settings['USE_DISCOUNTS'] == 'Y') { ?>
			<form class="change-form" action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
				<div class="basket-discounts">
					<div class="inline">
						<?php echo $MESS['cart_page_discount_input_code']; ?>
					</div>
					<div class="inline">
						<input type="text" name="discount_code" value="<?php echo @filter_var($_POST['discount_code'], FILTER_SANITIZE_STRING); ?>" <?php echo in_array("discount_code", $hasError) ? 'style="border-color: red;"' : '' ?> >
					</div>
					<div class="inline">
						<input type="submit" name="discount_input" class="discount-input" value="<?php echo $MESS['cart_page_discount_code_submit']; ?>">
					</div>
					<div class="inline" style="margin-left: 10px;">
						<strong><?php echo @$_SESSION['BASKET']['DISCOUNT']['MESSAGE']; ?></strong>
					</div>
				</div>
			</form>
		<?php } ?>
			
			<h3><?php echo $MESS['cart_page_form_title']?></h3>
			<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="POST">
				<div class="basket-items-table form">
					<div class="basket-table-row">
						<div class="basket-table-col">
							<?php echo $MESS['cart_page_form_field_name']?>
						</div>
						<div class="basket-table-col">
							<input type="text" name="order_name" id="order_name" value="<?php echo isset($_POST['order_name']) ? $_POST['order_name'] : ''?>" <?php echo in_array("order_name", $hasError) ? 'style="border-color: red;"' : '' ?> required />
						</div>
					</div>
					<div class="basket-table-row">
						<div class="basket-table-col">
							<?php echo $MESS['cart_page_form_field_phone']?>
						</div>
						<div class="basket-table-col">
							<input type="text" name="order_phone" id="order_phone" value="<?php echo isset($_POST['order_phone']) ? $_POST['order_phone'] : ''?>" <?php echo in_array("order_phone", $hasError) ? 'style="border-color: red;"' : '' ?> required />
						</div>
					</div>
					<div class="basket-table-row">
						<div class="basket-table-col">
							<?php echo $MESS['cart_page_form_field_email']?>
						</div>
						<div class="basket-table-col">
							<input type="email" name="order_email" id="order_email" value="<?php echo isset($_POST['order_email']) ? $_POST['order_email'] : ''?>" required />
						</div>
					</div>
					<?php if ($basket_settings['SHOW_DELIVERY'] == 'Y' && !empty($basket_settings['DELIVERY'])):?>
					<div class="basket-table-row">
						<div class="basket-table-col">
							<?php echo $MESS['cart_page_form_field_delivery']?>
						</div>
						<div class="basket-table-col">
							<select name="order_delivery" required >
								<option class="first" value=""><?php echo $MESS['cart_page_form_select_empty_option']?></option>
								<?php foreach ($basket_settings['DELIVERY'] as $delivery):
									if(isset($MESS[$delivery])) $delivery = $MESS[$delivery];
									else $delivery = $delivery; ?>
									<option value="<?php echo $delivery?>" <?php echo (isset($_POST['order_delivery']) && $_POST['order_delivery']==$delivery)?"selected":""?> ><?php echo $delivery?></option>
								<?php endforeach?>
							</select>
						</div>
					</div>
					<?php endif?>
					<?php if ($basket_settings['SHOW_PAYMENT'] == 'Y' && !empty($basket_settings['PAYMENT'])):?>
					<div class="basket-table-row">
						<div class="basket-table-col">
							<?php echo $MESS['cart_page_form_field_payment']?>
						</div>
						<div class="basket-table-col"> <?php
						if($basket_settings['BASKET_BANK_LINKS']) { ?>
							<div class="basket-table-row">
								
									<input type="radio" name="paymentgroup" id="banklink_no" value="1" onClick="this.form.submit();" <?php echo (!isset($_POST['paymentgroup']) || $_POST['paymentgroup']==1)?"checked":""?> />
									<label for="banklink_no">Simple methods</label> 
									<input type="radio" name="paymentgroup" id="banklink_yes" value="2" onClick="this.form.submit();" <?php echo (isset($_POST['paymentgroup']) && $_POST['paymentgroup']==2)?"checked":""?> class="radio-next" />
									<label for="banklink_yes">Banklink</label>
								
							</div>
							<div class="basket-table-row fullwidth">
						<?php }
						if(!isset($_POST['paymentgroup']) || $_POST['paymentgroup'] == 1) { ?>
								<select name="order_payment" required>
									<option class="first" value=""><?php echo $MESS['cart_page_form_select_empty_option']?></option>
								<?php foreach ($basket_settings['PAYMENT'] as $payment):
										if(isset($MESS[$payment])) $payment = $MESS[$payment]; ?>
										<option value="<?php echo $payment?>" <?php echo (isset($_POST['order_payment']) && $_POST['order_payment']==$payment)?"selected":""?> ><?php echo $payment?></option>
								<?php endforeach?>
								</select>
				<?php 	} else { 
						if(isset($banks_info) && count($banks_info) > 0) {
							for($i=0; $i<count($banks_info); $i++) {
							?>
								<p><input type="radio" name="banklinkgroup" id="<?php echo $banks_info[$i]['DIR']?>" value="<?php echo $banks_info[$i]['DIR']?>" />
								<label for="<?php echo $banks_info[$i]['DIR']?>">
									<?php 
									if(isset($banks_info[$i]['IMG']) && !empty($banks_info[$i]['IMG'])) { ?>
										<img class="banklink-image" alt="<?php echo $banks_info[$i]['ALT']?>" src="<?php echo $SITEURL.'plugins/'.$banks_info[$i]['IMG']; ?>" title="<?php echo $banks_info[$i]['ALT']?>" >
							<?php 	}
										echo $banks_info[$i]['DESC']?>
								</label></p>
						<?php }}}
						if($basket_settings['BASKET_BANK_LINKS']) { ?>
							</div>
						<?php } ?>
						</div>
					</div>
					<?php endif?>
					<div class="basket-table-row">
						<div class="basket-table-col" style="vertical-align: top;">
							<p><?php echo $MESS['cart_page_form_field_message']?></p>
							<?php if ($basket_settings['SHOW_DELIVERY'] == 'Y' && !empty($basket_settings['DELIVERY'])) { echo '<p>'.$MESS['cart_page_form_field_message_delivery'].'</p>'; }?>
						</div>
						<div class="basket-table-col">
							<textarea name="order_text" id="order-text" <?php echo in_array("order_text", $hasError) ? 'style="border-color: red;"' : ''?> ><?php echo isset($_POST['order_text']) ? $_POST['order_text'] : ''?></textarea>
						</div>
					</div>
					<div class="basket-table-row">
						<div class="basket-table-col" style="vertical-align: top;">
							<p><?php echo $MESS['CAPTCHA_TXT']; ?></p>
						</div>
						<div class="basket-table-col">
							<fieldset class="captcha-form <?php echo $HasErrorCaptcha; ?>">
								<div class="<?php echo $HasErrorCaptcha; ?>" style="padding: 6px;">
									<p><img id="captcha" src="<?php echo $captcha_dir; ?>captcha.php" width="160" height="45" border="1" alt="CAPTCHA">
									<small><a href="#" onclick="document.getElementById('captcha').src = '<?php echo $captcha_dir; ?>captcha.php?' + Math.random();
									document.getElementById('captcha_code').value = '';
									return false;"><?php echo $MESS['CAPTCHA_RELOAD']; ?></a></small></p>
									<p><label class="control-label">CAPTCHA<strong>*</strong></label><input id="captcha_code" type="text" name="captcha" size="6" maxlength="5" onkeyup="this.value = this.value.replace(/[^\d]+/g, '');" required=""> <small><?php echo $MESS['CAPTCHA_TEXT']; ?></small></p>
								</div>
							</fieldset>
						</div>
					</div>
				</div>
				<div class="basket-items-table total">
					<div class="basket-table-row">
						<div style="text-align: center; margin: 10px;">
							<input type="submit" name="order_submit" value="<?php echo $MESS['cart_page_form_submit_value']?>" onClick="this.form.submit();" />
						</div>
					</div>
				</div>
			</form>
			
			<?php if (strlen($basket_settings['BASKET_MESSAGE']) > 0 && $basket_settings['BASKET_MESSAGE_POSITION'] == 'B'):?>
				<?php echo $basket_settings['BASKET_MESSAGE']?>
			<?php endif?>
			
		</div> <?php
	if(isset($HasErrorCaptcha) && !empty($HasErrorCaptcha)) { ?>
		<div class="alert alert-dismissable alert-danger">
			<button data-dismiss="alert" class="close" type="button">x</button>
			<?php echo $MESS['MAIL_ERR_SEND']; ?>
			<ul>
				<li><?php echo $MESS['CAPTCHA_ERROR']?></li>
			</ul>
		</div>
	<?php
	}
	if(isset($HasErrormail) && $HasErrormail) { ?>
		<div class="alert alert-dismissable alert-danger">
			<button data-dismiss="alert" class="close" type="button">x</button>
			<?php echo $MESS['MAIL_ERR_SEND']; ?>
			<ul>
				<li><?php echo $MESS['MAIL_ERROR']?></li>
			</ul>
		</div>
	<?php
	}
		endif;
}

function history_logic() {
	// change item status
	if (!empty($_POST['status_change'])) {
		$xml = getXML($_POST['file']);
		unset($xml->status);
		$xml->addChild('status', serialize($_POST['status_change']));
		XMLsave($xml, $_POST['file']);
	}
	// change item admin_message
	if (isset($_POST['admin_message'])) {
		$xml = getXML($_POST['file']);
		unset($xml->admin_message);
		$xml->addChild('admin_message', serialize($_POST['admin_message']));
		XMLsave($xml, $_POST['file']);
	}
	// history file delete
	if (isset($_POST['file_delete'])) {
		unlink($_POST['file_delete']);
		unset($_POST['file_delete']);
	}
}

// Set Title and clear page content
function history_page_title() {
	global $title; global $content; global $MESS;
	$title = $MESS['history_page_title'];
	$content = '';
}

// show histore page
function history_page() {
	global $history_dir; global $MESS; global $basket_settings; ?>
		<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="get" class="history-form">
			<input type="hidden" name="history" value="Y">
			<div class="basket-items-table">
				<div class="basket-table-row">
					<div class="basket-table-col">
						<?php echo $MESS['history_page_insert_number']; ?>
					</div>
					<div class="basket-table-col">
						<input type="text" name="order" id="history-order" required value="<?php echo @filter_var($_GET['order'], FILTER_SANITIZE_NUMBER_INT); ?>">
					</div>
				</div>
				<div class="basket-table-row">
					<div class="basket-table-col">
						<?php echo $MESS['history_page_insert_name']; ?>
					</div>
					<div class="basket-table-col">
						<input type="text" name="user" id="history-user" required value="<?php echo @filter_var($_GET['user'], FILTER_SANITIZE_STRING); ?>">
					</div>
				</div>
			</div>
			<div class="basket-items-table total">
				<div class="basket-table-row">
					<div style="text-align: center; margin: 10px;">
						<input type="submit" value="<?php echo $MESS['history_page_get_order_button']; ?>">
					</div>
				</div>
				</div>
		</form>
	<?php
	if (isset($_GET['order']) && !empty($_GET['order']) && isset($_GET['user']) && !empty($_GET['user'])) {
		$is_order = false;
		$valid_order = false;
		$valid_user = false;
		if (!preg_match('/^[0-9]/', $_GET['order'])) {
			echo $MESS['bad_numbers_exists']; ?>
			<script> $("#history-order").css("border-color", "red"); </script>
			<?php
		}
		else {
			$sanitize_order = filter_var($_GET['order'], FILTER_SANITIZE_NUMBER_INT);
			$valid_order = true;
		}
		if (!preg_match('/^[\p{L}\p{N}][\p{L}\p{N} _.-]+$/u', $_GET['user'])) {
			echo $MESS['bad_characters_exists']; ?>
			<script> $("#history-user").css("border-color", "red"); </script>
			<?php
		}
		else {
			$sanitize_user = filter_var($_GET['user'], FILTER_SANITIZE_STRING);
			$valid_user = true;
		}
		if($valid_order && $valid_user) {
			if ($handle = opendir($history_dir)) {
				while (false !== ($entry = readdir($handle))) {
					if ($entry != "." && $entry != "..") {
						$xmls = getXML($history_dir.$entry);
						if($_GET['order'] == unserialize($xmls->order_nr) && strtolower($_GET['user']) == strtolower(unserialize($xmls->name))) {
							$is_order = true;
							break;
						}
					}
				}
				closedir($handle);
			}
			if (!$is_order) {
				echo $MESS['history_page_wrong_number'];
			} else {
				$xmlOrder = $xmls;
				if (strtolower($_GET['user']) !== strtolower(unserialize($xmls->name))) {
					echo $MESS['history_page_wrong_user'];
				} else { ?>
				<p>
					<strong><?php echo $MESS['order_created'] ?></strong> - <?php echo unserialize($xmlOrder->date) ?> <br/>
					<strong><?php echo $MESS['history_table_phone_column'] ?></strong> - <?php echo @unserialize($xmlOrder->phone) ?> <br/>
					<strong><?php echo $MESS['history_table_email_column'] ?></strong> - <?php echo @unserialize($xmlOrder->email) ?> <br/>
					<strong><?php echo $MESS['history_table_items_column'] ?></strong> - <?php echo @unserialize($xmlOrder->items) ?> <br/>
					<strong><?php echo $MESS['history_table_sum_column'] ?></strong> - <?php echo @unserialize($xmlOrder->sum).' '.$basket_settings['CURRENCY'] ?> <br/>
					<strong><?php echo $MESS['order_status'] ?></strong> - <?php echo @unserialize($xmlOrder->status) ?> <br/>
					<strong><?php echo $MESS['history_table_message_column'] ?></strong> - <?php echo @unserialize($xmlOrder->message) ?> <br/>
				</p>
				<hr>
				<h2><?php echo $MESS['order_contain'] ?></h2>
					<?php echo $xmlOrder->order;
					if (isset($xmlOrder->admin_message) && 2 < strlen(unserialize($xmlOrder->admin_message))) {
						echo '<hr><h3>'.$MESS['history_page_admin_message'].'</h3>'.unserialize($xmlOrder->admin_message);
					}
					unset($xmlOrder);
				}
			}
			unset($xmls);
		}
	}
}

// ajax basket logic
function ajax_basket() {
	global $basket_settings; global $MESS;
	$galima = false;
	$srch_content = 1;
	if(isset($_GET['basket']) && $_GET['basket'] == "Y" || isset($_GET['history']) && $_GET['history'] == "Y") $srch_content = 0;
	?>
	<script type="text/javascript">
		var basket_empty_message = "<?php echo $MESS['cart_small_empty_basket_message']; ?>";
		$(document).ready(function() { 
			var srch_content = "<?php echo $srch_content; ?>";
			if(srch_content == 0) {
				document.getElementById("search-outer").style.display = "none";
			}
			$(".add-form").ajaxForm({success: ChangeSmallBasket});
			$(".delete-form").ajaxForm({success: ChangeAllBasket});
			$(".change-form").ajaxForm({success: ChangeAllBasket});
			var basket_height = $("#basket").height();
			var basket_length = $("#basket").width();
			if ($('#basket').length && $('#basket').css('background-image') != 'none') { //Get background image dimensions
				var image_url = $('#basket').css('background-image'), image;
				image_url = image_url.match(/^url\("?(.+?)"?\)$/);
				if (image_url[1]) {
					image_url = image_url[1];
					image = new Image();
					$(image).load(function () {
						$("#basket").css("cssText", "padding-left:"+(image.width+4)+"px;right:-"+(basket_length+12)+"px");
					});
					image.src = image_url;
				}
			} else {
				$("#basket").css("cssText", "padding-left:"+(basket_height+16)+"px;right:-"+(basket_length+12)+"px");
			}
		});
		
		function ChangeSmallBasket(responseText) {
			var no_item = <?php echo json_encode($MESS['cart_small_empty_basket_message']); ?>;
			var change;
			$("#basket").empty().html($($.parseHTML(responseText)).filter("#basket").html());
			if($("#basket:contains("+no_item+")").length) {	change = false;	}
			else { change = true; }
			if(change === true) {
				$("#basket").addClass("added");
				var basket_length = $("#basket").width();
				if ($('#basket').css('background-image') != 'none') { //Get background image dimensions
					var image_url = $('#basket').css('background-image'), image;
					image_url = image_url.match(/^url\("?(.+?)"?\)$/);
					if (image_url[1]) {
						image_url = image_url[1];
						image = new Image();
						$(image).load(function () {
							$("#basket").css("cssText", "padding-left:"+(image.width+4)+"px;right:-"+(basket_length+12)+"px");
						});
						image.src = image_url;
					}
				} else {
					$("#basket").css("cssText", "right:-"+(basket_length+12)+"px");
				}
			}
		}
		
		function ChangeAllBasket(responseText) {
			var $result = $(responseText).find("#big-basket").html();
			$("#basket").empty().html($(responseText).filter("#basket").html());
			if (typeof($result) !== "undefined") {
				$("#big-basket").empty().html($(responseText).find("#big-basket").html());
				$(".delete-form").ajaxForm({success: ChangeAllBasket});
				$(".change-form").ajaxForm({success: ChangeAllBasket});
			} else {
				$("#big-basket").empty().html('<p class="empty-big-basket">'+basket_empty_message+'</p>');
			}
			if ( $("#basket").children("a").length == 0 ) {
				$("#basket").removeClass("added");
				var basket_length = $("#basket").width();
				if ($('#basket').css('background-image') != 'none') { //Get background image dimensions
				var image_url = $('#basket').css('background-image'), image;
				image_url = image_url.match(/^url\("?(.+?)"?\)$/);
				if (image_url[1]) {
					image_url = image_url[1];
					image = new Image();
					$(image).load(function () {
						$("#basket").css("cssText", "padding-left:"+(image.width+4)+"px;right:-"+(basket_length+12)+"px");
					});
					image.src = image_url;
				}
			} else {
				$("#basket").css("cssText", "right:-"+(basket_length+12)+"px");
			}
				$(".basket-print").hide();
			} 
		}
	</script>
	<?php
}

function discounts_logic() {
	global $discounts_file;
	$arDiscounts = getXML($discounts_file);
	if (isset($_POST['delete_discount'])) {
		if ($node = $arDiscounts->xpath("//discount[code='".$_POST['code']."']")) {
		    unset($node[0][0]);
		}
	}
	if (isset($_POST['change_discount'])) {
		if ($node = $arDiscounts->xpath("//discount[code='".$_POST['code']."']")) {
			unset($node[0]->value);
			unset($node[0]->use);
			$node[0]->addChild('value',$_POST['value']);
			$node[0]->addChild('use',$_POST['use']);
		}
	}
	if (isset($_POST['create_discount']) && !empty($_POST['code']) && !empty($_POST['value'])) {
		$discount = $arDiscounts->addChild('discount');
		$discount->addChild('code',$_POST['code']);
		$discount->addChild('desc',$_POST['desc']);
		$discount->addChild('use',$_POST['use']);
		$discount->addChild('value',$_POST['value']);
	}
	if (!empty($_POST)) {
		XMLsave($arDiscounts, $discounts_file);
	}
}

function basket_settings_show() {
	global $basket_settings, $MESS, $basket_version;
	$banklink_file = GSDATAOTHERPATH.'banklinks.xml';
	global $live_plugins;
	$banklinks = false;
	$bank_list = array();
if (file_exists($banklink_file)) {
	$banklinks_data = getXML($banklink_file);
	if ($banklinks_data) {
		$banklinks = false;
		foreach ($banklinks_data->children() as $key) {
			$bname = (string) $key->name;
			$filename = (string) $key->filename;
			if(isset($live_plugins[$filename]) && $live_plugins[$filename] != "false") {
				$banklinks = true;
				$bank_list[] = ucfirst($bname);
			}
			continue;
		}
	}
	if(!$banklinks) unlink($banklink_file);
}
	
	// settings page
	if (isset($_GET['settings']) || $_GET['id']=='basket_plugin' && !isset($_GET['history']) && !isset($_GET['discounts'])){ ?>
	<?php
		if (!empty($_POST['demo_spec_page']) || !empty($_POST['demo_spec_tv']) || !empty($_POST['ddemo_spec_laptop']))
			echo '<div style="background: maroon; color:#fff; padding:5px; text-align: center; margin-bottom:10px;">'.$MESS['go_to_spec_page_settings'].'</div>';
	?>
	<p style="font-size: 11px;font-style: italic;text-align: right;margin-bottom: 0;">Basket plugin MOD  (v. <?php echo $basket_version; ?>)</p>
	<center><p style="font-size:150%; font-weight:bold;"><?php echo $MESS['settings_page_title']?></p></center>
	<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="POST">
		<table cellpadding="10" cellspacing="0" >
			<tr>
				<td><?php echo $MESS['settings_page_use_discounts']?></td>
				<td>
					<label for="use_discounts_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="use_discounts_yes" name="use_discounts" value="Y" <?php if($basket_settings['USE_DISCOUNTS'] == 'Y') echo 'checked';?> />
					<label for="use_discounts_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="use_discounts_no" name="use_discounts" value="N" <?php if($basket_settings['USE_DISCOUNTS'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_save_history']?></td>
				<td>
					<label for="save_history_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="save_history_yes" name="save_history" value="Y" <?php if($basket_settings['SAVE_HISTORY'] == 'Y') echo 'checked';?> />
					<label for="save_history_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="save_history_no" name="save_history" value="N" <?php if($basket_settings['SAVE_HISTORY'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_history_to_user']?></td>
				<td>
					<label for="show_history_to_user_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_history_to_user_yes" name="show_history_to_user" value="Y" <?php if($basket_settings['SHOW_HISTORY_TO_USER'] == 'Y') echo 'checked';?> />
					<label for="show_history_to_user_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_history_to_user_no" name="show_history_to_user" value="N" <?php if($basket_settings['SHOW_HISTORY_TO_USER'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_allow_print_order']?></td>
				<td>
					<label for="allow_print_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="allow_print_yes" name="allow_print" value="Y" <?php if($basket_settings['ALLOW_PRINT'] == 'Y') echo 'checked';?> />
					<label for="allow_print_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="allow_print_no" name="allow_print" value="N" <?php if($basket_settings['ALLOW_PRINT'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo isset($MESS['settings_page_send_mail_buyer'])?$MESS['settings_page_send_mail_buyer']:'Send e-mail to the customer after order was maked?'; ?></td>
				<td>
					<label for="buyer_mail_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="buyer_mail_yes" name="buyer_mail" value="Y" <?php if(isset($basket_settings['BUYER_MAIL']) && $basket_settings['BUYER_MAIL'] == 'Y') echo 'checked';?> />
					<label for="buyer_mail_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="buyer_mail_no" name="buyer_mail" value="N" <?php if(isset($basket_settings['BUYER_MAIL']) && $basket_settings['BUYER_MAIL'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_admin_email']?></td>
				<td><input style="width:321px; padding: 5px;" type="email" name="admin_mail" value="<?php echo $basket_settings['ADMIN_MAIL']?>" required/></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_price_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="price_field_name" value="<?php echo $basket_settings['PRICE_FIELD_NAME']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_rebate_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="rebate_field_name" value="<?php echo isset($basket_settings['REBATE_FIELD_NAME']) && !empty($basket_settings['REBATE_FIELD_NAME'])?$basket_settings['REBATE_FIELD_NAME']:"rebate"?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_percent_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="percent_field_name" value="<?php echo isset($basket_settings['PERCENT_FIELD_NAME']) && !empty($basket_settings['PERCENT_FIELD_NAME'])?$basket_settings['PERCENT_FIELD_NAME']:"ispercent"?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_image']?></td>
				<td>
					<label for="show_image_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_image_yes" name="image_show" value="Y" <?php if($basket_settings['IMAGE_SHOW'] == 'Y') echo 'checked';?> />
					<label for="show_image_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_image_no" name="image_show" value="N" <?php if($basket_settings['IMAGE_SHOW'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_image_field']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="image_field_name" value="<?php echo $basket_settings['IMAGE_FIELD_NAME']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_letter_subject']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="letter_header" value="<?php echo $basket_settings['LETTER_HEADER']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_sucess_text']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="ok_text" value="<?php echo $basket_settings['OK_TEXT']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_smallcart_styles']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="basket_styles" value="<?php echo $basket_settings['BASKET_STYLES']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_currency']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="currency" value="<?php echo $basket_settings['CURRENCY']?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_message_position']?></td>
				<td>
					<label for="position_top" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_top']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="position_top" name="basket_message_positions" value="T" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'T') echo 'checked';?> />
					<label for="position_middle" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_middle']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="position_middle" name="basket_message_positions" value="M" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'M') echo 'checked';?> />
					<label for="position_bottom" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_bottom']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="position_bottom" name="basket_message_positions" value="B" <?php if($basket_settings['BASKET_MESSAGE_POSITION'] == 'B') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_message']?></td>
				<td><textarea style="width:321px; padding: 5px; height: 100px;" name="basket_message"><?php echo $basket_settings['BASKET_MESSAGE']?></textarea></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_delivery']?></td>
				<td>
					<label for="show_delivery_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_delivery_yes" name="show_delivery" value="Y" <?php if($basket_settings['SHOW_DELIVERY'] == 'Y') echo 'checked';?> />
					<label for="show_delivery_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_delivery_no" name="show_delivery" value="N" <?php if($basket_settings['SHOW_DELIVERY'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_delivery_options']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="delivery" value="<?php echo implode(',',$basket_settings['DELIVERY'])?>" /></td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_show_payment']?></td>
				<td>
					<label for="show_payment_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_payment_yes" name="show_payment" value="Y" <?php if($basket_settings['SHOW_PAYMENT'] == 'Y') echo 'checked';?> />
					<label for="show_payment_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_payment_no" name="show_payment" value="N" <?php if($basket_settings['SHOW_PAYMENT'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td><?php echo $MESS['settings_page_payment_options']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="payment" value="<?php echo implode(',',$basket_settings['PAYMENT'])?>" /></td>
			</tr>
	<?php	if(count($bank_list) > 0) { ?>
			<tr>
				<td><?php echo $MESS['settings_page_show_banklink']?></td>
				<td>
		<?php	for($i = 0; $i < count($bank_list); $i++) { ?>
					<p style="color:green"><?php echo $bank_list[$i]; ?></p>
		<?php	} ?>
				</td>
			</tr>
	<?php	} ?>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_ajax']?></td>
				<td>
					<label for="ajax_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="ajax_yes" name="ajax" value="Y" <?php if($basket_settings['AJAX'] == 'Y') echo 'checked';?> />
					<label for="ajax_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="ajax_no" name="ajax" value="N" <?php if($basket_settings['AJAX'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_jquery_include']?></td>
				<td>
					<label for="jquery_include_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="jquery_include_yes" name="jquery_include" value="Y" <?php if($basket_settings['JQUERY_INCLUDE'] == 'Y') echo 'checked';?> />
					<label for="jquery_include_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="jquery_include_no" name="jquery_include" value="N" <?php if($basket_settings['JQUERY_INCLUDE'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_pretty_include']?></td>
				<td>
					<label for="pretty_include_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="pretty_include_yes" name="pretty_include" value="Y" <?php if(isset($basket_settings['PRETTY_INCLUDE']) && $basket_settings['PRETTY_INCLUDE'] == 'Y') echo 'checked';?> />
					<label for="pretty_include_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="pretty_include_no" name="pretty_include" value="N" <?php if(isset($basket_settings['PRETTY_INCLUDE']) && $basket_settings['PRETTY_INCLUDE'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr>
				<td width="300px">
					<input type="checkbox" id="basketshow" name="basketshow" value=1 style="float: left; margin-right: 6px; margin-top: 2px; cursor: pointer;" <?php if(isset($basket_settings['BASKET_SHOW']) && $basket_settings['BASKET_SHOW']) echo 'checked';?> /><label for="basketshow" style="font-weight: normal; cursor: pointer;"><?php echo $MESS['is_basket_show']?></label>
					<input type="checkbox" id="basketchilds" name="basketchilds" value=1 style="float: left; margin-right: 6px; margin-top: 10px; cursor: pointer;" <?php if(isset($basket_settings['BASKET_CHILDS']) && $basket_settings['BASKET_CHILDS']) echo 'checked';?> /><label for="basketchilds" style="font-weight: normal; cursor: pointer; margin-top: 6px;"><?php echo $MESS['is_basket_childs']?></label>
				</td>
				<td>
					<input style="width:321px; padding: 5px; margin-top: 2px;" type="text" name="basket_pages" value="<?php if(isset($basket_settings['BASKET_SHOW_PAGES']) && $basket_settings['BASKET_SHOW_PAGES']) echo $basket_settings['BASKET_SHOW_PAGES']?>" />
				</td>
			</tr>
			<tr>
				<td width="300px"><?php echo $MESS['settings_page_show_related']?></td>
				<td>
					<label for="show_related_yes" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_yes']?></label>
					<input style="display:block; float: left; margin-top: 3px; margin-right: 20px;" type="radio" id="show_related_yes" name="show_related" value="Y" <?php if(isset($basket_settings['SHOW_RELATED']) && $basket_settings['SHOW_RELATED'] == 'Y') echo 'checked';?> />
					<label for="show_related_no" style="display:block; float: left; margin-right: 10px;"><?php echo $MESS['settings_radio_no']?></label>
					<input style="display:block; float: left; margin-top: 3px" type="radio" id="show_related_no" name="show_related" value="N" <?php if(isset($basket_settings['SHOW_RELATED']) && $basket_settings['SHOW_RELATED'] == 'N') echo 'checked';?> />
				</td>
			</tr>
			<tr id="related_count">
				<td width="300px"><?php echo $MESS['settings_page_related_count']?></td>
				<td><input style="width:321px; padding: 5px;" type="text" name="related_count" value="<?php echo isset($basket_settings['RELATED_COUNT']) ? $basket_settings['RELATED_COUNT'] : 3?>" /></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="basket_settings_change" value="<?php echo $MESS['settings_page_save_button']?>" /></td>
			</tr>
		</table>
	</form>
	<hr />
	<p><?php echo $MESS['settings_page_required_plugins']?><br />
		<div style="width: 160px; float: left;">1) I18n Base</div><div><?php echo (function_exists('i18n_init')) ? '<font color="green">Installed</font>' : '<font color="red">Not Installed</font>'; ?></div>
		<div style="width: 160px; float: left;">2) I18n Special Pages</div><div><?php echo (function_exists('return_special_field')) ? '<font color="green">Installed</font>' : '<font color="red">Not Installed</font>'; ?></div>
		<div style="width: 160px; float: left;">3) I18n Search</div><div><?php echo (function_exists('return_i18n_search_results')) ? '<font color="green">Installed</font>' : '<font color="red">Not Installed</font>'; ?></div>
	</p>
	<p><i><?php echo $MESS['settings_page_instruction_plugins']?></i></p>
	<p>
		<strong><?php echo $MESS['settings_page_example_text']?></strong>
		<div style="border:1px solid silver; padding:5px 0; font-size:90%; margin-top:-15px">
		<?php highlight_string('<form action="<?php echo htmlspecialchars($_SERVER[\'REQUEST_URI\'])?>" method="POST" class="add-form">
  <span>'.$MESS['table_quantity_column'].':</span>
  <input type="hidden" name="id" value="<?php echo return_special_field(\'id\')?>" readonly />
  <input type="text" size="3" value="1" name="quantity" />
  <input type="submit" name="add_item" value="'.$MESS['buy_item'].'" readonly />
</form>')?>
		</div>
		<strong style="color:red; font-size:80%"><?php echo $MESS['settings_page_danger_text']?></strong>
	</p>
	<hr />
	<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
		<center>
			<p>
				<?php echo $MESS['settings_page_special_demo_offer']?>
				<input type="submit" style="width:100%" name="demo_spec_page" value="<?php echo $MESS['settings_page_special_demo_submit']?>" />
				<input type="submit" style="width:100%;margin:6px 0px;" name="demo_spec_tv" value="<?php echo $MESS['settings_page_special_demo_tv']?>" />
				<input type="submit" style="width:100%" name="demo_spec_laptop" value="<?php echo $MESS['settings_page_special_demo_laptop']?>" />
			</p>
		</center>
	</form>
	<hr />
	<?php echo $MESS['settings_page_forum_link']?>
	<hr />
	<small>&copy; <a href="http://vk.com/cupuyc1989" target="_blank">Makhonin Pavel</a>. 08.2014y.<span style="padding-left:20px">&copy; <a href="http://pigios-svetaines.eu/projects/eshop-ra" target="_blank">Andrejus Semionovas</a>. 06.2016y.</span></small>
	<script>
		$('input[name="show_related"]').on('click change', function(e) {
			if(e.target.id == "show_related_no") {
				$('#related_count').hide();
			}
			if(e.target.id == "show_related_yes") {
				$('#related_count').show();
			}
		});
		if (!$('input[name="show_related"]').is(':checked')) {
			$('#related_count').hide();
		}
	</script>
	<?php
	}
	// history page
	elseif (isset($_GET['history'])) {
		// make files array
		global $history_dir; global $MESS; global $LANG; global $sort_history; global $SITEURL;
		if(isset($MESS['datetime_formatter'])) $date_formatter = $MESS['datetime_formatter'];
		else $date_formatter = 'm/d/Y H:i:s A';
		$show_clear = false;
		
		$arFiles = array(); $str = ''; $i = 1;
		if ($handle = opendir($history_dir)) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					$xmlItems = getXML($history_dir.$entry);
					if(isset($_GET['filter_status']) && $_GET['filter_status'] !== unserialize($xmlItems->status)) continue;
					if(isset($_GET['search_nr']) && (int)$_GET['search_nr'] !== unserialize($xmlItems->order_nr)) continue;
					if(isset($_GET['filter_payment']) && strpos($xmlItems->order, $_GET['filter_payment']) === false) continue;
					$arFiles[] = array(
						"PATH" => $history_dir.$entry,
						"CREATED" => filectime($history_dir.$entry),
						"NAME" =>  unserialize($xmlItems->name),
						"MAIL" =>  unserialize($xmlItems->email),
						"STATUS" =>  unserialize($xmlItems->status),
						"NUMBER" =>  unserialize($xmlItems->order_nr),
						"CONTENT" =>  $xmlItems->order,
					);
				}
			}
			closedir($handle);
		}
		if(isset($_GET['filter_status']) || isset($_GET['search_nr']) || isset($_GET['filter_payment'])) $show_clear = true;
		echo '<center><p style="font-size:150%; font-weight:bold;">'.$MESS['history_title'].'</p></center>';
		// history hasn't got files
		if (0 >= count($arFiles)) { ?>
			<a style="position: relative;top: -36px;right: -85%;padding: 5px 10px; margin: 5px 3px; background: #11171B; color: #fff; text-decoration:none" href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=basket_plugin&history&clearf=true"><?php echo isset($MESS['clear_filters'])?$MESS['clear_filters']:'Clear filters'; ?></a> <?php
			echo '<p>'.$MESS['history_empty'].'.</p>';
		} else {
			// item status array
			$arStatus[] = $MESS['history_status_default'];
			$arStatus[] = $MESS['history_status_waiting'];
			$arStatus[] = $MESS['history_status_sucess'];
			$arStatus[] = $MESS['history_status_canceled'];
						
			// sorting array by file created time
			if(isset($_SESSION['sort_history'])) {
				$sort_history = unserialize($_SESSION['sort_history']);
			}
			if(count($sort_history) <= 0) $sort_history['CREATED'] = 'desc';
			$replacement = array('&crea_date=asc','&crea_date=desc','&cre_date=asc','&cre_date=desc','&nam_date=asc','&nam_date=desc','&name_date=asc','&name_date=desc','&mail_date=asc','&mail_date=desc','&email_date=asc','&email_date=desc');
			if(isset($_GET['filter_status']) || isset($_GET['search_nr']) || isset($_GET['filter_payment'])) $page_link = htmlspecialchars($_SERVER['PHP_SELF']).'?id=basket_plugin&history';
			else $page_link = $_SERVER["REQUEST_URI"];
			$cre_value = "desc";
			$sort_filed = "crea_date";
			
			if(isset($_GET['clearf'])) {
				$page_link = htmlspecialchars($_SERVER['PHP_SELF']).'?id=basket_plugin&history';
				$show_clear = false;
			}
			if(isset($_GET['cre_date'])) {
				$cre_value = $_GET['cre_date'];
				if(strpos($_GET['cre_date'], "desc") !== false) $cre_value = "asc";
				if(strpos($_GET['cre_date'], "asc") !== false) $cre_value = "desc";
				$sort_history = array();
				$sort_history['CREATED'] = $cre_value;
				$page_link = substr($_SERVER["REQUEST_URI"], 0, strpos($_SERVER["REQUEST_URI"], "&cre_date"));
				$show_clear = true;
			}
			elseif(isset($_GET['crea_date'])) {
				$cre_value = $_GET['crea_date'];
				$sort_history = array();
				$sort_history['CREATED'] = $cre_value;
				$page_link = str_replace('crea_date', 'cre_date', $_SERVER["REQUEST_URI"]);
				$show_clear = true;
			}
			if(isset($_GET['nam_date'])) {
				$cre_value = $_GET['nam_date'];
				if(strpos($_GET['nam_date'], "desc") !== false) $cre_value = "asc";
				if(strpos($_GET['nam_date'], "asc") !== false) $cre_value = "desc";
				$sort_filed = "name_date";
				$sort_history = array();
				$sort_history['NAME'] = $cre_value;
				$page_link = str_replace($replacement, '', $_SERVER["REQUEST_URI"]);
				$show_clear = true;
			}
			elseif(isset($_GET['name_date'])) {
				$cre_value = $_GET['name_date'];
				$sort_filed = "name_date";
				$sort_history = array();
				$sort_history['NAME'] = $cre_value;
				$page_link = str_replace($replacement, '', $_SERVER["REQUEST_URI"]);
				$show_clear = true;
			}
			if(isset($_GET['mail_date'])) {
				$cre_value = $_GET['mail_date'];
				if(strpos($_GET['mail_date'], "desc") !== false) $cre_value = "asc";
				if(strpos($_GET['mail_date'], "asc") !== false) $cre_value = "desc";
				$sort_filed = "email_date";
				$sort_history = array();
				$sort_history['NAME'] = $cre_value;
				$page_link = str_replace($replacement, '', $_SERVER["REQUEST_URI"]);
				$show_clear = true;
			}
			elseif(isset($_GET['email_date'])) {
				$cre_value = $_GET['email_date'];
				$sort_filed = "email_date";
				$sort_history = array();
				$sort_history['NAME'] = $cre_value;
				$page_link = str_replace(array('&crea_date=asc','&crea_date=desc','&cre_date=asc','&cre_date=desc','&nam_date=asc','&nam_date=desc'), '', $_SERVER["REQUEST_URI"]);
				$show_clear = true;
			}
			usort($arFiles, function ($a, $b) use ($sort_history) {
				foreach ($sort_history as $key => $value) {
					if ($a[$key] == $b[$key]) {
						return 0;
					}
				}
				if($value === 'asc') return ($a[$key] > $b[$key]) ? 1 : -1;
				else return ($a[$key] > $b[$key]) ? -1 : 1;
			});
			if($show_clear) { ?>
				<a style="position: relative;top: -36px;right: -84%;padding: 5px 10px; margin: 5px 3px; background: #11171B; color: #fff; text-decoration:none" href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>?id=basket_plugin&history&clearf=true"><?php echo isset($MESS['clear_filters'])?$MESS['clear_filters']:'Clear filters'; ?></a> <?php
			} ?>
			<div>
			<div style="width:33%;float:left;margin-bottom: 6px;"><span style="font-size: 16px; padding-right: 2px;">&#8981;</span><input type="text" id="search_nr" style="padding: 2px 4px;" name="search_nr" autocomplete="off" placeholder="<?php echo isset($MESS['search_order_nr'])?$MESS['search_order_nr']:'By order number'; ?>"  onkeypress="return startSearch(event)"></div>
			<div style="width:33%;float:left;margin-bottom: 6px;"><span style="font-size: 16px; padding-right: 2px;"><img src="<?php echo $SITEURL?>plugins/basket_plugin/images/filter.png" style="width: 12px;" /></span><select id="filter_status" name="filter_status" style="max-width: 90%;"> 
			<?php
			$status = '<option value="">'.$MESS['cart_page_form_select_empty_option'].'</option>';
			foreach ($arStatus as $oneStatus) {
				$status .= '<option value="'.$oneStatus.'">'.$oneStatus.'</option>';
			} 
			echo $status; ?>
			</select>
			</div>
			<div style="width:33%;float:left;margin-bottom: 6px;"><span style="font-size: 16px; padding-right: 2px;"><img src="<?php echo $SITEURL?>plugins/basket_plugin/images/filter.png" style="width: 12px;" /></span><select id="filter_payment" name="filter_payment" style="max-width: 92%;">
				<option class="first" value=""><?php echo $MESS['cart_page_form_select_empty_option']?></option>
			<?php foreach ($basket_settings['PAYMENT'] as $payment) {
				if(isset($MESS[$payment])) $payment = $MESS[$payment]; ?>
					<option value="<?php echo $payment?>"><?php echo $payment?></option>
			<?php } ?>
			</select>
			</div>
			</div>
			<script>
				document.getElementById('filter_status').onchange = function() {
					var linkas = "<?php echo $page_link; ?>";
					window.location = linkas + "&filter_status=" + this.value;
				};
				document.getElementById('filter_payment').onchange = function() {
					var linkas = "<?php echo $page_link; ?>";
					window.location = linkas + "&filter_payment=" + this.value;
				};
				function startSearch(e) {
					if (e.keyCode == 13) {
						var tb = document.getElementById("search_nr");
						var linkas = "<?php echo $page_link; ?>";
						window.location = linkas + "&search_nr=" + eval(tb.value);
						return false;
					}
				}
			</script>
			<?php
			// pagination
			$cre_link = ($cre_value === "asc")?'&'.$sort_filed.'=asc':'';
			if (count($arFiles) > 15) { ?>
				<hr style="clear: both;" /><div style="text-align: right"> <div style="float:left"><?php echo $MESS['history_pagination'] ?></div> <?php
				for ($j = 0 ; $j<count($arFiles); $j++) {
					if ($j%15 == 0) { echo '<a style="dysplay: inline-block; padding: 5px 10px; margin: 5px 3px; background: #11171B; color: #fff; text-decoration:none" href="'.htmlspecialchars($_SERVER['PHP_SELF']).'?id=basket_plugin&history&page='.ceil($j/15).''.$cre_link.'">'.ceil($j/15+1).'</a>'; }
					if ($j%219 == 0 && $j !== 0) { echo '<br /><br />'; }
				} ?>
				</div><hr /> <?php
			}
			
			//some little styles for history ?>
			<style type="text/css">
				.history-table td{vertical-align: middle!important;}.history-table .bordered th {border: 1px solid #000; text-align: center}.history-table p {margin-bottom:0}.filedelete{width:22px;height:22px; margin-right:20px;background:red;color:#fff;font-weight:bold;cursor:pointer;border:1px solid #F00;border-radius:4px;}
			</style>
			<?php
			//table header ?>
			<table class="history-table" width="100%" border="1" cellpadding="5" cellspacing="0">
				<thead>
					<tr class="bordered">
						<th>№</th>
						<th><?php echo $MESS['history_table_order_number']?></th>
						<th><a style="text-decoration: none;" href="<?php echo $page_link; ?>&cre_date=<?php echo $cre_value; ?>"><span><?php echo ($cre_value === "asc")?'&#9650;':'&#9660;'?><?php echo $MESS['history_table_created_column']?></span></a>/<span><?php echo $MESS['history_table_status_column']; ?></span></th>
						<th><a style="text-decoration: none;" href="<?php echo $page_link; ?>&nam_date=<?php echo $cre_value; ?>"><?php echo ($cre_value === "asc")?'&#9650;':'&#9660;'?><?php echo $MESS['history_table_name_column']?></a></th>
						<th><?php echo $MESS['history_table_phone_column']?></th>
						<th><a style="text-decoration: none;" href="<?php echo $page_link; ?>&mail_date=<?php echo $cre_value; ?>"><?php echo ($cre_value === "asc")?'&#9650;':'&#9660;'?><?php echo $MESS['history_table_email_column']?></a></th>

						<th><?php echo $MESS['history_table_items_column']?></th>
						<th><?php echo $MESS['history_table_sum_column'].' ('.$basket_settings['CURRENCY']; ?>)</th>
					</tr>
				</thead>
				<tbody> <?php
			//table elements with pagination
			if (isset($_GET['page'])) {
				$page = $_GET['page'];
			} else {
				$page = 0;
			}
			for ($k = intVal($page*15) ; $k<intVal($page*15+15); $k++) {
				if (file_exists(@$arFiles[$k]['PATH'])) {
					$status = '';
					$xmlItem = getXML($arFiles[$k]['PATH']);
					foreach ($arStatus as $oneStatus) {
						if ($oneStatus == unserialize($xmlItem->status)) {
							$status .= '<option value="'.$oneStatus.'" selected>'.$oneStatus.'</option>';
						} else {
							$status .= '<option value="'.$oneStatus.'">'.$oneStatus.'</option>';
						}
					} ?>
					<tr>
						<td align="right"><?php echo intVal($k+1); ?></td>
						<td align="right"><?php echo isset($xmlItem->order_nr) ? unserialize($xmlItem->order_nr) : intVal($k+1); ?></td>
						<td align="center">
							<?php echo date($date_formatter, strtotime(unserialize($xmlItem->date))); ?>
							<br />
							<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
								<input type="hidden" name="file" value="<?php echo $arFiles[$k]['PATH']?>" />
								<select name="status_change" onchange="this.form.submit();"><?php echo $status?></select>
							</form>
						</td>
						<td><?php echo unserialize($xmlItem->name); ?></td>
						<td><?php echo unserialize($xmlItem->phone); ?></td>
						<td><a href="mailto:<?php echo unserialize($xmlItem->email); ?>"><?php echo unserialize($xmlItem->email); ?></a></td>
						<td align="center"><a style="display:block; padding: 2px; background: #CF3805; text-decoration: none; color: #fff;" href="javascript:void(0)" onclick="$('#item_<?php echo $i?>').slideToggle()" title="<?php echo $MESS['history_show_hidden_button']?>"><b><?php echo unserialize($xmlItem->items); ?></b></a></td>
						<td align="center"><?php echo unserialize($xmlItem->sum); ?></td>
					</tr>
					<tr style="background: #F6F6F6">
						<td colspan="8" style="padding:0">
							<div id="item_<?php echo $i?>" style="display:none">
								<?php echo $xmlItem->order?>
								<P>
								<strong><?php echo $MESS['history_table_message_column']?>: </strong>
								<?php echo @unserialize($xmlItem->message); ?></p>
								<form style="margin-bottom: 10px" action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
								<div style="text-align: right; margin-bottom: 10px;">
									<button class="filedelete" name="file_delete" value="<?php echo $arFiles[$k]['PATH']?>" title="<?php  echo $MESS['history_file_delete_button']?>">X</button>
								</div>
									<center>
										<input type="hidden" name="file" value="<?php echo $arFiles[$k]['PATH']; ?>" />
										<textarea name="admin_message" style="width:95%;height:100px"><?php echo unserialize($xmlItem->admin_message); ?></textarea>
										<input type="submit" value="<?php echo $MESS['history_make_comment_button']?>">
									</center>
								</form>
							</div>
						</td>
					</tr> <?php
					++$i;
				}
			} ?>
				</tbody>
			</table> <?php
		}
	}
	elseif (isset($_GET['discounts'])) {
?>		<center><p style="font-size:150%; font-weight:bold;"><?php echo $MESS['discounts_title']?></p></center>
<?php
		global $discounts_file;
		$DiscoutsXML = getXML($discounts_file); ?>

		<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
			<table>
				<thead>
					<tr>
						<th colspan="2"><?php echo $MESS['discount_page_add_discount_title']?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo $MESS['discount_page_discount_code']?></td>
						<td><input style="width:100%; padding: 5px;" type="text" name="code"></td>
					</tr>
					<tr>
						<td><?php echo $MESS['discount_page_discount_value']?></td>
						<td><input style="width:100%; padding: 5px;" type="text" name="value"></td>
					</tr>
					<tr>
						<td><?php echo $MESS['discount_page_discount_use']?></td>
						<td><input style="width:100%; padding: 5px;" type="text" name="use"></td>
					</tr>
					<tr>
						<td><?php echo $MESS['discount_page_discount_description']?></td>
						<td><input style="width:100%; padding: 5px;" type="text" name="desc"></td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="2" align="center"><input style="padding:0 30px" type="submit" name="create_discount" value="<?php echo $MESS['discount_page_create_discount_button']?>"></td>
					</tr>
				</tfoot>
			</table>
		</form>
		<hr/>

		<table width="100%">
			<thead>
				<tr>
					<th width="15%"><?php echo $MESS['discount_page_discount_code']?></th>
					<th width="40%"><?php echo $MESS['discount_page_discount_description']?></th>
					<th width="30%"><?php echo $MESS['discount_page_discount_value']?></th>
					<th width="10%"><?php echo $MESS['discount_page_discount_use']?></th>
					<th colspan="2" width="10%"><?php echo $MESS['discount_page_discount_actions']?></th>
				</tr>
			</thead>
			<tbody>
<?php	foreach ($DiscoutsXML as $arDiscount) { ?>
				<tr>
					<td><strong><?php echo (string)$arDiscount->code; ?></strong></td>
					<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
						<input type="hidden" name="code" value="<?php echo (string)$arDiscount->code; ?>">
						<td><?php echo (string)$arDiscount->desc; ?></td>
						<td><input type="text" name="value" value="<?php echo (string)$arDiscount->value; ?>"></td>
						<td><input type="text" name="use" value="<?php echo (string)$arDiscount->use; ?>"></td>
						<td><input type="submit" name="change_discount" value="<?php echo $MESS['discount_page_discount_change']?>"></td>
					</form>
					<td>
						<center>
							<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'])?>" method="post">
								<input type="hidden" name="code" value="<?php echo (string)$arDiscount->code; ?>">
								<input type="submit" name="delete_discount" value="X">
							</form>
						</center>
					</td>
				</tr>
<?php	} ?>
			</tbody>
		</table>
<?php
	}
}

function show_related_items() {
	global $basket_settings; global $MESS;
	$spec_name = return_special_page_type();
	$pages_data = getXML(GSDATAOTHERPATH.'pages.xml');
	$related_data = array();
	$position = (strpos(return_special_field('url'), '_') !== false) ? strpos(return_special_field('url'), '_') : strlen(return_special_field('url'));
	$current = substr(return_special_field('url'), 0, $position);
	$related_count = isset($basket_settings['RELATED_COUNT']) ? (int) $basket_settings['RELATED_COUNT'] : 3;
	foreach($pages_data as $page_data) {
		$page_url = $page_data->url;
		if($page_data->special == $spec_name && $page_data->related == "on" && $current != $page_data->url && strpos($page_data->url, '_') === false) {
			$related_data[] = array("special" => (string) $page_data->special, "related" => (string) $page_data->related, "title" => (string) $page_data->title, "image" => (string) $page_data->image, "url" => (string) $page_data->url, "price" => (string) $page_data->price, "rebate" => (string) $page_data->rebate, "ispercent" => (string) $page_data->ispercent,);
		}
	}
	shuffle($related_data);
	unset($pages_data);
	if(count($related_data) > 0) {
		$counter = 0;
	?>
	<div class="related-products">
		<h3 class="related-title"><?php echo $MESS['show_related_title']; ?></h3> <?php
	foreach($related_data as $relate_data) {
		if($counter >= $related_count) {
			echo '</div>';
			return false;
		}
		if($relate_data['special'] == $spec_name && $relate_data['related'] == "on") { ?>
		<div class="basket-items col-md-4 col-sm-4 col-xs-4 col-lg-4">
			<div class="wrapper">
				<a href="<?php echo filter_var($relate_data['url'], FILTER_SANITIZE_URL); ?>">
<?php		if ($relate_data['image']) { ?>
					<div class="img-outer">
						<img src="<?php echo htmlspecialchars($relate_data['image']); ?>" alt="<?php echo $relate_data['title']; ?>" title="<?php echo $relate_data['title']; ?>" />
					</div>
				</a>
				<div class="title-outer <?php echo $relate_data['title']; ?>">
					<a href="<?php echo filter_var($relate_data['url'], FILTER_SANITIZE_URL); ?>" class="item-title"><?php echo $relate_data['title']; ?>
					</a>
				</div>
<?php if (!empty($relate_data['rebate'])){ ?>
		<div class="discount-image" title="<?php echo $MESS['item_discount']; ?>">
		<?php if ($relate_data['ispercent'] == "on"){ ?>
			<span class="discount-text"><?php echo htmlspecialchars($relate_data['rebate']); ?>%</span>
		<?php } else { ?>
			<span class="discount-text"><?php echo htmlspecialchars($relate_data['rebate']).' '.$basket_settings['CURRENCY']; ?></span>
		<?php } ?>
		</div>
		<div class="discount-prices">
			<span class="old-price"><?php echo htmlspecialchars($relate_data['price']).' '.$basket_settings['CURRENCY']; ?></span> 
		<?php if ($relate_data['ispercent'] == "on"){
			$price = number_format($relate_data['price'] - (($relate_data['price'] /100) * $relate_data['rebate']), 2, '.', '');
			?>
			<span class="new-price"><?php echo $price; echo ' '.$basket_settings['CURRENCY']; ?></span>
		<?php } else {
			$price = number_format($relate_data['price'] - $relate_data['rebate'], 2, '.', '');
			?>
			<span class="new-price"><?php echo $price;  echo ' '.$basket_settings['CURRENCY']; ?> </span>
		<?php } ?>
		</div>
	<?php } else { ?>
		<div class="new-price"><?php echo $relate_data['price'];  echo ' '.$basket_settings['CURRENCY']; ?></div>
	<?php } ?>
			</div>
		</div>
<?php		}
			$counter++;
		}
	}
?>	</div> <?php
	}
}
?>