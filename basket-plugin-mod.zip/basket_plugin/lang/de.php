<?php
// german language file v0.1 for cart get-simple v1.0
// 2014 phpman@outlook.com
global $MESS;
$MESS['register_plugin_name'] = 'Warenkorb f&uuml;r GetSimple MOD';
$MESS['register_plugin_desc'] = 'Warenkorb Funktion f&uuml;r CMS GetSimple';
$MESS['tab_sidebar_settings_name'] = 'Basket Einstellungen';
$MESS['tab_sidebar_history_name'] = 'Basket Bestellhistorie';
$MESS['in_letter_order_was_created'] = 'neue Bestellung wurde erstellt';
$MESS['in_letter_user_name'] = 'Kunden Name:';
$MESS['in_letter_user_phone'] = 'Kunden Telefonnummer:';
$MESS['in_letter_user_email'] = 'Kunden E-Mail:';
$MESS['in_letter_user_message'] = 'Kunden Nachricht:';
$MESS['in_letter_delivery_label'] = 'Lieferung:';
$MESS['in_letter_payment_label'] = 'Zahlung:';
$MESS['in_letter_order_list_title'] = 'Bestell-Liste';
$MESS['table_picture_column'] = 'Bild';
$MESS['table_name_column'] = 'Artikel';
$MESS['table_price_column'] = 'Preis';
$MESS['table_quantity_column'] = 'Menge';
$MESS['table_sum_column'] = 'Summe';
$MESS['table_delete_column'] = 'Reiben';
$MESS['cart_small_link_title'] = 'Warenkorb';
$MESS['cart_small_cart_items_message'] = 'Artikel';
$MESS['cart_small_cart_items_message_count'] = ' ';
$MESS['cart_small_cart_items_sum'] = 'Gesamt';
$MESS['cart_small_empty_basket_message'] = 'Ihr Warenkorb ist leer';
// translation done

$MESS['cart_page_empty_basket_message'] = 'Make order first';

// translation done
$MESS['cart_page_title'] = 'Ihr Warenkorb';
$MESS['cart_page_no_picture_message'] = 'kein Bild';
$MESS['cart_page_order_list_total'] = 'Gesamtsumme';
$MESS['cart_page_form_title'] = 'Bestellformular';
$MESS['cart_page_form_field_name'] = 'Ihr Name:';
$MESS['cart_page_form_field_phone'] = 'Ihre Telefonnummer:';
$MESS['cart_page_form_field_email'] = 'Ihre E-Mail:';
$MESS['cart_page_form_field_delivery'] = 'Lieferung ausw&auml;hlen';
$MESS['cart_page_form_field_payment'] = 'Zahlung ausw&auml;hlen';
$MESS['cart_page_form_field_message'] = 'Nachricht:';
$MESS['cart_page_form_field_message_delivery'] = '(Lieferadresse)';
$MESS['cart_page_form_submit_value'] = 'Bestellung aufgeben';
$MESS['cart_page_form_select_empty_option'] = 'Aus Liste ausw&auml;hlen';
$MESS['settings_page_title'] = 'Warenkorb Einstellungen.';
$MESS['settings_radio_yes'] = 'Ja';
$MESS['settings_radio_no'] = 'Nein';
$MESS['settings_radio_top'] = 'oben';
$MESS['settings_radio_middle'] = 'mitte';
$MESS['settings_radio_bottom'] = 'unten';
$MESS['settings_page_save_history'] = 'Bestellverlauf speichern:';
$MESS['settings_page_admin_email'] = 'Administrator E-Mail:';
$MESS['settings_page_price_field'] = 'Special page Feld mit Preis:';
$MESS['settings_page_show_image'] = 'Bild in Warenkorb anzeigen?';
$MESS['settings_page_image_field'] = 'Spezialseiten Feld mit Bild (Pfad):';
$MESS['settings_page_letter_subject'] = 'Bestellseiten Betreff';
// translation done

$MESS['settings_page_sucess_text'] = 'Sucess text after order was maked (for user)';
$MESS['settings_page_smallcart_styles'] = 'Small cart styles';

// translation done
$MESS['settings_page_currency'] = 'Warenkorb W&auml;hrung';
$MESS['settings_page_message_position'] = 'Nachrichten Position';
$MESS['settings_page_message'] = '<br>Nachricht auf der Warenkorbseite <br> <b><i>html oder text</i></b>';
$MESS['settings_page_show_delivery'] = 'Lieferung anzeigen?';
$MESS['settings_page_delivery_options'] = 'Lieferoptionen <br>(durch Kommas getrennt)';
$MESS['settings_page_show_payment'] = 'Zahlung anzeigen?';
$MESS['settings_page_payment_options'] = 'Zahlungsoptionen <br>(durch Kommas getrennt)';
$MESS['settings_page_save_button'] = 'Einstellungen speichern';
$MESS['settings_page_required_plugins'] = 'Achtung! Installieren Sie erst folgende Plugins: ';
// translation done

$MESS['settings_page_instruction_plugins'] = 'Create a special page type with a price, image, and other necessary fields. Product selection is performed using a form field ID value. This field is should be transmitted to the plugin settings for further processing. Field value is determined separately for elements from the search results (Search button) and own brand page (button View). Search results ID field is obtained by using the function <b>return_special_field(\'id\')</b>. Item page - by using the function <b>get_page_slug()</b>.';
$MESS['settings_page_example_text'] = 'Example ("Search" and "Display" in Special Pages Settings render):';
$MESS['settings_page_danger_text'] = 'Don\'t change "name" attr in form input. Input name "id", "quantity" need to work plugin.';
$MESS['settings_page_special_demo_offer'] = '<strong>Warning!</strong><br>If you allready install required plugins you can';
$MESS['settings_page_special_demo_submit'] = 'Create Demo Special Page Types with all required fields you need';
$MESS['settings_page_forum_link'] = '<center>Forum thred <a href="http://get-simple.info/forums/showthread.php?tid=8438" target="_blank">here</a></center>';

// translation done
$MESS['history_title'] = 'Bestellhistorie';
$MESS['history_empty'] = 'Sie haben keine Bestellungen';
$MESS['history_status_default'] = 'Akzeptiert';
$MESS['history_status_waiting'] = 'Zahlung ausstehend';
$MESS['history_status_sucess'] = 'Fertig';
$MESS['history_status_canceled'] = 'Storniert';
$MESS['history_pagination'] = 'Seiten:';
$MESS['history_table_created_column'] = 'Erstelldatum';
$MESS['history_table_status_column'] = 'Status';
$MESS['history_table_name_column'] = 'Name';
$MESS['history_table_phone_column'] = 'Telefon';
$MESS['history_table_email_column'] = 'E-Mail';
$MESS['history_table_message_column'] = 'Nachricht';
$MESS['history_table_items_column'] = 'Artikel';
$MESS['history_table_sum_column'] = 'Summe';
// v0.8
$MESS['cart_page_list_title'] = 'Bestell-Liste';
$MESS['quantity_change_button'] = '&Auml;nderung';
// translation done

$MESS['settings_page_ajax'] = 'Use AJAX <br>(form must have "<strong>add-form</strong>" class)?';
$MESS['settings_page_jquery_include'] = 'Include Jquery library from cloud?';

// translation done
$MESS['go_to_spec_page_settings'] = 'gehe zu Spezialseiten Einstellungen';
// v 1.0
$MESS['history_page_title'] = 'Bestellhistorie';
$MESS['history_page_insert_number'] = 'Ihre Bestellnummer';
$MESS['history_page_insert_name'] = 'Ihr Name';
$MESS['history_page_get_order_button'] = 'Bestellung anzeigen';
$MESS['history_page_wrong_number'] = 'Bestellung mit dieser Nummer existiert nicht!';
$MESS['history_page_wrong_user'] = 'falscher Name!';
// translation done

$MESS['history_page_admin_message'] = 'Manager message';

// translation done
$MESS['order_number'] = 'Ihre Bestellnummer lautet ';
$MESS['order_status'] = 'Bestellstatus';
$MESS['order_created'] = 'Bestellung wurde erstellt';
$MESS['order_contain'] = 'Bestellartikel';
$MESS['show_history_link_text'] = 'Bestellhistorie';
$MESS['settings_page_show_history_to_user'] = 'Bestellhistorie f&uuml;r Benutzer anzeigen?';
// translation done

$MESS['history_make_comment_button'] = 'Make manager message';
// v 1.1
$MESS['settings_page_use_discounts'] = 'Use discounts?';
$MESS['tab_sidebar_discounts_name'] = 'Basket Discounts';
$MESS['discounts_title'] = 'Site discounts';
$MESS['discount_page_add_discount_title'] = 'Add new discount';
$MESS['discount_page_discount_code'] = 'Code';
$MESS['discount_page_discount_value'] = 'Discount size (%)';
$MESS['discount_page_discount_use'] = 'Uses';
$MESS['discount_page_discount_description'] = 'Discount description';
$MESS['discount_page_create_discount_button'] = 'Add Discount';
$MESS['discount_page_discount_actions'] = 'Actions';
$MESS['discount_page_discount_change'] = 'Change';
$MESS['cart_page_discount_not_exists'] = 'Discount is not exists';
$MESS['cart_page_discount_was_used'] = 'This discount was used';
$MESS['cart_page_discount_accepted'] = 'Discount accepted! Sum with dicount -';
$MESS['cart_page_discount_persent'] = 'Discount size -';
$MESS['cart_page_discount_input_code'] = 'Enter discount code';
$MESS['cart_page_discount_code_submit'] = 'Enter code';
$MESS['in_letter_discount_was_used'] = 'Use discount code:';
// v 1.2
$MESS['print_order'] = 'Print order';
$MESS['settings_page_allow_print_order'] = 'Allow print orders?';
//MOD v 1.2.1
$MESS['buy_item'] = 'In den Korb';
$MESS['new_item'] = 'Neue Vertriebs';
$MESS['item_discount'] = 'Werbeartikel ';
$MESS['quantity_short'] = 'Menge';
$MESS['save_money'] = 'Speichern';
$MESS['in_stock'] = 'Auf Lager';
$MESS['specifications'] = 'Spezifikationen';
$MESS['Pickup'] = 'DPD Sendung';
$MESS['By post'] = 'In der Post';
$MESS['Courier'] = 'per Kurier';
$MESS['Cash when pickup'] = 'Nachnahme';
$MESS['Cash to courier'] = 'Cash-Kurier';
$MESS['By Card when pickup'] = 'Kreditkarte nach der Entbindung';
$MESS['By Card to courier'] = 'Kreditkarte Kurier';
$MESS['Cash(on post)'] = 'Bargeld per Post';
$MESS['OK_TEXT'] = 'Ihre Bestellung wurde angenommen. Wir werden Sie in K�rze kontaktieren.';
$MESS['LETTER_HEADER'] = 'Der neue Auftrag wurde durchgef�hrt';
$MESS['settings_page_special_demo_tv'] = 'Erstellen TV Demos spezielle Seitentyp';
$MESS['settings_page_special_demo_laptop'] = 'Erstellen Laptops Demos spezielle Seitentyp';
$MESS['is_basket_show'] = 'Warenkorb zeigen auf diesen Seiten nur<br>(seiten slugs durch Komma getrennt):';
$MESS['is_basket_childs'] = 'Einschlie�lich Kinderseiten';
$MESS['settings_page_pretty_include'] = 'Einschlie�en PrettyPhoto bibliothek?';
//MOD v 1.2.2
$MESS['history_table_order_number'] = 'Art.-Nr.';
$MESS['order_status_desc'] = '<br>Sie k�nnen durch Eingabe der Auftragsnummer und Ihren Namen den Status Ihrer Bestellhistorie �berwachen.';
$MESS['MAIL_ERR_SEND'] = '<strong>Fehler!</strong> Es scheint, dass es ein Problem mit Ihrer Nachricht ist, bitte es zu beheben und versuchen Sie es erneut:';
$MESS['MAIL_ERROR'] = 'Sorry, die E-Mail-Adresse, die Sie eingegeben haben, war ung�ltig! Versuchen Sie eine andere E-Mail-Adresse eingeben.';
$MESS['CAPTCHA_TXT'] = 'CAPTCHA-Test.<br>Schutz vor Spam-Versand.';
$MESS['CAPTCHA_RELOAD'] = 'erfrischen';
$MESS['CAPTCHA_TEXT'] = 'Geben Sie die Ziffern';
$MESS['CAPTCHA_ERROR'] = 'Sorry, das CAPTCHA-Code wurde nicht korrekt eingegeben!';
//MOD v 1.2.3
$MESS['settings_page_rebate_field'] = 'Spezielle Seitenfeld mit dem Handelsrabatt:';
$MESS['settings_page_percent_field'] = 'Spezielle Seitenfeld mit dem Handel der prozentualen Rabatt:';
$MESS['bad_characters_exists'] = '<span style="color:#f00;">Leider d�rfen nur Buchstaben, Ziffern, Bindestriche eingeben, Striche, Punkten und Leerzeichen.</span>';
$MESS['bad_numbers_exists'] = '<span style="color:#f00;">Leider erlaubt nur Zahlen eingeben.</span>';
$MESS['history_show_hidden_button'] = 'Zeigen Sie bestellen Details';
$MESS['history_file_delete_button'] = 'L�schen Sie diese Protokolldatei ';

$MESS['settings_page_show_banklink'] = 'Installierte Banklinks Gateways:';
$MESS['banklink_pay_text'] = 'Bezahlen eine Bestellung';
$MESS['banklink_form_text'] = 'Die Zahlung durch die Banklink ';
$MESS['in_letter_click'] = ' Oder klicken Sie auf diesen Link: ';
$MESS['in_letter_your_order'] = 'Ihre Bestellung Info';
$MESS['settings_page_send_mail_buyer'] = 'Sende eine Mail an den Benutzer nach der Best�tigung?';
$MESS['order_check_mail'] = '�berpr�fen Sie Ihre E-Mail-Adresse, haben wir Ihnen die Buchungsdaten verschickt.';
$MESS['datetime_formatter'] = 'd-m-Y H:i:s';
$MESS['clear_filters'] = 'Filter l�schen';
$MESS['search_order_nr'] = 'Nach Angaben der Bestellnummer';
$MESS['settings_page_show_related'] = 'Siehe verwandte Produkte auf der Produktseite?';
$MESS['show_related_title'] = '�hnliche Produkte';
$MESS['settings_page_related_count'] = 'Verwandte Artikel pro Seite?';
?>