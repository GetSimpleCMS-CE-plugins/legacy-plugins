<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}
/*
Plugin Name: sponsorlogo
Description: Plugin to show a sponsor page or randomly show sponsor logos.
Version: 1.1
Author: Ruud Hop
Author URI: http://www.hopjes.net/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
	$thisfile, 
	'Sponsor logo', 	
	'1.1', 		
	'Ruud Hop',
	'http://www.hopjes.net/', 
	'Plugin to show a sponsor page or randomly show sponsor logos',
	'pages',
	'sponsorlogo_admin'  
);


# language
$file = GSDATAOTHERPATH.'/sponsorlogo.xml';
if(!file_exists($file)) {
    # If not exist: create settings file
    $xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><sponsorlogo_plugin></sponsorlogo_plugin>');
    $xml->addChild('lang', 'en_US');
    XMLsave($xml, $file);
}
$xml = simplexml_load_file($file);
$lang = $xml->lang;
i18n_merge('sponsorlogo', $lang) || i18n_merge('sponsorlogo', 'en_US'); # language selection
$LANG = $lang;
unset($xml, $file, $lang);


# hooks, filters
add_action('pages-sidebar', 'createSideMenu', array($thisfile, i18n_r('sponsorlogo/sponsorlogo')));


# create folder for logo files if not exists 
if(!is_dir(GSDATAOTHERPATH.'/sponsorlogo')) {
    mkdir(GSDATAOTHERPATH.'/sponsorlogo');
}

# Check if admin page is loaded, if yes, start with list
if(!isset($_GET['sponsorlogo']) and !isset($_GET['settings']) and !isset($_GET['edit'])) $_GET['list'] = True;

# admin page
function sponsorlogo_admin() {
    include 'sponsorlogo/admin.php';
}

# frontend
# Sponsorpage
$xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo.xml');
if(isset($_GET['id']) && ($xml->page == $_GET['id'] or $xml->page == "index")) {
    function c_client_sponsorpage() { 
        include 'sponsorlogo/inc/client_sponsorpage.php'; 
    }
    add_filter('content', 'c_client_sponsorpage');
}

# Sponsorlist
include 'sponsorlogo/inc/client_sponsorlist.php';

?>