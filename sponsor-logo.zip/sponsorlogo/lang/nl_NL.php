<?php

/**
 * Sponsorlogo english language by Ruud Hop
 */

$i18n = array(
    'sponsorlogo' => 'Sponsorlogo Beheer',
    'sponsorlogo_settings' => 'Sponsorlogo Instellingen',
    'or' => 'of',
	'example' => 'voorbeeld',
	#fields
    'sponsor_name' => 'Sponsornaam',
    'page_name' => 'Sponsorpagina',
    'language' => 'Taal',
    'contents' => 'Inhoud',
    # buttons
    'add' => 'Toevoegen',
    'list' => 'Lijst',
    'settings' => 'Instellingen',
    'settingsSave' => 'Instellingen opslaan',
    'save' => 'Opslaan',
    'delete' => 'Verwijderen',
    'delete_sponsor' => 'Verwijder sponsor',
	#messages
    'deleteSuccess' => 'Verwijderd',
    'settingsChangeSuccess' => 'Instellingen opgeslagen',
	'NoLogosFound' => 'Er zijn nog geen logo\'s gedefinieerd.',
	#help
    'helpPage' => 'Om een sponsorpagina toe te voegen (lijst van alle sponsors): <br>- Maak een lege pagina.<br>- Ga naar <font style="color: darkblue;">admin->pagina\'s->Sponsorlogo Beheer(in de zijbalk)->Instellingen.</font><br>- Stel de nieuwe pagina in als "Sponsorpagina".',
	'helpCSSpage' => 'Om de opmaak van de sponsorpagina te wijzigen, wijzig het bestand <font style="color: green;">plugins/sponsorlogo/css/sponsorpage.css</font>',
	'helpList' => 'Om een lijst met willekeurige sponsors op een pagina te tonen: plaats <font style="color: darkred;">&lt;?php c_sponsorlist(); ?&gt; </font>in je php template bestand. <br>Standaard worden er twee sponsorlogo\'s getoond: wijzig het bijvoorbeeld in <font style="color: darkred;">&lt;?php c_sponsorlist(3); ?&gt;</font> om er drie te tonen.',
    'helpCSSlist' => 'Om de opmaak van de sponsorlijst/tabel te wijzigen, wijzig het bestand <font style="color: green;">plugins/sponsorlogo/css/sponsorlist.css</font>',
);

?>
