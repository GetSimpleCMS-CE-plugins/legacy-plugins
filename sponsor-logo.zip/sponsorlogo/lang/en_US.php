<?php

/**
 * Sponsorlogo english language by Ruud Hop
 */

$i18n = array(
    'sponsorlogo' => 'Sponsor logo Manager',
    'sponsorlogo_settings' => 'Sponsor logo Settings',
	'or' => 'or',
	'example' => 'example',
	#fields
    'sponsor_name' => 'Sponsor name',
    'page_name' => 'Sponsor page',
    'language' => 'Language',
    'contents' => 'Content',
    # buttons
    'add' => 'Add',
    'list' => 'List',
    'settings' => 'Settings',
    'settingsSave' => 'Save settings',
    'save' => 'Save',
    'delete' => 'Delete',
    'delete_sponsor' => 'Delete sponsor',
	#messages
    'deleteSuccess' => 'Delete success',
    'settingsChangeSuccess' => 'Settings successfully changed',
	'NoLogosFound' => 'There are no logos defined yet.',
	#help
    'helpPage' => 'To add a page with all sponsors:<br>- Create an empty page.<br>- goto <font style="color: darkblue;">admin->pages->Sponsor logo Manager(in sidebar)->settings.</font><br>- Set the new page as the "Sponsor page".',
	'helpCSSpage' => 'To change the style of the page with sponsor logos, edit file: <font style="color: green;">plugins/sponsorlogo/css/sponsorpage.css</font>',
	'helpList' => 'To add a sponsor list just write: <font style="color: darkred;">&lt;?php c_sponsorlist(); ?&gt; </font>in your php template file. <br>If you want to show 3 sponsors, you just write: <font style="color: darkred;">&lt;?php c_sponsorlist(3); ?&gt;</font>',
    'helpCSSlist' => 'To change the sponsor list/table style edit file: <font style="color: green;">plugins/sponsorlogo/css/sponsorlist.css</font>',
);

?>
