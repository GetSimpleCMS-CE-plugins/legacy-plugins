<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');} ?>
<h3 class="floated"> <?php if(isset($_GET['settings'])) i18n('sponsorlogo/sponsorlogo_settings'); else i18n('sponsorlogo/sponsorlogo'); ?></h3>
<div class="edit-nav clearfix">
    <a href="load.php?id=sponsorlogo&settings" <?php if(isset($_GET['settings'])) { ?>class="current"<?php } ?>><?php i18n('sponsorlogo/settings'); ?></a>
    <a href="load.php?id=sponsorlogo&list" <?php if(isset($_GET['list'])) { ?>class="current"<?php } ?>><?php i18n('sponsorlogo/list'); ?></a>
    <a href="load.php?id=sponsorlogo&edit" <?php if(isset($_GET['edit'])) { ?>class="current"<?php } ?>><?php i18n('sponsorlogo/add'); ?></a>
</div>
<?php 
if(isset($_GET['delete'])) {
    # Delete
    $file = GSDATAOTHERPATH.'/sponsorlogo/'.$_GET['delete'].'.xml';
    if(file_exists($file)) {
        # delete file
        unlink($file);
        # show message
        $msg .= i18n_r('sponsorlogo/deleteSuccess').'!'
        ?>
        <script type="text/javascript">
          $(function() {
            $('div.bodycontent').before('<div class="<?php echo $isSuccess ? 'updated' : 'error'; ?>" style="display:block;">'+
                    <?php echo json_encode($msg); ?>+'</div>');
            $(".updated, .error").fadeOut(500).fadeIn(500);
          });
        </script>
        <?php 
    }
}

if(isset($_GET['list'])) { 
    # List of sponsors
    include 'inc/admin_list.php';
    
} elseif(isset($_GET['settings'])) { 
    # Settings
    include 'inc/admin_settings.php';
    
} elseif(isset($_GET['edit'])) { 
    # Edit sponsor definition
    include 'inc/admin_edit.php';
    
}
?>