<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

function c_sponsorlist($ShowNrOfLogos = False) {
    
    $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo.xml');
    $page = $xml->page;
    $url = 'index.php?id='.$page;
    
    $sponsors = array();
    $number = 1;
    if($ShowNrOfLogos == False) $ShowNrOfLogos = 2;
    
    # Load sponsors in array
    $dir = opendir(GSDATAOTHERPATH.'/sponsorlogo');
    while($file = readdir($dir)) {
        if($file != '.' and $file != '..'){
            $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo/'.$file);
			$contents = $xml->contents;
            $sponsors["$number"] = $contents;
            $number++;
        }
    }
	$FoundLogos = $number - 1;
    closedir($dir);

	$sponsor_list = '';
	if ($FoundLogos == 0) {
		# No logo defintions found
		$sponsor_list = '<td>'.i18n_r('sponsorlogo/NoLogosFound').'</td>';
	} elseif ($FoundLogos <= $ShowNrOfLogos) {
		# Logo's found, but just enough or less then the amount to show, so show all without randomizing.
		foreach($sponsors as $content) {
			$sponsor_list .= '<td>'.$content.'</td>';
		}
	} else {
		# More than enough logo's found, take a random pick to show.
		$random_number_array = range(1, $FoundLogos);
		shuffle($random_number_array );
		$random_number_array = array_slice($random_number_array, 0, $ShowNrOfLogos);
		foreach($random_number_array as $number) {
			$sponsor_list .= '<td>'.$sponsors["$number"].'</td>';
		}

	}
    # show the table with sponsors
    ?>
    <link type="text/css" href="<?php get_site_url(); ?>/plugins/sponsorlogo/css/sponsorlist.css" rel="stylesheet" />
    <table id="sponsorlist">
		<tr>
        <?php echo $sponsor_list; ?>
		</tr>
    </table>

    <?php
}
?>
