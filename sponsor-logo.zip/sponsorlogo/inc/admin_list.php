<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

    function c_list() {
        $dir = opendir(GSDATAOTHERPATH.'/sponsorlogo');
        
        while($file = readdir($dir)) {
            if($file != '.' and $file != '..'){
                $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo/'.$file);
                $name = $xml->name;
                $list["$name"] = $file;
            }
        }
        closedir($dir);
        
		$list = empty($list)? '' : $list;
		if ($list != null) {
		
			ksort($list);
            foreach($list as $name => $file) {
				$xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo/'.$file);
				$file = explode('.', $file);
				$file = $file[0];
				$name = $xml->name;
				?>
				<tr>
					<td class="posttitle">
						<a href="load.php?id=sponsorlogo&edit=<?php echo $file; ?>"><?php echo $name; ?></a>
					</td>
					<td class="delete">
						<a href="load.php?id=sponsorlogo&delete=<?php echo $file; ?>" class="delconfirm" title="<?php i18n('sponsorlogo/delete_sponsor'); ?>: <?php echo $name; ?>">X</a>
					</td>
				</tr>
				<?php 
			}
		}
    }
    
?>    
<table id="posts" class="highlight">
    <tr>
        <th><?php i18n('sponsorlogo/sponsor_name'); ?></th>
        <th></th>
    </tr>
    <tr>
        <?php c_list(); ?>
    </tr>
</table>