<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

    if(isset($_POST['page']) and isset($_POST['lang'])) {
        $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo.xml');
        $xml->lang = $_POST['lang'];
        $xml->page = $_POST['page'];
        XMLsave($xml, GSDATAOTHERPATH.'/sponsorlogo.xml');
        # display message
		$msg = "";
		$msg .= i18n_r('sponsorlogo/settingsChangeSuccess').'!';
        ?>
        <script type="text/javascript">
          $(function() {
            $('div.bodycontent').before('<div class="<?php echo $isSuccess ? 'updated' : 'error'; ?>" style="display:block;">'+
                    <?php echo json_encode($msg); ?>+'</div>');
            $(".updated, .error").fadeOut(500).fadeIn(500);
          });
        </script>
        <?php 
    }
    
	# Load current settings
    $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo.xml');
    $setLang = $xml->lang;
    $setPage = $xml->page;
?>
<form class="largeform" id="settings" action="load.php?id=sponsorlogo&settings" method="post" accept-charset="utf-8">
    <div class="leftsec">
        <p>
            <label><?php i18n('sponsorlogo/page_name'); ?>:</label>
            <select class="text" name="page">
                <?php
                $pages = get_available_pages();
                foreach ($pages as $page) {
                    $slug = $page['slug'];
                    if ($slug == $setPage)
                        echo '<option value="'.$slug.'" selected="selected">'.$slug.'</option>\n';
                    else
                        echo '<option value="'.$slug.'">'.$slug.'</option>\n';
                }
                ?>
            </select>
        </p>
    </div>
    <div class="rightsec">
        <p>
            <label><?php i18n('sponsorlogo/language'); ?>:</label>
            <select class="text" name="lang">
                <?php
                    $dir = opendir('../plugins/sponsorlogo/lang');
                    while($file = readdir($dir)) {
                        if($file != '.' and $file != '..' and $file != '.htaccess') {
                            $lang = explode('.', $file);
                            $lang = $lang[0];
                            if ($lang == $setLang)
                                echo '<option value="'.$lang.'" selected="selected">'.$lang.'</option>\n';
                            else
                                echo '<option value="'.$lang.'">'.$lang.'</option>\n';
                        }
                    }
                    closedir($dir);
                ?>
            </select>
        </p>
    </div>
    <div class="clear"></div>
    <p>
        <span>
            <input class="submit" type="submit"value="<?php i18n('sponsorlogo/settingsSave'); ?>" />
        </span>
    </p>
    <br /><br />
    <p style="font-size: 12px;">
		<?php i18n('sponsorlogo/helpPage'); ?><br />
		<br />
		<?php i18n('sponsorlogo/helpCSSpage'); ?><br />
        <br />
		<?php i18n('sponsorlogo/helpList'); ?><br />
        <br />
		<?php i18n('sponsorlogo/helpCSSlist'); ?><br />
    </p>
</form>