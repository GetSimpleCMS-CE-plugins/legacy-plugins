<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

function c_sponsorpage() {
	$sponsors = array();
    $number = 1;
    
    # Load sponsors in array
    $dir = opendir(GSDATAOTHERPATH.'/sponsorlogo');
    while($file = readdir($dir)) {
        if($file != '.' and $file != '..'){
            $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo/'.$file);
			$contents = $xml->contents;
            $sponsors["$number"] = $contents;
            $number++;
        }
    }
	$FoundLogos = $number - 1;
    closedir($dir);

	$sponsor_page = '';
	if ($FoundLogos == 0) {
		# No logo defintions found
		$sponsor_page = i18n_r('sponsorlogo/NoLogosFound');
	} else {
		# Logo's found, create table with logo's.
		$sponsor_page = '';
		$number = 0;
		foreach($sponsors as $content) {
			if ($number == 0) { $sponsor_page .= '<tr>'; }
			$sponsor_page .= '<td>'.$content.'</td>';
            $number++;
			if ($number == 2) { 
				$sponsor_page .= '</tr>'; 
				$number = 0;
			}
		}
		# odd number of logo's, close table row
		if ($number == 1) { $sponsor_page .= '<td></td></tr>'; }
	}
	echo $sponsor_page;
}
?>
<link type="text/css" href="<?php get_site_url(); ?>/plugins/sponsorlogo/css/sponsorpage.css" rel="stylesheet" />
<table id="sponsorlogo">
    <?php
        $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo.xml');
        $page = $xml->page;
        c_sponsorpage();
    ?>
</table>

