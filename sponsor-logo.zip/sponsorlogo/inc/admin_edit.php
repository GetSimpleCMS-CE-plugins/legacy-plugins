<?php if (!defined('IN_GS')) {die('you cannot load this page directly.');}

	global $HTMLEDITOR;
	
	$name = empty($name)? i18n_r('sponsorlogo/example') : $name;
	$contents = empty($contents)? '' : $contents;
	$file = empty($file) ? '' : $file;
	
    if(isset($_POST['name']) and isset($_POST['post-content'])) {
        $xml = simplexml_load_file(GSPLUGINPATH.'/sponsorlogo/example.xml');
        $xml->name = $_POST['name'];
        $xml->contents = $_POST['post-content'];
        $file = $_POST['name'];
        $file = stripslashes($file);
        $file = to7bit($file, 'UTF-8');
        $file = clean_url($file);
        XMLsave($xml, GSDATAOTHERPATH.'/sponsorlogo/'.$file.'.xml');
        $_GET['edit'] = $file;
    }

    if(!empty($_GET['edit'])) {
        $xml = simplexml_load_file(GSDATAOTHERPATH.'/sponsorlogo/'.$_GET['edit'].'.xml');
 		$file = explode('.', $file);
        $file = $file[0];
		$name = $xml->name;
        $contents = $xml->contents;
    }
?>
<form action="load.php?id=sponsorlogo&edit=<?php echo $_GET['edit']; ?>" method="POST">
    <p>
        <label><?php i18n('sponsorlogo/sponsor_name'); ?>:</label>
        <input class="text short" type="text" name="name" value="<?php echo $name; ?>" style="width: 250px;" />
    </p>
    <p>
        <label><?php i18n('sponsorlogo/contents'); ?>:</label>
        <textarea name="post-content" id="post-content"><?php echo $contents; ?></textarea>	
		<?php
			# wysiwyg editor
			if (isset($HTMLEDITOR) && $HTMLEDITOR != '') include('ckeditor.php');
		?>
	</p>
    <input type="submit" class="submit" value="<?php i18n('sponsorlogo/save'); ?>" /> <?php i18n('sponsorlogo/or'); ?> <a class="cancel" href="load.php?id=sponsorlogo&delete=<?php echo $_GET['edit']; ?>" title="<?php i18n('sponsorlogo/delete_sponsor'); ?>: <?php echo $_GET['edit']; ?>"><?php i18n('sponsorlogo/delete'); ?></a>
</form>