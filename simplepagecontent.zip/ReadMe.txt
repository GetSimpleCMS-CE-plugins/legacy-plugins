Plugin Name: Simple Page Content
Description: Get a HTML of page without the whole html and template, but just only the page content
Version: 1.2
Author: Sanjeya Cooray
Author URI: http://www.misadev.com/sanjeya/


----INSTALL----

copy SimplePageContent.php file in GetSimple CMS plugin folder


----USE----

in your template use this code to show a page

<?php echo get_page_by_id('page-slug'); ?>

page-slug is the slug of the page that you want to show