<?php

$i18n = array(
    "PASSWORD_TITLE"        => "Denne siden er passordbeskyttet",
    "ENTER_PASSWORD"        => "Skriv inn eit passord:",
    "PASSWORD_PLACEHOLDER"  => "Passord",
    "SUBMIT_BUTTON"         => "Lås Opp",
    "WRONG_PASSWORD"        => "<p style='color: red; font-weight: bold;'>Feil Passord!</p>"
);