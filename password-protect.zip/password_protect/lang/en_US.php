<?php

$i18n = array(
    "PASSWORD_TITLE"        => "This page is password protected",
    "ENTER_PASSWORD"        => "Enter a Password:",
    "PASSWORD_PLACEHOLDER"  => "Password",
    "SUBMIT_BUTTON"         => "Unlock",
    "WRONG_PASSWORD"        => "<p style='color: red; font-weight: bold;'>Wrong password!</p>"
);