<?php
define('EG_ID', 'ExtraGallery');

define('EG_STORAGEPATH', GSDATAPATH . 'ExtraGallery/');

define('EG_SETTINGSPATH', EG_STORAGEPATH . 'settings/');
define('EG_GALLERIESPATH', GSDATAPATH . 'ExtraGallery/galleries/');
define('EG_PREFIX', 'eg');

define('EG_ADMINTHUMBS', EG_STORAGEPATH . 'admin-thumbs/');
define('EG_THUMBS', EG_STORAGEPATH . 'thumbs/');


define('EG_AJAXURL', '../plugins/ExtraGallery/ajax/');

