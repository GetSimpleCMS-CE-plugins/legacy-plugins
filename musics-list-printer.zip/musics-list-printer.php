<?php
/*
Plugin Name: Musics-list-printer
Description:  Output all music files from one folder. To use the plug-in, you need to create folder in the Files section, put your music tracks into it, after opening the editor of the necessary page and insert the block %musicslistprinter_show:dir%
Version: 3.0
Author: Sergey Tregubov
Author URI: https://trgbvs.net
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Musics list printer', 	
	'3.0', 		
	'Sergey Tregubov',
	'https://trgbvs.net', 
	'Output all music files from one folder. To use the plug-in, you need to create folder in the Files section, put your music tracks into it, after opening the editor of the necessary page and insert the block <b>%musicslistprinter_show:dir% </b>',
	'plugins',
	'musicslistprinter_show'  
);

register_style('musics-list-printer', $SITEURL.'plugins/musics-list-printer/css/musics-list-printer.css', FALSE, 'all');
queue_style('musics-list-printer',GSBOTH);

# activate filter
add_filter('content','musicslistprinter_show');






# functions

function musicslistprinter_show($content) {
	preg_match_all("/%musicslistprinter_show:(.*?)%/", $content, $matches);
	for($i=0; $i<count($matches[0]); $i++){    
		$content= str_replace($matches[0][$i], musicslistprinter_getCodeForTag($matches[0][$i]), $content);
	}
	return $content;
}

//get html-code for one tag
function musicslistprinter_getCodeForTag($tag){
	$dirName= musicslistprinter_getNameDir($tag);
	$files= musicslistprinter_getFilesSortLastModifiedDate('data/uploads/'.$dirName.'/');
	$html= '';
	
	for($i=0; $i<count($files); $i++){
		//if filename=dir, than continue
		if (is_dir($files[$i]))
			continue;
		$html.= '<div class="musics-list-printer-div">';
		$html.= $files[$i]."<br>";
		$html.= '<audio controls class="musics-list-printer-audio">';
		$html.= '<source src= "'.$_SERVER['REQUEST_URI'].'data/uploads/'.$dirName.'/'.$files[$i].'"><br>';
		$html.= '</audio>';
		$html.= '</div>';		
	}
	return $html.'<div style="clear: left;"></div>';
}

//get dir name in short-tag
function musicslistprinter_getNameDir($tag){
	preg_match("/%musicslistprinter_show:(.*?)%/", $tag, $matches);
	$dirName= $matches[1];
	return $dirName;
}

//Function for sort files by date last modified
function musicslistprinter_getFilesSortLastModifiedDate($path){
	$files = scandir($path);
	//array for functional sort files by last modified date
	$filesArray = array(); 
	for($i=0; $i<count($files); $i++){
		$filesArray[$files[$i]]= '"'.filemtime($path.$files[$i]).'"';
	}
	//sort array by value "date modified"
	asort($filesArray);
	//sort by last date order
	$filesArray= array_reverse($filesArray);
	//get file keys
	$filesArray= array_keys($filesArray);	
	return $filesArray;
}


?>