<?php
define('RUPLSRENAMEPATH', './upload.php?ruPlsBrowser=true&');

$thisfile = basename(__FILE__, ".php");
register_plugin(
	$thisfile,
	'ruPlsRename',
	'1.0.2',
	'opiums',
	'http://opiums.eu',
	ruPlsRename::localad('pluginDesc'),
	'files',
	'ruPlsRename::help'
);
add_action('footer', 'ruPlsRename::footer');

class ruPlsRename{
	public static $uploads_fol = 'uploads'; // Папка загрузки | Uploads folder
	public static $thumbs_fol = 'thumbs'; // Папка миниатюр | Thumbs folder
	
	public static $local = array(
		'ru' => array(
			'pluginDesc' => 'Переименование, перемещение и копирование файлов и папок в разделе загрузок.',
			'rename' => 'Переименовать',
			'movecr' => 'Переместить',
			'copycr' => 'Скопировать',
			'gotocr' => 'Перейти',
			'delete' => 'Удалить',
			'newname' => 'Введите новое имя:',
			'newmove' => 'в',
			'nofound' => 'Исходный файл или директория не найдены!',
			'replace' => 'Одинаковые названия будут заменены!',
			'pastecr' => 'Вставить сюда',
		),
		'en' => array(
			'pluginDesc' => 'Rename, move and copy files and folders in the downloads section.',
			'rename' => 'Rename',
			'movecr' => 'Move',
			'copycr' => 'Copy',
			'gotocr' => 'Go to',
			'delete' => 'Delete',
			'newname' => 'Enter a new name:',
			'newmove' => 'in',
			'nofound' => 'Source file or directory not found!',
			'replace' => 'The same names will be replaced!',
			'pastecr' => 'Paste here',
		)
	);
	
	public static function localad($val){
		global $LANG;
		$lang = (string)substr($LANG, 0, -3);
		$loclang = (!empty($lang) && in_array($lang, array_keys(self::$local))) ? $lang : array_keys(self::$local)[1]; // 'en';
		return self::$local[$loclang][$val];
	}
	
	public static function help(){
		echo '<h3>'.self::localad('pluginDesc').'</h3>';
	}

	public static function footer(){
		global $path;
		$requestf = basename($_SERVER['PHP_SELF']);
		if($requestf == 'upload.php' || (isset($_GET['id']) && $_GET['id'] == 'ruPlsRename')){
			?>
<style>
.context-menu-open{
	display: none;
	position: fixed;
	z-index: 99999;
	top: 0;
	left: 0;
	box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.54);
	background-color: #fff;
	border-radius: 4px;
	padding: 4px;
}
.context-menu-open ul{
	padding: 0;
	margin: 0;
}
.context-menu-open ul li{
	cursor: pointer;
	font-size: 11px;
	color: #777;
	list-style: none;
	padding: 10px 12px;
	margin: 0;
	border-bottom: 1px solid #CF3805;
}
.context-menu-open ul li:last-child{
	border-bottom: 1px solid transparent;
}
.context-menu-open ul li:hover{
	background-color: #FFFFD5;
}
</style>
<div class="context-menu-open">
	<ul>
		<li class="context-rename">&#9997; <?=self::localad('rename');?></li>
		<li class="context-movecr">&#8794; <?=self::localad('movecr');?></li>
		<li class="context-copycr">&#169; <?=self::localad('copycr');?></li>
		<li class="context-gotocr">&#9971; <?=self::localad('gotocr');?></li>
		<li class="context-delete">&#10006; <?=self::localad('delete');?></li>
	</ul>
</div>
<script>
var thisclickcontext, movecr, copycr;
$(document).ready(function(){
	var contextMenu = $('.context-menu-open');
	$('#file_load table td').live('contextmenu',function(e){
		thisclickcontext = $(this);
		e.preventDefault();
		contextMenu.css({top: e.clientY + 'px', left: e.clientX + 'px'});
		contextMenu.show();
	});
	$(document).live('click',function(){
		contextMenu.hide();
	});
	$('.context-rename').live('click',function(){
		var name = thisclickcontext.closest('tr').find('td')[1];
		var oldname = $(name).find('a').text();
		var newname = prompt('<?=self::localad('newname');?>', oldname);
		if(!newname) return false;
		$.ajax({
			type:"POST",
			url:"upload.php?ruPlsRename=true&path=<?=$path;?>",
			dataType:"json",
			data:{oldname:oldname,newname:newname},
			success:function(res){
				if(!res['uploads'] && !res['thumbs']) alert('<?=self::localad('nofound');?>');
				$('#loader').fadeOut(500);
				$('#maincontent').load(location.href+' #maincontent > *');
			}
		});
	});
	$('.context-movecr').live('click',function(){
		var name = thisclickcontext.closest('tr').find('td')[1];
		movecr = $(name).find('a').text();
		window.open('upload.php?ruPlsBrowser=true&path=<?=$path;?>&func=fill_move_pls&type=folder', 'browser', 'width=800,height=500,left=100,top=100,scrollbars=yes');
	});
	$('.context-copycr').live('click',function(){
		var name = thisclickcontext.closest('tr').find('td')[1];
		movecr = $(name).find('a').text();
		window.open('upload.php?ruPlsBrowser=true&path=<?=$path;?>&func=fill_copy_pls&type=folder', 'browser', 'width=800,height=500,left=100,top=100,scrollbars=yes');
	});
	$('.context-gotocr').live('click',function(){
		var name = thisclickcontext.closest('tr').find('td')[1];
		location.href = $(name).find('a').attr('href');
	});
	$('.context-delete').live('click',function(){
		var name = thisclickcontext.closest('tr').find('.delete a')[0];
		if(name) $(name).click();
	});
});
function fill_move_pls(url){
	var newmove = confirm('<?=self::localad('movecr');?> ' + movecr + ' <?=self::localad('newmove');?> ' + url.replace(/\.\.\/data\//i, '/') + ' (<?=self::localad('replace');?>)?');
	if(!newmove) return false;
	$.ajax({
		type:"POST",
		url:"upload.php?ruPlsMovecr=true&path=<?=$path;?>",
		dataType:"json",
		data:{from:movecr,to:url},
		success:function(res){
			if(!res['uploads'] && !res['thumbs']) alert('<?=self::localad('nofound');?>');
			$('#loader').fadeOut(500);
			$('#maincontent').load(location.href+' #maincontent > *');
		}
	});
}
function fill_copy_pls(url){
	var newmove = confirm('<?=self::localad('copycr');?> ' + movecr + ' <?=self::localad('newmove');?> ' + url.replace(/\.\.\/data\//i, '/') + ' (<?=self::localad('replace');?>)?');
	if(!newmove) return false;
	$.ajax({
		type:"POST",
		url:"upload.php?ruPlsCopycr=true&path=<?=$path;?>",
		dataType:"json",
		data:{from:movecr,to:url},
		success:function(res){
			if(!res['uploads'] && !res['thumbs']) alert('<?=self::localad('nofound');?>');
			$('#loader').fadeOut(500);
			$('#maincontent').load(location.href+' #maincontent > *');
		}
	});
}
</script>
			<?php
		}
	}
	
	public static function copy_all($from, $to, $rewrite = true){
		if(is_dir($from)){
			@mkdir($to);
			$d = dir($from);
			while(false !== ($entry = $d->read())){
				if($entry == "." || $entry == "..") continue;
				self::copy_all("$from/$entry", "$to/$entry", $rewrite);
			}
			$d->close();
		}else{
			if(!file_exists($to) || $rewrite)	copy($from, $to);
		}
	}
	
	public static function delete_all($mypath){
		if(!is_dir($mypath)) return unlink($mypath);
		$dir = opendir($mypath);
		while(($file = readdir($dir))){
			if(is_file($mypath."/".$file))
				unlink($mypath."/".$file);
			elseif(is_dir($mypath."/".$file) && ($file != ".") && ($file != ".."))
				self::delete_all($mypath."/".$file);
		}
		closedir($dir);
		rmdir($mypath);
	}
}

if(isset($_GET['ruPlsRename']) && $_GET['ruPlsRename'] == 'true'){
	if(!cookie_check()) die(header('HTTP/1.0 404 Not Found'));
	if(isset($_GET['path']) && !empty($_GET['path'])){
		$path = preg_replace('/\.+\//','',$_GET['path']);
		$path = tsl("../data/".ruPlsRename::$uploads_fol."/".$path);
		if(!path_is_safe($path,GSDATAUPLOADPATH)) die();
		$tpath = tsl("../data/".ruPlsRename::$thumbs_fol."/".strtr($path, array("../data/".ruPlsRename::$uploads_fol."/" => '')));
	}else{
		$path = "../data/".ruPlsRename::$uploads_fol."/";
		$tpath = "../data/".ruPlsRename::$thumbs_fol."/";
	}
	
	if(empty($_POST['oldname']) || empty($_POST['newname'])) die(header('HTTP/1.0 404 Not Found'));
	$oldPlsname = htmlspecialchars($_POST['oldname']);
	$newPlsname = htmlspecialchars($_POST['newname']);
	
	header("Content-type: application/json; charset=utf-8");
	if(!file_exists($path.$oldPlsname) && !is_dir($path.$oldPlsname)) die(array('uploads' => false, 'thumbs' => false));
	
	$ruPlspath = $ruPlstpath = true;
	$ruPlsfolder = is_dir($path.$oldPlsname);
	
	if($ruPlsfolder){
		if(file_exists($path.$oldPlsname)){
			rename($path.$oldPlsname, $path.$newPlsname);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.$oldPlsname)){
			rename($tpath.$oldPlsname, $tpath.$newPlsname);
		}else $ruPlstpath = false;
	}else{
		if(file_exists($path.$oldPlsname)){
			rename($path.$oldPlsname, $path.$newPlsname);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.'thumbnail.'.$oldPlsname)){
			rename($tpath.'thumbnail.'.$oldPlsname, $tpath.'thumbnail.'.$newPlsname);
			if(file_exists($tpath.'thumbsm.'.$oldPlsname)) rename($tpath.'thumbsm.'.$oldPlsname, $tpath.'thumbsm.'.$newPlsname);
		}else $ruPlstpath = false;
	}
	
	echo json_encode(array('folder' => $ruPlsfolder, 'uploads' => $ruPlspath, 'thumbs' => $ruPlstpath));
	exit();
}

if(isset($_GET['ruPlsMovecr']) && $_GET['ruPlsMovecr'] == 'true'){
	if(!cookie_check()) die(header('HTTP/1.0 404 Not Found'));
	if(isset($_GET['path']) && !empty($_GET['path'])){
		$path = preg_replace('/\.+\//','',$_GET['path']);
		$path = tsl("../data/".ruPlsRename::$uploads_fol."/".$path);
		if(!path_is_safe($path,GSDATAUPLOADPATH)) die();
		$tpath = tsl("../data/".ruPlsRename::$thumbs_fol."/".strtr($path, array("../data/".ruPlsRename::$uploads_fol."/" => '')));
	}else{
		$path = "../data/".ruPlsRename::$uploads_fol."/";
		$tpath = "../data/".ruPlsRename::$thumbs_fol."/";
	}
	
	if(empty($_POST['from']) || empty($_POST['to'])) die(header('HTTP/1.0 404 Not Found'));
	$fromPls = htmlspecialchars($_POST['from']);
	$toPls = htmlspecialchars($_POST['to']);
	
	header("Content-type: application/json; charset=utf-8");
	if(!file_exists($path.$fromPls) && !is_dir($path.$fromPls)) die(array('uploads' => false, 'thumbs' => false));
	
	$ruPlspath = $ruPlstpath = true;
	$ruPlsfolder = is_dir($path.$fromPls);
	
	if($ruPlsfolder){
		if(file_exists($path.$fromPls)){
			ruPlsRename::copy_all($path.$fromPls, $toPls.$fromPls);
			ruPlsRename::delete_all($path.$fromPls);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.$fromPls)){
			ruPlsRename::copy_all($tpath.$fromPls, $toPls.$fromPls);
			ruPlsRename::delete_all($tpath.$fromPls);
		}else $ruPlstpath = false;
	}else{
		if(file_exists($path.$fromPls)){
			ruPlsRename::copy_all($path.$fromPls, $toPls.$fromPls);
			ruPlsRename::delete_all($path.$fromPls);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.'thumbnail.'.$fromPls)){
			ruPlsRename::copy_all($tpath.'thumbnail.'.$fromPls, $toPls.'thumbnail.'.$fromPls);
			ruPlsRename::delete_all($tpath.'thumbnail.'.$fromPls);
			if(file_exists($tpath.'thumbsm.'.$fromPls)) ruPlsRename::copy_all($tpath.'thumbsm.'.$fromPls, $toPls.'thumbsm.'.$fromPls);
			if(file_exists($tpath.'thumbsm.'.$fromPls)) ruPlsRename::delete_all($tpath.'thumbsm.'.$fromPls);
		}else $ruPlstpath = false;
	}
	
	echo json_encode(array('folder' => $ruPlsfolder, 'uploads' => $ruPlspath, 'thumbs' => $ruPlstpath));
	exit();
}

if(isset($_GET['ruPlsCopycr']) && $_GET['ruPlsCopycr'] == 'true'){
	if(!cookie_check()) die(header('HTTP/1.0 404 Not Found'));
	if(isset($_GET['path']) && !empty($_GET['path'])){
		$path = preg_replace('/\.+\//','',$_GET['path']);
		$path = tsl("../data/".ruPlsRename::$uploads_fol."/".$path);
		if(!path_is_safe($path,GSDATAUPLOADPATH)) die();
		$tpath = tsl("../data/".ruPlsRename::$thumbs_fol."/".strtr($path, array("../data/".ruPlsRename::$uploads_fol."/" => '')));
	}else{
		$path = "../data/".ruPlsRename::$uploads_fol."/";
		$tpath = "../data/".ruPlsRename::$thumbs_fol."/";
	}
	
	if(empty($_POST['from']) || empty($_POST['to'])) die(header('HTTP/1.0 404 Not Found'));
	$fromPls = htmlspecialchars($_POST['from']);
	$toPls = htmlspecialchars($_POST['to']);
	
	header("Content-type: application/json; charset=utf-8");
	if(!file_exists($path.$fromPls) && !is_dir($path.$fromPls)) die(array('uploads' => false, 'thumbs' => false));
	
	$ruPlspath = $ruPlstpath = true;
	$ruPlsfolder = is_dir($path.$fromPls);
	
	if($ruPlsfolder){
		if(file_exists($path.$fromPls)){
			ruPlsRename::copy_all($path.$fromPls, $toPls.$fromPls);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.$fromPls)){
			ruPlsRename::copy_all($tpath.$fromPls, $toPls.$fromPls);
		}else $ruPlstpath = false;
	}else{
		if(file_exists($path.$fromPls)){
			ruPlsRename::copy_all($path.$fromPls, $toPls.$fromPls);
		}else $ruPlspath = false;
		
		if(file_exists($tpath.'thumbnail.'.$fromPls)){
			ruPlsRename::copy_all($tpath.'thumbnail.'.$fromPls, $toPls.'thumbnail.'.$fromPls);
			if(file_exists($tpath.'thumbsm.'.$fromPls)) ruPlsRename::copy_all($tpath.'thumbsm.'.$fromPls, $toPls.'thumbsm.'.$fromPls);
		}else $ruPlstpath = false;
	}
	
	echo json_encode(array('folder' => $ruPlsfolder, 'uploads' => $ruPlspath, 'thumbs' => $ruPlstpath));
	exit();
}

if(isset($_GET['ruPlsBrowser']) && $_GET['ruPlsBrowser'] == 'true'){
	if(!defined('GSADMIN')) define('GSADMIN', 'admin');
	if(!cookie_check()) die(header('HTTP/1.0 404 Not Found'));
	if(isset($_GET['path'])){
		$subPath = preg_replace('/\.+\//','',$_GET['path']);
		$subPath = preg_replace('/\/\//','/',$subPath);
		$path = "../data/".ruPlsRename::$uploads_fol."/".$subPath;
		if(strpos(realpath($path), realpath(GSDATAUPLOADPATH)) !== 0) die(); // no path traversal
	}else{
		$subPath = "";
		$path = "../data/".ruPlsRename::$uploads_fol."/";
	}
	$path = tsl($path);
	
	$isUnixHost = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? false : true);
	$fullPath = htmlentities((string)"/data/".ruPlsRename::$uploads_fol."/", ENT_QUOTES);
	
	$func = preg_replace('/[^\w]/', '', @$_GET['func']);
	$type = @$_GET['type'];
	$sort = @$_GET['sort'];
	if(empty($sort) && defined('NMIMAGESORT')) $sort = NMIMAGESORT; // custom default
	if(!in_array($sort, array('name','size','date'))) $sort = 'date'; // default
	
	global $LANG;
	$LANG_header = preg_replace('/(?:(?<=([a-z]{2}))).*/', '', $LANG);
	?>
	<!DOCTYPE html>
	<html lang="<?php echo $LANG_header; ?>">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title><?php echo i18n_r('FILE_BROWSER'); ?></title>
		<link rel="shortcut icon" href="../<?php echo GSADMIN; ?>/favicon.png" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="../<?php echo GSADMIN; ?>/template/style.php?v=<?php echo GSVERSION; ?>" media="screen" />
		<style>.wrapper, #maincontent, #imageTable{width:100%;} .edit-nav a{float:left;}</style>
		<script type="text/javascript">
		window.opener.confirm = window.confirm;
		function submitLink(url){
			if(window.opener) window.opener.<?php echo $func; ?>(url);
			window.close();
		}
		</script>
	</head>
	<body id="filebrowser">
	<div class="wrapper">
		<div id="maincontent">
		<div class="main" style="border:none;">
		<h3><?php echo i18n('UPLOADED_FILES'); ?><span id="filetypetoggle">&nbsp;&nbsp;/&nbsp;&nbsp;<?php echo ($type == 'images' ? i18n('IMAGES') : i18n('SHOW_ALL') ); ?></span></h3>
		<?php
		$count = "0";
		$dircount = "0";
		$counter = "0";
		$totalsize = 0;
		$filesArray = array();
		$dirsArray = array();
		$filesSorted = array();
		$dirsSorted = array();
		
		$filenames = getFiles($path);
		if(count($filenames) != 0){
			foreach($filenames as $file){
				if($file == "." || $file == ".." || $file == ".htaccess" || $file == "web.config"){
				// not a upload file
				}elseif(is_dir($path . $file)){
					$dirsArray[$dircount]['name'] = $file;
					$dircount++;
				}else{
					$filesArray[$count]['name'] = $file;
					$ext = substr($file, strrpos($file, '.') + 1);
					$extension = get_FileType($ext);
					$filesArray[$count]['type'] = $extension;
					clearstatcache();
					$ss = @stat($path . $file);
					$filesArray[$count]['date'] = @date('M j, Y',$ss['ctime']);
					$filesArray[$count]['sortdate'] = $ss['ctime'];
					$filesArray[$count]['size'] = fSize($ss['size']);
					$totalsize = $totalsize + $ss['size'];
					$count++;
				}
			}
			if($sort == 'name') $filesSorted = subval_sort($filesArray,'name');
			elseif($sort =='size') $filesSorted = subval_sort($filesArray,'size','desc');
			else $filesSorted = subval_sort($filesArray,'sortdate','desc');
			$dirsSorted = subval_sort($dirsArray,'name');
		}
		
		$pathParts = explode("/",$subPath);
		$urlPath = "";
		
		echo '<div class="h5">/ <a href="'.RUPLSRENAMEPATH.'func='.$func.'&amp;type='.$type.'&amp;sort='.$sort.'">uploads</a> / ';
		foreach($pathParts as $pathPart){
			if($pathPart != ''){
				$urlPath .= $pathPart."/";
				echo '<a href="'.RUPLSRENAMEPATH.'path='.$urlPath.'&amp;func='.$func.'&amp;type='.$type.'&amp;sort='.$sort.'">'.$pathPart.'</a> / ';
			}
		}
		echo "</div>";
		
		echo '<table class="highlight" id="imageTable">';
		if($type != 'folder'){
			$linksort = RUPLSRENAMEPATH.'path='.$urlPath.'&amp;func='.$func.'&amp;type='.$type.'&sort=';
			echo '<tr><th class="imgthumb" ></th><th></th><th>';
			echo ($sort == 'name') ? i18n_r('FILE_NAME') : '<a href="'.$linksort.'name">'.i18n_r('FILE_NAME').'</a>';
			echo '</th><th style="text-align:right;">';
			echo ($sort == 'size') ? i18n_r('FILE_SIZE') : '<a href="'.$linksort.'size">'.i18n_r('FILE_SIZE').'</a>';
			echo '</th><th style="text-align:right;">';
			echo ($sort == 'date') ? i18n_r('DATE') : '<a href="'.$linksort.'date">'.i18n_r('DATE').'</a>';
			echo '</th></tr>';
		}
		
		if(is_array($dirsSorted) && count($dirsSorted) != 0){
			foreach($dirsSorted as $upload){
				echo '<tr class="All" >';
				echo '<td class="" colspan="5">';
				$adm = ($subPath ? $subPath . "/" : "") . $upload['name'];
				echo '<img src="../'.GSADMIN.'/template/images/folder.png" width="11" /> <a href="'.RUPLSRENAMEPATH.'path='.$adm.'&amp;func='.$func.'&amp;type='.$type.'&amp;sort='.$sort.'" title="'. $upload['name'] .'"	><strong>'.$upload['name'].'</strong></a>';
				echo '</td>';
				echo '</tr>';
			}
		}
		
		if(count($filesSorted) != 0){
			foreach($filesSorted as $upload){
				$thumb = null; $thumbnailLink = null;
				$subDir = ($subPath == '' ? '' : $subPath.'/');
				$selectLink = 'title="'.i18n_r('SELECT_FILE').': '. htmlspecialchars(@$upload['name']) .'" href="javascript:void(0)" onclick="submitLink(\''.$fullPath.$subDir.$upload['name'].'\')"';
				
				if($type == 'images'){
					if($upload['type'] == i18n_r('IMAGES') .' Images'){
						# get internal thumbnail to show beside link in table
						$thumb = '<td class="imgthumb" style="display:table-cell" >';
						$thumbLink = $urlPath.'thumbsm.'.$upload['name'];
						if(file_exists('../data/'.ruPlsRename::$thumbs_fol.'/'.$thumbLink)) $imgSrc = '<img src="../data/'.ruPlsRename::$thumbs_fol.'/'. $thumbLink .'" />';
						else $imgSrc = '<img src="../'.GSADMIN.'/inc/thumb.php?src='. $urlPath . $upload['name'] .'&amp;dest='. $thumbLink .'&amp;x=65&amp;f=1" />';
						$thumb .= '<a '.$selectLink.' >'.$imgSrc.'</a>';
						$thumb .= '</td>';
						
						# get external thumbnail link
						$thumbLinkExternal = 'data/'.ruPlsRename::$thumbs_fol.'/'.$urlPath.'thumbnail.'.$upload['name'];
						if(file_exists('../'.$thumbLinkExternal))
							$thumbnailLink = '<span>&nbsp;&ndash;&nbsp;&nbsp;</span><a href="javascript:void(0)" onclick="submitLink(\'/'.$thumbLinkExternal.'\')">'.i18n_r('THUMBNAIL').'</a>';
					}else continue;
				}
				
				if($type == 'folder'){
					if(file_exists('../data/'.ruPlsRename::$uploads_fol.'/'.$urlPath.$upload['name'])) continue;
				}
				
				$counter++;
				echo '<tr class="All '.$upload['type'].'" >';
				echo ($thumb == '' ? '<td style="display:none;"></td>' : $thumb);
				echo '<td><a '.$selectLink.' class="primarylink">'.htmlspecialchars($upload['name']) .'</a>'.$thumbnailLink.'</td>';
				echo '<td style="width:80px;text-align:right;" ><span>'. $upload['size'] .'</span></td>';
				
				// get the file permissions.
				if($isUnixHost && defined('GSDEBUG')){
					$filePerms = substr(sprintf('%o', fileperms($path.$upload['name'])), -4);
					$fileOwner = function_exists('posix_getpwuid') ? @posix_getpwuid(fileowner($path.$upload['name'])) : null;
					if($filePerms && @$fileOwner['name']) echo '<td style="width:70px;text-align:right;"><span>'.$fileOwner['name'].'/'.$filePerms.'</span></td>';
				}
				echo '<td style="width:85px;text-align:right;" ><span>'. shtDate($upload['date']) .'</span></td>';
				echo '</tr>';
			}
		}
		echo '</table>';
		if($type != 'folder')
			echo '<p><em><b>'. $counter .'</b> '.i18n_r('TOTAL_FILES').' ('. fSize($totalsize) .')</em></p>';
		else
			echo '<div class="edit-nav"><a title="'.ruPlsRename::localad('replace').'" href="javascript:void(0)" onclick="submitLink(\''.$path.'\')"><b>'.ruPlsRename::localad('pastecr').'</b></a></div>';
		?>
		</div>
		</div>
	</div>
	</body>
	</html>
	<?php
	exit();
}
?>