==========================================================
            Trailing Slash Auto Adder [ver 1.1]
==========================================================

** Changelog **

Fix throwing error of undefined variable.

**Installation**

Copy a 'trailing_slash_auto_adder.php' file to your get-simple plug-in folder(default: /plugins).

**Caution**

Use this plug-in at the Fancy URL's mode.

**Copyright**

You can freely use, modify this plug-in. but Don't delete or change the credit.

-----
Thank you for using. Enjoy! :-)