<?php
/*
Plugin Name: Trailing Slash Auto Adder
Description: Automatically redirect non-trailing slash url to trailing slash url. Works fine at the Fancy URL\'s mode.
Version: 1.1
Author: Noesis Mik (http://noesismik.blogspot.com)
*/

$thisfile=basename(__FILE__, ".php");

register_plugin(
	$thisfile,
	'Trailing Slash Auto Adder',
	'1.1',
	'Noesis Mik',
	'http://noesismik.blogspot.com/',
	'Automatically redirect non-trailing slash url to trailing slash url. Works fine at the Fancy URL\'s mode.',
	'',
	''
);

add_action('theme-header','auto_add_trailing_slash');

/**
 * main plugin function
 */ 
function auto_add_trailing_slash()
{ 
  echo '<!-- CREDIT START : Trailing Slash Auto Adder by Noesis Mik (http://noesismik.blogspot.com) -->';
  echo '<!-- CREDIT END : don\'t delete this credit -->';

  # get current requested url
  $current_url = htmlentities('http://'.$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
  
  # check trailing slash
  if($current_url{strlen($current_url)-1} != '/' )
  {
    $redirect_url = $current_url.'/';
    echo '<script type="text/javascript">
          <!--
          window.location = "'.$redirect_url.'"
          //-->
          </script>
          ';
  }
  else
    $redirect_url = $current_url;
  
  if($redirect_url != $current_url)
    return $redirect_url;
}