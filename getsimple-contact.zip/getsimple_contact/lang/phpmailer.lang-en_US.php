<?php
$PHPMAILER_LANG = array(
    'authenticate' => 'SC_FE_PHPMAILER_AUTHENTICATE',
    'connect_host' => 'SC_FE_PHPMAILER_CONNECT_HOST',
    'data_not_accepted' => 'SC_FE_PHPMAILER_DATA_NOT_ACCEPTED',
    'empty_message' => 'SC_FE_PHPMAILER_EMPTY_MESSAGE',
    'encoding' => 'SC_FE_PHPMAILER_ENCODING',
    'execute' => 'SC_FE_PHPMAILER_EXECUTE',
    'file_access' => 'SC_FE_PHPMAILER_FILE_ACCESS',
    'file_open' => 'SC_FE_PHPMAILER_FILE_OPEN',
    'from_failed' => 'SC_FE_PHPMAILER_FROM_FAILED',
    'instantiate' => 'SC_FE_PHPMAILER_INSTANTIATE',
    'invalid_address' => 'SC_FE_PHPMAILER_INVALID_ADDRESS',
    'mailer_not_supported' => 'SC_FE_PHPMAILER_MAILER_NOT_SUPPORTED',
    'provide_address' => 'SC_FE_PHPMAILER_PROVIDE_ADDRESS',
    'recipients_failed' => 'SC_FE_PHPMAILER_RECIPIENTS_FAILED',
    'signing' => 'SC_FE_PHPMAILER_SIGNING',
    'smtp_connect_failed' => 'SC_FE_PHPMAILER_SMTP_CONNECT_FAILED',
    'smtp_error' => 'SC_FE_PHPMAILER_SMTP_ERROR',
    'variable_set' => 'SC_FE_PHPMAILER_VARIABLE_SET'
);
?>