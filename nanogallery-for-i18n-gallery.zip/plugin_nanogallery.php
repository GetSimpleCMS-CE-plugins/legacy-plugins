<?php

/********************************************************************************/
/* plugin_nanogallery.php  Version 1.0.2   Graeme Higson                        */
/*                                                                              */
/* This is a gallery type plugin for the GetSimple plugin i18n Gallery.         */
/* The plugin is a wrapper for the gallery nanoGallery,  from                   */
/* ref : http://nanogallery.brisbois.fr/                                        */
/*                                                                              */
/* nanoGallery is a gallery with slideshow support. Clicking on an image        */
/* thumbnail shows the main image viewer, which also supports slideshow         */
/* functionality. The gallery is fully responsive and supports swipe actions    */
/* on mobiles/touch sensitive devices.                                          */
/*                                                                              */
/********************************************************************************/

i18n_gallery_register('nanogallery', 'nanogallery', 
  '<strong>nanoGallery</strong> is an image gallery tool. Clicking on an image thumbnail shows the main image viewer, which also supports slideshow functionality. The gallery is fully responsive and supports swipe actions on mobiles/touch sensitive devices.<br/>'.
  'License: <a target="_blank" href="http://creativecommons.org/licenses/by-nc/3.0/">CC BY-NC 3.0.</a> Free for private use. It may be used in commercial projects or in business environments, but with the purchase of a professional license, via ref below.<br/>'.
  '<a target="_blank" href="http://nanogallery.brisbois.fr/">http://nanogallery.brisbois.fr/</a>',
  'i18n_gallery_nanogallery_edit', 'i18n_gallery_nanogallery_header', 'i18n_gallery_nanogallery_content');

function i18n_gallery_nanogallery_edit($gallery) {

	/*   Thumbnail config 
	 * $gallery['thumbwidth']   => input => thumbnail width, px  
	 * $gallery['thumbheight']  => input => thumbnail height, px 
	 * $gallery['thumbcrop']    => checkbox => tick=crop image   
	 * $gallery['thumbpadding'] => select  => Have thumbnail padding or not - 'none', 'padding' 
	 * $gallery['thumbpadcol']  => input   => Thumbnail padding colour -  Eg  #555, red, none
	 * $gallery['thumbbdrwidth'] => input   => Thumbnail border width, px  (0 = no border)
	 * $gallery['thumbbdrcol']   => input   => Thumbnail border color - Eg #555, black 
	 * $gallery['thumbgutterwidth'] => input  => Thumbnail gutter width, px  (separation outside border)  
	 *
	 *   Main Viwer Config 
	 * $gallery['toolbar'] => select =>  main viewer toolbar content  -  full, labelonly, none
	 * $gallery['interval'] => input   => slideshow slde period, ms   
	 * 
	 */
	
	?>

	<p><label>Thumbnail Config</label> </p>
	
   <p>If you define the height, but leave width empty, then the width is set to fit the image shape</p>
   <p>If you define the width, but leave height empty, then the height is set to fit the image shape</p>
   <p>If you define both width and height, then you can tick crop to crop each image to fit. If you don't crop then an image may have vertical or horizontal padding depending on the shape</p>
  
  <p>
    <label for="nanogallery-thumbwidth"><?php i18n('i18n_gallery/MAX_THUMB_DIMENSIONS'); ?>, w(px) x h(px) </label>
    <input type="text" class="text" id="nanogallery-thumbwidth" name="nanogallery-thumbwidth" value="<?php echo @$gallery['thumbwidth']; ?>" style="width:5em" onblur="setDefault_thumbdims()"/>
    x
    <input type="text" class="text" id="nanogallery-thumbheight" name="nanogallery-thumbheight" value="<?php echo @$gallery['thumbheight']; ?>" style="width:5em" onblur="setDefault_thumbdims()" />
    &nbsp;
    <span id="nanogallery-thumbcrop-span">
      <input type="checkbox" id="nanogallery-thumbcrop" name="nanogallery-thumbcrop" value="1" <?php echo @$gallery['thumbcrop'] ? 'checked="checked"' : ''; ?> style="vertical-align:middle; width:auto;"/> 
      <?php i18n('i18n_gallery/CROP'); ?>
    </span>
  </p>

   <p>
    <label for="nanogallery-thumbpadding">Thumbnail padding</label>
    <select class="text" name="nanogallery-thumbpadding" style="width:12em">
      <option value="none" <?php echo @$gallery['thumbpadding'] == 'none' ? 'selected="selected"' : ''; ?>>none</option>
      <option value="padding" <?php echo @$gallery['thumbpadding'] == 'padding' ? 'selected="selected"' : ''; ?>>padding</option>
    </select>
  </p>
  
  <p id="nanogallery-thumbpadcol-span">
    <label for="nanogallery-thumbpadcol">Thumbnail padding color, eg #CCF, red, none</label>
    <input type="text" class="text" id="nanogallery-thumbpadcol" name="nanogallery-thumbpadcol" value="<?php echo @$gallery['thumbpadcol']; ?>" style="width:5em" onblur="setDefault_thumbpadcol()"/>
  </p>
 
  <p id="nanogallery-thumbbdrwidth-span">
    <label for="nanogallery-thumbbdrwidth">Thumbnail border width (px) (0 for no border) </label>
    <input type="text" class="text" id="nanogallery-thumbbdrwidth" name="nanogallery-thumbbdrwidth" value="<?php echo @$gallery['thumbbdrwidth']; ?>" style="width:5em" onblur="setDefault_thumbbdrwidth()"/>
  </p>
 
  <p id="nanogallery-thumbbdrcol-span">
    <label for="nanogallery-thumbbdrcol">Thumbnail border color, eg #CCF, black</label>
    <input type="text" class="text" id="nanogallery-thumbbdrcol" name="nanogallery-thumbbdrcol" value="<?php echo @$gallery['thumbbdrcol']; ?>" style="width:5em" onblur="setDefault_thumbbdrcol()"/>
  </p>

  <p id="nanogallery-thumbgutterwidth-span">
    <label for="nanogallery-thumbgutterwidth">Thumbnail gutter width (px)</label>
    <input type="text" class="text" id="nanogallery-thumbgutterwidth" name="nanogallery-thumbgutterwidth" value="<?php echo @$gallery['thumbgutterwidth']; ?>" style="width:5em" onblur="setDefault_thumbgutterwidth()"/>
  </p>
 
 

  <p><label>Main Viewer Config</label> </p>
  
  <p>
    <label for="nanogallery-toolbar"> Toolbar content</label>
    <select class="text" name="nanogallery-toolbar" style="width:12em">
      <option value="labelonly" <?php echo @$gallery['toolbar'] == 'labelonly' ? 'selected="selected"' : ''; ?>>labelonly</option>
      <option value="full" <?php echo @$gallery['toolbar'] == 'full' ? 'selected="selected"' : ''; ?>>full</option>
      <option value="none" <?php echo @$gallery['toolbar'] == 'none' ? 'selected="selected"' : ''; ?>>none</option>
    </select>
  </p>
  
  <p>
    <label for="nanogallery-interval"><?php i18n('i18n_gallery/INTERVAL'); ?></label>
    <input type="text" class="text" id="nanogallery-interval" name="nanogallery-interval" value="<?php echo @$gallery['interval']; ?>" style="width:5em" onblur="setDefault_interval()"/>
  </p>
  
  
  <!--  Do Js to Hide  some elements - Crop, ..  -->
  
  <script type="text/javascript">
    function changeNanoGalleryThumbSize() {
      var show = $.trim($('#nanogallery-thumbwidth').val()) != '' && $.trim($('#nanogallery-thumbheight').val()) != '';
      if (show) $('#nanogallery-thumbcrop-span').show(); else $('#nanogallery-thumbcrop-span').hide().find('input').attr('checked',false);
    }
    $(function() {
      $('#nanogallery-thumbwidth, #nanogallery-thumbheight').change(changeNanoGalleryThumbSize);
      changeNanoGalleryThumbSize();
    });
  </script>

  
  
 <?php 
 
  /* Define any defualt values
   * -----------------------------
   * 1) If the user creates a new gallery in the GS Backend, adds images,  chooses  the gallery 
   *    type nanoGallery, and then just immediately  save the gallery and use it in the Frontend, 
   *    then all the nanogallery config have default values such that the gallery appears sensible
   *    in the Frontend   
   *  2. <input> fields : Define a default value on first loading page, and then if 
   *                      necessary when user leaves focus 
   *   
   * 3. <select> / <Options> fields :   Define default values as follows 
   *    Just make the 1st option field the default value .. Then if the corresp $gallery['param']
   *    is not set or totally empty, then none of the <options> fields will be given an attrib
   *    selected = "selected". As such the first field in the list will be displayed. 
   * */

  ?> 
  
<script>

	setDefault_thumbdims();
	setDefault_thumbpadcol();
	setDefault_thumbbdrwidth();
	setDefault_thumbbdrcol();
	setDefault_thumbgutterwidth();
	setDefault_interval();
	
	function setDefault_thumbdims() {
	    var w = document.getElementById("nanogallery-thumbwidth");
	    var h = document.getElementById("nanogallery-thumbheight");
	    var c = document.getElementById("nanogallery-thumbcrop");
	    w.value = w.value.trim();
	    h.value = h.value.trim();
	    if ((w.value == '') && (h.value.trim() == '')) {
	         w.value = '';
	         h.value = '100';
	         c.value = '0';
	    }
	}
	
	function setDefault_thumbpadcol() {
	    var x = document.getElementById("nanogallery-thumbpadcol");
	    x.value = x.value.trim();
	    if (x.value == '') {
	         x.value = 'none';
	    }
	}
	
	function setDefault_thumbbdrwidth() {
	    var x = document.getElementById("nanogallery-thumbbdrwidth");
	    x.value = x.value.trim();
	    if (x.value == '') {
	         x.value = '1';
	    }
	}
	
	function setDefault_thumbbdrcol() {
	    var x = document.getElementById("nanogallery-thumbbdrcol");
	    x.value = x.value.trim();
	    if (x.value == '') {
	         x.value = 'black';
	    }
	}
	
	function setDefault_thumbgutterwidth() {
	    var x = document.getElementById("nanogallery-thumbgutterwidth");
	    x.value = x.value.trim();
	    if (x.value == '') {
	         x.value = '2';
	    }
	}
	
	function setDefault_interval() {
	    var x = document.getElementById("nanogallery-interval");
	    x.value = x.value.trim();
	    if (x.value == '') {
	         x.value = '3000';
	    }
	}

</script>
  

<?php
}

function i18n_gallery_nanogallery_header($gallery) {
	
	//  Insert the Gen jQuery.js lib 
	// ------------------------------
	if (i18n_gallery_check($gallery,'jquery') && i18n_gallery_needs_include('jquery.js')) {
?>
  <!-- Insert the gen jquery lib for nanoGallery, if not already  .. Shld be >= 1.7 -->
  <script type="text/javascript" src="<?php echo i18n_gallery_site_link(); ?>plugins/i18n_gallery/js/jquery-1.11.2.min.js"></script>
<?php
	}
	
	
  // Insert the nanoGallery jQuery Plugin file 
	// ------------------------------
	if (i18n_gallery_needs_include('jquery.nanogallery.js')) {
?>
  <!-- Insert the nanoGallery jQuery Plugin file  -->
	<script type="text/javascript" src="<?php echo i18n_gallery_site_link(); ?>plugins/i18n_gallery/js/jquery.nanogallery.js"></script>
<?php
	}
	
	
	//  Insert the Nanogallery CSS file 
	// ------------------------------	
	if (i18n_gallery_check($gallery,'css') && i18n_gallery_needs_include('nanogallery.css')) { 
?>
  <!-- Insert the gen nanoGallery CSS file  -->
  <link rel="stylesheet" href="<?php echo i18n_gallery_site_link(); ?>plugins/i18n_gallery/css/nanogallery/nanogallery.css" type="text/css" media="screen" charset="utf-8" />
  <link rel="stylesheet" href="<?php echo i18n_gallery_site_link(); ?>plugins/i18n_gallery/css/nanogallery/themes/light/nanogallery_light.css" type="text/css" media="screen" charset="utf-8" />
  <link rel="stylesheet" href="<?php echo i18n_gallery_site_link(); ?>plugins/i18n_gallery/css/nanogallery/themes/clean/nanogallery_clean.css" type="text/css" media="screen" charset="utf-8" />
<?php
	}
	
	//  Insert the actual nanoGallery  function call for the Gallery 
	// -------------------------------------------------------------		
	 
	// Fetch page (% gallery %) tag id param  .. to allow more than one album on the same page
	// Here the id is used to define a unique CSS id for the naongallery div    
	$id = i18n_gallery_id($gallery);
	
	
	/* Apply $gallery[] config to the nanoGallyer fn call params :
	* -----------------------------------------------------------
   * 1. Thumbnail width / height :  
   * i) If width/height is empty, the other has a value, then set the empty to 'auto'
   *    => width/height is set to  value acc thumbnail aspect ratio  
   * ii) If both empty set to width/height to 'auto'/'100'.
   * 
   * 2. Thumbnail crop : Not used. Simply use the already cropped thumbnail image  
   * 3. Thumbnail padding : 
   * 		'padding'  => Just use the default nanoGallery css theme. This shows the 
   *                   background of an outer div around the thumbnail, which visually
   *                   appears as a padding arounnd the thumbnail
   *     'none'     => Define nanoGallery css theme 'light'. This does does NOT show the 
   *                   background of an outer div around the thumbnail, so appaers as no 
   *                   thumbnail padding
   * 4. Thumbnail colour : Apply to a nanoGallery colorScheme background param
   * 5. Thumbnail border width / colour : Apply to a nanoGallery colorScheme border param
   * 6. Thumbnail gutter width : Apply to both nanoGallery params thumbnailGutterWidth and 
   *                             thumbnailGutterHeight. Gutter is the thumbnail separation outside border
	*
	* 7. Main Viewer toolbar   :  Defines nanoGallery param  viewerToolbar, with the following result
	*  		full :  Show the full toolbar incl slideshow play/pause, slidenr, title and description.
	*  		labelonly : Show the toolbar but just with the title and description   
	*  		none : Do not show any toolbar / any information  
	* 
	* 8. Main Viewer slideshow interval :  Apply to nanoGallery param slideshowDelay 
	*/

	// Fetch the thumbwidth/height .. 
	$tw = @$gallery['thumbwidth'];
	$th = @$gallery['thumbheight'];
	if (($tw == '') && ($th == '')){
       // Don't actually need this bit as done in _edit() in js defaults 
       $tw = 'auto';
       $th = '100';
	}
	if ($tw == '') $tw = 'auto';
	if ($th == '') $th = 'auto';
	
	?>	
	<script>
      $(document).ready(function () {

        var nanoGalColorScheme = {
          thumbnail: {
            background: '<?php echo @$gallery['thumbpadcol']; ?>',
            border: '<?php echo @$gallery['thumbbdrwidth']; ?>px solid <?php echo @$gallery['thumbbdrcol']; ?>', 
          }
        };

        jQuery("#nanoGallery-<?php echo $id; ?>").nanoGallery({

          // Thumbnail config
          // ---------------
            
          // Don't need itemsBaseURL, as all image and thumb urls below are absolute
          // itemsBaseURL:'http://localhost/graeme/gallery_tests',
          thumbnailWidth: '<?php echo $tw; ?>',
          thumbnailHeight: '<?php echo $th; ?>',
          thumbnailLabel:{display:false},
				
          // Thumbnail padding or not 
          <?php if (@$gallery['thumbpadding'] == 'none') echo "theme:'light'," ?>
          
          thumbnailGutterWidth : <?php echo @$gallery['thumbgutterwidth']; ?>, 
          thumbnailGutterHeight : <?php echo @$gallery['thumbgutterwidth']; ?>,

          colorScheme: nanoGalColorScheme,
          
          // Only used if display a single album thumb, is just ignored  if display all image thumbs  
          thumbnailAlbumDisplayImage: true, 

          // Main Viewer config
          // -----------------
          
          viewerDisplayLogo:false,

          // Toolbar contents 
          <?php 
          if (@$gallery['toolbar'] == 'full') 
          	echo "viewerToolbar: { standard:'minimizeButton , previousButton, pageCounter ,nextButton,playPauseButton,fullscreenButton,infoButton,linkOriginalButton,closeButton,label,custom1' }, ";
          else if (@$gallery['toolbar'] == 'labelonly') 
            echo "viewerToolbar: { standard:'label', style:'innerImage'},"; 
          else // (@$gallery['toolbar'] == 'none')
          	echo "viewerToolbar: { display :false },"; 
          ?>  
          
          <?php 
                 if (@$gallery['toolbar'] == 'full') {   
                    echo "// Slideshow interval";  
                    echo "\n          slideshowDelay : ".@$gallery['interval'].",";
                 }
          ?>

          
        });

      });
	</script>
	<?php
		
}  // End fn


function i18n_gallery_nanogallery_content($gallery) {

	//  Insert the actual nanoGallery   HTML / Inline image refs
	// -------------------------------------------------------------

	// Images at, eg : C:\xampp\htdocs\graeme\gallery_tests\data\uploads\gallery\gal2\m_img1.jpg
	// Thumbs at, eg : C:\xampp\htdocs\graeme\gallery_tests\data\thumbs\gallery\gal2 \ i18npic.160x120.m_img1.jpg

   // Fetch page (% gallery %) tag id param  .. to allow more than one album on the same page
   // Here the id is used to define a unique CSS id for the naongallery div
	$id = i18n_gallery_id($gallery);

	// Generate a new/unique albumIdnr as integer .. to allow more than one album on the same page
	// Gen a new id nr  even if don't use it.  On 1st use the val wiill be 1, = init of 0 then an incr 
	global $ng_album_id;
	$ng_album_id++;

	?>

	<div id="nanoGallery-<?php echo $id; ?>">
	
<?php

 	// Output A) a single album thumb or B) a thumb for each gallery image
   // IF the gallery thumb param IS set, eg thumb=4, then do A) and set album
   //    thumb image to the thumb nr.
   // IF the gallery thumb param is  NOT set, then do B).
   // For A) output a annoGallery album element plus image elements, and connect each
   //   image element with the NG data-ngalbumid param 
   // For B) Just output output the image elements, with NO NG data-ngalbumid param

	$thumb = i18n_gallery_thumb($gallery);
	if (isset($thumb))$show_onethumb = true; 
	else $show_onethumb = false; 
	
	if ($show_onethumb) {

		$main_image_link = i18n_gallery_image_link($gallery,$gallery['items'][$thumb], false);
		$thumb_link = i18n_gallery_thumb_link($gallery,$gallery['items'][$thumb], false);
		
?>
		<!-- Album element   -->
      <a href="<?php echo($main_image_link); ?>"
      data-ngkind="album"
      data-ngid="<?php echo $ng_album_id; ?>"
      data-ngthumb="<?php echo($thumb_link); ?>">Album 1</a>
			
<?php

	} // End if $show_onethumb
	

	// Init the nanoGallery image id nr ... 
	// NOTE It looks like for nanoGallery that  the image id nr and an album id nr
	// CANNOT OVERLAP .. so start the image id nr at 11 (10 + incr), and start the
	// album element id nr at 1            
	$i = 10;	

  	foreach ($gallery['items'] as $item) { 
 	  
 	  // Get the Title and Descr in the selected lang
      $title = htmlspecialchars(@$item['_title']);
      $description = htmlspecialchars(@$item['_description']);
      
      // Get the abs Urls for the main and thumb images 
      $main_image_link = i18n_gallery_image_link($gallery,$item, false);
      $thumb_link = i18n_gallery_thumb_link($gallery,$item, false);
      $i++;
?>
      	<a href="<?php echo($main_image_link); ?>"
      		data-ngthumb="<?php echo($thumb_link); ?>"
      		data-ngid="<?php echo($i); ?>"
      		<?php if ($show_onethumb) { echo('data-ngalbumid="'.$ng_album_id.'"');  }  ?>     		
      		data-ngdesc="<?php echo($description); ?>"><?php echo($title); ?></a>							
<?php     								
  }    
?>
	</div>
<?php

}


