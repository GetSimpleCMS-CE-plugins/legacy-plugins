<?php
/*
Plugin Name: GS-Socialize
Description: Adds social bookmark icons/links to the bottom of all posts/pages.
Version: 1.1
Author: Chris Cagle
Author URI: http://www.cagintranet.com/
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
define('GSSOCIALICONPATH', $SITEURL.'plugins/gs-social-icons/');

# registration
register_plugin(
	$thisfile,
	'GS Socialize',
	'1.1',
	'Chris Cagle',
	'http://www.cagintranet.com/',
	'Adds social bookmark icons/links to the bottom of all posts/pages',
	'',
	''
);

# hooks
add_action('theme-header', 'gssocial_css');
add_action('content-bottom', 'gssocial_icons');

# functions
function gssocial_css() {
	echo '
		<style type="text/css">
			div#socialize {margin:20px 0;}
			div#socialize a {margin:0 8px 0 0 0;}
			div#socialize a img {border:none;}
		</style>
	';
}

function gssocial_icons() {
	echo '
	<div id="socialize">
		<b class="gssocial-title" >Share:</b>&nbsp;
		<a href="http://www.facebook.com/share.php?u='. get_page_url(TRUE) .'&t='. return_page_title() .'" title="Add to Facebook" ><img src="'.GSSOCIALICONPATH .'facebook.png" alt="Add to Facebook" /></a>
		<a href="http://twitter.com/home?status='. return_page_title() .' - '. get_page_url(TRUE) .'" title="Tweet This" ><img src="'.GSSOCIALICONPATH .'twitter.png" alt="Tweet This" /></a>
		<a href="http://delicious.com/post?url='. get_page_url(TRUE) .'&title='. return_page_title() .'" title="Add to Delicious" ><img src="'.GSSOCIALICONPATH .'delicious.png" alt="Add to Delicious" /></a>
		<a href="http://digg.com/submit?phase=2&url='. get_page_url(TRUE) .'&title='. return_page_title() .'" title="Submit to Digg" ><img src="'.GSSOCIALICONPATH .'digg.png" alt="Submit to Digg" /></a>
		<a href="http://www.stumbleupon.com/submit?url='. get_page_url(TRUE) .'&title='. return_page_title() .'" title="Stumble This" ><img src="'.GSSOCIALICONPATH .'stumble.png" alt="Stumble This" /></a>
	</div>	
	';
}

?>