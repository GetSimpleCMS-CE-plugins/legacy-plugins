<?php

$i18n = array(

"HLP_HTMLEDITOR" => "The editor will be active when you enable the HTML editor on the Settings page.",

"THEME" => "Theme",
"HLP_THEME" => "Select which interface to be used in the editor.",

"PLUGINS" => "Plugins in editor",
"HLP_PLUGINS" => "Selected items will be enabled in the editor. You can select multiple items by holding the CTRL key.",

"LBL_TOOLBAR" => "Toolbar",
"LBL_BUTTON" => "button",

"COMPATIBILITY" => "Compatibility",
"HLP_COMPATIBILITY" => "Increase the compatibility if you have troubles with other installed plugins.",
"AUTO" => "Auto",
"HIGH" => "High",
"NONE" => "None",

"X" => "not translated"
);

?>
