<?php
	$tf = basename(__FILE__,'.php');
	register_plugin(
		$tf,
		'<code>slug</code> Transliteration',
		'2',
		'Martijn van der Ven',
		'http://zegnat.com/',
		'If you use a language with non ASCII characters <a href="http://en.wikipedia.org/wiki/Transliteration">transliteration</a> can be used by GetSimple to change your page titles into slugs.'
	);
	add_action('changedata-save','translit');
	function translit($t=false,$m=false) {
		global $i18n;
		if (is_array($a=$m)||is_array($a=@$i18n['TRANSLITERATION'])||is_array($a=@$i18n['TRANSLIT'])) {
			if (!$t&&isset($_POST['submitted'])) {
				global $url, $xml, $file;
				$t = ($u=$_POST['post-id'])?$u:($u=$_POST['post-title'])?$u:'temp';
				$url = clean_url(to7bit(str_replace(array_keys($a),array_values($a),$t)));
				unset($xml->url);
				$note = $xml->addChild('url');
				$note->addCData($url);
				$file = GSDATAPAGESPATH.$url.".xml";
				return true;
			}
			return str_replace(array_keys($a),array_values($a),$t);
		}
		else return false;
	}
?>