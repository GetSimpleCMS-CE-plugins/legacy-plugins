<?php

$i18n = array (
	
    'TITLE'=>'Migrate (perkelti svetainę į kitą domeną)',
    'EXIST_NAME'=>'Esamo serverio URL adresas:',
    'NEW_NAME'=>'Naujo serverio URL adresas:',
	'REPLACE'=>'Pakeisti esamus failus',
	'ARCHIVE'=>'Keisti failus vėlesniam naudojimui',
	'SUBMIT'=>'Keisti',
    'NOT_NEW'=>'Jūs neįvedėte reikšmę laukui "Naujas domenas"',
    'IDENTICAL'=>'Esamo ir naujo domenų laukai yra identiški',
	'ALL_INCLUDE'=>'Įtraukti visus XML failus (taip pat nemodifikuotus)',
	'ALL_REPLACE'=>'Viso pakeista: ',
	'ALL_FILES'=>' įrašas(-ai). Pakeistų failų: ',
	'TOTAL_FILES'=>'. Iš viso duomenų failų: ',
	'ALL_SPEC_ITEMS'=>'<br>Iš jų pakeistų spec. lauku: ',
	'ARCH_FILE'=>'Archyvo failas sukurtas sėkmingai.<br/>Jūs galite atsisiųsti jį failo atsisiuntimo zonoje.<br/>',
	'REPL_FILE'=>'Visi failai modifikuoti sėkmingai.<br/>Dabar galite pabandyti peržiūrėti svetaines turinį.<br/>',
	'ZIP_NOT'=>'Klasė ZipArchive nerasta. Patikrinkite svetainės GS branduolio instaliacija.',
	'FOR_DOWNLOAD'=>'Paruošti atsisiuntimui failai',
	'NOT_DIR_ACCESS'=>'Nepavyksta pasiekti aplanką: ',
	'NOT_DIR_EXIST'=>'Aplankas neegzistuoja: ',
	'DEL_FILE'=>'Ištrinti šį failą',
	'ZIP_NOT_OPEN'=>'Negaliu atidaryti ZipArchive failo. Patikrinkite archyvinio failo kelio nuorodą.',
	'ZIP_NOT_CLOSE'=>'Negaliu uždaryti ZipArchive failo. Patikrinkite archyvinio failo turinį ir katalogo prieigos teises.',
	'ALL_NM_ITEMS'=>'<br>Iš jų pakeistų News Manager elementų: ',
);

?>