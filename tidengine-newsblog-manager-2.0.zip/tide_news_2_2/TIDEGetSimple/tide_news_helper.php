<?php
    

    /**
     * tide_international_set() - Multilanguage set
     * 
     * @param string $plugin_name
     * @param string $language 
     */
    function tide_international_set($plugin_name, $language) {

        i18n_merge($plugin_name) || i18n_merge($plugin_name, $language);
    }

    /**
     * tide_admin_menu() -  Create Admin Slide Menu - If we have subnavigation stay on same parent menu
     * 
     * @global array $storage
     * @param string $plugin_id
     * @param array $navigation_list 
     */
    function tide_admin_menu($plugin_id, $navigation_list) {
        global $storage;
        $extra = '';
        if ($storage[0] == 'undefined') {
            $extra = ' onclick="return false"';
        }

        if (isset($_GET['id']) && $_GET['id'] == $plugin_id) {
            $text = '';

            foreach ($navigation_list as $key => $val) {
                $class = '';
                if (isset($_GET[$key])) {
                    $class = 'class="current"';
                } else {
                    if (!empty($val['children'])) {

                        $class = check_elements($val['children']);
                    }
                }

                $text .= '<li id="sb_' . $key . '">';
                $text .= '<a href="load.php?id=' . $plugin_id . '&amp;' . $key . '" ' . $class . ' ' . $extra . '>' . $val['menu_text'] . '</a>';
                $text .= '</li>';
            }
        }
        echo $text;
    }

    /**
     * check_elements()
     * @param array $child
     * @return string 
     */
    function check_elements($child) {
        $class = '';
        $ch_num = count($child);
        for ($i = 0; $i < $ch_num; $i++) {
            if (isset($_GET[$child[$i]])) {
                $class = 'class="current"';
            }
        }
        return $class;
    }

    /**
     * check_constants() - Checks if constant are defined and if not define them
     * 
     * @param array $constants 
     */
    function check_constants($constants) {

        foreach ($constants as $def => $val) {
            if (!defined('' . $def . ''))
                define('' . $def . '', '' . $val . '');
        }
    }

    /**
     * find_themes() - Get installed Themes
     * @return type 
     */
    function find_themes() {

        return glob(GSTHEMESPATH . '*', GLOB_ONLYDIR);
    }

    /**
     *  create_directory() - Create Directory
     * @param string $path
     * @param string $hta
     * @return boolean 
     */
    function create_directory($path, $hta) {

        $htaccess_rule = array('alow' => 'Allow from all', 'deny' => 'Deny from all');
        $htaccess_file = $path . '/.htaccess';
        $path = os_separator($path);
        $check_dir = is_dir($path);

        if (!$check_dir) {
            $r[] = mkdir($path, 0755, true);
            $r[] = file_put_contents($htaccess_file, $htaccess_rule[$hta]);
            $r[] = chmod($htaccess_file, 0644);
        }
        return tide_check($r);
    }

    /**
     * os_separator() - Check for Host OS and fix slashes
     * 
     * @param string $path
     * @return string 
     */
    function os_separator($path) {

        $os = PHP_OS;
        switch ($os) {
            case "Linux":
                $paths = str_replace("\\", "/", $path);
                break;
            case ("WINNT" || "WIN32" || "Windows") :
                $paths = str_replace("/", "\\", $path);
                break;
            default:
                $paths = str_replace("\\", "/", $path);
                break;
        }
        return $paths;
    }

    /**
     * load_template() - Simple Template Engine
     * 
     * @param string $template
     * @param array $data
     * @param array $settings
     * @return string 
     */
    function load_template($template, $data = false, $settings = false) {
        ob_start();
        include( $template );
        $template = ob_get_contents();
        ob_end_clean();
        return $template;
    }

    /**
     *  get_news() 
     * 
     * @return type 
     */
    function get_news() {
        $pages = get_files(GSDATAPAGESPATH, 'xml', true);
        $pages = array_change_values($pages, NEWS_DIR);
        return get_files($pages, 'xml');
    }

    function get_page_news($page) {
        return get_files(NEWS_DIR . $page . '/', 'xml');
    }

    /**
     * get_settings() - Read different settings from file and return data
     * @param string $path
     * @return type - settings array
     */
    function get_settings($path) {
        $settings = xml_content_array($path);
        return tide_html_ent_decode($settings['data']);
    }

    /**
     * get_news_number()
     * @return type 
     */
    function get_news_number() {
        $news = get_news();
        return count($news, COUNT_RECURSIVE) - count($news);
    }

    /**
     *
     * @param bool $data
     * @param string $success
     * @param string $fail
     * @param string $extra
     * @return string 
     */
    function get_messages($data, $success, $fail, $extra = '') {

        if (!$data) {
            $result = '<div class="error">' . $fail . ' ' . $extra . '</div>';
        } else {
            $result = '<div class="updated">' . $success . ' ' . $extra . '</div>';
        }
        return $result;
    }

    /**
     * installed_languages()
     * 
     * @return type 
     */
    function installed_languages() {
        $lang_handle = opendir(GSLANGPATH) or die("Unable to open " . GSLANGPATH);

        while ($lfile = readdir($lang_handle)) {
            if (is_file(GSLANGPATH . $lfile) && $lfile != "." && $lfile != "..") {
                $lang_array[] = basename($lfile, ".php");
            }
        }
        return $lang_array;
    }

    /**
     * category_array() - Create category array eg. [slug] => title
     * 
     * @param array $data
     * @return array 
     */
    function category_array($data) {
        $cat = array();
        foreach ($data['data'] as $key => $value) {
            $cat[$value['category_slug']] = $value['category_title'];
        }
        return $cat;
    }

    /**
     * get_pages() -Get Existing pages
     * @param string $path
     * @return array 
     */
    function get_pages($path, $unset_permanent = false) {
        global $general_settings;
        $data = xml_content_array($path, false);
        $i = 0;
        $r = array();

        while ($i < count($data)) {
            $r[$data[$i]['slug']] = $data[$i]['title'];
            $i++;
        }
        if ($unset_permanent) {
            unset($r['rss']);
            unset($r[$general_settings['all_news_page']]);
            unset($r['archive']);
            unset($r['tags']);
        }
        return $r;
    }

    /**
     * array_change_values()
     * 
     * @param array $array
     * @param string $add
     * @return array 
     */
    function array_change_values($array, $add) {
        $keys = array_keys($array);
        $values = array_values($array);

        for ($i = 0; $i < count($keys); $i++) {
            $keys[$i] = $values[$i];
            $values[$i] = $add . $values[$i];
        }
        return array_combine($keys, $values);
    }

    /**
     * tide_check() - Checks for proccess errors
     * @param array $data
     * @return boolean 
     */
    function tide_check($data) {

        if (in_array(false, $data)) {
            $r = false;
        } else {
            $r = true;
        }
        return $r;
    }

    /**
     * tide_check_file() - Checks if file is deleted
     * @param string $path
     * @return boolean 
     */
    function tide_check_file($path) {

        if (file_exists($path)) {
            $r = false;
        } else {
            $r = true;
        }
        return $r;
    }

    /**
     * create_news_paths() - Create all paths for News Creation
     * 
     * @global array $tags_settings
     * @param array $data
     * @param boolean $just_paths
     * @return boolean|array 
     */
    function create_news_paths($data, $just_paths = false) {
  
        global $tags_settings;
        $paths = array();

        $paths['news_file'] = os_separator(NEWS_DIR . 'news/' . $data['category'] . '/' . $data['slug'] . '.xml');
        $paths['news_index'] = os_separator(NEWS_DIR . 'news/news_index.xml');

        $archive_month = date_reformat($data['date']);
        $paths['category_archive'] = os_separator(NEWS_DIR . 'archives/' . $data['category'] . '/' . $archive_month . '.xml');
        $paths['master_archive'] = os_separator(NEWS_DIR . 'archives/' . $archive_month . '.xml');

        $paths['category_news'] = os_separator(NEWS_DIR . 'category/' . $data['category'] . '.xml');

        if (!empty($data['tags'])) {
            if (!is_array($data['tags'])) {
                $tags[0] = $data['tags'];
            } else {
                $tags = $data['tags'];
            }

            $tags_num = count($tags);

            for ($i = 0; $i < $tags_num; $i++) {
                if (strlen($tags[$i]) > $tags_settings['tags_min_length']) {
                    $tags[$i] = urlencode(urldecode($tags[$i]));
                    $paths['category_tags'][$i] = os_separator(NEWS_DIR . 'tags/' . $data['category'] . '/' . $tags[$i] . '.xml');
                    $paths['master_tags'][$i] = os_separator(NEWS_DIR . 'tags/' . $tags[$i] . '.xml');
                }
            }
        } else {
            $paths['category_tags'] = false;
            $paths['master_tags'] = false;
        }

        if (!$just_paths) {
            return create_news_files($paths, $data);
        } else {
            return $paths;
        }
    }

    /**
     * tide_reduce_text() - Reduce text on number of words defined in general settings
     * @param string $string
     * @param number $length
     * @return string 
     */
    function tide_reduce_text($string, $length) {
        $string = stripslashes(html_entity_decode($string, ENT_QUOTES, 'UTF-8'));
        $string = strip_tags($string);
        if (str_word_count($string) > $length) {
            $string = implode(' ', array_slice(str_word_count($string, 1), 0, $length));
        }
        return $string;
    }

    /**
     * news_index() - Create and update News Index, and keep number of new limit
     * @param string $path
     * @param number $news_num
     * @param string $news_index
     * @return bool 
     */
    function news_index($path, $news_num, $news_index) {

        if (file_exists($path)) {
            $check_news = xml_content_array($path, true);

            if ($check_news['nodes'] > $news_num * 10) {
                tide_xml_file('', $path, 'create');
                array_shift($check_news['data']);
                foreach ($check_news['data'] as $key => $val) {
                    $id = $val['@attributes']['id'];
                    unset($val['@attributes']);
                    tide_xml_file($val, $path, 'update', $id);
                }
                $number = $check_news['nodes'] - 1;
            }
            $ids = md5($news_index['category'] . $news_index['slug']);
            $f = array('id' => $ids, 'category' => $news_index['category']);

            unset($news_index['slug']);
        
            $r = tide_xml_file($news_index, $path, 'update', $f, false);
        } else {
            $ids = md5($news_index['category'] . $news_index['slug']);
            $f = array('id' => $ids, 'category' => $news_index['category']);

            unset($news_index['slug']);
            $r = tide_xml_file($news_index, $path, 'create', $f, false);
        }
        return $r;
    }

    /**
     * news_items() - Depending of file existance create new or update existing file
     * @param string $data
     * @param string $path
     * @param string $slug
     * @param bool $bool
     * @return bool 
     */
    function news_items($data, $path, $slug, $bool) {
        if (!file_exists($path)) {
            $r = tide_xml_file($data, $path, 'create', $slug, $bool);
        } else {
            $r = tide_xml_file($data, $path, 'update', $slug, $bool);
        }
        return $r;
    }

    /**
     * create_news_files() - Create all New News Files and Coresponding data
     * 
     * @global array $menu_settings
     * @param array $paths
     * @param array $data
     * @return boolean 
     */
    function create_news_files($paths, $data) {

        global $menu_settings;
        global $general_settings;
        $xml_data = array('item' => $paths['news_file']);

        $re = array('id' => $data['slug'], 'category' => $data['category']);

        $data['summary'] = tide_reduce_text($data['summary'], $menu_settings['menu_content_lenght']);
        $link = url_builder($general_settings['all_news_page'], $data['category'], $data['slug'], 'tide_show_news', false, false);

        $news_index = array('title' => $data['title'], 'date' => $data['date'], 'category' => $data['category'], 'summary' => $data['summary'], 'link' => $link, 'file' => $paths['news_file'], 'slug' => $data['slug']);

        $r[] = news_index($paths['news_index'], $menu_settings['menu_news_number'], $news_index);
        $r[] = news_items($xml_data, $paths['category_archive'], $data['slug'], true);

        $ids = md5($news_index['category'] . $news_index['slug']);
        $f = array('id' => $news_index['slug'], 'category' => $news_index['category'], 'unique' => $ids);
        $r[] = news_items($xml_data, $paths['master_archive'], $f, true);

        $news_array = array('title' => $data['title'], 'file' => $paths['news_file'], 'date' => $data['date']);

        $r[] = tide_xml_file($news_array, $paths['category_news'], 'update', $data['slug'], false);

        if ($paths['category_tags'] && $paths['master_tags']) {
            foreach ($paths['category_tags'] as $key => $val) {
                $r4[] = news_items($xml_data, $val, $data['slug'], true);
            }
            if (in_array(false, $r4)) {
                $r[] = false;
            }

            foreach ($paths['master_tags'] as $key => $val) {

                $r5[] = news_items($xml_data, $val, $f, true);
            }
            if (in_array(false, $r5)) {
                $r[] = false;
            }
        }

        if (in_array(false, $r)) {
            $res = false;
        } else {
            $res = true;
        }
        return $res;
    }

    /**
     * get_files() - Get files list from directory
     * 
     * @param string $path
     * @param string $extension
     * @param bool $basename
     * @param bool $set_keys
     * @return array
     * @todo - fix function  
     */
    function get_files($path, $extension, $basename = false, $set_keys = false) {
        $files = array();

        if (is_array($path)) {

            foreach ($path as $key => $value) {

                $files = glob($value . '/*' . $extension);
                if (!empty($files)) {
                    usort($files, create_function('$a,$b', 'return filemtime($b) - filemtime($a);'));


                    if ($basename) {
                        $extension = "." . $extension;
                        $files = get_basename_array($files, $extension, $set_keys);
                    }
                } else {
                    $files = 'empty';
                }

                $result[$key] = $files;
                $files = '';
            }
        } else {

            $result = glob($path . '/*' . $extension);
            usort($result, create_function('$a,$b', 'return filemtime($b) - filemtime($a);'));
            if ($basename) {
                $extension = "." . $extension;

                $result = get_basename_array($result, $extension, $set_keys);
            }
        }

        if (count($result) > 0) {

            return $result;
        }
    }

    /**
     * get_basename_array()
     * 
     * @param array $files
     * @param string $extension
     * @param bool $set_keys
     * @return array 
     */
    function get_basename_array($files, $extension, $set_keys) {
        $result = array();
        foreach ($files as $key => $file) {
            if (!$set_keys) {
                $result[$key] = basename($file, $extension);
            } else {
                $name = basename($file, $extension);
                $result[$name] = $file;
            }
        }
        return $result;
    }

    /**
     * tide_news_page_build() - Build Sumary News PAge
     * 
     * @global array $general_settings
     * @param number $news_number
     * @param array $news_items
     * @param array $category_data
     * @param string $plugin_functions
     * @return string 
     */
    function tide_news_page_build($news_number, $news_items, $category_data, $plugin_functions = false) {

        global $general_settings;
        $combine = '';

        if ($news_number > 0) {

            $start = 1;
            $times_loop = $general_settings['news_page_number'] + 1;

            if (empty($_GET['page_number'])) {
                if ($general_settings['news_page_number'] < $news_number) {
                    $current_page = 1;
                } else {
                    $current_page = false;
                }
            } else {
                $current_page = $_GET['page_number'];
            }

            if (!empty($_GET['page_number'])) {
                if ($_GET['page_number'] > 1) {
                    $start = (($_GET['page_number'] - 1) * $general_settings['news_page_number']) + 1;
                    $times_loop = $times_loop + $start - 1;
                }
            }

            if ($times_loop >= $news_number + 1) {

                $times_loop = $news_number + 1;
            }
            if (!isset($_GET['id'])) {
                $_GET['id'] = 'index';
            }
            for ($i = $start; $i < $times_loop; $i++) {

                $data = xml_content_array($news_items[$i - 1]['file'], false);


                $category_index = os_separator(NEWS_DIR . 'category_index.xml');
                $cat = tide_xml_search_value($category_index, 'category_slug', $data['category']);
                $cat = tide_xml_decode($cat);

                $data['category_title'] = $cat['category_title'];

                if ($data['news_visibility'] == 'N' || cookie_check()) {

                    $data['link'] = url_builder($_GET['id'], $data['category'], $data['slug'], $plugin_functions, $current_page);

                    if ($data['click_title'] == 'checked') {
                        $data['title'] = '<a  href="' . $data['link'] . '">' . $data['title'] . '</a>';
                    }

                    if ($data['date_show'] !== 'checked') {
                        $data['date'] = i18n_r('tide_news/NEWS_POSTED');
                    } else {
                        $data['date'] = i18n_r('tide_news/NEWS_DATE') . ': ' . $data['date'] . ' ' . i18n_r('tide_news/NEWS_POSTED_CAT');
                    }

                    $data['c_tags'] = '';
                    if (isset($data['tags'])) {
                        $data['c_tags'] = tide_news_tags($data['tags']);
                    }

                    if (!empty($data['summary'])) {

                        $data['summary'] = $data['summary'] . '<div class="tide_read_more"><a href="' . htmlspecialchars($data['link']) . '">' . i18n_r('tide_news/NEWS_READ_MORE') . ' . . .</a></div>';
                    } else {
                        $data['summary'] = $data['content'];
                    }
                     $data['summary'] = html_entity_decode($data['summary'], ENT_QUOTES, 'UTF-8');
                    $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/news.tpl', $data);
                }
            }

            $last = ceil($news_number / $general_settings['news_page_number']);

            $pages_array = nav_drop_down($category_data['pages'], range(0, $last - 1), true, $plugin_functions);

            if ($general_settings['news_page_number'] < $news_number) {

                switch ($general_settings['navigation_type']) {
                    case 'paginate':

                        if ($news_number > $general_settings['news_page_number']) {
                            $data = nav_paginate($last, $current_page, $pages_array, $general_settings['news_page_number']);
                            $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/nav_paginate.tpl', $data);
                        }
                        break;
                    case 'drop down':
                        $g_page = nav_drop_down($category_data['pages'], array($current_page));
                        $pages_array = array_flip($pages_array);
                        $data['drop_down'] = construct_dropdown('tide_drop_down', 'text', $pages_array, $g_page[0], 'onchange="window.open(this.options[this.selectedIndex].value,\'_top\')"', true);
                        $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/nav_drop_down.tpl', $data);

                        break;
                    default:
                        $data = nav_old_new($last, $current_page, $category_data['pages'], 'nav_default');
                        $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/nav_default.tpl', $data);
                }
            }
        } else {

            $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/no_news.tpl');
        }
        return $combine;
    }

    /**
     * tide_complete_news_build() - Extended News Page Build
     * 
     * @param string $data_link
     * @return string 
     */
    function tide_complete_news_build($data_link) {
        
        $combine = '';
        global $general_settings;
        $data = xml_content_array($data_link, false);
  
        $category_index = os_separator(NEWS_DIR . 'category_index.xml');
        $cat = tide_xml_search_value($category_index, 'category_slug', $data['category']);
        $cat = tide_xml_decode($cat);

        $data['category_title'] = $cat['category_title'];
   
        if ($data['news_visibility'] == 'Y' && !cookie_check()) {
            $data['content'] = '<div class="tide_news_private">' . i18n_r('tide_news/NEWS_PRIVATE') . '</div>';
            $data['content'] .= '<div class="tide_news_private_info">' . i18n_r('tide_news/NEWS_PRIVATE_INFO') . '</div>';
        }

        $data['p_link'] = '';
        if ($data['permanent_link'] == 'checked') {
            $data['p_link'] .= url_builder($_GET['id'], $_GET['category'], $data['slug']);
        }

        if ($data['date_show'] !== 'checked') {
            $data['date'] = 'Posted in: Category ';
        } else {
            $data['date'] = i18n_r('tide_news/NEWS_DATE') . ': ' . $data['date'] . ' in ';
        }

        $data['modified'] = '';
        if (isset($data['modified_date']) && isset($data['modified_time'])) {
            $data['modified'] = '<span class="tide_news_content_modified_pre">'.i18n_r('tide_news/NEWS_MODIFIED') .'  </span><span class="tide_news_content_modified_date">'. $data['modified_date'] . ' ' . $data['modified_time'].'</span>';
        }
       
        $data['c_tags'] = '';
        if (isset($data['tags'])) {
            $data['c_tags'] = tide_news_tags($data['tags']);
        }
         $data['summary'] = html_entity_decode($data['summary'], ENT_QUOTES, 'UTF-8');
        $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/news_extended.tpl', $data);

        if ($general_settings['external_comments'] = "checked" && function_exists('get_external_comments')) {
            $data['icon'] = SITE_URL . 'plugins/tide_news/icons/';
            $combine .= load_template(TIDE_NEWS_TEMPLATES . 'frontend/comments.tpl', $data);
        }
      $content = html_entity_decode(tide_shortcodes($combine, false), ENT_QUOTES, 'UTF-8');
    
        return $content;
    }

    /**
     * slug_sanitize() - Sanitize slug 
     * 
     * @global type $general_settings
     * @param string $slug
     * @param string $title
     * @param bool $separator
     * @return type 
     */
    function slug_sanitize($slug, $title, $separator = false) {
        global $general_settings;
        if ($separator) {
            $s = '-';
        } else {
            $s = $general_settings['slug_separator'];
        }
        if (empty($slug)) {
            $slug = $title;
        }
        $slug = tide_clean_string($slug);
        $slug = str_replace(' ', $s, $slug);
        return $slug;
    }

    /**
     * tide_clean_string()
     * 
     * @param string $string
     * @return string 
     */
    function tide_clean_string($string) {
        $string = strtolower($string);
        $string = trim($string);
        $string = preg_replace('/[^A-Za-z0-9_]/i', ' ', $string);
        $string = preg_replace('/[[:blank:]]+/', ' ', $string);
        return $string;
    }

    /**
     * pagebreak_process() - Split news on summary and extended news
     * 
     * @param string $content
     * @return string 
     */
    function pagebreak_process($content) {
      
        preg_match('/(.*)&lt;!--more--&gt;(.*)/usm', $content, $matches);
        if(!$matches){
            preg_match('/(.*)<!--more-->(.*)/usm', $content, $matches);
        }
 
        if (!$matches) {

            $data = $content;
        } else {
            $data = $matches[1];
        }
        return $data;
    }

    ############################# MISC FUNCTIONS ##################################    

    /**
     * upload_image()
     * 
     * @global array $SESSIONHASH
     * @return string 
     */
    function upload_image() {
        global $SESSIONHASH;
        $path = "";

        $fileSizeLimit = toBytes(ini_get('upload_max_filesize')) / 1024;
        $upload_image = '<ul class="snav">
            <li class="upload" id="sb_uploadify" >
		<div id="uploadify"></div>';


        $upload_image .= "<script type=\"text/javascript\">
	jQuery(document).ready(function() {
            upload();
        });
        
        function upload(){
		
		$('#uploadify').uploadify({
			'buttonText'	: '" . i18n_r('tide_news/S_RSS_UPLOAD') . "',
			'buttonCursor'	: 'hand',
			'uploader'	: '".SITE_URL."admin/upload-uploadify.php',
			'swf'		: '".SITE_URL."admin/template/js/uploadify/uploadify.swf',
			'multi'		: false,
			'auto'		: true,
			'height'	: '25',
			'width'		: '100%',
			'requeueErrors'	: true,
                        'preventCaching'  : false,
			'fileSizeLimit'	: '" . $fileSizeLimit . "', 
			'cancelImage'	: '".SITE_URL."admin/template/images/cancel.png',
			'checkExisting'	: 'uploadify-check-exists.php?path=" . $path . "',
			'postData'		: {
				'sessionHash' : '" . $SESSIONHASH . "',
				'path' : '" . $path . "'
			},
			onUploadProgress: function(file) {
				$('#loader').show();
                               
			},
			onUploadComplete: function(file) {
				$('#loader').fadeOut(500);
				$('#maincontent').load(location.href+' #maincontent', function() {
					$('#feed_im_prew').attr('src', '" . SITE_URL . "data/uploads/' + file['name'].toLowerCase());
                                        upload();      
				});
                                
			},
			onSelectError: function(file,errorCode,errorMsg) {
				//alert(file + ' Error ' + errorCode +':'+errorMsg);
			},
			onUploadError: function(file,errorCode,errorMsg, errorString) {
				alert(errorMsg);
			}
		});
               }
	
	</script>";
        $upload_image .= '</li><li style="float:right;" id="sb_filesize" ><small>File size: <strong>' . $fileSizeLimit . 'MB</strong></small></li>
</ul><p>';

        return $upload_image;
    }

    /**
     * smartCopy()
     * 
     * @param string $source
     * @param string $dest
     * @param array $options
     * @return boolean 
     */
    function smartCopy($source, $dest, $options = array('folderPermission' => 0755, 'filePermission' => 0755)) {
        $result = false;

        if (is_file($source)) {
            if ($dest[strlen($dest) - 1] == '/') {
                if (!file_exists($dest)) {
                    cmfcDirectory::makeAll($dest, $options['folderPermission'], true);
                }
                $__dest = $dest . "/" . basename($source);
            } else {
                $__dest = $dest;
            }
            $result = copy($source, $__dest);
            chmod($__dest, $options['filePermission']);
        } elseif (is_dir($source)) {
            if ($dest[strlen($dest) - 1] == '/') {
                if ($source[strlen($source) - 1] == '/') {
                    //Copy only contents
                } else {
                    //Change parent itself and its contents
                    $dest = $dest . basename($source);
                    @mkdir($dest);
                    chmod($dest, $options['filePermission']);
                }
            } else {
                if ($source[strlen($source) - 1] == '/') {
                    //Copy parent directory with new name and all its content
                    @mkdir($dest, $options['folderPermission']);
                    chmod($dest, $options['filePermission']);
                } else {
                    //Copy parent directory with new name and all its content
                    @mkdir($dest, $options['folderPermission']);
                    chmod($dest, $options['filePermission']);
                }
            }

            $dirHandle = opendir($source);
            while ($file = readdir($dirHandle)) {
                if ($file != "." && $file != "..") {
                    if (!is_dir($source . "/" . $file)) {
                        $__dest = $dest . "/" . $file;
                    } else {
                        $__dest = $dest . "/" . $file;
                    }
                    //echo "$source/$file ||| $__dest<br />";
                    $result = smartCopy($source . "/" . $file, $__dest, $options);
                }
            }
            closedir($dirHandle);
        } else {
            $result = false;
        }
        return $result;
    }

    function pr($data) {
        print_r('<pre>');
        print_r($data);
        print_r('</pre>');
    }

################################################################################
//
############################ NEWS TAGS FUNCTIONS ###############################

    /**
     * check_tags() - Check Tags changes during edit news and apply them
     * @param array $old_tags
     * @param array $new_tags
     * @param string $news_path
     * @param string $old_slug
     * @param string $new_slug
     * @return boolean 
     */
    function check_tags($old_tags, $new_tags, $news_path, $old_slug, $new_slug, $master_tags=false) {
   //tide_xml_node_update($path, $data, $node, $id, $reference, $new_reference = false)
        $r = array();
        if ($old_tags == $new_tags) {
            foreach ($old_tags as $key => $link) {
                if(!$master_tags){
                    $r[] = tide_xml_node_update($link, $news_path, 'item', 'id', $old_slug, $new_slug);
                }else{
                    $r[] = tide_xml_node_update($link, $news_path, 'item', 'unique', $old_slug, $new_slug);
                }
            }
        } else {
            if (!empty($new_tags) && !empty($old_tags)) {
                $same_tags = array_intersect($old_tags, $new_tags);
                   
                $deleted_tags = array_diff($old_tags, $new_tags);
                $new_tags = array_diff($new_tags, $old_tags);

                if (!empty($same_tags)) {
                    foreach ($same_tags as $key => $link) {
                         if(!$master_tags){
                            $r[] = tide_xml_node_update($link, $news_path, 'item', 'id', $old_slug, $new_slug);
                         }else{
                             $r[] = tide_xml_node_update($link, $news_path, 'item', 'unique', $old_slug, $new_slug);
                         }
                    }
                }

                if (!empty($deleted_tags)) {
                    foreach ($deleted_tags as $key => $link) {
                        if(!$master_tags){
                            $r[] = tide_xml_node_remove($link, 'item', 'id', $old_slug, true);
                        }else{
                            $r[] = tide_xml_node_remove($link, 'item', 'unique', $old_slug, true);
                        }
                    }
                }
                if (!empty($new_tags)) {
                    $xml_data = array('item' => $news_path);
                    foreach ($new_tags as $key => $link) {
                         
                        $r[] = news_items($xml_data, $link, $new_slug, true);
                    }
            
                }
            } else {
                if (empty($new_tags)) {
                    foreach ($old_tags as $key => $link) {
                        if(!$master_tags){
                            $r[] = tide_xml_node_remove($link, 'item', 'id', $old_slug, true);
                        }else{
                             $r[] = tide_xml_node_remove($link, 'item', 'unique', $old_slug, true);          
                        }
                    }
                }

                if (empty($old_tags)) {
                    foreach ($new_tags as $key => $link) {
                        $r[] = news_items($news_path, $link, $new_slug, true);
                    }
                }
            }
        }
        $r = tide_check($r);
        return $r;
    }

    /**
     * tags_url_builder()
     * 
     * @param string $tag
     * @param bool $urls
     * @param bool|string $category
     * @return string 
     */
    function tags_url_builder($tag, $urls = false, $category = false) {
        $c = '';
        $tag = urldecode($tag);
        if (PRETTY_URLS == '1') {
            if ($category) {
                $c = '/' . $category;
            }
            if ($urls) {
                $url = SITE_URL . 'tags/' . $tag . $c;
            } else {
                $url = '<a href="' . SITE_URL . 'tags/' . $tag . $c . '">' . $tag . '</a>';
            }
        } else {
            if ($category) {
                $c = '&amp;category=' . $category;
            }
            if ($urls) {
                $url = SITE_URL . 'index.php?id=tags&amp;tide_tags=' . $tag . $c;
            } else {
                $url = '<a href="' . SITE_URL . 'index.php?id=tags&amp;tide_tags=' . $tag . $c . '">' . $tag . '</a>&nbsp;&nbsp;';
            }
        }
        return $url;
    }

    /**
     * tide_news_tags() - Create Tags HTML Structure
     * @param array $tags
     * @return string 
     */
    function tide_news_tags($tags) {

        if (isset($tags['data']) && $tags !== 'empty') {
            $t = '';
            if (!is_array($tags['data'])) {
                $tgs[0] = $tags['data'];
            } else {
                $tgs = $tags['data'];
            }

            foreach ($tgs as $key => $val) {
                $t .= '<em class="tide_news_single_tag">' . tags_url_builder($val) . '</em>';
            }
        } else {
            $t = '';
        }

        return $t;
    }

    /**
     * get_tag_color()
     * 
     * @param number $weight
     * @param string $mincolor
     * @param string $maxcolor
     * @return string 
     */
    function get_tag_color($weight, $mincolor, $maxcolor) {

        $weight = $weight / 100;

        $mincolor = hexdec($mincolor);
        $maxcolor = hexdec($maxcolor);

        $r1 = ($mincolor >> 16) & 0xff;
        $g1 = ($mincolor >> 8) & 0xff;
        $b1 = $mincolor & 0xff;

        $r2 = ($maxcolor >> 16) & 0xff;
        $g2 = ($maxcolor >> 8) & 0xff;
        $b2 = $maxcolor & 0xff;

        $r = $r1 + ($r2 - $r1) * $weight;
        $g = $g1 + ($g2 - $g1) * $weight;
        $b = $b1 + ($b2 - $b1) * $weight;
        $color = ($r << 16) | ($g << 8) | $b;

        return sprintf("%06x", $color);
    }

    /**
     * This function takes a value and returns an RGB color between Red to Yellow to Green in a given spectrum. 
     * 50% = FFFF00 
     * 
     * @param mixed $value required
     * @param mixed $brightness value between 1 and 255
     * @param mixed $max default 100
     * @param mixed $min default 0
     * @param mixed $thirdColorHex '00'
     */
    function percent2Color($value, $brightness = 255, $max = 100, $min = 0, $thirdColorHex = '00') {
        // Calculate first and second color (Inverse relationship)
        $first = (1 - ($value / $max)) * $brightness;
        $second = ($value / $max) * $brightness;
        $letters = "1234567890ABCDEF";

        $randomChar = $letters[rand(0, strlen($letters) - 1)];
        $randomChar .= $letters[rand(0, strlen($letters) - 1)];
        echo $randomChar;
        // Find the influence of the middle color (yellow if 1st and 2nd are red and green)
        $diff = abs($first - $second);
        $influence = ($brightness - $diff) / 2;
        $first = intval($first + $influence);
        $second = intval($second + $influence);

        // Convert to HEX, format and return
        $firstHex = str_pad(dechex($first), 2, 0, STR_PAD_LEFT);
        $secondHex = str_pad(dechex($second), 2, 0, STR_PAD_LEFT);

        return $firstHex . $secondHex . $randomChar;
    }

    /**
     *  tide_tag_sanitize()
     * 
     * @param string $tags
     * @return string 
     */
    function tide_tag_sanitize($tags) {
        $n = count($tags);
        $search = array('/', '\\');
        for ($i = 0; $i < $n; $i++) {
            $tags[$i] = urlencode($tags[$i]);
            $tags[$i] = strtolower(str_replace($search, '-', $tags[$i]));
        }
        return $tags;
    }

################################################################################
############################ XML FUNCTIONS #####################################
    /**
     * xml_load_file() - heck if file exists and if exist load content
     * @param strng $path
     * @return boolean|array 
     */

    function tide_xml_load_file($path) {
        if (file_exists($path)) {
            $xml = simplexml_load_file($path, "SimpleXMLElement", LIBXML_NOCDATA | LIBXML_NOENT);
        } else {
            $xml = false;
        }
        return $xml;
    }

    /**
     * tide_count_nodes() - Count xml nodes
     * 
     * @param string $path  - File path.
     * @param string $node  - Node name.
     * @param bool $parent  - (true)-Count child nodes, (false)-Count root nodes.
     * @return number|boolo 
     */
    function tide_count_nodes($path, $node, $parent = false) {

        $xml = tide_xml_load_file($path);

        if (!$xml) {
            return $xml;
        } else {

            if (!$parent) {
                $k = $xml->$node;
            } else {
                $k = $xml->$node->children();
            }

            if ($xml->$node) {
                $res = count($k);
            } else {
                $res = false;
            }
            return $res;
        }
    }

    /**
     * tide_xml_node_remove() - Remove XML node based on indentifier. If $unlink_empty==true and there are no more nides delete xml file
     * 
     * @param string $path
     * @param string $node
     * @param string $id
     * @param string $reference
     * @param bool $unlink_empty
     * @return bool 
     */
    function tide_xml_node_remove($path, $node, $id, $reference, $unlink_empty = false) {
      
        $xml = tide_xml_load_file($path);

        if (!$xml) {
            return $xml;
        } else {
            $nodes = count($xml);

            $er = $node . '[@' . $id . '="' . $reference . '"]';
            $result = $xml->xpath($er);
            $c = count($result);

            if ($nodes == $c && $unlink_empty) {
                $xml = null;
                unlink($path);
                $r = tide_check_file($path);
            } else {
                if (!is_array($result)) {
                    unset($result[0][0]);
                } else {
                    foreach ($result as $key) {
                        unset($key[0][0]);
                    }
                }
                $r = tide_xml_save($xml, $path);
            }
            return $r;
        }
    }

    /**
     * tide_xml_node_update() - 
     * 
     * @param string $path
     * @param string $data
     * @param string $node
     * @param string $id
     * @param string $reference
     * @param string $new_reference
     * @return bool 
     */
    function tide_xml_node_update($path, $data, $node, $id, $reference, $new_reference = false) {
    
        $xml = tide_xml_load_file($path);

        if (!$xml) {
            return $xml;
        } else {

            $er = $node . '[@' . $id . '="' . $reference . '"]';
            $result = $xml->xpath($er);

            foreach ($result as $element) {
                if ($new_reference) {
                    if (!is_array($new_reference)) {
                        $element[0][0]->attributes()->$id = $new_reference;
                    } else {
                        foreach ($new_reference as $key => $val) {
                            $element[0][0]->attributes()->$key = $val;
                        }
                    }
                }
                if (is_array($data)) {
                    foreach ($data as $keysss => $valss) {
                        $element[0][0]->$keysss = $valss;
                    }
                } else {
                    $element[0][0] = $data;
                }
            }

            $r = tide_xml_save($xml, $path);
            return $r;
        }
    }

    /**
     * tide_xml_save() - Save xml file
     * 
     * @param array $data
     * @param string $path
     * @param bool $no_whitespace
     * @return bool 
     */
    function tide_xml_save($data, $path, $no_whitespace = true) {
         
        if ($no_whitespace) {
    
            $xml_string = $data->asXML();
           
            
            $xml_cleaned = preg_replace('~\s*(<([^>]*)>[^<]*</\2>|<[^>]*>)\s*~', '$1', $xml_string);
            
            $xml_data = simplexml_load_string($xml_cleaned);
           
            $result = $xml_data->asXML($path);
        } else {
            $result = $data->asXML($path);
        }
        if ($result) {
            $result = chmod($path, 0755);
        }
        return $result;
    }

    /**
     * tide_html_ent() - Encode html array items
     * @param array $data
     * @return array 
     */
    function tide_html_ent($data) {
        array_walk_recursive($data, 'tide_xml_encode_data');
        return $data;
    }

    /**
     * tide_xml_encode_data()
     * 
     * @param array $item
     * @param array $data
     * @return array 
     */
    function tide_xml_encode_data(&$item) {
        $item = trim($item);

        if (empty($item)) {
            $item = '';
        } else {
            $item = htmlentities($item, ENT_QUOTES, 'UTF-8', false);
        }
    }

    /**
     * tide_xml_decode() 
     * 
     * @param type $data
     * @return boolean 
     */
    function tide_xml_decode($data) {
        $data = json_decode(json_encode((array) $data), 1);
        if (!empty($data)) {
            $data = tide_html_ent_decode($data);
        } else {
            $data = false;
        }
        return $data;
    }

    /**
     *
     * @param type $data
     * @return type 
     */
    function tide_html_ent_decode($data) {

        if (count($data) == 1) {
            $key = array_keys($data);
            $data = $data[$key[0]];
        }

        array_walk_recursive($data, 'tide_xml_decode_data');
        return $data;
    }

    /**
     * tide_xml_decode_data()
     * @param array $item 
     */
    function tide_xml_decode_data(&$item) {

        if (!empty($item)) {
            $item = htmlspecialchars_decode($item);
        } else {
            $item = '';
        }
    }

    /**
     * tide_xml_file() - Create/ Update XML file 
     * 
     * @param string $data
     * @param string $path
     * @param string $action
     * @param string|bool $attribute
     * @param string|bool $parent
     * @param string|bool $root_element
     * @return boolean 
     */
    function tide_xml_file($data, $path, $action = 'create', $attribute = false, $parent = false, $root = false, $no_whitespace = true, $cd_data = false) {
        if (!$root) {
            $root_element = '<root> </root>';
        } else {
            if (!is_array($root)) {
                $root_element = '<' . $root . '> </' . $root . '>';
            } else {
                $root_element = '<' . $root['element'] . ' ' . $root['id'] . '> </' . $root['element'] . '>';
            }
        }

        if ($action == 'create') {
            if (!$cd_data) {
                $xml_info = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?>' . $root_element . '');
                if ($data) {
                    array_to_xml($data, $xml_info, $attribute, $parent, $root);
                }
            } else {
                $xml_info = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?>' . $root_element . '');
                if ($data) {
                    array_to_xml_cd_data($data, $xml_info, $attribute, $parent, $root, $cd_data);
                }
            }
        } elseif ($action == 'update') {
            if (!$parent) {
                $datas['item'] = $data;
            } else {
                $datas[0] = $data;
            }
            $xml = simplexml_load_file($path);
            if (!$cd_data) {
                $xml_info = new SimpleXMLElement($xml->asXML());
                array_to_xml($datas, $xml_info, $attribute, $parent, $root);
            } else {
                $xml_info = new SimpleXMLExtended($xml->asXML());
                array_to_xml_cd_data($data, $xml_info, $attribute, $parent, $root, $cd_data);
            }
        }
       
        $result = tide_xml_save($xml_info, $path, $no_whitespace);

        return $result;
    }

    function array_to_xml_cd_data($info, &$xml_info, $add_attribute = false, $parent = false) {

        foreach ($info as $key => $value) {
            if (is_array($value)) {
                if (!is_numeric($key)) {
                    $subnode = $xml_info->addChild("$key");
                    array_to_xml($value, $subnode, $add_attribute, $parent);
                } else {

                    if ($key !== 0) {
                        $subnode = $xml_info->addChild("item");
                        array_to_xml($value, $subnode, $add_attribute, $parent);
                    } else {
                        array_to_xml($value, $xml_info, $add_attribute, $parent);
                    }
                }
            } else {
                $value = htmlentities($value, ENT_QUOTES, 'UTF-8');
                if (is_numeric($key)) {
                    $cd = $xml_info->addChild("data");
                    $cd->addCData($value);
                } else {
                    if (!$parent) {
                        if ($add_attribute) {
                            if (is_array($add_attribute)) {
                                foreach ($add_attribute as $k => $v) {
                                    $xml_info->addAttribute("$k", "$v");
                                }
                            } else {
                                $xml_info->addAttribute('id', "$add_attribute");
                            }
                            $add_attribute = false;
                            $parent = false;
                        }
                    }

                    $r = $xml_info->addChild("$key");
                    $r->addCData($value);

                    if ($parent) {
                        if ($add_attribute) {
                            if (is_array($add_attribute)) {
                                foreach ($add_attribute as $k => $v) {
                                    $r->addAttribute("$k", "$v");
                                }
                            } else {
                                $r->addAttribute('id', "$add_attribute");
                            }
                            $add_attribute = false;
                            $parent = false;
                        }
                    }
                }
            }
        }
    }

    function array_to_xml($info, &$xml_info, $add_attribute = false, $parent = false, $rss = false) {
        
        foreach ($info as $key => $value) {
            if (is_array($value)) {
                if (!is_numeric($key)) {
                    $subnode = $xml_info->addChild("$key");
                    array_to_xml($value, $subnode, $add_attribute, $parent, $rss);
                } else {
                    if ($key !== 0) {
                        $subnode = $xml_info->addChild("item");
                        array_to_xml($value, $subnode, $add_attribute, $parent, $rss);
                    } else {
                        array_to_xml($value, $xml_info, $add_attribute, $parent, $rss);
                    }
                }
            } else {
                $value = htmlentities($value, ENT_QUOTES, 'UTF-8');
                if (is_numeric($key)) {

                    $xml_info->addChild("data", "$value");
                } else {
                    if (!$parent) {
                        if ($add_attribute) {
                            if (is_array($add_attribute)) {
                                foreach ($add_attribute as $k => $v) {
                                    $xml_info->addAttribute("$k", "$v");
                                }
                            } else {
                                $xml_info->addAttribute('id', "$add_attribute");
                            }
                            $add_attribute = false;
                            $parent = false;
                        }
                    }
//                    if ($rss && $key == 'description') {
//                        $value = htmlspecialchars($value);
//                    }

                    $r = $xml_info->addChild("$key", "$value");

                    if ($parent) {
                        if ($add_attribute) {
                            if (is_array($add_attribute)) {
                                foreach ($add_attribute as $k => $v) {
                                    $r->addAttribute("$k", "$v");
                                }
                            } else {
                                $r->addAttribute('id', "$add_attribute");
                            }
                            $add_attribute = false;
                            $parent = false;
                        }
                    }
                }
            }
        }
    }

    /**
     * xml_content_array() - Read xml file to array
     * 
     * @param string $path
     * @param boolean $r_node_num
     * @return boolean 
     * @todo must be redone 
     */
    function xml_content_array($path, $r_node_num = true) {
        
        $data = tide_xml_load_file($path);
        
        if(!$data){
            return $data;
        }else{
            $node_number = count($data);
          
            if ($node_number > 0) {

                $data = json_decode(json_encode((array) $data), 1);

                $node_key = array_keys($data);
                if ($node_number == 1) {
                    $res_data[0][0] = $data[$node_key[0]];
                    $data = $res_data;
                }

                if ($node_key == 'item') {
                    $data = $data['item'];
                }

                foreach ($data as $key => $val) {

                    if (empty($val)) {
                        $data[$key] = '';
                    }
                    if (is_array($val) && empty($val[0]) && !isset($val['data'])) {
                        $data[$key] = '';
                    }
                }

                $data = tide_html_ent_decode($data);

                if ($r_node_num) {
                    $r = array('data' => $data, 'nodes' => $node_number);
                } else {
                    $r = $data;
                }
            } else {
                $r = false;
            }
            return $r;
        }
    }

    /**
     * tide_get_xml_node() - Get XML node based on attribute
     * @param string $path
     * @param string $node
     * @param string $id
     * @param string $reference
     * @return array 
     */
    function tide_get_xml_node($path, $node, $id, $reference) {
        $items = '';
        $xml = simplexml_load_file($path);
        $er = $node . '[@' . $id . '="' . $reference . '"]';

        foreach ($xml->xpath($er) as $info) {
            $items = tide_xml_decode($info);
        }
        return $items;
    }

    /**
     * tide_xml_search_value() - Search node value and return parent
     * 
     * @param type $path
     * @param type $node
     * @param type $value
     * @return boolean 
     */
    function tide_xml_search_value($path, $node, $value) {
        $xml = tide_xml_load_file($path);

        if (!$xml) {
            return $xml;
        } else {
            foreach ($xml->xpath('//' . $node . '') as $page) {

                if ($page[0] == $value) {
                    $parent_node = $page->xpath("parent::*");
                }
            }

            if (!isset($parent_node)) {
                $parent_node = false;
            }
            return $parent_node;
        }
    }

    //$todo - Zameniti na jednom mestu u tide_news stara funkcija
    function update_xml($path, $new_values) {

        $reference = $new_values['old_slug'];
        unset($new_values['old_slug']);
        $xml = simplexml_load_file($path);
        foreach ($element = $xml->xpath("item[@id='" . $reference . "']") as $info) {

            $info->attributes()->id = $new_values['slug'];
            unset($new_values['slug']);
            foreach ($new_values as $key => $value) {

                $info->$key = $value;
            }
        }

        $result = XMLsave($xml, $path);
        if ($result) {
            $result = true;
        } else {
            $result = false;
        }
        return $result;
    }

#################################################################################
##################### PAGE SHORTCODE FUNCTIONS #################################
    
    /**
     * tide_remove_code() - Remove plugin shortcode from page if exists
     * @param string $page
     * @return boolean 
     */
    function tide_remove_code($page) {
        
        global $general_settings;
        

        
        $xml = tide_xml_load_file($page);

        if (!$xml) {
            return $xml;
        } else {
            $val = (string) $xml->content[0];
            preg_match('/{%{([A-Z0-9_:-]+)}%}/usm', $val, $matches);
            
            if(empty($matches)){
                 preg_match('/&amp;lt;\?php tide_show_news\((.*)\); \?&amp;gt;/usm', $val, $matches);
            }
    
         
            if ($matches) {
                $xml->content = str_replace($matches[0], "", $val);
                $result = tide_xml_save($xml, $page);
            } else {
                $result = false;
            }

            return $result;
        }
    }

    /**
     * tide_check_code() - Check Plugin Shortcode on pages. 
     * @param string $page
     * @return string 
     */
    function tide_check_code($page) {
        
        $xml = simplexml_load_file($page);

        if (!$xml) {
            return $xml;
        } else {
            $val = (string) $xml->content[0];
             $c = 'shortcode';
            preg_match( '/{%{([A-Z0-9_:-]+)}%}/usm', $val, $matches);
            
            if(empty($matches)){
                 preg_match(  '/&amp;lt;\?php tide_show_news\((.*)\); \?&amp;gt;/usm', $val, $matches);
                 $c = 'php';
            }
            
            $result = false;
            if ($matches) {
                $result = array($matches[1], $c);
            }
            return $result;
        }
    }

    /**
     * tide_pages_category() - Check Pages Shortcode and determine category
     *  
     * @param array|bool $slugs
     * @return type 
     */
    function tide_pages_category($slugs = false) {

        global $general_settings;
        $pages = get_pages(GSDATAOTHERPATH . 'pages.xml', true);

        $ch_pages = array();

        foreach ($pages as $slug => $title) {
            $r = tide_check_code(GSDATAPATH . 'pages/' . $slug . '.xml');
           
            if ($r) {
                if ( $r == 'shortcode') {
                    $r = strtolower(str_replace("TIDE_NEWS::", "", $r[0]));
                } else {
                    $r = html_entity_decode($r[0], ENT_QUOTES, 'UTF-8');
                    $r = str_replace("'", "", $r);
                    $r = str_replace('"', "", $r);
                }

                if ($slugs) {
                    if ($slugs == $r) {
                        $ch_pages[$slug] = $title . ' >>Current Category';
                    } else {
                        $ch_pages[$slug] = $title . ' >>Category Exists';
                    }
                } else {
                    if ($r) {
                        $ch_pages[$slug] = $title . ' >>Category Exists';
                    }
                }
            } else {
                $ch_pages[$slug] = $title;
            }
        }
        return $ch_pages;
    }

    /**
     * tide_update_page() - Update Page Shortcode with new category
     * 
     * @param string $path
     * @param string $category
     * @return boolean 
     */
    function tide_update_page($path, $category) {
        
        global $general_settings;
        
        $needle = '/{%{([A-Z0-9_:-]+)}%}/usm';
        $add_function_code = '{%{TIDE_NEWS::' . strtoupper($category) . '}%}';
        
        $xml = simplexml_load_file($path);
        $val = (string) $xml->content[0];

        preg_match($needle, $val, $matches);

        if (!$matches) {
            $xml->content = $val . $add_function_code;
        } else {
            $xml->content = str_replace($matches[1], 'TIDE_NEWS::'.strtoupper($category), $val);     
        }
        return tide_xml_save($xml, $path, false);
    }

################################################################################
############################ URL NAV FUNCTIONS #################################
    /**
     * convert_url() - Conver url to friendly url
     * 
     * @param string $url
     * @return string 
     */

    function convert_url($url) {

        $urls = SITE_URL . 'index.php?';
        $link = str_replace($urls, '', $url);

        parse_str($link, $output);

        if (isset($output['id'])) {
            $furl = url_builder($output['id'], $output['category'], $output['news_current']);
        } else {
            $furl = $url;
        }

        return $furl;
    }

    /**
     *  archive_url_builder() - Archive menu url build
     * @param string $archive
     * @param string $category 
     */
    function archive_url_builder($archive, $category) {
        if (PRETTY_URLS == '1') {
            $url = SITE_URL . 'archive/' . $archive . '/' . $category;
        } else {
            $url = SITE_URL . 'index.php?id=archive&amp;tide_archive=' . $archive . '&amp;category=' . $category . '';
        }
        return $url;
    }

    /**
     * url_builder()
     * 
     * @param string $page
     * @param string $category
     * @param string $news
     * @param string $plugin_functions
     * @param number $page_num
     * @param bool $not_pretty
     * @return string 
     */
    function url_builder($page, $category, $news, $plugin_functions = false, $page_num = false, $not_pretty = true) {
        if (!$plugin_functions) {
            $plugin_functions = 'tide_show_news';
        }
        $pn = '';

        if (PRETTY_URLS == '1' && $not_pretty) {
            if ($page_num) {
                $url = SITE_URL . 'news/' . $page . '/' . $page_num . '/' . $category . '/' . $news;
            } else {
                $url = SITE_URL . 'news/' . $page . '/' . $category . '/' . $news;
            }
        } else {

            if ($page_num) {
                $pn = '&amp;page_number=' . $page_num;
            }
            $url = SITE_URL . 'index.php?id=' . $page . '&amp;' . $plugin_functions . '&amp;category=' . $category . '&amp;news_current=' . $news . $pn;
        }
        return $url;
    }

    /**
     * url_builder_pages()
     * 
     * @param string $page
     * @param string $news
     * @param number $current
     * @return string 
     */
    function url_builder_pages($page, $news, $current) {

        if (PRETTY_URLS == '1') {
//            $url = SITE_URL . 'page-' . $page . '-' . $current . '-news-' . $news;
            $url = SITE_URL . 'news/' . $page . '/page-' . $current . '/' . $news;
        } else {
            $url = SITE_URL . 'index.php?id=' . $page . '&amp;tide_show_news&amp;page=' . $current . '&amp;current_news=' . $news;
        }
        return $url;
    }

    /**
     * nav_default()
     * 
     * @param string $page
     * @param number $page_num
     * @param string $old_new
     * @return string 
     */
    function nav_default($page, $page_num, $old_new) {

        if (PRETTY_URLS == '1') {
            $url = SITE_URL . 'news/' . $page . '/page-' . $page_num;
        } else {
            $url = SITE_URL . 'index.php?id=' . $page . '&tide_show_news&page_number=' . $page_num;
        }
        return $url;
    }

    /**
     * nav_news_admin()
     * 
     * @param string $page
     * @param number $page_num
     * @param string $old_new
     * @return string 
     */
    function nav_news_admin($page, $page_num, $old_new) {
        $url = SITE_URL . 'admin/load.php?id=tide_news&amp;tide_news_overview=' . $page . '&amp;page_number=' . $page_num;
        return $url;
    }

    /**
     * nav_rss_admin()
     * 
     * @param string $page
     * @param number $page_num
     * @param string $old_new
     * @return string 
     */
    function nav_rss_admin($page, $page_num, $old_new) {
        $url = SITE_URL . 'admin/load.php?id=tide_news&amp;tide_rss_management&amp;subpage=tide_rss_manual_create' . $page . '&amp;page_number=' . $page_num;
        return $url;
    }

    /**
     * nav_category_admin() - News Category List Url creation
     * @param string $page
     * @param string $page_num
     * @param string $old_new
     * @return string 
     */
    function nav_category_admin($page, $page_num, $old_new) {
        $url = SITE_URL . 'admin/load.php?id=tide_news&amp;tide_category&subpage=tide_category_list&amp;page_number=' . $page_num;
        return $url;
    }

    /**
     * nav_drop_down()
     * 
     * @param string $page
     * @param number $page_num
     * @param bool|string $extra
     * @param string $plugin_functions
     * @return string 
     */
    function nav_drop_down($page, $page_num, $extra = false, $plugin_functions = false) {
        foreach ($page_num as $key => $value) {
            if ($extra) {
                $value++;
                $key++;
            }
            if (!$plugin_functions) {
                $plugin_functions = 'news';
            }
            if (PRETTY_URLS == '1') {
                $url[$key] = SITE_URL . $plugin_functions . '/' . $page . '/page/' . $value;
            } else {
                $url[$key] = SITE_URL . 'index.php?id=' . $page . '&amp;' . $plugin_functions . '&amp;page_number=' . $value;
            }
        }
        return $url;
    }

    /**
     * nav_old_new() - Create Simple Old/New Page Navigation
     * @param number $last
     * @param number $current_page
     * @param string $page
     * @param string $function
     * @return string 
     */
    function nav_old_new($last, $current_page, $page, $function) {

        if ($current_page == 1) {
            $older_link = call_user_func_array($function, array($page, $current_page + 1, 'older'));
            $data['older'] = '<a href="' . $older_link . '">' . i18n_r('tide_news/NEWS_PAG_OLD') . '</a>';
            $data['newer'] = '';
        } else if ($current_page == $last) {
            $newer_link = call_user_func_array($function, array($page, $current_page - 1, 'newer'));
            $data['older'] = '';
            $data['newer'] = '<a href="' . $newer_link . '">' . i18n_r('tide_news/NEWS_PAG_NEW') . '</a>';
        } else {
            $older_link = call_user_func_array($function, array($page, $current_page + 1, 'older'));
            $newer_link = call_user_func_array($function, array($page, $current_page - 1, 'newer'));

            $data['newer'] = '<a href="' . $newer_link . '">' . i18n_r('tide_news/NEWS_PAG_NEW') . '</a>';
            $data['older'] = '<a href="' . $older_link . '">' . i18n_r('tide_news/NEWS_PAG_OLD') . '</a>';
        }
        return $data;
    }

    /**
     * nav_paginate()
     * 
     * @param number $last
     * @param number $current_page
     * @param array $pages_array
     * @return string 
     */
    function nav_paginate($last, $current_page, $pages_array) {

        $data['paginate'] = '';

        if ($last >= 10 && ($current_page > 3 && $current_page < $last - 3)) {

            $new_array[0] = array_slice($pages_array, 0, 3, true);

            if ($current_page == 4) {
                $new_array[1] = array_slice($pages_array, 3, 3, true);
            } else if ($current_page + 1 <= $last - 3) {
                $new_array[1] = array_slice($pages_array, $current_page - 2, 3, true);
            } else {
                $new_array[1] = array_slice($pages_array, $current_page - 1, 3, true);
            }
            $new_array[2] = array_slice($pages_array, $last - 3, 3, true);
        } elseif ($last >= 10 && ($current_page <= 3 || $current_page >= $last - 3)) {

            $new_array[0] = array_slice($pages_array, 0, 3, true);

            if ($current_page == 3) {
                $new_array[1] = array_slice($pages_array, 3, 3, true);
            } else if ($current_page == $last - 3) {
                $new_array[1] = array_slice($pages_array, $current_page - 3, 3, true);
            } else {
                $new_array[1] = array_slice($pages_array, round($last / 2) - 1, 3, true);
            }

            $new_array[2] = array_slice($pages_array, $last - 3, 3, true);
        }

        if ($last < 10) {
            foreach ($pages_array as $key => $value) {

                if ($key == $current_page) {
                    $data['paginate'] .= '<span class="tide_current">' . $key . '</span>';
                } else {
                    $data['paginate'] .= '<a  href="' . $value . '"> ' . $key . ' </a>';
                }
            }
        } else {

            for ($i = 0; $i < count($new_array); $i++) {
                foreach ($new_array[$i] as $key => $value) {

                    if ($key == $current_page) {
                        $data['paginate'] .= '<span class="tide_current">' . $key . '</span>';
                    } else {
                        $data['paginate'] .= '<a  href="' . $value . '"> ' . $key . ' </a>';
                    }
                }

                if (end($new_array) !== $new_array[$i]) {
                    $data['paginate'] .= '...';
                }
            }
        }

        if ($current_page == 1) {
            $data['prev'] = '<span class="tide_inactive tide_prew_page"> Previous </span>&nbsp;';
        } else {
            $data['prev'] = '<a class="tide_prew_page"  href="' . $pages_array[$current_page - 1] . '"> Previous </a>&nbsp;';
        }

        if ($current_page == $last) {
            $data['next'] = '<span class="tide_inactive tide_prew_page"> Next </span>&nbsp;';
        } else {
            $data['next'] = '<a class="tide_prew_page"  href="' . $pages_array[$current_page + 1] . '"> Next </a>&nbsp;';
        }
        return $data;
    }

    /**
     * construct_dropdown() - Select list construct
     * @param string $s_name
     * @param string $s_class
     * @param array $data
     * @param string $selected
     * @param string $extra
     * @param bool|string $keys
     * @return string 
     */
    function construct_dropdown($s_name, $s_class, $data, $selected = false, $extra = '', $keys = false) {

        $select = '<select class="' . $s_class . '" id="' . $s_name . '" name="' . $s_name . '" ' . $extra . '>';

        foreach ($data as $key => $value) {
            if (!$keys) {
                if ($selected && $selected == $value) {
                    $select .= '<option selected="" value="' . $value . '">' . $value . '</option>';
                } else {
                    $select .= '<option value="' . $value . '">' . $value . '</option>';
                }
            } else {

                if ($selected && $selected == $key) {
                    $select .= '<option selected="" value="' . $key . '">' . $value . '</option>';
                } else {
                    $select .= '<option value="' . $key . '">' . $value . '</option>';
                }
            }
        }
        $select .= '</select>';

        return $select;
    }

#################################################################################
############################ DATE TIME FUNCTIONS #################################

    /**
     * tide_time_format()
     * 
     * @global array $general_settings
     * @return string 
     */
    function tide_time_format() {
        global $general_settings;
        $time_array_search = array("%H", "%k", "%I", "%l", "%p", "%M", "%S", "%Z", "%z", "%R", "%T", "%r");
        $time_array_replace = array("h", "hh", "h", "hh", "TT", "mm", "ss", "", "", "hh:mm", "hh:mm:ss", "hh:mm:ss TT");

        $new_format = str_replace($time_array_search, $time_array_replace, $general_settings['time_format']);
        return strtolower($new_format);
    }

    /**
     * tide_date_format()
     * 
     * @global array $general_settings
     * @return string 
     */
    function tide_date_format() {
        global $general_settings;

        $date_array_search = array("%Y", "%y", "%B", "%b", "%m", "%A", "%a", "%d", "%e", "%D", "%v", "%F");
        $date_array_replace = array("yy", "y", "MM", "M", "mm", "DD", "D", "dd", "d", "mm/dd/y", "dd-MM-yy", "yy-MM-dd");

        $new_format = str_replace($date_array_search, $date_array_replace, $general_settings['date_format']);
        return $new_format;
    }

    /**
     * date_convert() - Format Date/ Time Based on Language Settings
     * 
     * @global array $general_settings
     * @param string $syntax
     * @return string 
     */
    function date_convert($syntax) {
        global $general_settings;

        $old_locale = setlocale(LC_CTYPE, 0);
        setlocale(LC_TIME, $general_settings['language']);
        $date = strftime($syntax);
        setlocale(LC_TIME, $old_locale);

        return $date;
    }

    /**
     * date_format_convert()
     * 
     * @param string $date_format
     * @param string $direction
     * @return string 
     */
    function date_format_convert($date_format, $direction = false) {

        $caracs = array(
            // Day - no strf eq : S
            'd' => '%d', 'D' => '%a', 'j' => '%e', 'l' => '%A', 'N' => '%u', 'w' => '%w', 'z' => '%j',
            // Week - no date eq : %U, %W
            'W' => '%V',
            // Month - no strf eq : n, t
            'F' => '%B', 'm' => '%m', 'M' => '%b',
            // Year - no strf eq : L; no date eq : %C, %g
            'o' => '%G', 'Y' => '%Y', 'y' => '%y',
            // Time - no strf eq : B, G, u; no date eq : %r, %R, %T, %X
            'a' => '%P', 'A' => '%p', 'g' => '%l', 'h' => '%I', 'H' => '%H', 'i' => '%M', 's' => '%S',
            // Timezone - no strf eq : e, I, P, Z
            'O' => '%z', 'T' => '%Z',
            // Full Date / Time - no strf eq : c, r; no date eq : %c, %D, %F, %x 
            'U' => '%s'
        );
        if ($direction) {
            $caracs = array_flip($caracs);
        }

        return strtr((string) $date_format, $caracs);
    }

    /**
     * date_reformat() - Format Archive Date based on Settings eg. Month-Year
     * @global array $general_settings
     * @param string $date
     * @return string 
     */
    function date_reformat($date) {
        global $general_settings;
        $reformat = date_format_convert($general_settings['date_format'], true);
        $patern = '/[^F M m Y y]/iu';
        $a_date = trim(preg_replace($patern, '', "'.$reformat.'"));
        $a_date = str_replace(' ', '-', $a_date);
        return date($a_date, strtotime($date));
    }

#################################################################################
############################# HEADER FUNCTIONS ##################################   

    /**
     * init_scripts()
     * 
     * @param string $script_path
     * @param string $type
     * @return string 
     */
    function init_scripts($script_path, $type) {

        $sc = array();
        if (!is_array($script_path)) {
            $sc[0] = $script_path;
        } else {
            $sc = $script_path;
        }

        $script = '';
        if ($type == 'css') {
            $pre = '<link href="';
            $post = '" rel="stylesheet">';
        } elseif ($type == 'js') {
            $pre = '<script type="text/javascript" src="';
            $post = '"></script>';
        }

        foreach ($sc as $key => $path) {
            $script .= $pre . $path . $post . "\n";
        }

        return $script;
    }

#################################################################################
############################# RSS FUNCTIONS ##################################  
    /**
     * rss_buider()
     * 
     * @param string $page
     * @return string 
     */

    function rss_buider($page) {

        if (PRETTY_URLS == '1') {
            $url = SITE_URL . 'rss/' . $page;
        } else {
            $url = SITE_URL . 'index.php?id=rss&amp;page=' . $page;
        }
        return $url;
    }

    /**
     * create_rss() - Create RSS Feed
     * 
     * @global array $rss_settings
     * @global array $general_settings
     * @param string $type
     * @param string $category_title
     * @param string $data_receve
     * @return string 
     */
    function create_rss($type = 'general', $data_receve = false, $category_title = false) {

        global $rss_settings;
        global $general_settings;

        if (!$data_receve) {
            if ($type == 'general') {
                $news_index = os_separator(NEWS_DIR . 'news/news_index.xml');
                $category = i18n_r('tide_news/RSS_CATEGORY_GENERAL');
            } else {
                $news_index = os_separator(NEWS_DIR . 'category/' . $type . '.xml');
            }

            $data_primary = xml_content_array($news_index, true);

            for ($i = 0; $i < $data_primary['nodes']; $i++) {
                $data_receve[$i] = $data_primary['data'][$i]['file'];
            }
        }


        $path = NEWS_RSS_DIR . $type . '.xml';
        $category_index = NEWS_DIR . 'category_index.xml';
        $categorys = xml_content_array($category_index, false);

        $cat = array();
        foreach ($categorys as $key => $val) {
            unset($val['@attributes']);
            $cat[$val['category_slug']] = $val;
        }

        $rss = '';

        $settings['feed_date'] = date("D, d M Y H:i:s T", time());


        $settings['feed_title'] = $rss_settings['feed_title'];
        $settings['feed_description'] = $rss_settings['feed_description'];
        $settings['feed_link'] = rss_buider($type);
        if (!empty($rss_settings['feed_image'])) {
            $settings['feed_image'] = SITE_URL . 'data/uploads/' . $rss_settings['feed_image'];
        }
        $settings['feed_lang'] = $rss_settings['feed_lang'];
        $settings['feed_ttl'] = '360';
        $settings['feed_date'] = date("D, d M Y H:i:s T", time());
        $settings['feed_generator'] = $rss_settings['feed_generator'];

        $rss .= load_template(TIDE_NEWS_TEMPLATES . 'backend/rss_start.tpl', false, $settings) . "\n";
       

        foreach ($data_receve as $key => $link) {
            $data_rss = xml_content_array($link, false);

            $data['title'] = $data_rss['title'];
            if (isset($cat[$data_rss['category']])) {
                $page = $cat[$data_rss['category']]['pages'];
            } else {
                $page = $general_settings['all_news_page'];
            }
            $data['news_link'] = url_builder($page, $data_rss['category'], $data_rss['slug'], 'tide_show_news');

            $data['category'] = $cat[$data_rss['category']]['category_title'];
            $data['summary'] = $data_rss['summary'];
            $data['date'] = $data_rss['date'] . ' ' . $data_rss['time'];
            $rss .= load_template(TIDE_NEWS_TEMPLATES . 'backend/rss_item.tpl', $data) . "\n";
        }

        $rss .= load_template(TIDE_NEWS_TEMPLATES . 'backend/rss_end.tpl');

        $result = file_put_contents($path, $rss);

        return $result;
    }

    #################################################################################   
    ############################# CKEDITOR FUNCTIONS ##################################    

    /**
     * init_editor() - Init CKEditor 
     * @global array $cfk_settings
     * @param string $instance
     * @param string $plugin
     * @param string $toolbar
     * @param string $skin
     * @param number $height
     * @return string 
     */
    function init_editor($instance, $plugin, $toolbar = false, $skin = false, $height = false) {
        global $cfk_settings;

        if (isset($_GET['id']) and $_GET['id'] == $plugin) {

            $language = $cfk_settings['cke_languages'];

            $code = '<script type="text/javascript">';
            if ($toolbar) {
                if ($toolbar == 'basic') {
                    $cke_toolbar = "['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source', 'syntaxhighlight', 'WPMore']";
                } else {
                    $cke_toolbar = "['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', 'Table', 'TextColor', 'BGColor', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source'],'/',  ['Styles','Format','Font','FontSize', 'syntaxhighlight', 'WPMore']";
                }
            } else {
                if ($cfk_settings['ckeditor_type'] == 'basic') {
                    $cke_toolbar = "['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source', 'syntaxhighlight', 'WPMore']";
                } else if ($cfk_settings['ckeditor_type'] == 'advanced') {
                    $cke_toolbar = "['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', 'Table', 'TextColor', 'BGColor', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source'],'/',  ['Styles','Format','Font','FontSize', 'syntaxhighlight', 'WPMore']";
                } else if ($cfk_settings['ckeditor_type'] == 'custom') {
                    $cke_toolbar = $cfk_settings['cke_data'];
                }
            }

            if ($height) {
                $cke_height = $height;
            } else {
                $cke_height = $cfk_settings['cke_height'];
            }

            if ($skin) {
                $cke_skin = $skin;
            } else {
                $cke_skin = $cfk_settings['ckeditor_skin'];
            }
            $code .= ' 
var editor = CKEDITOR.replace( "' . $instance . '", {
removePlugins : "maximize,resize",
skin : "' . $cke_skin . '",
forcePasteAsPlainText : true,
language : "' . $language . '",
defaultLanguage : "' . $language . '",
entities : false,
uiColor : "#FFFFFF",
height: "' . $cke_height . '",
baseHref : "' . SITE_URL . '",
toolbar :[' . $cke_toolbar . '],
tabSpaces:10,
filebrowserBrowseUrl : "filemanager/filebrowser.php?type=all",
filebrowserImageBrowseUrl : "filebrowser.php?type=images",
filebrowserWindowWidth : "730",
filebrowserWindowHeight : "500",
});';

            $code .= '</script>';
        }
        return $code;
    }

#################################################################################
