<?php
/**
 * English Language File for DY Simple Photo Gallery Plugin
**/

$i18n = array(
  // Common
  'DESCRIPTION'     => 'Converts given folder with photos into a photo gallery',
);
