<?php
/**
 * Russian Language File for DY Simple Photo Gallery Plugin
**/

$i18n = array(
  // Common
  'DESCRIPTION'     => 'Создаёт фотогалерию из заданной директории с фотографиями',
);
