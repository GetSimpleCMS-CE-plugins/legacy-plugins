<?php
/*
Plugin Name: DY Simple Photo Gallery
Version: 1.0
Description: Converts given folder with photos into a photo gallery
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

/*
 * Version history
 * 
 * 1.0 - 03/09/2015
 * - Initial version
 */

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY Simple Photo Gallery',                  # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  i18n_r($thisfile . '/DESCRIPTION'),   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content', 'dySimplePhotoGalleryShortcode');

function dySimplePhotoGalleryShortcode($content) {
  // (% dySimplePhotoGallery folder:my-photos template:default %)
  // (% photogallery folder:my-photos %)
  $pattern = '(\(%\s+(?:dySimplePhotoGallery|photogallery)\s+(.*?)\s+%\))';
  return preg_replace_callback($pattern, 'dySimplePhotoGalleryCallback', $content);
}

function dySimplePhotoGalleryCallback($matches) {
  if (isset($matches[1])) {
    $pattern = '/folder\s*[:=]+[\s"\']*([^\s"\']*)[\s"\']*/i';
    preg_match($pattern, $matches[1], $data);
    if (isset($data[1])) {
      $folder = $data[1];
    }
    if (!isset($folder)) return null;
    $pattern = '/template\s*[:=]+[\s"\']*([^\s"\']*)[\s"\']*/i';
    preg_match($pattern, $matches[1], $data);
    if (isset($data[1])) {
      $template = GSPLUGINPATH . 'DY_SimplePhotoGallery/templates/' . $data[1] . '.tpl';
    }
    if (!isset($template) || !is_readable($template)) {
      $template = GSPLUGINPATH . 'DY_SimplePhotoGallery/templates/default.tpl';
    }
    $files = dySimplePhotoGalleryScanFolder($folder);
    if (count($files) == 0) return null;
    $url = get_site_url(false) . 'data/uploads/' . $folder . '/';
    $thumb = get_site_url(false) . 'data/thumbs/' . $folder . '/thumbnail.';
    ob_start();
    include_once $template;
    $gallery = ob_get_contents();
    ob_end_clean();
    return $gallery;
  }
}

function dySimplePhotoGalleryScanFolder($folder, $type = array('gif', 'jpeg', 'jpg', 'png')) {
  $folder = GSDATAUPLOADPATH . $folder;
  $dh = @opendir($folder);
  $files = array();
  if ($dh) {
    $pattern = '/\.(?:'. implode($type, '|') .')$/i';
    while (($filename = readdir($dh)) !== false) {
      $files[] = $filename;
    }
    if (!empty($files)) {
      $files = preg_grep($pattern, $files);
    }
  }  
  return $files;
}

function dySimplePhotoGalleryThumbnail($folder, $file) {
  $folder .= '/';
  $thumb_path = GSTHUMBNAILPATH . $folder . 'thumbnail.' . $file;
  if (!is_file($thumb_path)) {
    include_once GSADMININCPATH . 'imagemanipulation.php';
    return genStdThumb($folder, $file);
  } else {
    return true;
  }
  
}

?>