<?php
/*
Plugin Name: DY File Include
Version: 1.0
Description: Includes text file into a page content
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY File Include',                  # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  'Includes text file into a page content',   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content', 'dyFileIncludeShortcode');

function dyFileIncludeShortcode($content) {
  // (% dyFileInclude filename:'data.txt' tag:'p' htmlspecialchars:'false' %)
  $pattern = '(\(%\s+dyFileInclude\s+(.*)\s+%\))';
  return preg_replace_callback($pattern, 'dyFileIncludeCallback', $content);
}

function dyFileIncludeCallback($matches) {
  $result = '';
  if (isset($matches[1])) {
    preg_match("/filename\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
    if (isset($tmp[2])) {
      $filename = GSDATAUPLOADPATH . DIRECTORY_SEPARATOR . $tmp[2];
      if (is_readable($filename)) {
        preg_match("/tag\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
        $tag = isset($tmp[2]) ? $tmp[2] : false;
        preg_match("/htmlspecialchars\\s*:\\s*([\"'])(.*?)\\1/", $matches[1], $tmp);
        $htmlspecialchars = (isset($tmp[2]) && $tmp[2] === 'true') ? true : false; 
        if ($tag && !$htmlspecialchars) {
          return str_replace("\n", "</$tag>\n<$tag>", '<' . $tag . '>' . file_get_contents($filename) . '</' . $tag . '>');
        } elseif ($tag && $htmlspecialchars) {
          return str_replace("\n", "</$tag>\n<$tag>", '<' . $tag . '>' . htmlspecialchars(file_get_contents($filename)) . '</' . $tag . '>');
        } elseif (!$tag && $htmlspecialchars) {
          return htmlspecialchars(file_get_contents($filename));          
        } else {
          return file_get_contents($filename);
        }
      }              
    }
  }
}

?>