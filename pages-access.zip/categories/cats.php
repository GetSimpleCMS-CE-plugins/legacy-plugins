<?php $cats = array("page404"=>array('admin'),"index"=>array('admin')); ?>
