<?php $admin = array();$page404 = array();$groups = array("admin"=>$admin,"page404"=>$page404); ?>
