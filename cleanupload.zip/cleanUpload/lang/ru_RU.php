<?php

/**
 * Русский языковой файл для cleanUpload плагина
 *
 * Created by PhpStorm.
 * Разработчик: BATPYIIIKOB
 * Дата: 04.05.2015
 * Время: 20:09
 *
 * @package GetSimple
 * @subpackage Language
 */

$i18n = array (

    "CLEAN_TITLE"       =>  "Очистка каталога Upload",
    "FILES_NOT_USE"     =>  "Количество не используемых файлов: ",
    "FILES_DELETED"     =>  "Удалённые файлы:",
    "FILES_NOT_CLEAN"	=>	"Нет файлов для очистки",
    "DELETED"	        =>	"удален",
    "DESCRIPTION"		=>	"Данный плагин ищет файлы в <b>Upload</b>, которые не используются в контенте сайта или фотоальбомах <b>I18N Gallery</b>",
    "RECOMENDATION_CLEAN"	=>	"Перед удалением рекомендую сделать полную копию данных сайта <b>Бекап - Архив сайта</b>",
    "BTN_FIND"	        =>	"Поиск",
    "BTN_DEL"		    =>	"Удалить",
    "COMMON_DEL_FILES"  =>  "Общий объём неиспользуемых/удаляемых файлов"
);

?>