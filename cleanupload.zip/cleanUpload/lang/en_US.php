<?php

/**
 * English Language File for cleanUpload Plugin
 *
 * Created by PhpStorm.
 * User: BATPYIIIKOB
 * Date: 04.05.2015
 * Time: 20:09
 *
 * @package GetSimple
 * @subpackage Language
 */

$i18n = array (

    "CLEAN_TITLE"       =>  "CleanUpload",
    "FILES_NOT_USE"     =>  "The number of unused files: ",
    "FILES_DELETED"     =>  "Deleted files:",
    "FILES_NOT_CLEAN"	=>	"No files to clean",
    "DELETED"	        =>	"deleted",
    "DESCRIPTION"		=>	"This plug-in looks for files in <b>Upload</b>, that not used in the website content or photo albums <b>I18N Gallery</b>",
    "RECOMENDATION_CLEAN"	=>	"Before removing I recommend making a full copy of the site data <b>Backup -> Archive site</b>",
    "BTN_FIND"	        =>	"Search",
    "BTN_DEL"		    =>	"Delete",
    "COMMON_DEL_FILES"  =>  "Total unused/deleted files"
);

?>