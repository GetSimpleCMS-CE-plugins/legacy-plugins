<?php
header("Content-type:text/html; charset='utf-8'");

/*
Plugin Name: cleanUpload
Description: Удаляет неиспользуемые в контенте файлы из upload
Version: 2.0
Author: BATPYIIIKOB
Author URI: http://get-simple.info/forums/showthread.php?tid=7262
*/

# получение корректного идентификатора плагина
$thisfile = basename(__FILE__, ".php");

# add in this plugin's language file
i18n_merge($thisfile) || i18n_merge($thisfile, 'en_US');

# регистрируем плагин в системе
register_plugin(
    $thisfile, //идентификатор плагина
    i18n_r($thisfile.'/CLEAN_TITLE'), //Название плагина
    '2.0', 		//Версия плагина
    'BATPYIIIKOB',  //автор плагина
    'http://get-simple.info/forums/showthread.php?tid=7262', //сайт автора
    'Удаляет неиспользуемые в контенте файлы из upload', //краткое описание плагина
    'files', //тип страницы – на какой из вкладок административной панели появится плагин
    'clean_upload'  //главная функция плагина (функция администрирования)
);

# activate filter/активируем фильтр
add_action('files-content','clean_upload');

# Добавляем ссылку на вкладку Темы
add_action('files-sidebar','createSideMenu',array($thisfile,i18n_r("cleanUpload/CLEAN_TITLE")));


##############################################################################################################################################


# Преобразование размеров файла в удобочитаемый вид
function human_filesize($bytes, $decimals = 2) {
  $sz = 'BKMGTP';
  $factor = floor((strlen($bytes) - 1) / 3);
  return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$sz[$factor];
}

# Вывод результата на экран
function PrePrintArray($arr){
	$sum_size = 0;

    echo '<br><b>'.i18n_r("cleanUpload/FILES_NOT_USE").count($arr).'</b><br><br>';

	echo '<table>';

    foreach ($arr as &$filename) {

		echo "<tr><td>$filename</td>";
		echo "<td>".human_filesize(filesize("../".$filename));		
		echo "</td></tr>";
		$sum_size = filesize("../".$filename)+$sum_size;
	}

    echo '<tr style="background-color:#86C6EC;color:#336699;"><td><b>';
    echo i18n("cleanUpload/COMMON_DEL_FILES");
    echo '</b></td><td><b>' . human_filesize($sum_size) . '</b></td></tr></table>';
}


# Удалить найденные файлы
function deleteResult($arr){
    $sum_size = 0;
    //echo '<br><b>'."Удалённых файлов: ".count($arr).'</b><br><br>';
    echo '<table>';

    foreach ($arr as &$filename) {
        unlink("../".$filename);
        echo "<tr><td><i>$filename</i></td>";
        echo "<td><i>".i18n_r("cleanUpload/DELETED")."</i></td>";
        echo "</tr>";
    }

    echo '<tr style="background-color:#86C6EC;color:#336699;"><td><b>';
    echo i18n("cleanUpload/COMMON_DEL_FILES");
    echo '</b></td></tr></table>';
}

##############################################################################################################################################


# Выборка файлов XML в массив из каталога DATA_PATH возврат массива с краткими именами файлов
function GetXMLFiles($path)
{
    $result = array();
    
    if ($handle = opendir($path)) {

        while (false !== ($entry = readdir($handle))) {
            if (substr(strrchr($entry, "."), 1) === 'xml') {                
                $result[] = $entry;                
            }
        }
        closedir($handle);
    }
    return $result;
}


function ListFilesDirectory($dirname){

    static $result = array();   
    
    $handle = opendir($dirname);

    while (($file = readdir($handle)) !== false)
    {
        if($file != "." && $file != "..")
        {
            if(is_file($dirname."/".$file))
            {
               if($file != '.htaccess' && $file != 'index.html' && $file != 'index.htm' && $file != 'index.php'){
					$result[] = trim (substr($dirname, 3)."/".$file," \t\n\r\0\x0B");                    
                }                
            }
			
            # Если директория
            if(is_dir($dirname."/".$file))
            {
                ListFilesDirectory($dirname."/".$file);
            }
        }
    }

    closedir($handle);
    return $result;
}


function ContentFromGalleryFiles($pagexml,$DATA_GALLERY_PATH){

    foreach($pagexml as &$value) {
        
        if (file_exists($DATA_GALLERY_PATH.$value)){
            
            $xml = simplexml_load_file($DATA_GALLERY_PATH.$value);
            
            for ($i = 0; $i <= count($xml->item)-1; $i++) {                
                $result[] = 'data/uploads/'.(string)$xml->item[$i]->filename;                
            }
        }
    }
    return $result;
}



function DataFromFiles($listArray,$DATA_PAGES_PATH) {
    
    foreach ($listArray as &$value) {
        if (file_exists($DATA_PAGES_PATH.$value)) {           
            $result[$value] = (string) file_get_contents($DATA_PAGES_PATH.$value);            
        }
    }

    return $result;   
}


# Поиск заданной строки в массиве с параметрами начала и окончания строки.
# Возврат массива, список строк соответствующих условию поиска
function ListHTTPArrayDataContent($allData,$str_begin){
    
    foreach ($allData as $key => &$value) {
        $position = 0;
        while (strpos($allData[$key], $str_begin, $position)) {        
            if ($currposition = strpos($allData[$key], $str_begin, $position)) {
                
                $position = $currposition;

                while (($allData[$key][$position] != '&') && ($allData[$key][$position] != ']') && ($allData[$key][$position] != '<') && ($allData[$key][$position] != '>')){                    
                    $position++; 
                }
            
                $result[] = trim(substr($allData[$key], $currposition, $position-$currposition), " \t\n\r\0\x0B");
            }      
        }    
    }
    return (array_unique($result,SORT_STRING));
}


##############################################################################################################################################


# Теперь – функции плагина
function clean_upload() {


	# Костанты
	# Path constants
	$DATA_PATH = '../data/';
	$DATA_GALLERY_PATH = $DATA_PATH.'i18n_gallery/';
	$DATA_UPLOAD_PATH  = $DATA_PATH.'uploads';
	$DATA_PAGES_PATH   = $DATA_PATH.'pages/';
	$str_begin = 'data/uploads';

    i18n("cleanUpload/DESCRIPTION");

    echo "<br><br>";
	echo "<form method='POST'>";
    echo "<input type='submit' class='submit' name='find-files' value=".i18n_r("cleanUpload/BTN_FIND").">";
    echo "<hr>";


    if (isset($_POST['find-files']) or isset($_POST['delete-result'])) {
		
		$pagesName        = GetXMLFiles($DATA_PAGES_PATH);                 // имена всех страниц
		$fotoGalleryName  = GetXMLFiles($DATA_GALLERY_PATH);               // имена всех фотогаллерей
		$allUploadFiles   = ListFilesDirectory($DATA_UPLOAD_PATH);         // имена всех файлов в Upload
		$allData          = DataFromFiles($pagesName,$DATA_PAGES_PATH);    // выгрузка всего содержимого из $pagesName
		$allNameUsedFiles = ListHTTPArrayDataContent($allData,$str_begin); // анализ содержимого и выгрузка имён всех используемых файлов

		$allNameUsedFilesGallery   = ContentFromGalleryFiles($fotoGalleryName,$DATA_GALLERY_PATH);

		# из всех ссылок на файлы в Upload удаляем ссылки которые используются в контенте и галлереи
		$diffArray = array_diff($allUploadFiles,$allNameUsedFiles,$allNameUsedFilesGallery);

        # если нажали кнопку "Удалить всё"
        if (isset($_POST['delete-result'])){
            deleteResult($diffArray);
        }else{
            if (!empty($diffArray)) {
                PrePrintArray($diffArray);
                echo "<br><hr>";
                i18n("cleanUpload/RECOMENDATION_CLEAN");
                echo "<br><br>";
                echo "<input type='submit' class='submit' name='delete-result' value=".i18n_r("cleanUpload/BTN_DEL").">";
            }else{
                i18n("cleanUpload/FILES_NOT_CLEAN");
            }
        }
    }

    echo "</form>";
}

?>