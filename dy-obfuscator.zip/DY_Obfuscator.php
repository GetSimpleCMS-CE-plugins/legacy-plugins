<?php
/*
Plugin Name: DY Obfuscator
Description: Converts given string into obfuscated and hardly readable form
Version: 1.0
Author: Dima Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY Obfuscator',                    # Title of plugin
  '1.0',                              # Version of plugin
  'Dima Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  'Converts given string into obfuscated and hardly readable form',   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content','dyObfuscateShortcode');

function dyObfuscateShortcode($content) {
  // (% dyObfuscate : my-email@my-mail.ru %)
  $pattern = '(\(%\s+dyObfuscate\s*:\s*(.*)\s+%\))';
  return preg_replace_callback($pattern, 'dyObfuscateCallback', $content);
}

function dyObfuscateCallback($matches) {
  return isset($matches[1]) ? dyObfuscate($matches[1]) : null;
}

function dyObfuscate($string, $echo = false) {
  $obfuscated = '';
  foreach(str_split($string) as $letter) {
    switch(rand(1, 3)) {
      case 1:
        $obfuscated .= $letter;
        break;
      case 2:
        $obfuscated .= '&#' . ord($letter) . ';';
        break;
      case 3:
        $obfuscated .= '&#x' . dechex(ord($letter)) . ';';
        break;
    }
  }
  if ($echo) {
    echo $obfuscated;
  } else {
    return $obfuscated;
  }
}

?>