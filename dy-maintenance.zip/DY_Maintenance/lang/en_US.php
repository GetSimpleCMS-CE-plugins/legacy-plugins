<?php
/**
 * English Language File for DY Maintenance
**/

$i18n = array(
    'DESCRIPTION' => "Website maintenance mode",
    'NOTIFICATION_MESSAGE' => "<strong>Attention!</strong> The website is in maintenance mode and is not available for visitors",
    'MAINTENANCE_SWITCH_LABEL' => "The website is on maintenance",
    'MAINTENANCE_TEXT_LABEL' => "Message to visitors"
);