<?php

$numMaps=0;

function addGroupDocsSignature($atts, $content = null) {
 extract(gdsig_shortcode_atts(array(
    "id" => null,
    "width" => '500',
    "height" => '600'    
  ), $atts));
  return '<div><iframe src="https://apps.groupdocs.com/signature/forms/SignEmbed/'.$id.'?quality=50&use_pdf=False&download=False&referer=getsimple/1.0" frameborder="0" width="'.$width.'" height="'.$height.'"></iframe></div>';
}
gdsig_add_shortcode('GroupDocsSignature','addGroupDocsSignature', '[groupdocs id="" width="" height="" /]');
