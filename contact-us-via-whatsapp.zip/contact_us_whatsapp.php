<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } 
$thisfile = basename(__FILE__, '.php');
$file_wp_c_data_file = GSDATAOTHERPATH . 'whatsapp-settings.xml';
$site_url = $SITEURL;
$plugin_folder = basename(GSPLUGINPATH);
$plugin_url = $site_url.$plugin_folder; 

# register this plugin
register_plugin(
	$thisfile, 
	'Contact us via whatsapp', 	
	'0.1', 		
	'Jorge Miguel',
	'https://api.whatsapp.com/send?phone=5511981087234&text=Hi!', 
	'Contact button via whatsapp on your site',
	'settings',
    'file_wp_c_admin_process'
); 
add_action ('settings-sidebar', 'createSideMenu', array($thisfile, 'Contact us via whatsapp')); 
 
function insert_whatsapp_config() { 
	$file = GSDATAOTHERPATH . 'whatsapp-settings.xml';  
	if (file_exists($file)) {
		$s = getXML($file);   
		
		$phone_number = false;
		$btn_text = false;
		$default_text = false;
	
		$phone_number = $s->phone_number;
		$btn_text = $s->btn_text;
		$default_text = $s->default_text;   
	
		echo '<div class="fixed-tabs-Whats"><div class="aba-whatsphone"><div class="aba-whatsphone-icone"><a target="_blank" href="https://api.whatsapp.com/send?phone=' . $phone_number . '&text=' . $default_text . '"><p>' . $btn_text . '</p></a></div></div></div>';
		echo "\n";
		echo '<style>.fixed-tabs-Whats{position:fixed;right:0;top:50%;margin-top:-170px;z-index:100}.aba-whatsphone{background:#1EBEA5;height:60px;width:70px;border-radius:30px 0 0 30px;transition:.7s ease}.aba-whatsphone:hover{width:280px;transition:.7s ease}.aba-whatsphone-icone{background:url(https://i.imgur.com/4PY1VfJ.png) no-repeat;width:280px;background-size:70px;background-position-y:-7px;padding:7px}.aba-whatsphone-icone a{color:#fff;font-size:14px;line-height:20px;margin-left:70px;text-decoration:none;height:60px;font-family:sans-serif}.aba-whatsphone-icone a p{display:block;font-size:16px;margin-left:70px}</style>';		
		return true;
	} else {
		return false;
	}  
}
add_action ('theme-footer', 'insert_whatsapp_config');

  	
function wp_c_theme_form_process () { 
  global $file_whatsapp_settings;
  }
function file_wp_c_admin_process() {
    
    global $file_wp_c_data_file;
    if(isset($_POST['submit'])) {
        
		$file_wp_c_submitted_data['phone_number'] = $_POST['phone_number']; 
		$file_wp_c_submitted_data['btn_text'] = $_POST['btn_text'];
		$file_wp_c_submitted_data['default_text'] = $_POST['default_text'];    
        $result = file_wp_c_save_settings($file_wp_c_submitted_data);
        
    }
    
	$file_whatsapp_settings = file_wp_c_read_settings();
    echo '<h3>Contact us via whatsapp</h3>';
    
    if(isset($result)) {
        if($result == true) { 
            echo '<p class="updated" style="width: 100%; background: #DFF8D9; border: none; padding: 10px; color: #777">Settings saved.</p>';
			 
			echo "<meta http-equiv='refresh' content='6.75;url=". $_SERVER ['REQUEST_URI']. "'>";
        } elseif($result == false) { 
            echo '<p class="error">Error saving data. Check permissions.</p>';
        }
    }
 

?> 
    <form method="post" id="modern-admin" class="modern_admin2" action="<?php echo $_SERVER ['REQUEST_URI']; ?>" ononSubmit="window.location.reload()" value="refresh">
    
       <hr />
       <br /> 
       <br /> 
       <h3>Basic Settings</h3>
       <p> 
        <label><b>Your phone number</b></label><br />
        <input id="phone_number" name="phone_number" class="text" value="<?php echo $file_whatsapp_settings['phone_number']; ?>" style="width: 220px;" />
		<br><span>Only numbers - Ex: 5511981087234</span>
       </p>
       <p> 
        <label><b>Button text</b></label><br />
        <input id="btn_text" name="btn_text" class="text" value="<?php echo $file_whatsapp_settings['btn_text']; ?>" style="width: 220px;" />
		<br><span>Ex: Contact us via whatsapp</span>
       </p>
       <p> 
        <label><b>Default message when sending message</b></label><br />
        <input id="default_text" name="default_text" class="text" value="<?php echo $file_whatsapp_settings['default_text']; ?>" style="width: 220px;" />
       </p> 
       <br />        
       <div style="clear:both; height: 10px"></div>
        <p>
      
         <input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" />
        </p>
    </form>
    
      
<?php
} 
function file_wp_c_read_settings() {
    
    global $file_wp_c_data_file;
    
    if(file_exists($file_wp_c_data_file)) {
        
        $data = getXML($file_wp_c_data_file);
		$file_whatsapp_settings['phone_number'] = $data->phone_number;
		$file_whatsapp_settings['btn_text'] = $data->btn_text; 
		$file_whatsapp_settings['default_text'] = $data->default_text; 
		
    } else {
         
		$file_whatsapp_settings['default_text'] = null;  
		
        file_wp_c_save_settings($file_whatsapp_settings);
        
    }
    
    
    
    $file_whatsapp_settings['site_root'] = '/';
    
    return $file_whatsapp_settings;
    
}


function file_wp_c_save_settings($settings) {
    
    global $file_wp_c_data_file;
    
    $xml = @new simpleXMLElement('<whatsapp_settings></whatsapp_settings>');
	
    $xml->addChild('phone_number', $settings['phone_number']);
	$xml->addChild('btn_text', $settings['btn_text']);
	$xml->addChild('default_text', $settings['default_text']); 
	
    return $xml->asXML($file_wp_c_data_file);
    
} 
?>