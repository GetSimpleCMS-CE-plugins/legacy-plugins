<?php

$i18n = array (
	
    'TITLE'=>'Настройки меню языка',
    'LANG_CODE'=>'Код языка',
    'LANG_TEXT'=>'Имя языка',
	'LANG_SORT'=>'Вес',
	'LANG_NOT_SETTINGS'=>'Не найден файл параметров плагина i18n меню языков (XML)!',
	'LANG_DEFAULT'=>' Активированы настройки по умолчанию.',
    'LI_CLASS_LABEL'=>'Класс &lt;li&gt; для активного языка',
    'MENU_TEXT'=>'Редактировать меню языка',
	'LANG_OUTPUT'=>'Место расположения иконы',
	'LANG_OUTPUT_EMPTY'=>'Текстовая ссылка',
	'LANG_OUTPUT_A'=>'Вместо ссылок',
	'LANG_OUTPUT_B'=>'Перед ссылкой',
	'LANG_OUTPUT_C'=>'После ссылки',
	'LANG_IMG_SIZE'=>'Размер изображения (px)',
	'LANG_POZ_DESC'=>'Позиционирование меню',
	'LANG_POZ_VERT'=>'Вертикальное',
	'LANG_POZ_HORZ'=>'Горизонтальное',
	'LANG_POZ_DROP'=>'Выпадающий (Bootstrap)',
	'LANG_POZ_NONE'=>'Без',
	'LANG_ICONS_DESC'=>'Стиль иконок',
	'LANG_ICO_2D'=>'Стандартный',
	'LANG_ICO_3D'=>'Трехмерный',
	'LANG_HIDE_CURR_DESC'=>'Отображение текущего (активного) меню пункта в раскрывающемся меню',
	'LANG_SHOW_CURR'=>'Показывать элемент',
	'LANG_HIDE_CURR'=>'Скрыть элемент',
);



?>