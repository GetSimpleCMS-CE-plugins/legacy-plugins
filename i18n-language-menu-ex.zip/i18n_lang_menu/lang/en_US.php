<?php

$i18n = array (
	
    'TITLE'=>'Language menu management',
    'LANG_CODE'=>'Language code',
    'LANG_TEXT'=>'Language caption',
	'LANG_SORT'=>'Weight',
	'LANG_NOT_SETTINGS'=>'i18n language menu setup data file not found (XML)!',
	'LANG_DEFAULT'=>' Default settings activated.',
    'LI_CLASS_LABEL'=>'Current language&#39;s &lt;li&gt; class',
    'MENU_TEXT'=>'Edit language menu',
	'LANG_OUTPUT'=>'Icon placement',
	'LANG_OUTPUT_EMPTY'=>'Text link only',
    'LANG_OUTPUT_A'=>'Replace link',
	'LANG_OUTPUT_B'=>'Before link',
	'LANG_OUTPUT_C'=>'After link',
	'LANG_IMG_SIZE'=>'Image size (px)',
	'LANG_POZ_DESC'=>'Menu positioning',
	'LANG_POZ_VERT'=>'Vertical',
	'LANG_POZ_HORZ'=>'Horizontal',
	'LANG_POZ_DROP'=>'Dropdown (Bootstrap)',
	'LANG_POZ_NONE'=>'None',
	'LANG_ICONS_DESC'=>'Icon style',
	'LANG_ICO_2D'=>'Standard',
	'LANG_ICO_3D'=>'3-dimensional',
	'LANG_HIDE_CURR_DESC'=>'Current menu item display on the dropdown menu bar',
	'LANG_SHOW_CURR'=>'Show item',
	'LANG_HIDE_CURR'=>'Hide item',
);



?>