<?php

$i18n = array (
	
    'TITLE'=>'Kalbos meniu valdymas',
    'LANG_CODE'=>'Kalbos kodas',
    'LANG_TEXT'=>'Kalbos pavadinimas',
	'LANG_SORT'=>'Svoris',
	'LANG_NOT_SETTINGS'=>'i18n kalbos menių nustatymų duomenų failas nerastas (XML)!',
	'LANG_DEFAULT'=>' Aktyvuoti parametrai pagal nutylėjimą.',
    'LI_CLASS_LABEL'=>'Dabartines kalbos &lt;li&gt; klasė',
    'MENU_TEXT'=>'Redaguoti kalbos meniu',
	'LANG_OUTPUT'=>'Piktogramos vieta',
	'LANG_OUTPUT_EMPTY'=>'Tekstinę nuoroda',
	'LANG_OUTPUT_A'=>'Vietoje nuorodos',
	'LANG_OUTPUT_B'=>'Prieš nuorodą',
	'LANG_OUTPUT_C'=>'Po nuorodos',
	'LANG_IMG_SIZE'=>'Vaizdo dydis (px)',
	'LANG_POZ_DESC'=>'Menių pozicionavimas',
	'LANG_POZ_VERT'=>'Vertikalus',
	'LANG_POZ_HORZ'=>'Horizantalus',
	'LANG_POZ_DROP'=>'Išskleidžiamasis (Bootstrap)',
	'LANG_POZ_NONE'=>'Joks',
	'LANG_ICONS_DESC'=>'Piktogramų stilius',
	'LANG_ICO_2D'=>'Standartinis',
	'LANG_ICO_3D'=>'Trimatis',
	'LANG_HIDE_CURR_DESC'=>'Esamo (aktyvaus) menių elemento atvaizdavimas išskleidžiamajame menių',
	'LANG_SHOW_CURR'=>'Rodyti elementą',
	'LANG_HIDE_CURR'=>'Slėpti elementą',
);



?>