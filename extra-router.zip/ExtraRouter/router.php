<?php
function extra_router_route(){
	global $SITEURL;
	
	$settings = extra_router_get_settings(true);
	
	//part from ToroPHP
	$pathInfo = '/';
    $pathInfo = (strpos($_SERVER['REQUEST_URI'], '?') > 0) ? substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?')) : $_SERVER['REQUEST_URI'];
    
    $pathInfo = lowercase($pathInfo); //set lowercase
    
    
	//find site subdir from url 
	$subDir = rtrim( parse_url($SITEURL, PHP_URL_PATH), '/' );
	if (substr($pathInfo, 0, strlen($subDir)) == $subDir) {
		$pathInfo = substr($pathInfo, strlen($subDir));
	} 
	

	$matchedPatternIndex = null;
	
	//search by string
	for ($i = 0; $i < count($settings['patterns']); $i++) {
		if ($settings['patterns'][$i] == $pathInfo){
			$matchedPatternIndex = $i;
			break;
		}
	}
	
	if ($matchedPatternIndex === null){ //try to search by regex
		for ($i = 0; $i < count($settings['patterns']); $i++) {
			if (preg_match('#' . $settings['patterns'][$i] . '#', $pathInfo)) {
				$matchedPatternIndex = $i;
				break;
			}
		}
	}
	
	global $PATHARRAY;
	$PATHARRAY = $pathInfo == '/' ? array() : explode('/', trim($pathInfo, '/')); //remove begining and trailing /
    
    // var_dump($PATHARRAY);
    // die();
    
    
	if ($matchedPatternIndex === null)
		return '404';
	
    // die(var_dump($matchedPatternIndex));
	//include file
	return require(GSDATAOTHERPATH . 'ExtraRouter/pattern-'.$matchedPatternIndex.'.php');
    
}