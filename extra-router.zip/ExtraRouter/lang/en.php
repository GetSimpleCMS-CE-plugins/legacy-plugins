<?php
$i18n = array(
    'CONF_SIDEBAR' => 'Configure Extra Router',
    'CONF_HINT' => 'This plugins creates global <pre>$PATHARRAY</pre> variable that contains parts of path from url.<br/><br/>
	<b>Recommended .htaccess file content:</b><br/>
	<pre>
 RewriteEngine on

 RewriteCond %{REQUEST_FILENAME} !-f
 RewriteCond %{REQUEST_FILENAME} !-d
 RewriteRule ^(.*)$ index.php?/$1 [QSA,L]</pre>	
	',
    'CONF_SETTINGS' => 'settings',
    'CONF_ADD' => '+ ADD PATTERN',
    'CONF_DELETE' => 'Delete',
    'CONF_SAVE' => 'Save changes',
    'CONF_PATTERN' => 'Pattern to match (regular expressions supported). "<pre>/</pre>" is your page root. Path tested is in lowercase.',
    'CONF_PHP' => 'PHP code that should return <pre>id</pre> (slug) of page to load, this code is executed by <pre>indexid</pre> GS filter.',
    'CONF_SUCCESS' => 'Settings saved.'
);