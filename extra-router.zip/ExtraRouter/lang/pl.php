<?php
$i18n = array(
    'CONF_SIDEBAR' => 'Konfiguracja Extra Router',
    'CONF_HINT' => 'Ta wtyczka tworzy zmienną globalną <pre>$PATHARRAY</pre> która zawiera części ścieżki z adresu url.<br/><br/>
	<b>Zalecana zawartość głownego pliku .htaccess strony:</b><br/>
	<pre>
 RewriteEngine on

 RewriteCond %{REQUEST_FILENAME} !-f
 RewriteCond %{REQUEST_FILENAME} !-d
 RewriteRule ^(.*)$ index.php?/$1 [QSA,L]</pre>	
	',
    'CONF_SETTINGS' => 'konfiguracja',
    'CONF_ADD' => '+ DODAJ REGUŁĘ',
    'CONF_DELETE' => 'Usuń',
    'CONF_SAVE' => 'Zapisz zmiany',
    'CONF_PATTERN' => 'Wzorzec (może być wyrażeniem regularnym). Wzorzec: "<pre>/</pre>" odpowiada stronie startowej. Ścieżka testowana ma małe litery.',
    'CONF_PHP' => 'Kod PHP który powinien zwracać <pre>id</pre> strony do załadowania, ten kod jest wykonywany przez filtr <pre>indexid</pre>.',
    'CONF_SUCCESS' => 'Zmiany zostały zapisane.'
);