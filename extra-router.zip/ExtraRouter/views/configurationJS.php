$( document ).ready(function() {

	
    var $maincontent = $('#maincontent'),
		$configForm = $maincontent.find('#configForm'),
		$patternsInput = $configForm.find('input[name="patterns"]'),
		$codesInput = $configForm.find('input[name="codes"]');
		
	//prepare fields on start
	if ($patternsInput.val()){
		var patterns = $patternsInput.val().split('||||'),
			codes = $codesInput.val().split('||||');
			
		for (i = 0; i < patterns.length; i++) { 
			$configForm.find('.patterns').append(patternRow(patterns[i], codes[i]));
		}

	}
		
	
	//delete click handler
	$configForm.on('click', 'button.delete', function(event){
		$(this).closest('.row').remove();
	});	
	
	//add
	$configForm.on('click', 'button.add', function(event){
		$configForm.find('.patterns').append(patternRow());
	});
	
	//on submit
	$configForm.submit(function(event){
		var patterns = [],
			codes = [];
			
		$('.CodeMirror').each(function(i, el){ //update all textareas from codemirror
			el.CodeMirror.save();
		});

		$configForm.find('.patterns .row').each(function(){
			var $row = $(this);
			
			var pattern = $row.find('input[type="text"]').val().trim(),
				code = $row.find('textarea').val(); //do not trim php code

			
			if (!pattern)
				return; //continue loop
			
			
			patterns.push(pattern);
			codes.push(code);
		});
                
		$patternsInput.val(patterns.join('||||'));
		$codesInput.val(codes.join('||||'));
	});
	
	
	function patternRow(pattern, php){
		var $row = $('<div class="row"><label>' + '<?php i18n('ExtraRouter/CONF_PATTERN')?>' + '</label><div class="table"><div class="cell"><input type="text" /></div><div class="cell"><button class="delete" type="button" title="' + '<?php i18n('ExtraRouter/CONF_DELETE')?>' + '">&times;</button></div></div><label>' + '<?php i18n('ExtraRouter/CONF_PHP')?>' + '</label><textarea></textarea></div>');
		
		if (pattern)
			$row.find('input').val(pattern);
		
		var $textarea = $row.find('textarea');
		
		$textarea.val(php ? php : <?php echo "'<?php'"; ?>);
		
		setTimeout(function(){
			CodeMirror.fromTextArea($textarea.get(0), {
				// indentUnit: 4,
				// indentWithTabs: true,
				mode: "text/x-php"
			}
			);
		},0);
			
		return $row;
	}

});