<?php
/*
Plugin Name: Extra Router
Description: This plugin adds some more control for routing requrested url address into specific page. It checks url across defined patterns and executes PHP code where you can create custom logic and indicate page ID to load.
Version: 1.01
Author: Michał Gańko
Author URI: http://flexphperia.net
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 
	'Extra Router', 	
	'1.01', 		
	'Michał Gańko',
	'http://flexphperia.net', 
	'This plugin adds some more control for routing requrested url address into specific page. It checks url across defined patterns and executes PHP code where you can create custom logic and indicate page ID to load',
	'plugins',
	'extra_router_admin_tab'  
);

if (!is_frontend()) { //only on backend
	i18n_merge($thisfile, substr($LANG,0,2)) || i18n_merge($thisfile,'en');

	add_action('header','extra_router_on_header'); 
    add_action('plugins-sidebar', 'createSideMenu', array($thisfile, i18n_r('ExtraRouter/CONF_SIDEBAR')));
}
else{ //on front end
	require_once('ExtraRouter/router.php');
	add_filter( 'indexid', 'extra_router_route' );
}


function extra_router_admin_tab() {
	if (isset($_POST['save'])){ //is post	
		$patterns = $_POST['patterns'] ? explode('||||', $_POST['patterns']) : array();
		$codes = $_POST['codes'] ? explode('||||', $_POST['codes']) : array();

		extra_router_save_settings( $patterns, $codes );
		$saved = true;
	}

	$settings = extra_router_get_settings();
    
	require_once('ExtraRouter/views/configuration.html');
}

function extra_router_on_header(){
	
	if (strtolower(get_filename_id()) == 'load' && @$_GET['id'] == 'ExtraRouter'){
		?>
            <link rel="stylesheet" href="../plugins/ExtraRouter/css/configuration.css" />	
            <link rel="stylesheet" href="../plugins/ExtraRouter/codemirror/codemirror.css" />	
            <script src="../plugins/ExtraRouter/codemirror/codemirror.js" ></script>	
            <script src="../plugins/ExtraRouter/codemirror/clike.js" ></script>	
            <script src="../plugins/ExtraRouter/codemirror/php.js" ></script>	
			<script>
				<?php require_once('ExtraRouter/views/configurationJS.php'); ?>
			</script>
			
			
		<?php
	}
}

//retrieves settings from xml
function extra_router_get_settings($withoutCodes = false) {
    $file = GSDATAOTHERPATH . 'ExtraRouter/patterns.xml';
	
	if (!file_exists($file)) {
		extra_router_save_settings(array(), array()); //create empty one
	}
	
	$xml = getXML($file);
	
	$data = extra_router_unserializeToArray($xml);
	
    
	if (!$withoutCodes){
		$data['codes'] = array();

		for ($i = 0; $i < count($data['patterns']); $i++) {
			$data['codes'][] = file_get_contents(GSDATAOTHERPATH . 'ExtraRouter/pattern-'.$i.'.php');
		}
	}
	
	return $data;
}

//saves settings to xml
function extra_router_save_settings($patterns, $codes) {
    $file = GSDATAOTHERPATH . 'ExtraRouter/patterns.xml';
	
	if ( !file_exists(dirname($file)) ){ //directory not exists, prepare one, requsivly
		mkdir(dirname($file), 0755, true);
	}
	
	$xml = extra_router_serializeToXml(array('patterns' => $patterns));
	
	array_map('unlink', glob( GSDATAOTHERPATH . 'ExtraRouter/*.php')); //delete all code files
	
	//store php code
	for ($i = 0; $i < count($codes); $i++) {
		file_put_contents(GSDATAOTHERPATH . 'ExtraRouter/pattern-'.$i.'.php', $codes[$i]);
	}
	
	
	# write data to file
	XMLsave($xml, $file);
}


function extra_router_serializeToXml($arr, $xml = null, $rootName = 'root'){

	if($xml === null) 
		$xml = new SimpleXMLExtended('<'.$rootName.'/>');

	foreach ($arr as $k => $v){
		$nodeName = 'i';
		$node = $xml;
		
		if (preg_match('/[a-z]+[a-z0-9_-]*/i', $k)){ //check name is allowed for entity
			$nodeName = $k;
		}
		
		$node = $xml->addChild($nodeName);
		if ($nodeName == 'i') //save original key in attribute, coz name for entity is invalid
			$node->addAttribute('key', $k);

		if ( is_array($v) && count($v) > 0 ){
			extra_router_serializeToXml($v, $node);
		}
		else{
			$type = gettype($v);
			
			if ($type == 'array'){ //array hehr is only empty array
				$type = 'emptyArray';
				$v = '';
			}

			if (in_array($type, array('integer', 'boolean', 'NULL', 'emptyArray'))) //array is for only empty array
				$node->addAttribute('type', $type);
				
				
			$node->addCData($v); //assign value to last node (nodeName), can be multi if array
			//save php var type: integer or boolean, null
		}
	}

	return $xml;
}


function extra_router_unserializeToArray(SimpleXMLExtended $xml){
	$array = array();

	foreach ($xml as $k => $v){
		$attributes = $v->attributes();
		$k = isset($attributes['key']) ? (string)$attributes['key'] : $k; //if key is stored in attr
		
		if ( count($v->children()) ){
			$array[$k] = extra_router_unserializeToArray($v);
		}
		else{
			$value = (string)$v;

			if ( isset($attributes['type']) ){
				switch ( (string) $attributes['type'] ){
					case 'boolean':{
						$value = (bool)(string)$v; //double cast, needed
						break;
					}       
					case 'integer':{
						$value = (int)$v;
						break;
					}                               
					case 'NULL':{
						$value = null;
						break;
					}  
 					case 'emptyArray':{
						$value = array(); //empty array
						break;
					}       
				}
			}
			$array[$k] = $value;
		}
	}
	return $array;
}