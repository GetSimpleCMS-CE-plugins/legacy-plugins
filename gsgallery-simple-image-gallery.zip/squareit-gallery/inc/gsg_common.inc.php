<?php
define("GSG_PLUGINID", 'squareit-gallery');
define("GSG_FOLDERPATH", GSPLUGINPATH.GSG_PLUGINID.'/');
define("GSG_PLUGINPATH", GSG_FOLDERPATH.'plugins/');
define("GSG_DATAPATH", GSG_FOLDERPATH.'data/');
define("GSG_GALLERIESPATH", GSG_DATAPATH.'galleries/');
define("GSG_LANGPATH", GSG_FOLDERPATH.'lang/');
define("GSG_INCPATH", GSG_FOLDERPATH.'inc/');
define("GSG_THUMBSPATH", GSG_FOLDERPATH.'thumbs/');
define("GSG_RELFOLDERPATH", substr(GSPLUGINPATH, strlen(GSROOTPATH)).GSG_PLUGINID.'/');