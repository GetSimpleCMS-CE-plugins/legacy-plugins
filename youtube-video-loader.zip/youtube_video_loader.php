<?php
/*
Based on: Youtube Video Display
Author: Raul Dominguez - Luar
Author URL:rauldominguez.host22.com
Original Plugin description: Add a Youtube Video on the page from the youtube video ID.
*/
/*
Plugin Name: Youtube Video Loader
Description: Replace Youtube embraced URLs with tags to responsive or customized size video embedding 
Version: 0.1
Rewriten by: Glaucius Zacher
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

// register plugin
register_plugin(
	$thisfile,	// ID of plugin, should be filename minus php
	'Youtube Video Loader',	# Title of plugin
	'0.3',	// Version of plugin
	'Glaucius Zacher',	// Author of plugin
	'https://uy.linkedin.com/in/glauciuszacher',	// Author URL
	'Replace Youtube embraced URLs with tags to responsive or customized size video embedding.',	// Plugin Description
	'plugin',	// Page type of plugin
	'youtube_video_load'	// Function that displays content
);

# activate filter
add_filter('content','youtube_video_load');

/**
 * Parses the content on a page and matches it to valid embraced youtube URL.
 *
 * @param string $content - Content of Page
 * @return string;
 */

function youtube_video_load($content){
	$found = preg_match_all('/\{%(.|&nbsp;)https\:\/\/www\.youtube\.com\/watch\?v=.+(.|&nbsp;)%\}/', $content, $match);

	for ($i=0; $i<=$found; $i++){
		$sVideo = '';
    	unset($aVideoParams);
		if (isset($match[0][$i])){
	    	$sVideo = $match[0][$i];
    		$aVideoParams = explode('=', $match[0][$i]);
			//array_walk($aVideoParams, 'rem_brace');
      		rem_brace($aVideoParams[count($aVideoParams)-1]);
      		$eVid = $aVideoParams[1];
        	$iWidth = isset($aVideoParams[2]) ? $aVideoParams[2].'px' : '100%;';
      		$iHeight = isset($aVideoParams[3]) ? $aVideoParams[3].'px' : '100%; padding-bottom: 56.25%;';
		}else{
      		return $content;
		}

		$video = youtube_video_embed($eVid,$iWidth,$iHeight);
		$pattern_vid = (isset($aVideoParams[2])) ? $aVideoParams[1].'='.$aVideoParams[2].'='.$aVideoParams[3] : $eVid;
		//echo"<javascript>alert($pattern_vid)</javascript>";
    	$patt = '/\{%(.|&nbsp;)https\:\/\/www\.youtube\.com\/watch\?v='.$pattern_vid.'(.|&nbsp;)%\}/';
		$content = preg_replace($patt, $video, $content);
	}
	return $content;
}
/**
 * function youtube_video_embed
 * @param strings $id - video id, $w - width(and padding), $h - height(and padding)
 * @return html content for video embed
 */
function youtube_video_embed($id,$w,$h){
  return "<div style='position: relative;
  top: 0;
  bottom: 0;
  left: 0;
  width: $w;
  height: $h;
  border: 0;'>
<iframe style='  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: $w;
  height: $h;
  border: 0;'
  src='https://www.youtube.com/embed/$id?rel=0&amp;showinfo=0' 
  frameborder='0' 
  allowfullscreen>
</iframe>
</div>";
}
function rem_brace(&$var){
	$neddle = array(' %}','&nbsp;%}');
  $var = str_replace($neddle, '', $var);
}
?>