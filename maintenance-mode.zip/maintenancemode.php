<?php
$thisfile=basename(__FILE__, ".php");

register_plugin(
	$thisfile, //ID
	'Maintenance Mode', 	//Name
	'1.0.1', 		//Version
	'Frixel Solutions',  //Author
	'https://www.frixelsolutions.com/', //Author Website
	'Lets you temporarily enable a fully customizable maintenance mode on your site.', //Description
	'settings', //Admin Page
	'maintenancemode_function'  //Primary Function
);

//Checking if form was submitted from previous page
if(isset($_POST['maintenance_mode_plugin_submitted'])){
	maintenancemode_save($_POST['maintenancemodecheckbox'],$_POST['maintenancemodetextarea']);
}

//Primary Function
function maintenancemode_function(){
	$file = GSDATAOTHERPATH.'maintenancemodeplugindata.xml';

	if (file_exists($file)) {
	    $data = getXML($file);
		$maintenancemodemessage = $data->message;
		$maintenancemodestatus = $data->status;
  	} else {
  		file_put_contents(GSDATAOTHERPATH.'maintenancemodeplugindata.xml','<?xml version="1.0"?><item><status>off</status><message>Maintenance Mode Enabled</message></item>');
		$maintenancemodemessage = "Maintenance Mode Enabled";
		$maintenancemodestatus = "off";
	}

	if($maintenancemodestatus == "on"){
		$maintenancemodeonoff = 'checked';
	} else {
		$maintenancemodeonoff = '';
	}

	echo '<h3>Maintenance Mode</h3>';
	echo '<form method="post">';
	echo '<p><input type="checkbox" name="maintenancemodecheckbox" value="on" '.$maintenancemodeonoff.'> &nbsp;<b>Check to Enable Maintenance Mode</b><input type="hidden" name="maintenance_mode_plugin_submitted" value="true"></p>';
	echo '<p><textarea name="maintenancemodetextarea">'. $maintenancemodemessage .'</textarea></p>';
	echo '<input type="submit" class="submit" value="Submit"></form>';
}

//Saves form data to XML file
function maintenancemode_save($status, $msg) {
	if($status == "on"){
		$offon = "on";
	} else {
		$offon = "off";
	}
	file_put_contents(GSDATAOTHERPATH.'maintenancemodeplugindata.xml','<?xml version="1.0"?><item><status>'.$offon.'</status><message>'.$msg.'</message></item>');
}

add_action('settings-sidebar','createSideMenu',array($thisfile,'Maintenance Mode'));

add_action('index-pretemplate','maintenancemode_frontend');

//Check the XML file to see if we should display the maintenance page
function maintenancemode_frontend() {
	$file = GSDATAOTHERPATH.'maintenancemodeplugindata.xml';
	$data = getXML($file);
	$maintenancemodemessage = $data->message;
	$maintenancemodestatus = $data->status;

	if ($maintenancemodestatus == 'on' && !isset($_COOKIE['GS_ADMIN_USERNAME'])) {
		echo '<!DOCTYPE>';
		echo '<head><meta name="keywords" content="';
		get_page_meta_keywords();
		echo '"><head><title>';
		get_site_name();
		echo '</title></head><body>';
		echo '<div id="maintenance" style="width:93%; text-align:center; color: #B70000; height:auto; margin: auto; padding: 15px;  -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; border:2px dashed #B70000; font-family: sans-serif; font-size: 1.5em; text-align: center; ">';
		echo '<p>' . $maintenancemodemessage . '</p>';
		echo '</div></body></html>';
		die;
	}
}

?>