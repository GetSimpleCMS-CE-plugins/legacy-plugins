<?php
/*
Plugin Name: New Page From 404
Description: Helps user to create a new page from 404 
Version: 0.1
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru
*/

$thisfile = basename(__FILE__, '.php');

# register plugin
register_plugin(
  $thisfile,
  'New Page From 404',
  '0.1',
  'Dmitry Yakovlev',
  'http://dimayakovlev.ru',
  'Helps user to create a new page from 404',
  '',
  ''
);

add_action('admin-pre-header', 'get_new_page_from_404_admin');

function get_new_page_from_404_admin() {
  global $url;
  if (basename($_SERVER['PHP_SELF']) == 'edit.php') {
    if (!$url && isset($_GET['newpagefrom404'])) {
      $url = $_GET['newpagefrom404'];
    }
  }
}

function get_new_page_from_404_link($link_title) {
  global $id, $url, $GSADMIN;
  if ($url = '404' && $id != '404' && is_logged_in()) {
    $url = get_site_url(false) . $GSADMIN . '/edit.php?newpagefrom404=' . urlencode($id);
    echo '<a href="' . $url . '">' . $link_title . '</a>';
  }  
}