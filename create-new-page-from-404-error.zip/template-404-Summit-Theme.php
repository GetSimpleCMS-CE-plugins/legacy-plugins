<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File: 		template.php
* @Package:		GetSimple
* @Action:		Summit theme for GetSimple CMS
*
*****************************************************/

# Get this theme's settings based on what was entered within it's plugin. 
# This function is in functions.php 
Summit_Settings();

# Include the header template
include('header.inc.php'); 
?>

  <div id="page" style="background-color:#fcc; margin:100px;>

        <div id="content">
          <div class="post">
            <!-- page content -->
			<?php if ((string)$id != '404') $title = 'Page ' . $id . ' not found'; ?>
            <h2 class="title"><?php get_page_title(); ?></h2>  <!-- page title -->
            <div style="clear: both;">&nbsp;</div>
              <div class="entry">
               <?php pagify_set_size(8000, 9) ?>
                <center style="color:#888;font-size:80%;margin:0;">Rev - <?php get_page_date("M d, Y"); ?></center>
                <br>
                <p> <span style='color:red;font-size:110%;'><?php get_page_content(); ?></span></p>	           
                <br>
                <?php if (get_page_title(false) != '404') $title = get_page_title(false); ?>
                <?php if(function_exists('get_new_page_from_404_link')) get_new_page_from_404_link(get_page_title(true).' [&thinsp;Create it&thinsp;]' ); ?>
              </div>
            </div>
          <div style="clear: both;">&nbsp;</div>
          <?php include('footer.inc.php'); ?>
        </div>
        <!-- end #content -->
      
        <!-- Left Sidebar -->
        
        <br>
        <div id="navigation">
        
          <!-- Login info & search page link -->   
            <center>
              <p><?php welcome_message_login(); ?></p>
              <a href="http://zoomaviation.com/pinguino/index/login-or-search/">Login or Search</a>
              <br>
              <a href="<?php get_site_url();echo $GSADMIN;?>/edit.php?id=<?php get_page_slug();?>">Edit this page</a>
              <?php if (cookie_check()) { ?><br><a href="http://zoomaviation.com/pinguino/admin">Admin</a><?php } ?>
            </center>   
        
          <!-- Menu --> 
          <h1 align=center>Menu</h1> 
          <ul class="menu">
          <?php function_exists('get_i18n_navigation') ? get_i18n_navigation(return_page_slug(), 0, 100, I18N_FILTER_MENU | I18N_FILTER_CURRENT) : get_navigation(return_page_slug()); ?>
          </ul>        
        </div> <!-- end navigation/menu box -->
      
        
        <!-- Sidebar content -->
        <?php include('sidebar.inc.php'); ?>  
        <!-- end Sidebar content -->
        
        <div style="clear: both;">&nbsp;</div>
                    


  </div>  <!-- end #page -->


</body>
</html>
