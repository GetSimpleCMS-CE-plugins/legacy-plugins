<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } ?>
<body style="background-color:#fcc; margin:100px;">
  <!-- page content -->
  <?php if ((string)$id != '404') $title = 'Page "<u><i>' . $id . '</i></u>" not found '; ?>
  <h2 style="color:red;font-size:28px;"><center><?php get_page_title(); ?></center></h2>  <!-- page title -->
  <br>
  <center><span style='color:blue;font-size:18px;'><?php get_page_content(); ?></span></center>          
  <br>
  <center><?php if (get_page_title(false) != '404') $title = get_page_title(false); ?></center>
  <center><?php if(function_exists('get_new_page_from_404_link')) get_new_page_from_404_link(get_page_title(true).'[&thinsp;Create it&thinsp;]' ); ?></center>
</body>
</html>
