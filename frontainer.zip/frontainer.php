<?php
// plugin
$fronainer_file = basename(__FILE__, ".php");

// add in this plugin language file
i18n_merge($fronainer_file) || i18n_merge($fronainer_file, 'en_US');

// register plugin
register_plugin(
	$fronainer_file,
	i18n_r($fronainer_file.'/title'),
	'1.0.2',
	'Juri Ehret',
	'http://ehret-studio.com',
	i18n_r($fronainer_file.'/description'),
	'plugins',
	'frontainer_setup'
);

$config_file = GSDATAOTHERPATH .'frontainer.config.xml';
if(file_exists($config_file))
{
	$fc = getXML($config_file);
}
add_action('plugins-sidebar','createSideMenu',array($fronainer_file, i18n_r($fronainer_file.'/title')));

// templates directory
define('FR_TEMPLATE_DIR', GSPLUGINPATH.'/frontainer/tpl/');
// define slugs  according your pages
define('LOGIN_SLUG', 'login');
define('SIGNUP_SLUG', 'signup');
define('ACCOUNTS_SLUG', 'accounts');
define('LOGOUT_SLUG', 'logout');
define('RECOVERY_SLUG', 'recovery');
define('ACTIVATE_SLUG', 'activate');

require(GSPLUGINPATH. 'frontainer/usersignup.class.php');
require(GSPLUGINPATH. 'frontainer/loggedin.php');


function frontainer_get_content()
{
	global $fronainer_file, $fc;
	$fr = $fronainer_file;
	$output = '';

	$input = array_merge($_GET, $_POST);
	$manager = new IManager();
	$user = new FrontainerUserSignup($manager, $fr);

	// merge frontainer and ItemManager configs
	$manager->config->frontainer = !empty($fc) ? $fc : false;

	$tplEngine = $manager->getTemplateEngine();
	$tplEngine->init(FR_TEMPLATE_DIR);


	// user logout
	if(!empty($input['id']) && $input['id'] == LOGOUT_SLUG)
	{
		$user->logout(get_section_url(LOGIN_SLUG));
	}

	if(!empty($input['id']) && $input['id'] == ACCOUNTS_SLUG)
	{
		return build_user_area($manager);
	}
	// the user is logged in
	if(!headers_sent() && isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true
		&& isset($input['id']) && ($input['id'] == LOGIN_SLUG))
	{
		header('Status: 200');
		header('Location: ' . htmlspecialchars(get_section_url(ACCOUNTS_SLUG)));
		exit();
	}


	// displays the login form
	if(!empty($input['id']) && $input['id'] == LOGIN_SLUG)
	{
		// user data submited
		if(!empty($input['login']))
		{
			// error while logging in
			if(!$user->login($input))
			{
				// get error template
				$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
				$output .= $tplEngine->render($tplerror, array('msg' => MsgReporter::buildMsg()));
			// ur successfully logged in
			} else
			{
				if(!headers_sent())
				{
					// set a flash and redirect to the login page
					header('Status: 200');
					header('Location: ' . htmlspecialchars(get_section_url(ACCOUNTS_SLUG)));
					exit();
				}
				return;
			}
		}

		// get all signup templates
		$tplssignup = $tplEngine->getTemplates('signup');
		// get login form template
		$loginform = $tplEngine->getTemplate('login', $tplssignup);

		// parse login form template
		$output .= $tplEngine->render($loginform, array(
			'action' => htmlspecialchars(get_section_url(LOGIN_SLUG)),
			'lang_legend_loginform' => i18n_r($fr.'/legend_form'),
			'lang_email_tv' => i18n_r($fr.'/email_tv'),
			'lang_pass_tv' => i18n_r($fr.'/pass_tv'),
			'lang_submil_login' => i18n_r($fr.'/submit_login'),
			'lang_forgot_pass_title' => i18n_r($fr.'/forgot_pass_title'),
			'lang_forgot_pass' => i18n_r($fr.'/forgot_pass'),
			'recovery_link' => htmlspecialchars(get_section_url(RECOVERY_SLUG))
			)
		);
		return $output;
	}



	// displays sign up form
	if(!empty($input['id']) && $input['id'] == SIGNUP_SLUG)
	{
		// user data submited
		if(!empty($input['signup']))
		{
			// error while logging in
			if(!$user->signup($input))
			{
				// get error template
				$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
				$output .= $tplEngine->render($tplerror, array('msg' => MsgReporter::buildMsg()));
				// ur successfully logged in
			} else
			{
				// show link to join
				$tplssignup = $tplEngine->getTemplates('signup');
				// get signup form template
				$loginform = $tplEngine->getTemplate('successfully', $tplssignup);

				// parse login form template
				$output .= $tplEngine->render($loginform, array(
						'lang_successfully_signup' => i18n_r($fr.'/successfully_signup'),
						'lang_successfully_signup_msg' => i18n_r($fr.'/successfully_signup_msg'),
						'lang_link_text' => i18n_r($fr.'/link_text'),
						'link_address' => htmlspecialchars(get_section_url(LOGIN_SLUG))
					)
				);

				return $output;
			}
		}

		// get all signup templates
		$tplssignup = $tplEngine->getTemplates('signup');
		// get signup form template
		$loginform = $tplEngine->getTemplate('signup', $tplssignup);

		// parse signup form template
		$output .= $tplEngine->render($loginform, array(
				'action' => htmlspecialchars(get_section_url(SIGNUP_SLUG)),
				'lang_legend_signupform' => i18n_r($fr.'/legend_signupform'),
				'lang_user_name' => i18n_r($fr.'/user_name'),
				'lang_email_tv' => i18n_r($fr.'/email_tv'),
				'lang_name_tv' => i18n_r($fr.'/name_tv'),
				'lang_pass_tv' => i18n_r($fr.'/pass_tv'),
				'lang_submit_signup' => i18n_r($fr.'/submit_signup'),
				'lang_already_registered' => i18n_r($fr.'/already_registered'),
				'login_link' => htmlspecialchars(get_section_url(LOGIN_SLUG))
			)
		);
		return $output;
	}


	// activation new users
	if(!empty($input['id']) && $input['id'] == ACTIVATE_SLUG)
	{
		// error while logging in
		if(!$user->activate($input))
		{
			// get error template
			$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
			$msg = MsgReporter::buildMsg();
			if(!empty($msg))
				$output .= $tplEngine->render($tplerror, array('msg' => $msg));

		} else
		{
			// show link to join
			$tplssignup = $tplEngine->getTemplates('signup');
			// get signup form template
			$loginform = $tplEngine->getTemplate('successfully', $tplssignup);

			// parse login form template
			$output .= $tplEngine->render($loginform, array(
					'lang_successfully_signup' => i18n_r($fr.'/account_activated'),
					'lang_successfully_signup_msg' => '',
					'lang_link_text' => i18n_r($fr.'/link_activated'),
					'link_address' => htmlspecialchars(get_section_url(LOGIN_SLUG))
				)
			);
		}

		return $output;
	}


	// password recovery area
	if(!empty($input['id']) && $input['id'] == RECOVERY_SLUG)
	{

		// reset form data submited
		if(isset($input['reset']))
		{
			if(!$user->reset($input))
			{
				// get error template
				$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
				$msg = MsgReporter::buildMsg();
				if(!empty($msg))
					$output .= $tplEngine->render($tplerror, array('msg' => $msg));
			} else
			{
				// show link to join
				$tplssignup = $tplEngine->getTemplates('signup');
				// get signup form template
				$loginform = $tplEngine->getTemplate('successfully', $tplssignup);

				// parse login form template
				$output .= $tplEngine->render($loginform, array(
						'lang_successfully_signup' => i18n_r($fr.'/successfully_reset'),
						'lang_successfully_signup_msg' => '',
						'lang_link_text' => i18n_r($fr.'/link_activated'),
						'link_address' => htmlspecialchars(get_section_url(LOGIN_SLUG))
					)
				);
				return $output;
			}
		}


		// user clicked on the recovery link in the email
		if(!empty($input['key']) && !empty($input['user']))
		{
			// check user data
			if(!$user->validateRecovery($input))
			{
				// get error template
				$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
				$msg = MsgReporter::buildMsg();
				if(!empty($msg))
					$output .= $tplEngine->render($tplerror, array('msg' => $msg));

			// correct user data, show reset form
			} else
			{
				// get all signup templates
				$tplssignup = $tplEngine->getTemplates('signup');
				// get signup form template
				$loginform = $tplEngine->getTemplate('reset', $tplssignup);

				// parse login form template
				$output .= $tplEngine->render($loginform, array(
						'action' => htmlspecialchars(get_section_url(RECOVERY_SLUG)),
						'lang_legend_resetform' => i18n_r($fr.'/legend_resetform'),
						'reset_key' => htmlspecialchars($input['key']),
						'reset_name' => htmlspecialchars($input['user']),
						'lang_reset_pass_tv' => i18n_r($fr.'/reset_pass_tv'),
						'lang_reset_confirm_tv' => i18n_r($fr.'/reset_confirm_tv'),
						'lang_submit_reset' => i18n_r($fr.'/submit_reset'),
					)
				);
				return $output;
			}
		}

		// recovery form is sent.
		if(!empty($input['recovery']))
		{
			// error while recovery process
			if(!$user->recovery($input))
			{
				// get error template
				$tplerror = $tplEngine->getTemplate('error', $tplEngine->getTemplates('msg'));
				$msg = MsgReporter::buildMsg();
				if(!empty($msg))
					$output .= $tplEngine->render($tplerror, array('msg' => $msg));

			} else
			{
				// show link with info
				$tplssignup = $tplEngine->getTemplates('signup');
				// get signup form template
				$loginform = $tplEngine->getTemplate('successfully', $tplssignup);

				// parse login form template
				$output .= $tplEngine->render($loginform, array(
						'lang_successfully_signup' => i18n_r($fr.'/recovery_email_sent'),
						'lang_successfully_signup_msg' => '',
						'lang_link_text' => i18n_r($fr.'/link_recovery'),
						'link_address' => htmlspecialchars($manager->getSiteUrl())
					)
				);
				return $output;
			}
		}


		// show recovery form
		$tplssignup = $tplEngine->getTemplates('signup');
		// get signup form template
		$loginform = $tplEngine->getTemplate('recovery', $tplssignup);

		// parse recovery form template
		$output .= $tplEngine->render($loginform, array(
				'action' => htmlspecialchars(get_section_url(RECOVERY_SLUG)),
				'lang_legend_recovery' => i18n_r($fr.'/legend_recovery'),
				'lang_email_tv' => i18n_r($fr.'/email_tv'),
				'lang_submit_recovery' => i18n_r($fr.'/submit_recovery'),
			)
		);
		return $output;
	}
}

function frontainer_setup()
{
	global $fronainer_file,
		   $config_file,
		   $fc;

	$fr = $fronainer_file;
	$output = '';

	$input = array_merge($_GET, $_POST);
	$manager = new IManager();

	$tplEngine = $manager->getTemplateEngine(FR_TEMPLATE_DIR.'settings/');
	$tplEngine->init();

	// get signup form template
	$form = $tplEngine->getTemplate('form');

	if(isset($input['submit']))
	{
		// new file
		if(!file_exists($config_file))
			$fc = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><configs></configs>');
		else
			global $fc;
		$fc->sitename = !empty($input['sitename']) ? $input['sitename'] : '';
		$fc->email_from = !empty($input['email_from']) ? $input['email_from'] : '';
		$fc->email_to = !empty($input['email_to']) ? $input['email_to'] : '';
		$fc->asXml($config_file);
		MsgReporter::setClause('successfully_saved_settings', array(), false, $fr);
	}


	// parse settings form template
	echo $tplEngine->render($form, array(
			'msgs' => !empty(MsgReporter::msgs()) ? MsgReporter::buildMsg() : '',
			'frontainer_title' => i18n_r($fr.'/settings_header'),

			'sitename' => i18n_r($fr.'/settings_sitename'),
			'sitename_value' => !empty($fc->sitename) ? $fc->sitename : 'My Website',

			'email_from' => i18n_r($fr.'/email_from'),
			'email_from_info' => i18n_r($fr.'/email_from_info'),
			'email_from_value' => !empty($fc->email_from) ? $fc->email_from : 'Mypage@email.com',

			'email_to' => i18n_r($fr.'/email_to'),
			'email_to_info' => i18n_r($fr.'/email_to_info'),
			'email_to_value' => !empty($fc->email_to) ? $fc->email_to : 'Mypage@email.com',


			'savebutton' => i18n_r($fr.'/settings_savebutton'),
		), true
	);
}

function get_section_url($section)
{
	$data = menu_data($section);
	return !empty($data['url']) ? $data['url'] : '';
}

function dropEmail($recipient, $subject, $msg, $from, $reply)
{
	// send confirm email
	$header = 'From: '.$from . "\r\n" .
		'Reply-To: '.$reply . "\r\n" .
		'X-Mailer: PHP/' . phpversion();

	if(!mail($recipient, $subject, $msg, $header)){return false;}
	return true;
}


?>