<?php

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
 
# register plugin
register_plugin(
	$thisfile, //Plugin id
	'Detroit Theme', 	//Plugin name
	'1.0', 		//Plugin version
	'Mateusz Skrzypczak',  //Plugin author
	'https://multicolor.stargard.pl', //author website
	'Next theme for GS', //Plugin description
	'theme', //page type - on which admin tab to display
	'RunDetroit'  //main function (administration)
);
register_script('detroitscript', $SITEURL.'plugins/detroit-theme/js/script.js', '1.0', TRUE);
queue_script('detroitscript', GSBACK); 

register_style('detroiticon', 'https://unicons.iconscout.com/release/v2.0.1/css/unicons.css', GSVERSION, 'screen');
register_style('detroitstyle', $SITEURL.'/plugins/detroit-theme/css/style.css', GSVERSION, 'screen');
queue_style('detroitstyle',GSBACK); 
queue_style('detroiticon',GSBACK); 



 

?>