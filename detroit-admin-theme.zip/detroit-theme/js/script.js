document.querySelector('#nav_pages .pages').innerHTML = document.querySelector('#nav_pages .pages').innerHTML + " <i class='uil uil-newspaper'></i>";
document.querySelector('#nav_upload .files').innerHTML = document.querySelector('#nav_upload .files').innerHTML + " <i class='uil uil-file-upload'></i>";
document.querySelector('#nav_theme .theme').innerHTML = document.querySelector('#nav_theme .theme').innerHTML + " <i class='uil uil-swatchbook'></i>";
document.querySelector('#nav_backups .backups').innerHTML = document.querySelector('#nav_backups .backups').innerHTML + " <i class='uil uil-history'></i>";
document.querySelector('#nav_plugins .plugins').innerHTML = document.querySelector('#nav_plugins .plugins').innerHTML + " <i class='uil uil-history'></i>";
document.querySelector('.nav .settings').innerHTML = document.querySelector('.nav .settings').innerHTML + " <i class='uil uil-cog'></i>";
document.querySelector('.nav .support').innerHTML = document.querySelector('.nav .support').innerHTML + " <i class='uil uil-question-circle'></i>";
document.querySelector('.nav').classList.add('hide-mobile');

const mobileRwd = document.createElement("div");
mobileRwd.classList.add('btn-rwd');
mobileRwd.innerHTML = "<i class='uil uil-bars'></i>";

document.querySelector('.nav').before(mobileRwd);


document.querySelector('.btn-rwd').addEventListener('click', () => {
    document.querySelector('.nav').classList.toggle('hide-mobile');
});

s