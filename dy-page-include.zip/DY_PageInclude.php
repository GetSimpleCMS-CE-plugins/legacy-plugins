<?php
/*
Plugin Name: DY Page Include
Version: 1.0
Description: Includes content from one page to another
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY Page Include',                  # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  'Includes content from one page to another',   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content', 'dyPageIncludeShortcode');

function dyPageIncludeShortcode($content) {
  // (% dyPageInclude : page-slug-to-include %)
  $pattern = '(\(%\s+dyPageInclude\s*:\s*(\S+)\s+%\))';
  return preg_replace_callback($pattern, 'dyPageIncludeCallback', $content);
}

function dyPageIncludeCallback($matches) {
  global $pagesArray;
  if (isset($matches[1])) {
    $slug = lowercase($matches[1]);
    if (get_page_slug(false) != $slug && array_key_exists($slug, $pagesArray))
      return returnPageField($slug, 'content');
  }
}

?>