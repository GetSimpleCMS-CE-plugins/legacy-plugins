<?php

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");
$random_ads_file=GSDATAOTHERPATH .'random_ads.xml';

# register plugin
register_plugin(
	$thisfile, 													# ID of plugin, should be filename minus php
	'Random Ads', 									# Title of plugin
	'.9', 															# Version of plugin
	'Mike Henken',											# Author of plugin
	'http://www.profileyourcity.com', 						# Author URL
	'Allows For Easy Insertion Of Random Ads Or Banners', 	# Plugin Description
	'pages', 											# Page type of plugin
	'random_ads_process'  										# Function that displays content
);

# hooks
add_action('pages-sidebar','createSideMenu',array($thisfile,'Random Ads')); 

define('ADSDATAFILE', GSDATAOTHERPATH  . 'random_ads.xml');

global $error_cate;
$error_cate = '';

global $EDLANG, $EDOPTIONS, $toolbar, $EDTOOL;
if (defined('GSEDITORLANG')) { $EDLANG = GSEDITORLANG; } else {	$EDLANG = 'en'; }
if (defined('GSEDITORTOOL')) { $EDTOOL = GSEDITORTOOL; } else {	$EDTOOL = 'basic'; }
if (defined('GSEDITOROPTIONS') && trim(GSEDITOROPTIONS)!="") { $EDOPTIONS = ", ".GSEDITOROPTIONS; } else {	$EDOPTIONS = ''; }
if ($EDTOOL == 'advanced') {
$toolbar = "
	    ['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', 'Table', 'TextColor', 'BGColor', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source'],
    '/',
    ['Styles','Format','Font','FontSize']
";
} elseif ($EDTOOL == 'basic') {
$toolbar = "['Bold', 'Italic', 'Underline', 'NumberedList', 'BulletedList', 'JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock', 'Link', 'Unlink', 'Image', 'RemoveFormat', 'Source']";
} else {
$toolbar = GSEDITORTOOL;
}

function xml2array ( $xmlObject, $out = array () )
{
        foreach ( (array) $xmlObject as $index => $node )
            $out[$index] = ( is_object ( $node ) ) ? xml2array ( $node ) : $node;

        return $out;
}

function display_ads($category)
{
	$ad_count = 0;
	if(file_exists(ADSDATAFILE))
	{	
		$category_file = getXML(ADSDATAFILE);
	}
	foreach($category_file->category as $category_name)
	{
		if($category_name->categoryname == $category)		
		{
					
			foreach($category_name->ad as $ad_counter)
			{
				$ad_count++;
			}

			$category_array = xml2array($category_name);
				$ad_count = rand (0, ($ad_count - 1));
				echo $category_array['ad'][$ad_count]->contents;
	
		}
	}
	

}

function random_ads_add_ad() {
$new_ad_title = $_POST['title'];
$new_ad_contents = $_POST['contents'];
global $error_cate;
if(file_exists(ADSDATAFILE))
{	
	$category_file = getXML(ADSDATAFILE);
}
if($_POST['category'] == "")
{
	$error_cate = '<div class="error">Please Choose Category For Ad</div>';
}
else 
{
	$error_cate = '<div class="updated">Ad Succesfully Created</div>'; 
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');


	foreach($category_file->category as $category_name)
	{

		$category_title = $category_name->categoryname;
		$category_category = $xml->addChild("category");
		$category_category->addChild('categoryname', $category_title);

		if($_POST['category'] == $category_title)
		{
			$category_ad_new_xml = $category_category->addChild('ad');
			$category_ad_new_xml->addChild('title', $new_ad_title);
			$category_ad_new_xml_contents = $category_ad_new_xml->addChild('contents');
			$category_ad_new_xml_contents->addCData($new_ad_contents);
		}

		foreach($category_name->ad as $the_ad)
		{
				$ad_title = $the_ad->title;
				$ad_contents = $the_ad->contents;
				$category_ad_xml = $category_category->addChild('ad');
				$category_ad_xml->addChild('title', $ad_title);
				$category_ad_xml_contents = $category_ad_xml->addChild('contents');
				$category_ad_xml_contents->addCData($ad_contents);
		}
		XMLsave($xml, ADSDATAFILE);
}
}
return $error_cate;
}




function random_ads_add_category() {
$new_category_title = $_POST['title'];

if(file_exists(ADSDATAFILE))
{	
	$category_file = getXML(ADSDATAFILE);
}
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');

		

	foreach($category_file->category as $category_name)
	{
		$category_category = $xml->addChild("category");
		$category_title = $category_name->categoryname;
		$category_category->addChild('categoryname', $category_title);


		foreach($category_name->ad as $the_ad)
		{
				$ad_title = $the_ad->title;
				$ad_contents = $the_ad->contents;
				$category_ad_xml = $category_category->addChild('ad');
				$category_ad_xml->addChild('title', $ad_title);
				$category_ad_xml_contents = $category_ad_xml->addChild('contents');
				$category_ad_xml_contents->addCData($ad_contents);
		}
}
		$new_category_category = $xml->addChild("category");
		$new_category_category->addChild('categoryname', $new_category_title);
		XMLsave($xml, ADSDATAFILE);
}

function random_ads_edit_ad() {
$edit_ad_title = $_POST['title'];
$edit_ad_contents = $_POST['contents'];
if(file_exists(ADSDATAFILE))
{	
	$category_file = getXML(ADSDATAFILE);
}
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');


	foreach($category_file->category as $category_name)
	{

		$category_title = $category_name->categoryname;
		$category_category = $xml->addChild("category");
		$category_category->addChild('categoryname', $category_title);

		foreach($category_name->ad as $the_ad)
		{
				$ad_title = $the_ad->title;
				$ad_contents = $the_ad->contents;

				if($_POST['category'] == $category_title && $_POST['old-title'] == $the_ad->title)
				{
					$category_ad_edit_xml = $category_category->addChild('ad');
					$category_ad_edit_xml->addChild('title', $edit_ad_title);
					$category_ad_edit_xml_contents = $category_ad_edit_xml->addChild('contents');
					$category_ad_edit_xml_contents->addCData($edit_ad_contents);
										
				}
				else
				{

				$category_ad_xml = $category_category->addChild('ad');
				$category_ad_xml->addChild('title', $ad_title);
				$category_ad_xml_contents = $category_ad_xml->addChild('contents');
				$category_ad_xml_contents->addCData($ad_contents);
				}	
	}
		XMLsave($xml, ADSDATAFILE);
}

}

function random_ads_delete_ad() {
if(file_exists(ADSDATAFILE))
{	
	$category_file = getXML(ADSDATAFILE);
}
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');


	foreach($category_file->category as $category_name)
	{
		$category_title = $category_name->categoryname;
		$category_category = $xml->addChild("category");
		$category_category->addChild('categoryname', $category_title);
	foreach($category_name->ad as $the_ad)
	{
		$ad_title = $the_ad->title;
		$ad_contents = $the_ad->contents;
		$get_ad_delete = urldecode($_GET['delete']);
		if($ad_title == $get_ad_delete && $category_title == urldecode($_GET['category_of_deleted']))
		{
		}
		else
		{ 	$category_ad_xml = $category_category->addChild('ad');
			$category_ad_xml->addChild('title', $ad_title);
			$category_ad_xml_contents = $category_ad_xml->addChild('contents');
			$category_ad_xml_contents->addCData($ad_contents);
			
		}
	}
	XMLsave($xml, ADSDATAFILE);
}

}

function random_ads_delete_category() {

$delete_ad_category_title = urldecode($_GET['delete_category']);

if(file_exists(ADSDATAFILE))
{	
	$category_file = getXML(ADSDATAFILE);
}
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');

		

	foreach($category_file->category as $category_name)
	{
		if($category_name->categoryname == $delete_ad_category_title)
		{
			
		}
		else
		{
			$category_category = $xml->addChild("category");
			$category_title = $category_name->categoryname;
			$category_category->addChild('categoryname', $category_title);


			foreach($category_name->ad as $the_ad)
			{
					$ad_title = $the_ad->title;
					$ad_contents = $the_ad->contents;
					$category_ad_xml = $category_category->addChild('ad');
					$category_ad_xml->addChild('title', $ad_title);
					$category_ad_xml_contents = $category_ad_xml->addChild('contents');
					$category_ad_xml_contents->addCData($ad_contents);
			}
		}	
	}
	XMLsave($xml, ADSDATAFILE);
}



function random_ads_process() {
	global $error_cate;
	if(isset($_GET['delete']))
	{
		random_ads_delete_ad();
		random_ads_form($error_cate);
	}
	elseif(isset($_GET['add-new']))
	{
		random_ads_add_ad();
		random_ads_form($error_cate);
	}
	elseif(isset($_GET['edit-ad']))
	{
		random_ads_edit_ad();
		random_ads_form($error_cate);
	}
	elseif(isset($_GET['add_category']))
	{
		random_ads_add_category();
		random_ads_form($error_cate);
	}
	elseif(isset($_GET['delete_category']))
	{
		random_ads_delete_category();
		random_ads_form($error_cate);
	}
	else
	{
		random_ads_form($error_cate);
	}
}

	function random_ads_form($error_cate)
	{
		if(isset($error_cate))
		{
			if($error_cate != "")
			$error_cate = $error_cate;
		}
		else
		{
			$error_cate = "";
		}
	?>
<div style="width:100%;margin:0 -15px -15px -10px;padding:0px;">
	<h3 class="floated">Random Ads</h3>  
	<div class="edit-nav clearfix" style="">
		<a href="load.php?id=RandomAds&help" <?php if (isset($_GET['help'])){ echo 'class="current"'; } ?>>Help</a>
		<a href="load.php?id=RandomAds&categories" <?php if (isset($_GET['categories'])){ echo 'class="current"'; } ?>>Manage Categories</a>
		<a href="load.php?id=RandomAds&add" <?php if (isset($_GET['add']) && $_GET['add'] == "") { echo 'class="current"'; } ?>>Add New Ad</a>
		<a href="load.php?id=RandomAds&view" <?php if (isset($_GET['view'])) { echo 'class="current"'; } ?>>View All Ads</a>
	</div> 
</div>
</div>
<div class="main" style="margin-top:-10px;">

<?php
      if(!file_exists(ADSDATAFILE))
		{
		$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');
		$xml->asXML(ADSDATAFILE);
		 return true;
		}
	if(isset($_GET['add']))
	{
		global $SITEURL, $toolbar, $EDOPTIONS, $EDLANG;
?>
		<h3>Add New Ad</h3>
		<?php 
		if(isset($error_cate))
		{
			echo $error_cate;
		} 
		?>
		<form action="load.php?id=RandomAds&add&add-new" method="post" accept-charset="utf-8">
		<input type="text" name="title" class="text" style="width:635px;" value="Title.." onFocus="if(this.value == 'Title..') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Title..';}" />
		
		<select name="category" class="text" style="width:647px;margin:5px 0px 5px 0px">
			<option value="">Choose Category</option>
			<?php
				$ad_file = getXML(ADSDATAFILE);
				foreach($ad_file->category as $edit_cate)
				{
					echo '<option value="'.$edit_cate->categoryname.'">'.$edit_cate->categoryname.'</option>';
				}
			?>
		</select>

		<textarea name="contents"></textarea>
		<script type="text/javascript" src="template/js/ckeditor/ckeditor.js"></script>
		<script type="text/javascript">
		  // missing border around text area, too much padding on left side, ...
		  $(function() {
		    CKEDITOR.replace( 'contents', {
			        skin : 'getsimple',
			        forcePasteAsPlainText : false,
			        language : '<?php echo $EDLANG; ?>',
			        defaultLanguage : '<?php echo $EDLANG; ?>',
			        entities : true,
			        uiColor : '#FFFFFF',
					    height: '200px',
					    baseHref : '<?php echo $SITEURL; ?>',
			        toolbar : [ <?php echo $toolbar; ?> ]
					    <?php echo $EDOPTIONS; ?>
		    })
		  });
		</script>
		<input type="submit" class="submit" vaule="Add Ad" style="float:right;"/>
		</form>
		<div style="clear:both">&nbsp;</div>
<?php
	}

	elseif(isset($_GET['edit']))
	{
		global $SITEURL, $toolbar, $EDOPTIONS, $EDLANG;
		$ad_file = getXML(ADSDATAFILE);
		foreach($ad_file->category as $edit_cate)
		{	foreach($edit_cate->ad as $edit_ad)
			{
				if(urldecode($_GET['edit']) == $edit_ad->title)
				{
?>
				<h3>Edit Ad</h3>
				<form action="load.php?id=RandomAds&edit-ad" method="post" accept-charset="utf-8">
				<input type="text" name="title" class="text" style="width:635px;margin-bottom:5px;" value="<?php echo $edit_ad->title; ?>" />
				<input type="hidden" name="old-title" value="<?php echo $edit_ad->title; ?>" />
				<input type="hidden" name="category" value="<?php echo $edit_cate->categoryname; ?>" ?>
				<textarea name="contents"><?php echo $edit_ad->contents; ?></textarea>
				<script type="text/javascript" src="template/js/ckeditor/ckeditor.js"></script>
				<script type="text/javascript">
				  // missing border around text area, too much padding on left side, ...
				  $(function() {
				    CKEDITOR.replace( 'contents', {
					        skin : 'getsimple',
					        forcePasteAsPlainText : false,
					        language : '<?php echo $EDLANG; ?>',
					        defaultLanguage : '<?php echo $EDLANG; ?>',
					        entities : true,
					        uiColor : '#FFFFFF',
							    height: '200px',
							    baseHref : '<?php echo $SITEURL; ?>',
					        toolbar : [ <?php echo $toolbar; ?> ]
							    <?php echo $EDOPTIONS; ?>
				    })
				  });
				</script>
				<input type="submit" class="submit" vaule="Add Ad" style="float:right;"/>
				</form>
				<div style="clear:both">&nbsp;</div>
<?php
}
			}
		}
	}

	elseif(isset($_GET['categories']))
	{

?>			<h3>Add Category</h3>
			<form action="load.php?id=RandomAds&categories&add_category" method="post" accept-charset="utf-8">
				<p><input type="text" name="title" class="text" style="width:635px;" value="Category Title.." onFocus="if(this.value == 'Category Title..') {this.value = '';}" onBlur="if (this.value == '') {this.value = 'Category Title..';}" /></p>
				<input type="submit" class="submit" vaule="Add Category" style="float:right;"/>
			</form>		<div style="clear:both">&nbsp;</div>
		
<?php

			if(file_exists(ADSDATAFILE))
		{	
			$category_file = getXML(ADSDATAFILE);
		}

		$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');
		echo '<h3>Manage Categories</h3><table class="highlight">';
			$ad_count = '0';
		foreach($category_file->category as $category_name)
		{

				$ad_count++;
				$title = $category_name->categoryname;
				?>
				<tr>
				<td>
				<?php echo $title; ?>
				</td>
				<td class="delete">
				<a href="load.php?id=RandomAds&categories&delete_category=<?php echo $title; ?>" class="delconfirm" title="Delete Category: <?php echo $title; ?>?? This Will Delete ALL* Ads In The Category As Well!">
				X
				</a>
				</td>
				</tr>
<?php
		}

			echo '</table>';
			echo '<p><b>' . $ad_count . '</b> Ads</p>';	
}
	elseif(isset($_GET['help']))
	{
?>		<h3>Theme Functions:</h3>
		<p>You can include random ads in your template using the following function:</p>
		<ul>
		  <li><?php highlight_string('<?php display_ads(\'categoryname\'); ?>'); ?></li>
		</ul>
		<p>Filling in the category name will return a random ad from that category.<br/><strong> Make sure you place the category name exactly as it is set (case and space sensitive)</strong></p>
<?php
	}
	else{
			
		if(file_exists(ADSDATAFILE))
		{	
			$category_file = getXML(ADSDATAFILE);
		}

		$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>');

		foreach($category_file->category as $category_name)
		{
			$ad_count = '0';
			echo '<h3>'.$category_name->categoryname.'</h3><table class="highlight">';
			foreach($category_name->ad as $the_ad)
			{	
				$ad_count++;
				$contents = $the_ad->contents;
				$title = $the_ad->title;
				?>
				<tr>
				<td>
				<a href="load.php?id=RandomAds&edit=<?php echo $title; ?>" title="Edit Add: <?php echo $title; ?>">
				<?php echo $title; ?>
				</a>
				</td>
				<td class="delete">
				<a href="load.php?id=RandomAds&delete=<?php echo $title; ?>&category_of_deleted=<?php echo $category_name->categoryname; ?>" class="delconfirm" title="Delete Ad: <?php echo $title; ?>?">
				X
				</a>
				</td>
				</tr>
<?php
			}
			echo '</table>';
			echo '<p><b>' . $ad_count . '</b> Ads</p>';
		}

}}
?>