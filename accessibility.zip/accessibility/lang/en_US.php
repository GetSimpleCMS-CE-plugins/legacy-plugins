<?php
$i18n = array (
    'ACBL_PLUGIN_DESC'=>'Add an Accessibility Toolbar for people with vision problems',
	'ACBL_BUTTON'=>'Configure Accessibility',
	'ACBL_TITLE'=>'Accessibility Plugin',
	'ACBL_SUBMIT'=>'Save',
	'ACBL_FONTS'=>'Font size list separated by commas',
	'ACBL_WIDTH'=>'Toolbar Width (if empty width=100%)',
	'ACBL_WIDTH_DESC'=>'Numers only (eg. 1200)',
	'ACBL_STICKY'=>'Sticky Toolbar on Top',
	'ACBL_IS_IMG'=>'Show Images area on Toolbar',
	'ACBL_IS_BGR'=>'Show Backgrounds area on Toolbar',
	'ACBL_BGRD'=>'Backgrounds Count on Toolbar',
	'ACBL_LANG'=>'Site\'s default language (eg. "en_US")',
	'ACBL_SAVE_OK'=>'Your settings have been saved successfully.',
	'ACBL_HELP1'=>'Below is the HTML code for the button that calls up the Accessibility toolbar. You can insert this code anywhere in your theme\'s resource files. The button can contain picture only or can be with pictures and your text.',
	'ACBL_HELP2'=>'HTML code for the button which contain picture only:',
	'ACBL_HELP3'=>'HTML code for the button which contain picture and text:',
);

return $trans = array(
	'ACBL_SHOW'=>'show',
	'ACBL_DISB'=>'disable',
	'ACBL_FSIZE'=>'Font Size: ',
	'ACBL_IMG'=>'Images: ',
	'ACBL_BGR'=>'Background: ',
	'ACBL_SWT'=>'Switch off',
	'ACBL_FSMBL'=>'A',
	'ACBL_CLOSE'=>'X',
);
?>