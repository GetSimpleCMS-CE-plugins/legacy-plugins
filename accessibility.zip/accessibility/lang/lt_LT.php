<?php
$i18n = array (
    'ACBL_PLUGIN_DESC'=>'Pridėda Accessibility įrankių juostą žmonėms, turintiems regėjimo problemų',
	'ACBL_BUTTON'=>'Konfigūruoti Accessibility',
	'ACBL_TITLE'=>'Accessibility Įskiepis',
	'ACBL_SUBMIT'=>'Išsaugoti',
	'ACBL_FONTS'=>'Šrifto dydžio sąrašas atskirtas kableliais',
	'ACBL_WIDTH'=>'Įrankių juostos plotis (jei tuščia width=100%)',
	'ACBL_WIDTH_DESC'=>'Tik skaičiai (pvz., 1200)',
	'ACBL_STICKY'=>'Sticky įrankių juostą viršuje',
	'ACBL_IS_IMG'=>'Rodyti paveikslelių sritį juostoje',
	'ACBL_IS_BGR'=>'Rodyti fonų sritį juostoje',
	'ACBL_BGRD'=>'Fonų jungiklių kiekis juostoje',
	'ACBL_LANG'=>'Numatytoji svetainės kalba (pvz., "lt_LT")',
	'ACBL_SAVE_OK'=>'Jūsų nustatymai sėkmingai išsaugoti.',
	'ACBL_HELP1'=>'Žemiau yra mygtuko, kuris iškviečia Accessibility įrankių juostą, HTML kodas. Šį kodą galite įterpti bet kur į savo temos išteklių failus. Mygtuke gali būti tik paveikslėlis arba jis gali būti su paveikslėliu ir jūsų tekstu.',
	'ACBL_HELP2'=>'Mygtuko, kuriame yra tik paveikslėlis, HTML kodas:',
	'ACBL_HELP3'=>'Mygtuko, kuriame yra paveikslėlis ir tekstas, HTML kodas:',
);

return $trans = array(
	'ACBL_SHOW'=>'rodyti',
	'ACBL_DISB'=>'atjungti',
	'ACBL_FSIZE'=>'Šrifto dydis: ',
	'ACBL_IMG'=>'Paveiksliukai: ',
	'ACBL_BGR'=>'Fonas: ',
	'ACBL_SWT'=>'Išjungti',
	'ACBL_FSMBL'=>'A',
	'ACBL_CLOSE'=>'X',
);
?>