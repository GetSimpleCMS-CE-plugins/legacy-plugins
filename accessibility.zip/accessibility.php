<?php
$accebl_ver = '1.1';
/*
Plugin Name: Accessibility plugin
Description: Add an Accessibility Toolbar for people with vision problems
Version: 1.1
Author: Andrejus Semionovas
Author URI: http://pigios-svetaines.eu/
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# language support
i18n_merge($thisfile, substr($LANG,0,2)) || i18n_merge($thisfile, $LANG) || i18n_merge($thisfile, 'en') || i18n_merge($thisfile, 'en_US');

$accebl_path = $SITEURL."plugins/accessibility/";
$acbl_file = GSDATAOTHERPATH.$thisfile.".xml";

# register plugin
register_plugin(
	$thisfile, 										# ID of plugin, should be filename minus php
	'Accessibility plugin',							# Title of plugin
	$accebl_ver, 									# Version of plugin
	'Andrejus Semionovas',							# Author of plugin
	'http://pigios-svetaines.eu/', 					# Author URL
	i18n_r($thisfile.'/ACBL_PLUGIN_DESC'), 	    	# Plugin Description
	'plugins', 										# Page type of plugin
	'accebl_settings'  								# Function that displays content
);

# activate hooks
add_action('plugins-sidebar','createSideMenu',array($thisfile, i18n_r($thisfile.'/ACBL_BUTTON'))); 	// Add the sidebar 
add_action('theme-footer','accebl_scriptstoFooter');
register_style('acblcss', $SITEURL.'plugins/accessibility/scripts/accessebility.css', $accebl_ver, 'screen');
queue_style('acblcss', GSFRONT);

function accebl_settings() {
	global $accebl_path, $accebl_ver, $acbl_file; ?>
<style>
.widesec {
    overflow: auto;
}
.accessibil .acbl-label {
    font-size: 14px;
}
.acbl_input {
    color: #333;
    border: 1px solid #AAA;
    padding: 5px;
    font-family: Arial,Helvetica Neue,Helvetica,sans-serif;
    font-size: 12px;
    border-radius: 2px;
    width: 95%;
}
.chkbox .acbl-label {
    float: left;
	margin-top: 2px;
	cursor: pointer;
}
.chkbox .acbl_input {
    float: right;
	width: auto;
	margin: 6px 14px 0 0;
}
.acbl_input.number {
    width: 40px;
	float: right;
	margin: 0 12px 0 0;
}
.change-button {
	padding: 2px 10px;
	cursor: pointer;
}
.fancy-message {
    border: 1px solid;
    padding: 20px 10px 10px 10px;
    border-radius: 4px;
    margin-bottom: 20px;
	overflow: auto;
}
.fancy-message.error {
	background: #F2DEDE;
	color: #A94442;
}
.fancy-message.seccess {
    background: #DFF0D8;
    color: #3C8C8F;
}
.fancy-message.info {
    background: #D9EDF7;
    color: #31708F;
}
.fancy-message p {
    font-size: 14px;
    float: none;
    text-align: justify;
}
pre.code {
    color: green;
    background: white;
    padding-top: 10px;
	margin-top: 10px;
}
</style> <?php
	if(isset($_POST['acbl_save_set']) && $_POST['acbl_save_set']) {
		$acbl_xml = getXML($acbl_file);
		$acbl_xml->acbl_flist = $_POST['acbl_font_list'];
		$acbl_xml->acbl_width = preg_replace("/[^0-9]/", "",$_POST['acbl_width']);
		$acbl_xml->acbl_mode = isset($_POST['acbl_mode']) ? 1 : 0;
		$acbl_xml->acbl_img = isset($_POST['acbl_img']) ? 1 : 0;
		$acbl_xml->acbl_is_bg = isset($_POST['acbl_is_bg']) ? 1 : 0;
		$acbl_xml->acbl_bgr = isset($_POST['acbl_bgr']) ? $_POST['acbl_bgr'] : 2;
		$acbl_xml->acbl_lang = isset($_POST['acbl_lang']) ? $_POST['acbl_lang'] : '';
		XMLsave($acbl_xml, $acbl_file);
		?> <div id="save_mess" class="fancy-message seccess"><p><?php i18n('accessibility/ACBL_SAVE_OK'); ?></p></div>
<script>
	jQuery(function(){setTimeout(function(){jQuery("#save_mess").hide('slow');},10000);})
</script> <?php
	}
	$acbl_values = accebl_get_settings($acbl_file);
?>
	<h3><?php i18n('accessibility/ACBL_TITLE'); ?><span style="margin-left: 16px;">ver. <?php echo $accebl_ver; ?></span></h3>
	<form action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>" method="post" class="accessibil" name="accessibil">
		<div class="edit-nav" style="clear:both;margin: 0;">
			<div class="widesec">
				<div class="leftsec">
					<label class="acbl-label"><?php i18n('accessibility/ACBL_FONTS'); ?></label>
				</div>
				<div class="rightsec">
					<input type="text" name="acbl_font_list" class="acbl_input" value="<?php echo (isset($acbl_values['acbl_flist']) && strlen($acbl_values['acbl_flist'])>0) ? $acbl_values['acbl_flist'] : '17, 19, 21' ?>"/>
				</div>
			</div>
			<div class="widesec">
				<div class="leftsec">
					<label class="acbl-label"><?php i18n('accessibility/ACBL_WIDTH'); ?></label>
				</div>
				<div class="rightsec">
					<input type="text" name="acbl_width" class="acbl_input" value="<?php echo (isset($acbl_values['acbl_width']) && strlen($acbl_values['acbl_width'])>0) ? $acbl_values['acbl_width'] : '' ?>" placeholder="<?php i18n('accessibility/ACBL_WIDTH_DESC'); ?>"/>
				</div>
			</div>
			<div class="widesec">
				<div class="leftsec chkbox">
					<label class="acbl-label" for="acbl_mode"><?php i18n('accessibility/ACBL_STICKY'); ?></label>
					<input type="checkbox" id="acbl_mode" name="acbl_mode" class="acbl_input" value=1<?php echo (isset($acbl_values['acbl_mode']) && $acbl_values['acbl_mode']==1)?" checked":"" ?>/>
				</div>
				<div class="rightsec chkbox">
					<label class="acbl-label" for="acbl_img"><?php i18n('accessibility/ACBL_IS_IMG'); ?></label>
					<input type="checkbox" id="acbl_img" name="acbl_img" class="acbl_input" value=1<?php echo (isset($acbl_values['acbl_img']) && $acbl_values['acbl_img']==1)?" checked":"" ?> />
				</div>
			</div>
			<div class="widesec">
				<div class="leftsec chkbox">
					<label class="acbl-label" for="acbl_is_bg"><?php i18n('accessibility/ACBL_IS_BGR'); ?></label>
					<input type="checkbox" id="acbl_is_bg" name="acbl_is_bg" class="acbl_input" value=1<?php echo (isset($acbl_values['acbl_is_bg']) && $acbl_values['acbl_is_bg']==1)?" checked":"" ?>/>
				</div>
				<div class="rightsec chkbox">
					<label class="acbl-label" for="acbl_bgr"><?php i18n('accessibility/ACBL_BGRD'); ?></label>
					<input type="number" id="acbl_bgr" name="acbl_bgr" MIN="1" MAX="3" SIZE="3" class="acbl_input number" value="<?php echo isset($acbl_values['acbl_bgr'])?$acbl_values['acbl_bgr']:2 ?>" />
				</div>
			</div>
			<div class="widesec">
				<label class="acbl-label"><?php i18n('accessibility/ACBL_LANG'); ?></label>
				<input type="text" name="acbl_lang" class="acbl_input" value="<?php echo (isset($acbl_values['acbl_lang']) && strlen($acbl_values['acbl_lang'])>0) ? $acbl_values['acbl_lang'] : '' ?>" style="width: 60px;margin-left: 6px;" />
			</div>
			<div class="widesec" style="margin: 20px 0 0 0;padding: 0;">
				<input type="submit" name="acbl_save_set" class="change-button" value="<?php i18n('accessibility/ACBL_SUBMIT'); ?>" />
			</div>
			<div class="widesec" style="margin-top: 30px;">
				<div class="fancy-message info">
					<p><?php i18n('accessibility/ACBL_HELP1'); ?></p>
					<p style="margin-top: 10px;"><?php i18n('accessibility/ACBL_HELP2'); ?></p>
					<pre class="code">
&lt;div class="accessibility-outer">
   &lt;span id="noblind_btn">
      &lt;a href="javascript://" onclick="accbl()" title="Version for visually impaired">
         &lt;div class="accessibility">&lt;/div>
      &lt;/a>
   &lt;/span>
&lt;/div>
					</pre>
					<p style="margin: 10px 0;"><?php i18n('accessibility/ACBL_HELP3'); ?></p>
					<pre class="code">
&lt;div class="accessibility-outer">
   &lt;span id="noblind_btn">
      &lt;a href="javascript://" onclick="accbl()" title="Version for visually impaired">
         &lt;div class="accessibility with-text">
            &lt;span class="accessibility-text">Accessibility version&lt;/span>
         &lt;/div>
      &lt;/a>
   &lt;/span>
&lt;/div>
					</pre>
				</div>
			</div>
		</div>
	</form> <?php	
}

function accebl_get_settings($filename) {
	$acbl_values = false;
	if (!file_exists($filename)) {
		$acbl_xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><acbl_config></acbl_config>');
		$acbl_xml->addChild('acbl_flist', '17, 19, 21');
		XMLsave($acbl_xml, $filename);
	}
	else {
		$acbl_xml = getXML($filename);
		$acbl_values['acbl_flist'] = $acbl_xml->acbl_flist;
		$acbl_values['acbl_width'] = $acbl_xml->acbl_width;
		$acbl_values['acbl_mode'] = $acbl_xml->acbl_mode;
		$acbl_values['acbl_img'] = $acbl_xml->acbl_img;
		$acbl_values['acbl_is_bg'] = $acbl_xml->acbl_is_bg;
		$acbl_values['acbl_bgr'] = $acbl_xml->acbl_bgr;
		$acbl_values['acbl_lang'] = $acbl_xml->acbl_lang;
	}
	return $acbl_values;
}

function accebl_scriptstoFooter() {
	global $LANG, $SITEURL, $accebl_path, $acbl_file, $acbl_values, $thisfile;
	$acbl_values = accebl_get_settings($acbl_file);
	if(isset($acbl_values['acbl_flist']) && strlen($acbl_values['acbl_flist']) > 0) {
		$flist = explode(",", $acbl_values['acbl_flist']);
		$fonts = array();
		foreach($flist as $font) {
			$fonts[] = trim($font);
		}
	} else $fonts = array('17','19','21');
	if(isset($acbl_values['acbl_width'])) {
		if(strlen(($acbl_values['acbl_width']) <= 0)) $acbl_width = 'false';
		else $acbl_width = preg_replace("/[^0-9]/", "", $acbl_values['acbl_width']);
	} else $acbl_width = 1200;
	if(isset($acbl_values['acbl_mode']) && $acbl_values['acbl_mode']==0) {
		$acbl_mode = 1;
	} else $acbl_mode = 2;
	if(isset($acbl_values['acbl_img']) && $acbl_values['acbl_img']) {
		$acbl_img = (int)$acbl_values['acbl_img'];
	} else $acbl_img = 1;
	if(isset($acbl_values['acbl_is_bg']) && $acbl_values['acbl_is_bg']) {
		$acbl_is_bg = (int)$acbl_values['acbl_is_bg'];
	} else $acbl_is_bg = 1;
	if(isset($acbl_values['acbl_bgr']) && strlen($acbl_values['acbl_bgr']) > 0) {
		$count = (int)$acbl_values['acbl_bgr'];
		$bgrs = array();
		for($i=0; $i < $count; $i++) {
			$bgrs[] = $i+1;
		}
	} else $bgrs = array('1','2');
	if(isset($acbl_values['acbl_lang']) && $acbl_values['acbl_lang']) {
		$acbl_lang = $acbl_values['acbl_lang'];
		if(strpos($acbl_lang, "-") !== false) $acbl_lang = str_replace("-", "_", $acbl_lang);
		if (file_exists(str_replace('\\','/',dirname(__FILE__)).'/accessibility/lang/'.$acbl_lang.'.php')) {
			include(str_replace('\\','/',dirname(__FILE__)).'/accessibility/lang/'.$acbl_lang.'.php');
		} else {
			include(str_replace('\\','/',dirname(__FILE__)).'/accessibility/lang/en_US.php');
		}
	} else {
		include(str_replace('\\','/',dirname(__FILE__)).'/accessibility/lang/en_US.php');
		$acbl_lang = "en_US";
	}
?>
<script>
if (typeof jQuery == 'undefined') {
	document.write('<script type="text/javascript" src="<?php echo $SITEURL; ?>admin/template/js/jquery.min.js"><\/script>');        
}
</script>
<script src="<?php echo $accebl_path; ?>scripts/accessibility.min.js"></script>
<script>
var uhe=<?=$acbl_mode?>, lang="<?=$acbl_lang?>", has=0, imgs=<?=$acbl_img?>, bg=<?=$acbl_is_bg?>, hwidth=<?=$acbl_width?>, bgs=<?=json_encode($bgrs)?>, fonts=<?=json_encode($fonts)?>;
langs['<?=$acbl_lang?>'] = {1:'<?=$trans['ACBL_SHOW']?>',2:'<?=$trans['ACBL_DISB']?>',3:'<?=$trans['ACBL_FSIZE']?>',4:'<?=$trans['ACBL_IMG']?>',5:'<?=$trans['ACBL_BGR']?>',6:'<?=$trans['ACBL_SWT']?>',7:'<?=$trans['ACBL_FSMBL']?>',8:'<?=$trans['ACBL_CLOSE']?>'};
$(document).ready(function(){noBlind(has);if($('#noblind_outer').length){$('.accessibility-outer').hide()}else{$('.accessibility-outer').show();}});
</script> <?php
}
?>