Free Disk Space cPanel
v1.0
Modification of Free Disk Space plugin to show used/remaining disk space on cPanel hosting.

**

1. Download, unzip and open plugin in text/code editor
2. The CODE IS COMMENTED WHERE YOU NEED TO ENTER YOUR CPANEL USERNAME AND PASSWORD
3. Upload to "plugins" folder on your cPanel Get Simple CMS installation