<?php
/*
Plugin Name: Free Disk Space cPanel
Description: Shows available disk space on cPanel hosting account in "Files" page
Version: 1.0
Author: Borislav Dopudja
Author URI: borislav.dopudja@arboretum.hr
**
The plugin is based Free Disk Space plugin, written by Joshas.
The cPanel data reading code was provided by Miron Jajtic.
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile,
	'Free Disk Space cPanel',
	'1.0',
	'Borislav Dopudja',
	'http://www.arboretum.hr/',
	'Shows available free disk space on cPanel hosting account in "Files" page'
);

# attach hook
add_action('files-sidebar','display_disk_usage');

#function
function display_disk_usage() {


// SETTINGS - START

// PUT YOUR CPANEL HOSTING USERNAME HERE:
	$username = "USERNAME";

// PUT YOUR CPANEL HOSTING USERNAME HERE:
	$password = "PASSWORD";

// MODIFY THIS PATH TO REFLECT YOUR DOMAIN, REPLACING "DOMAIN-NAME" AND "YOUR-CPANEL-USERNAME":
	$query ="http://DOMAIN-NAME:2082/xml-api/cpanel?user=USERNAME&cpanel_xmlapi_module=StatsBar&cpanel_xmlapi_func=stat&display=diskusage";

// SETTINGS - END


	$curl = curl_init();
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
	curl_setopt($curl, CURLOPT_HEADER,0);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl, CURLOPT_USERPWD, $username.":".$password);
	curl_setopt($curl, CURLOPT_URL, $query);
	$result = curl_exec($curl);
	curl_close($curl); 

	$xml = simpleXML_load_string($result);

	$df = $xml->data[0]->_count; // used MB
	$ds = $xml->data[0]->_max; // max MB
	$du = $ds - $df; // free MB
	if ($ds > 0) $perc = number_format(100 * $du / $ds, 2); else $perc = 0;
	$color = '#e87d7d';
	if ($perc > 50) $color = '#e8cf7d';
	if ($perc > 70) $color = '#ace97c';
	echo '<li style="font-weight:bold;padding:5px 15px;border-radius:4px;-moz-border-radius:4px;-webkit-border-radius:4px;background-color:#182227;margin-left:13px;color:#afc5cf;">'
		.'Free disk space'
		.'<div style="border:1px solid #ccc;width:100%;margin:2px 5px 2px 0;padding:1px">'
		.'<div style="width:'.$perc.'%;background-color:'.$color.';height:6px"></div></div>'
		.$du.' of '.$ds.' MB free'.'</li>';
}
?>