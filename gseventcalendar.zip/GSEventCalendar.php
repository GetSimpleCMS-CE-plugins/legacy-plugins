<?php

global $LANG;
global $SITEURL;

$thisfile = basename(__FILE__, ".php");
register_plugin(
        $thisfile, //Plugin id
        'Events', //Plugin name
        '0.2', //Plugin version
        'Andre Bölts', //Plugin author
        'http://www.voltosoft.de', //author website
        'Create Event List', //Plugin description
        'pages', //page type - on which admin tab to display
        'show_event_list'  //main function (administration)
);
if (function_exists('i18n_load_texts')) {
    i18n_load_texts('GSEventCalendar');
} else {
    i18n_merge('GSEventCalendar', substr($LANG, 0, 2)) || i18n_merge('GSEventCalendar', 'en');
}
add_action('pages-sidebar', 'createSideMenu', array($thisfile, i18n_r("GSEventCalendar/OpenEventList")));
register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
queue_script('jquery', GSBACK);
register_script('eventCreate.script', $SITEURL . 'plugins/GSEventCalendar/scripts/eventCreate.script.js', '0.1', FALSE);
queue_script('eventCreate.script', GSBACK);
register_style('formStyle', $SITEURL . 'plugins/GSEventCalendar/scripts/formStyle.css', GSVERSION, 'screen');
queue_style('formStyle', GSBACK);

add_filter('content', 'getDisplayEventListinContent');

function getDisplayEventListinContent($content) {
    return preg_replace("(\\(% GSEventCalendar %\\))", getDisplayEventList(), $content);
}

function NodeRemove($file, $id) {
    $dom = new DOMDocument();
    $dom->load($file);
    $root = $dom->documentElement;
    $events = $root->getElementsByTagName("event");
    foreach ($events as $event) {
        $eid = $event->getAttribute("id");
        if ($eid == $id) {
            $parent = $event->parentNode;
            $parent->removeChild($event);
        }
    }
    $dom->save($file);
}

function NodeAdd($file, $id, $start, $end, $title, $location, $discription) {
    $dom = new DOMDocument();
    $dom->load($file);
    $newEvent = $dom->createElement("event");
    if (isset($id) && !($id == NULL || $id == '')) {
        $newEvent->setAttribute("id", $id);
    }
    $newEventDate = $dom->createElement("date");
    $newEventDateStart = $dom->createElement("start");
    $newEventDateStart->appendChild($dom->createTextNode($start));
    $newEventDate->appendChild($newEventDateStart);
    $newEventDateEnd = $dom->createElement("end");
    $newEventDateEnd->appendChild($dom->createTextNode($end));
    $newEventDate->appendChild($newEventDateEnd);
    $newEvent->appendChild($newEventDate);
    $newEventTile = $dom->createElement("title");
    $newEventTile->appendChild($dom->createTextNode($title));
    $newEvent->appendChild($newEventTile);
    $newEventLocation = $dom->createElement("location");
    $newEventLocation->appendChild($dom->createTextNode($location));
    $newEvent->appendChild($newEventLocation);
    $newEventDiscription = $dom->createElement("discription");
    $newEventDiscription->appendChild($dom->createTextNode($discription));
    $newEvent->appendChild($newEventDiscription);
    $dom->documentElement->appendChild($newEvent);
    $dom->save($file);
}

function show_event_list() {
    if (isset($_GET['event'])) {
        $file = GSDATAOTHERPATH . 'gs_event_calendar_data.xml';
        if (@$_GET['event'] == 'delete') {
            NodeRemove($file, @$_GET['eventid']);
        } else if (@$_GET['event'] == 'save') {
            NodeAdd($file, htmlentities($_POST['eventid'], ENT_QUOTES), htmlentities($_POST['start'], ENT_QUOTES), htmlentities($_POST['end'], ENT_QUOTES), preg_replace("/\r\n|\r|\n/i", "<br />", htmlentities($_POST['title'], ENT_QUOTES)), preg_replace("/\r\n|\r|\n/i", "<br />", htmlentities($_POST['location'], ENT_QUOTES)), preg_replace("/\r\n|\r|\n/i", "<br />", htmlentities($_POST['discription'], ENT_QUOTES)));
        }/* else if (@$_GET['event'] == 'edit') {

          } */
    }
    termin_header();
    getDisplayEventList_admin(getEventData());
    getCreateElements();
}

function termin_header() {
    echo '<h2>Event List</h2>';
    echo '<a class="event" href="#create">' . i18n_r("GSEventCalendar/CreateEvent") . '</a>';
}

function getDisplayEventList_admin($events = null) {
    if (is_null($events)) {
        $file = GSDATAOTHERPATH . 'gs_event_calendar_data.xml';
        if (!is_file($file))
            $events = @new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><root></root>');
        XMLsave($events, $file);
    }
    echo '<table><tbody>
        <tr><th>' . i18n_r("GSEventCalendar/EventStart") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventEnd") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventName") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventLocation") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventDiscription") . '</th>
            <td></td>
            </tr>';
    foreach ($events->children() as $event) {
        echo '<tr class="eventRow" id="' . $event["id"] . '">';
        echo '<td>' . date_format(new DateTime($event->date[0]->start[0]), 'd.m Y H:i:s') . '</td>';
        echo '<td>' . date_format(new DateTime($event->date[0]->end[0]), 'd.m Y H:i:s') . '</td>';
        echo '<td>' . $event->title[0] . '</td>';
        echo '<td>' . $event->location[0] . '</td>';
        echo '<td>' . $event->discription[0] . '</td>';
        echo '<td><a class="event" href="' . $SITEURL . 'load.php?id=GSEventCalendar&event=delete&eventid=' . $event['id'] . '">' . i18n_r("GSEventCalendar/Delete") . '</a><br />';
        /*        echo '<a class="event" href="' . $SITEURL . 'load.php?id=GSEventCalendar&event=edit&eventid=' . $event['id'] . '">' . i18n_r("GSEventCalendar/Edit") . '</a>'; */
        echo '</td></tr>';
    }
    echo '</tbody></table>';
}

function getEventData() {
    $events = null;
    $file = GSDATAOTHERPATH . 'gs_event_calendar_data.xml';
    if (is_file($file)) {
        $events = getXML($file);
    }
    return $events;
}

function getDisplayEventList() {

    $events = getEventData();
    if ($events == null)
        return "";
    $out = '<table><tbody>
        <tr><th>' . i18n_r("GSEventCalendar/EventStart") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventEnd") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventName") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventLocation") . '</th>
            <th>' . i18n_r("GSEventCalendar/EventDiscription") . '</th>
            </tr>';
    foreach ($events->children() as $event) {
        $start = new DateTime($event->date[0]->start[0]);
        $end = new DateTime($event->date[0]->end[0]);
        if (($start->getTimestamp() >= mktime()) || ($end->getTimestamp() >= mktime())) {
            $out .= '<tr class="eventRow" id="' . $event["id"] . '">';
            $out .= '<td>' . date_format(new DateTime($event->date[0]->start[0]), 'd.m Y H:i:s') . '</td>';
            $out .= '<td>' . date_format(new DateTime($event->date[0]->end[0]), 'd.m Y H:i:s') . '</td>';
            $out .= '<td>' . $event->title[0] . '</td>';
            $out .= '<td>' . $event->location[0] . '</td>';
            $out .= '<td>' . $event->discription[0] . '</td>';
            $out .= '</tr>';
        }
    }
    $out .= '</tbody></table>';
    return $out;
}

function getCreateElements() {
    echo '<form id="form1" name="form1" method="post" action="' . $SITEURL . 'load.php?id=GSEventCalendar&event=save">';
    echo '<table class="editevent" style="display:none;"><tbody>';
    echo '<tr><td>' . i18n_r("GSEventCalendar/EventStart") . '</td><td><input type="hidden" name="id" id="eventid" />
                                                                  <input type="text" name="start" id="start" /></td><tr/>';
    echo '<tr><td>' . i18n_r("GSEventCalendar/EventEnd") . '</td><td><input type="text" name="end" id="end" /></td><tr/>';
    echo '<tr><td>' . i18n_r("GSEventCalendar/EventName") . '</td><td><input type="text" name="title" id="title" /></td><tr/>';
    echo '<tr><td>' . i18n_r("GSEventCalendar/EventLocation") . '</td><td><input type="text" name="location" id="location" /></td><tr/>';
    echo '<tr><td>' . i18n_r("GSEventCalendar/EventDiscription") . '</td><td><textarea name="discription" id="discription"></textarea></td><tr/>';
    echo '<tr><td /><td><input type="submit" value="' . i18n_r("GSEventCalendar/EventSave") . '"><input type="reset" value="' . i18n_r("GSEventCalendar/Clear") . '" /></td></tr>';
    echo '</tbody></table>';
    echo '</form>';
}
?>

