<?php

if (!defined('IN_GS')) {
    die('you cannot load this page directly.');
}
header("Content-Type: text/calendar; charset=utf-8");
global $SITEURL;
$events = getEventData();
echo "BEGIN:VCALENDAR\n";
echo "VERSION:2.0\n";
echo "PRODID:GSEventCalendar v0.2 @" . $SITEURL . "\n";
echo "METHOD:PUBLISH";
foreach ($events->children() as $event) {
    echo "BEGIN:VEVENT\n";
    echo "UID:Termin-" . $event->id[0] . "@" . $SITEURL . "\n";
    echo "SUMMARY:" . $event->title[0]. "\n";
    echo "DESCRIPTION:" . $event->discription[0] . "\n";
    echo "LOCATION:" . $event->location[0] . "\n";
    echo "DTSTART:" . date_format(new DateTime($event->date[0]->start[0]), 'Ymd\THis') . "\n";
    echo "DTEND:" . date_format(new DateTime($event->date[0]->start[0]), 'Ymd\THis') . "\n";
    echo "END:VEVENT\n";
}
echo "END:VCALENDAR\n";
?>

