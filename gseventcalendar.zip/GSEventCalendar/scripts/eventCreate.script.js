$(document).on("click", "a.event[href=#create]", function(){
    $("table.editevent").show();
    var list = $('tr.eventRow[id]').map(function(){
        return parseInt($(this).attr("id"), 10);
    }).get();
    var max = Math.max.apply( Math, list ); 
    $("input[name=id]").val(max+1);
});
