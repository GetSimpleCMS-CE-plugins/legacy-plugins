<?php

$i18n = array(
    'OpenEventList' => 'Termin Liste',
    'CreateEvent' => 'Termin Erstellen',
    'NoEvents' => 'Keine Termine vorhanden',
    'EventStart' => 'Termin Anfang',
    'EventEnd' => 'Termin Ende',
    'EventName' => 'Veranstaltung',
    'EventLocation' => 'Ort',
    'EventDiscription' => 'Beschreibung',
    'Delete' => 'Termin Löschen',
    'Edit' => 'Termin Bearbeiten',
    'EventSave' => 'Termin Speichern',
    'Clear' => 'Abbrechen',
);