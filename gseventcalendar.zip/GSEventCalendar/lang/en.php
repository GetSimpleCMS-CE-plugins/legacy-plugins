<?php

$i18n = array(
    'OpenEventList' => 'Event List',
    'CreateEvent' => 'Ceate Event',
    'NoEvents' => 'No Events aviable',
    'EventStart' => 'Event Start',
    'EventEnd' => 'Event Stop',
    'EventName' => 'Name',
    'EventLocation' => 'Location',
    'EventDiscription' => 'Discription',
    'Delete' => 'Delete Event',
    'Edit' => 'Edit Event',
);