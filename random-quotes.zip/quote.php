<?

$thisfile=basename(__FILE__, ".php");

register_plugin(
	$thisfile, 					# ID of plugin, should be filename minus php
	'Quote plugin', 				# Title of plugin
	'0.1', 					# Version of plugin
	'Mikkel Bundgaard',			# Author of plugin
	'http://www.mikkelbundgaard.dk', # Author URL
	'quote plugin', 				# Plugin Description
	'plugins', 					# Page type of plugin
	'quotes_show'  				# Function that displays content
);

//require GSPLUGINPATH . '/quote/quote.class.php';

add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'Quotes'));


function quotes_show()
{


	$quotes = new Quotes();
	if (isset($_GET['add']) || isset($_GET['edited'])) 
	{
		if (isset($_GET['add']))
		{

			$quotes->createQuote($_POST['quote'], $_POST['author'], strftime("%A, %d %B, %Y"));
				
		} 
	} else
	if (isset($_GET['delete']))
	{
		  $quotes->deleteQuote($_GET['qid']);
	}

	

	print("<h3>Manage quotes</h3>");
	print('<form action="load.php?id=quote&');
	if(isset($_GET['edit'])) {
		echo 'edited='.$_GET['edit'];
	}
	else {
		echo 'add=y';
	}
	echo '" method="post" id="quote">';

	echo "<h2>Add a new entry:</h2>";
	print('<form action="load.php?id=quote&');
	if(isset($_GET['edit'])) {
		echo 'edited='.$_GET['edit'];
	}
	else {
		echo 'add=y';
	}
	echo '" method="post" id="quote">';
	print("<h3>Quote:</h3> <p><input type=\"text\" name=\"quote\" class=\"text title\"");
	if(isset($_GET['edit'])) {
		echo 'value="'.$posts[$_GET['edit']]->quote.'"';
	}
	echo ' /></p>';
	
	print("<h3>Author:</h3> <p><input type=\"text\" name=\"author\" class=\"text title\"");
	if(isset($_GET['edit'])) {
		echo 'value="'.$posts[$_GET['edit']]->author.'"';
	}
	echo '/></p>';
	
	

	print("<p><input type=\"submit\" value=\"");
	if(isset($_GET['edit'])) {
		echo 'Edit Quote';
	}
	else {
		echo 'Add Quote';
	}
	echo '" /></p>';
	print("</form>");



	echo '<table>';
	echo '<th>ID</th><th>Quote</th><th>Author</th><th>Delete</th>';
	foreach ($quotes->getQuotes() as  $quote)
	{
		echo '<tr>';
		echo '<td>' . $quote['id'] . '</td>';
		echo '<td>' .  $quote->quote . '</td>';
		echo '<td>' . $quote->author . '</td>';
		echo '<td> <a href="load.php?id=quote&delete=y&qid='.  $quote['id'] .'">Delete</a></td>';
		echo '</tr>';

	}
	echo '</table>';
		


}

function quote()
{
  $quotes = new Quotes();
  $quoteArray= $quotes->getQuotes();
  $ran = rand(0, (sizeof($quoteArray)-1));
  $i=0;	
  
  foreach($quoteArray as $quote)
  {
	
	if($i==$ran) {
	
		break;
	}
	$i++;
  }
  	  echo $quote->quote . " - <i>" . $quote->author . "</i>";
  //echo "num" . $i . "ran" . $ran;

}


class Quotes 
{
	private $xmlfile = "";

		public function __construct()
		{
			$xmlfile = GSDATAOTHERPATH . 'quotes.xml';
			$this->shandle = new SimpleXMLExtended(file_get_contents($xmlfile));
			$this->xmlfile = $xmlfile;
		}

		public function getQuotes() 
		{
			$id = 0;
			$posts_arr = array();
			if($this->shandle) {
				foreach($this->shandle->quote as $post) {
			
					$post->quote = html_entity_decode($post->quote);	
					$post->author = html_entity_decode($post->author);	
					$post->date= html_entity_decode($post->date);	
					
					$posts_arr[(int)$post['id']] = $post;	
				}
				//krsort($posts_arr);
				return $posts_arr;
			}
		}		

		private function getLastPostID() 
		{
			$maxID = 0;
			foreach($this->shandle->quote as $post) {
				if($post['id']>=$maxID) 
					{
						$maxID=$post['id']+1; 
					};
			}
			
			return $maxID-1;
			/*if($this->shandle) {
			//	return (sizeof($this->shandle->quote) - 1);
			//}*/
		}
		
		public function createQuote($quote, $author, $date, $id=null) 
		{
			$post_add = $this->shandle->addChild('quote');
			$quote = htmlentities($quote, ENT_QUOTES, 'UTF-8');
			$author = htmlentities($author, ENT_QUOTES, 'UTF-8');
			
			if($id == null) {
				$id = $this->getLastPostID() + 1;
			}
			
			$post_add->addAttribute('id', $id);
			$post_add->addChild('quote', $quote);
			$post_add->addChild('date', $date);
			$post_add->addChild('author', $author);
			$xml = $post_add->addChild('quote');
			$xml->addCData($quote);
			
			$this->shandle->asXML($this->xmlfile);
			
		}	

		public function deleteQuote($id) {
			if($this->shandle) {
				$target = false;
				$i = 0;
				foreach($this->shandle->quote as $post) {
					if($post['id'] == $id) {
						$target = $i;
						break;
					}
					$i++;
				}
				if($target !== false) {			
					unset($this->shandle->quote[$target]);
				}
				$this->shandle->asXML($this->xmlfile);		
				return 0;
			}
		}

}



?>
