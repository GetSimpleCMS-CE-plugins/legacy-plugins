<?php
/*
Plugin Name: Theme Selector
Description: Generate a webpage with a quick preview of all themese installed to be selected
Version: 0.4b
Author: Dominion IT (Johannes Pretorius)
Author URI: http://www.dominion-it.co.za/
GS Version : 2.01
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'Theme Selector', 	# Title of plugin
	'0.4b', 		# Version of plugin
	'Johannes Pretorius',	# Author of plugin
	'http://www.dominion-it.co.za/', 	# Author URL
	' Generate a webpage with a quick preview of all themese installed to be selected', 	# Plugin Description
	'theme', 	# Page type of plugin
	'show_theme_previews'  	# Function that displays content
);

# activate filter
add_action('theme-sidebar','createSideMenu',array($thisfile,'Themes Selector'));

function show_theme_previews(){
       global $TEMPLATE;
       $path = GSTHEMESPATH ;
       global $SITEURL;
       
       if (isset($_GET['TN'])) {
         $newActiveName = $_GET['TN']; 
           ///Is valid template selected./.. safety measure.
     
         
         if ((is_dir($path . $newActiveName)) && (is_file(($path .$newActiveName.'/template.php')))) {
           //yes.. k.. lets save as default temaplte
 
            $pathToOther = GSDATAOTHERPATH;
            $file = "website.xml";
        	// create new site data file
        	$bakpath = GSBACKUPSPATH.'other/';
        	createBak($file, $pathToOther, $bakpath);
            global $SITENAME;
            global $TIMEZONE;
            global $LANG;
            global $i18n;
            
        	// Update changes
        	$xml = @new SimpleXMLExtended('<item></item>');
        	$note = $xml->addChild('SITENAME');
        	$note->addCData($SITENAME);
        	$note = $xml->addChild('SITEURL');
        	$note->addCData(@$SITEURL);
        	$note = $xml->addChild('TEMPLATE');
        	$note->addCData(@$newActiveName);
        	$note = $xml->addChild('TIMEZONE');
        	$note->addCData(@$TIMEZONE);
        	$note = $xml->addChild('LANG');
        	$note->addCData(@$LANG);
        	$xml->asXML($pathToOther . $file);
        	$success = $i18n['THEME_CHANGED'];
            $TEMPLATE = $newActiveName;
         }
       }
        
        
        $filenames = getFiles($path); 
        $amountThemese = 0;
        if (count($filenames) != 0) {
            foreach ($filenames as $file) {
                if ((is_dir($path . $file) && !(($file == "." || $file == ".." ||  $file == ".htaccess"))) && (is_file($path . $file."/template.php"))) {
                  $amountThemese++;
                } 
            }
        }        
        $amountThemese = round(((($amountThemese / 2)+($amountThemese % 2)) * 305)) + 50;
        
//        $js_tooltipPath = $SITEURL."plugins/theme-selector/wtooltip.js";
        //echo "<script type='text/javascript' src='$js_tooltipPath'></script><script type='text/javascript' > $('#theme_info_box').wTooltip(); </script>";
        echo "<div style='height:{$amountThemese}px'>";
        if (count($filenames) != 0) {
            echo "<div style='background-color: #DAE86F;font-size: 1.2em;padding:2px;text-align: left;margin-bottom:10px;height:19px;width:98%;border:1px solid black;'>Select a theme to make it the active theme - <b>Active Theme : <font color='blue'> $TEMPLATE </font></b></div>";
            foreach ($filenames as $file) {
                if ((is_dir($path . $file) && !(($file == "." || $file == ".." ||  $file == ".htaccess"))) && (is_file($path . $file."/template.php"))) {
                  
                    //screenshot
                    $ThemeName = $file;
                    //get the screenshot if it exist
                    if (is_file($path . $file."/images/screenshot.png")) {
                       $screenshot = $SITEURL."theme/".$file."/images/screenshot.png";
                    } else {
                      $screenshot = $SITEURL."admin/template/images/screenshot.jpg";
                    }
                     $tmpContent = implode("", @file($path . $file."/template.php"));
                     
                    preg_match_all('/@(.*):(.*)(.\s)/i',$tmpContent,$tmpArr,PREG_PATTERN_ORDER);
                        $Datablocks = $tmpArr[1];
                        $datafields = $tmpArr[2];
                        $totalBlocks = count($Datablocks);
                        $fileInfo = "";
                        for ($x = 0;$x < $totalBlocks;$x++) {
                        
                          
                          if ((strtolower(trim($datafields[$x])) <> 'template.php') && (strtolower(trim($Datablocks[$x])) <> 'file')) {
                             $fileInfo .= "<br/>".trim($Datablocks[$x])." : ".trim($datafields[$x]);
                         }
                         
                        }                    
                        
                      $thisThemeURL = "load.php?id=themes-selector&TN=".$ThemeName;
                      $tipInfo = str_replace('<br/>',' | ',$fileInfo);
                      if ($TEMPLATE == $ThemeName) {
                        echo "<div title='$tipInfo' id='theme_info_box' style='display:inline;height:315px;overflow:hidden;'><a href='$thisThemeURL' ><div  style='font-weight: bold;background-color: #5963C1;font-size: 1.2em;text-align: center;margin:2px;float:left;width:275px;height:313px;border:2px solid black;'><img height='225' width='275' src='$screenshot'><br/>$ThemeName</a><p id='d_$x' style='font-weight: normal;text-align: left;font-size: 0.8em;'>$fileInfo</p>  </div></div>";
                      } else {
                       echo "<div title='$tipInfo' id='theme_info_box' style='display:inline;height:315px;overflow:hidden;'><a href='$thisThemeURL' ><div  style='font-weight: bold;background-color: #cacaca;font-size: 1.2em;text-align: center;margin:2px;float:left;width:275px;height:313px;border:2px solid black;'><img height='225' width='275' src='$screenshot'><br/>$ThemeName</a><p id='d_$x' style='font-weight: normal;text-align: left;font-size: 0.8em;'>$fileInfo</p>  </div></div>";
                      }  
                   
                } 
            }
        }
        echo "</div><div>GS Plugin - Theme Selector (v 0.4b) - Developed by <a href='http://www.dominion-it.co.za'>Dominion IT</a></div>";                           
   
}