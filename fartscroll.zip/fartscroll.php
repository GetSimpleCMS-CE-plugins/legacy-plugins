<?php
/*
Plugin Name: Fartscroll
Description: Makes your website Fart using the fartscroll script from the Onion
Version: 1.0
Author: Michael Atkins
Author URI: http://cubecolour.co.uk
*/

// get correct id for plugin
$thisfile=basename(__FILE__, ".php");

// register plugin
register_plugin(
	$thisfile, //Plugin id
	'Fartscroll', 	//Plugin name
	'1.0', 		//Plugin version
	'Michael Atkins',  //Plugin author
	'http://cubecolour.co.uk/', //author website
	'Makes your website Fart using the fartscroll script from the Onion', //Plugin description
	'', //page type - on which admin tab to display
	''  //main function (administration)
);

add_action('theme-header', 'pull_my_finger');

function pull_my_finger() {
?>
<script type="text/javascript" src="http://code.onion.com/fartscroll.js"></script>
<script type="text/javascript">$(document).ready(function() { fartscroll(600); });</script>
<?php
}