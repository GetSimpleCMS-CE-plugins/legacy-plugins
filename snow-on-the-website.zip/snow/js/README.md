# Snow.js
Pure JavaScript Snowfall &mdash; [Demo](http://kurisubrooks.github.io/snow.js/)

### Usage
```html
<script src="snow.js"></script>
<style>html,body{margin:0;height:100%;}</style>
```

### Contributors
[rainbow.arch.scriptmania.com](http://rainbow.arch.scriptmania.com/)  
[kurisubrooks.com](https://kurisubrooks.com)
