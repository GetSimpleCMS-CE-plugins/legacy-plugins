gs_shortcodes
=============

Shortcodes for GetSimple