<?php
/****************************************************
*
* @File:		common.php
* @Author:		Unapzeus Adinovic
* @URL: 		www.bimsala.com	
* @Package:		ABI Wizard
* @Action:		Load common script to run ABIwizard.
*
*****************************************************/

# get correct id for plugin
$lang=basename(__FILE__, ".php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>ABIwizard Documentation</title>
		<style type="text/css" rel="stylesheet">
		<!--
			html,body{margin:0 auto;height:100%;background-color:#FFFFFF;}
			.box{width:650px;}
			.title{font:24px Arial;color:#FF0000;padding:10px;text-align:center;border-bottom:1px dashed #cccccc;}
			.content{padding:10px;color:#000000;font:16px Arial;text-align:justify;}
			a {color:green; text-decoration:none;font-weight:bold;}
			pre code{font:12px Consolas;}
			.red{color:red;}
		//-->
		</style>
	</head>
	<body>
		<table width="100%" height="100%" border="0">
			<tr>
				<td valign="middle" align="center">
					<img src="../images/logo.png" />
					<br /><br />
					<div class="box">
						<div class="title">ABIwizard Documentation</div>
						<div class="content">
							ABIwizard is the core library to run the advanced GetSimple themes. By using ABIwizard, you can easy to modify your website. Yap! Very easy to modify. Just create a theme functions, and call the ABIwizard function key, also add some parameter, now you can easy control your site template. <br /><b>Below is Sample of funtions.php </b> you would be know if connect your theme creations to ABIwizard:<br /><br />
<pre><code>
&lt;?php if(!defined('IN_GS')){ die('Hey duck! What are you doing here?'); }
/****************************************************
*
* @File:		functions.php
* @Author:		Unapzeus Adinovic
* @URL: 		www.bimsala.com	
* @Package:		ABI Wizard
* @Action:		Clear Sky - Get Simple Theme with super easy customization. 
*
****************************************************/

if (function_exists('ABIwizard')) {
	$LAYOUT		= '.wrapper';
	$MAIN_BG	= '#sidebar,.wrapper';
	$SCHEME_BG	= 'ul#nav li:hover a,ul#nav li:hover ul,#footer';
	$SCHEME_TEXT	= '.title,.main h1,.main h2,.main h3,.main h4,.main a,code';
	$LOGO		= '/images/logo.png';
	$CREDITS	= 'Theme By Unapzeus Adinovic';
} else {
	include 'notify.inc.php';
	exit;
}
</code></pre>
<br />
<b style="color:blue;">Knowing the Parameter Usage</b>
<ol>
	<li><b>if (function_exists('ABIwizard')) { [........] } else { include 'notify.inc.php'; exit; } </b> : This statement is used to notify the users who using your theme but they haven't install the ABIwizard plugin. You can using your own script as notify. By using include or inline.</li>
	<li><b>$LAYOUT </b> : This is the parameter for CSS class when user's switch to <b>Boxed</b> layout. In sample above, I am using the <b>.wrapper</b> class to wrap the content. </li>
	<li><b>$MAIN_BG </b> : The CSS ID or CLASS when user's enable color manipulation and define the Main Background Color.</li>
	<li><b>$SCHEME_BG </b> : The CSS ID or CLASS when user's define the colorscheme. This is coloring the BACKGROUND. </li>
	<li><b>$SCHEME_TEXT </b> : Define CSS ID or CLASS, or HTML TAG to coloring the text and link when color scheme is defined </li>
	<li><b>$LOGO </b> : The default theme logo path when user's not set the custom logo</li>
	<li><b>$CREDITS </b> : The default credit text (Copyright) when user's not set the copyright text</li>
</ol>
<br />
<b style="color:blue;">Call the ABIwizard settings to theme</b><br />
You can place the ABIwizard functions everywhere in your theme design just like grab the GetSimple components. <br />
Put the functions like this: <i>&lt;?php wizard('abc'); ?> </i>where abc is the name of settings. Why abc? Because I don't like xxx :D  <br />
Below is current existing ABIwizard functions, I will add some more configurations if this plugin's comfortable for you. <br />
<ol>
	<li><u class="red">&lt;?php wizard('logo'); ?></u> : The output of this function is logo image URL.</li>
	<li><u class="red">&lt;?php wizard('ads'); ?></u> : The output of this function is your defined Ads.</li>
	<li><u class="red">&lt;?php wizard('social'); ?></u> : The output of this function is your defined social account. I was wrapping the output inside the "social" div class. You may add these class to your CSS file otherwise it will not visible. Please feel free to cheat my CSS in theme sample :D </li>	<li><u class="red">&lt;?php wizard('menu'); ?></u> : The output of this function will define the navigation menu inside the &lt;UL> tag. Please note that you must wrapping this function inside the &lt;ul> tag because this menu globaly start with &lt;li> tag to prevent you modify the navigation style.</li>
	<li><u class="red">&lt;?php wizard('copyright'); ?></u> : The out of this function will grab your defined copyright text.</li>
</ol>
That's all you need to know. The additional settings will auto configured. Hope you happy with this plugin. When you wish to develop this plugin become better or connect your themes creation to ABIwizard, just do it... <br /><br />
							<center>In order to keep me in themes creation, a cup of coffee are welcome :D</center>
							<table width="100%" cellpadding="10" cellspacing="10" border="0">
								<tr>
									<td align="right"><a href="http://bimsala.com/">Donate Me</a></td>
									<td align="center"> or </td>
									<td align="left"><a href="http://facebook.com/unapzeus/">Catch Me!</a></td>
								</tr>
							</table>
						</div>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>



