<?php
/****************************************************
*
* @File:		navigation.php
* @Author:		Unapzeus Adinovic
* @URL: 		www.bimsala.com	
* @Package:		ABI Wizard
* @Action:		Build a navigation to be nested in parent menu.
*
*****************************************************/
# hook
add_action('changedata-save','ABImenu_flush_cache');
add_action('page-delete', 'ABImenu_flush_cache');

function ABImenu_flush_cache() {
	$cachepath = GSDATAOTHERPATH.'ABIwizard/';
	if (is_dir($cachepath)) {
		$dir_handle = @opendir($cachepath) or exit('Unable to open ABIwizard folder');
		$filenames = array();
		while ($filename = readdir($dir_handle)) {
			$filenames[] = $filename;
		}
		if (count($filenames) != 0) {
			foreach ($filenames as $file) {
				if (!($file == '.' || $file == '..' || is_dir($cachepath.$file) || $file == '.htaccess')) {
					unlink($cachepath.$file) or exit('Unable to clean up ABIwizard folder');
				}
			}
		}
	}
}

function nav_data() {
	$menu_data = menu_data();
	usort($menu_data, 'nav_data__parents');
	$nav_data = array();
	foreach($menu_data as $item) {
		if (empty($item['menu_status'])) continue;
		if (empty($item['menu_text'])) $item['menu_text'] = $item['title'];
		if (empty($item['title'])) $item['title'] = $item['menu_text'];
		if (empty($item['parent_slug'])) {
			$nav_data[$item['slug']] = $item;
			$nav_data[$item['slug']]['children'] = array();
		}
		elseif(isset($nav_data[$item['parent_slug']])) {
			$nav_data[$item['parent_slug']]['children'][] = $item;
		}
	}
	usort($nav_data, 'nav_data__priority');
	foreach($nav_data as $key => $item) {
		$children = $nav_data[$key]['children'];
		if (sizeof($children)) {
			usort($children, 'nav_data__priority');
			$nav_data[$key]['children'] = $children;
		}
	}
	return $nav_data;
}

function ABInavigation($echo = true) {
	$active_page=return_page_slug();
	$cachepath = GSDATAOTHERPATH.'ABIwizard/'.$active_page.'.cache';
	if (is_file($cachepath)) {
		echo file_get_contents($cachepath);
	}else{
		$nav_data = nav_data();
		$items = array();
		$num_items = sizeof($items);
		foreach($nav_data as $key => $item) {
			$num_children = sizeof($item['children']);
			$classes = array($item['slug']);
			if ($key == 0) $classes[] = 'first';
			elseif($key == ($num_items - 1)) $classes[] = 'last';
			if ($num_children) $classes[] = 'submenu';
			if ($item['slug'] == $active_page) $classes[] = 'current';
			$string = '<li name="%s"><a href="'. $item['url'] . '">'.stripslashes($item['menu_text']).'</a>';
			if ($num_children) {
				$string .= "\n  <ul>";
				foreach ($item['children'] as $sub_key => $sub_item) {
					$string .= "\n    <li name=\"" . $sub_item['slug'];
					if ($sub_key == 0) $string .= ' first';
					elseif($sub_key == ($num_children - 1)) $string .= ' last';
					if ($sub_item['slug'] == $active_page) {
						$classes[] = 'current_parent';
						$string .= ' current';
					}
					$string .= '"><a href="'. $sub_item['url'] . '">'.stripslashes($sub_item['menu_text']).'</a></li>';
				}
				$string .= "\n  </ul>\n";
			}
			$string .= '</li>';
			$items[] = sprintf($string, implode(' ', $classes));
		}
		if (sizeof($items)) {
			$items = implode("\n", $items);
			if ($echo) {
				nav_cache($cachepath, $items);
				echo $items;
			}
		else return $items;
		}
		else return "";
	}
}

function nav_data__parents($a, $b) {
	if (empty($a['parent_slug']) && empty($b['parent_slug'])) {
		return 0;
	}elseif(empty($a['parent_slug'])) {
		return -1;
	}else return 1;
}

function nav_data__priority($a, $b) {
	if (intval($a['menu_priority']) == intval($b['menu_priority'])) {
		return 0;
	}
	return (intval($a['menu_priority']) < intval($b['menu_priority'])) ? -1 : 1;
}

function nav_cache($cachepath, $content) {
	//Check if cache folder exists.
	if (is_dir(GSDATAOTHERPATH.'ABIwizard')==false) {
		mkdir(GSDATAOTHERPATH.'ABIwizard', 0755) or exit('Unable to create nested_menu_cache folder');
	}
	//Save cached child menu file.
	$fp = @fopen($cachepath, 'w') or exit('Unable to save ' . $cachepath);
	fwrite($fp, $content);
	fclose($fp);
}