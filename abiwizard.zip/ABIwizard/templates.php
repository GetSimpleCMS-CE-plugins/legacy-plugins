<?php
/****************************************************
*
* @File:		templates.php
* @Author:		Unapzeus Adinovic
* @URL: 		www.bimsala.com	
* @Package:		ABI Wizard
* @Action:		Connecting configuration from theme functions.
*
*****************************************************/
ABIwizard();
function ABIwizard() {
global $logo, $social, $facebook, $twitter, $linkedin, $ads, $copyright, $iedetector, $iemessage, $layout, $skins, $codehead, $codefoo, $colorscheme, $bgcolor, $bgimg, $bgimgstyle, $mainbg;
$file = GSDATAOTHERPATH . 'ABIwizard.xml';
if (file_exists($file)) {
	$id			= getXML($file);
	$logo 		= $id->logo;
	$social 		= $id->social;
	$facebook 		= $id->facebook;
	$twitter 		= $id->twitter;
	$linkedin 		= $id->linkedin;
	$ads	 		= $id->ads;
	$copyright 		= $id->copyright;
	$iedetector 	= $id->ie_detector;
	$iemessage	 	= $id->ie_message;
	$layout 		= $id->wrapper;
	$skins 		= $id->color_opt;
	$codehead 		= $id->codeheader;
	$codefoo 		= $id->codefooter;
	$colorscheme 	= $id->colorscheme;
	$bgcolor 		= $id->background;
	$bgimg 		= $id->bgimg;
	$mainbg 		= $id->bgcontent;

	function wizard($x) {
		global $file, $logo, $social, $facebook, $twitter, $linkedin, $ads, $copyright, $iemessage, $LOGO, $CREDITS, $SITENAME, $SITEURL;
		if (!isset($LOGO, $CREDITS)) {
			$LOGO = $logo; $CREDITS = $copyright;
		}
		if ($x == 'menu') {
			if (function_exists('ABInavigation')) {
				ABInavigation()."\n";
			}else{
				get_navigation(get_page_slug(FALSE))."\n";
			}
		}
		elseif ($x == 'logo' && $logo != '') {
			echo $logo;
		}elseif ($x == 'logo' && $logo =='') {
			$theme = get_theme_url();
			if ($LOGO !='') {
				echo $theme . '/' . $LOGO;
			}else{
				echo $theme . '/images/logo.png';
			}
		}
		elseif ($x == 'social' && $social =='Y') {
			echo '<div class="social">';
			if ($facebook != '') {
				echo '<a href="'.$facebook.'" class="facebook" target="_blank"> </a>';
			}
			if ($twitter != '') {
				echo '<a href="'.$twitter.'" class="twitter" target="_blank"> </a>';
			}
			if ($linkedin != '') {
				echo '<a href="'.$linkedin.'" class="linkedin" target ="_blank"> </a>';
			}
			echo '<div class="addthis_toolbox" style="display:inline;width:24px;">';
			echo '<a href="//www.addthis.com/bookmark.php?v=250" class="addthis_button_compact share"> </a>';
			echo '</div>'."\n";
			echo '<div class="clear"></div>'."\n";
			echo '</div>'."\n";
			echo '<script type="text/javascript" src="//s7.addthis.com/js/250/addthis_widget.js"></script>'."\n";
		}
		elseif ($x == 'ads' && $ads != '') {
			echo $ads."\n";
		}
		elseif ($x == 'copyright' && $copyright != '') {
			echo $copyright."\n";
		}elseif ($x == 'copyright' && $copyright == '') {
			if ($CREDITS != '') {
				echo $CREDITS."\n";
			}else{
				$date = date('Y');
				$url = $SITEURL;
				$name = $SITENAME;
				echo 'Copyright &#169;'.$date.' - <a href="'.$url.'">'.$name.'</a><br />All Rights Maybe Reserved<br /><br /> Theme by <a href="http://facebook.com/unapzeus/" target="_blank">Unapzeus Adinovic</a>'."\n";
			}
		}
		elseif ($x == 'iemessage' && $iemessage != '') {
			echo $iemessage."\n";
		}elseif ($x == 'iemessage' && $iemessage == '') {
			echo '<b>Whoaaaaaaa!!!</b><br /><br />'."\n";
			echo 'This site is using very old design. But you accessing this site by using a futuristic browser. Don\'t hurt my site, please downgrade your browser :D'."\n";
		}

	}
	if ($iedetector == 'Y') {
		$ua = $_SERVER['HTTP_USER_AGENT'];
		if(preg_match('/MSIE/i',$ua)) {
			add_action('theme-footer','iedetector'); 
			function iedetector() {
				include 'iedetector.php';
			}
		}
	}
	add_action('theme-header','ABI_header');
	function ABI_header() {
		global $file, $layout, $skins, $colorscheme, $bgcolor, $bgimg, $bgimgstyle, $mainbg, $codehead,  $LAYOUT, $MAIN_BG, $SCHEME_BG, $SCHEME_TEXT;
		if (!isset($LAYOUT, $MAIN_BG, $SCHEME_BG, $SCHEME_TEXT)) {
			include 'themedetector.php';
		}
		if ($codehead != '') {
			echo '	' . $codehead."\n";
		}
		if ($layout == 'boxes') {
			echo '	<style>' . $LAYOUT . '{width:960px;margin:30px auto;}</style>'."\n";
		}
		if ($skins == 'Y') {
			echo '	<style>';
			if ($colorscheme != '') {
				echo $SCHEME_BG . '{background:'.$colorscheme.' !important;}';
				echo $SCHEME_TEXT . '{color:'.$colorscheme.' !important;}a.button{color:#FFFFFF !important;}';
			}
			if ($bgimgstyle == 'tile') {
				$style = '';
			}elseif ($bgimgstyle == 'stretch') {
				$style = ' center center no-repeat !important;-moz-background-size:cover;-webkit-backround-size:cover;o-background-size:cover;background-size:cover;';
			}elseif ($bgimgstyle == 'stretchfix') {
				$style = ' center center fixed no-repeat !important;-moz-background-size:cover;-webkit-backround-size:cover;o-background-size:cover;background-size:cover;';
			}
			if ($bgcolor != '' && $bgimg !='') {
				echo 'body{background:'.$bgcolor.' url('.$bgimg.')'.$style.'}';
			} elseif ($bgcolor !='') {
				echo 'body{background:'.$bgcolor.' !important;}';
			} elseif ($bgimg !='') {
				echo 'body{background:url('.$bgimg.')'.$style.'}';
			}
			if ($mainbg != '') {
				echo $MAIN_BG . '{background:'.$mainbg.'; !important}';
			}
			echo '</style>'."\n";
		}
	}
	add_action('theme-footer','ABI_footer');
	function ABI_footer() {
		global $file, $codefoo;

		# load footer code
		if ($codefoo != '') {
			echo $codefoo."\n";
		}
		echo "<script>$('a[rel*=zoom]').fancybox({'type':'iframe'});</script>"."\n";
	}
}else{
	include 'notify.php';
	exit;
}
}