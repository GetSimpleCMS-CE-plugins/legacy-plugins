<!DOCTYPE html>
<html>
	<head>
		<title>Theme's broken!</title>
		<style type="text/css" rel="stylesheet">
		<!--
			html,body{margin:0 auto;height:100%;background-color:#FFFFFF;}
			.box{width:600px;}
			.title{font:24px Arial;color:#FF0000;padding:10px;text-align:center;border-bottom:1px dashed #cccccc;}
			.content{padding:10px;color:#000000;font:16px Arial;text-align:center;}
			a {color:green; text-decoration:none;font-weight:bold;}
		//-->
		</style>
	</head>
	<body>
		<table width="100%" height="100%" border="0">
			<tr>
				<td valign="middle" align="center">
					<img src="<?php get_theme_url(); ?>/images/logo.png" />
					<br /><br />
					<div class="box">
						<div class="title">This Theme's Broken!</div>
						<div class="content">
							ABIwizard plugin are required in order to run this theme. I recommend you to install the plugin and activate it before using this theme.<br /><br />
							Click the link below to download it for free
							<table width="100%" cellpadding="10" cellspacing="10" border="0">
								<tr>
									<td align="right"><a href="http://bimsala.com/">ABIwizard Official</a></td>
									<td align="left"><a href="http://get-simple.info/extend/">GetSimple Extend</a></td>
								</tr>
							</table>
						</div>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>

