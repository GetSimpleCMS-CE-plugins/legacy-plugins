<style type="text/css">
* html #ABIbox{
	background-image:url(about:blank);
	background-attachment:fixed;
}
* html #IEbox{
	display:none;
}
* html .ABIbox, .ABIbox{
	position:fixed;
	left:50%;
	margin-left:-300px;
	width:600px;
	text-align:justify;
	z-index:999;
	background:#00a;
	padding:10px;
}
.ABIbox{
	top:50%;
	margin-top:-25%;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	-o-border-radius:5px;
	border-radius:5px;
}
* html .ABIbox{
	margin-top:150px;
}	
* html #ABIbox .ABIbox{
	position:absolute;
	top:expression(0+((e=document.documentElement.scrollTop)?e:document.body.scrollTop)+'px');
}
.ABIttl{
	color:#fff;
	padding:5px;
	font-size:16px;
	font-weight:bold;
	position:relative;
	text-align:left;
}
a.ABIclose{
	position:absolute;
	right:0;
	top:0;
	padding:2px 5px;
	border-top:1px solid #ddd;
	border-right:1px solid #777;
	border-bottom:1px solid #777;
	border-left:1px solid #ddd;
	background:#aaa;
	color:#000;
	text-decoration:none;
}
.ABIctn{
	padding:10px;
	background:#fff;
	color:000;
	position:relative;
	height:200px;
	overflow-y:auto;
}
.ABIctn ul, .ABIctn ol{
	margin-left:30px;
}
.ABIctn li{
	margin:5px 0;
}
</style>
<script>
function hide(obj) {
	var ABI = document.getElementById(obj);
	ABI.style.display = 'none';
}
</script>
<blink>
<div id="ABIbox">
<div class="ABIbox">
	<div class="ABIttl"><?php get_site_name(); ?> <a class="ABIclose" href="#" onClick="hide('ABIbox')">X</a></div>
	<div class="ABIctn">
		<b style="color:red;">NOTIFICATION:</b> It's looks like you are activated ABIwizard plugin. But you are haven't correct theme functions. There are some instructions that may be fix this problems. <br /><br />
		<ul>
			<li>If you using a theme that are designed for ABIwizard, make sure this variable is exists on your theme functions: 
				<ol>
					<li>$LAYOUT</li>
					<li>$MAIN_BG</li>
					<li>$SCHEME_BG</li>
					<li>$SCHEME_TEXT</li>
				</ol>
			You can only modify the value of these variable.</li>
			<li>If you using a standard theme (not for ABIwizard), please to deactivate ABIwizard plugin first.</li>
			<li>If this notification's still visible despite the above error has been corrected, please read the plugin documentation or write your problem in forum discussion.</li>
		</ul>
		That's all that you might be know.<br /><br />
	</div>
</div>
</div>
</blink>
