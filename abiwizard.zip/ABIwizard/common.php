<?php
/****************************************************
*
* @File:		common.php
* @Author:		Unapzeus Adinovic
* @URL: 		www.bimsala.com	
* @Package:		ABI Wizard
* @Action:		Load common script to run ABIwizard.
*
*****************************************************/

$xmlfile=GSDATAOTHERPATH .'ABIwizard.xml';
# get XML data
if (file_exists($xmlfile)) {
	$x = getXML($xmlfile);
	$social = $x->social;
	$facebook = $x->facebook;
	$twitter = $x->twitter;
	$linkedin = $x->linkedin;
	$logo = $x->logo;
	$ads = $x->ads;
	$ie_detector = $x->ie_detector;
	$ie_message = $x->ie_message;
	$color_opt = $x->color_opt;
	$background = $x->background;
	$bgimg = $x->bgimg;
	$bgimgstyle = $x->bgimgstyle;
	$bgcontent = $x->bgcontent;
	$colorscheme = $x->colorscheme;
	$wrapper = $x->wrapper;
	$copyright = $x->copyright;
	$codeheader = $x->codeheader;
	$codefooter = $x->codefooter;
} else {
	$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
	$xml->addChild('social', '');
	$xml->addChild('facebook', '');
	$xml->addChild('twitter', '');
	$xml->addChild('linkedin', '');
	$xml->addChild('logo', '');
	$xml->addChild('ads')->addCData('');
	$xml->addChild('ie_detector', '');
	$xml->addChild('ie_message')->addCData('');
	$xml->addChild('color_opt', '');
	$xml->addChild('background', '');
	$xml->addChild('bgimg', '');
	$xml->addChild('bgimgstyle', '');
	$xml->addChild('bgcontent', '');
	$xml->addChild('colorscheme', '');
	$xml->addChild('wrapper', '');
	$xml->addChild('copyright')->addCData('');
	$xml->addChild('codeheader')->addCData('');
	$xml->addChild('codefooter')->addCData('');
	XMLsave($xml, $xmlfile);
}

require_once GSPLUGINPATH . 'ABIwizard/navigation.php';
require_once GSPLUGINPATH . 'ABIwizard/templates.php';