<style type="text/css">
* html #IEbox{
	background-image:url(about:blank);
	background-attachment:fixed;
}
* html .IEbox{
	position:fixed;
	left:50%;
	margin-left:-250px;
	margin-top:100px;
	width:500px;
	text-align:center;
	z-index:999;
	background:#f00;
	padding:1px;
}
* html #IEbox .IEbox{
	position:absolute;
	top:expression(0+((e=document.documentElement.scrollTop)?e:document.body.scrollTop)+'px');
}
* html .IEttl{
	color:#fff;
	padding:5px;
	font-size:16px;
	font-weight:bold;
	position:relative;
	text-align:left;
}
* html a.IEclose{
	position:absolute;
	right:2px;
	top:1px;
	padding:2px 8px 3px 8px;
	border-top:1px solid #ddd;
	border-right:1px solid #777;
	border-bottom:1px solid #777;
	border-left:1px solid #ddd;
	background:#aaa;
	color:#000;
}
* html .IEctn{
	padding:10px;
	font-size:16px;
	background:#fff;
	color:000;
}
</style>
<script>
function hide(obj) {
	var ABI = document.getElementById(obj);
	ABI.style.display = 'none';
}
</script>
<div id="IEbox">
<div class="IEbox">
	<div class="IEttl"><?php get_site_name(); ?> <a class="IEclose" href="#" onClick="hide('IEbox')">X</a></div>
	<div class="IEctn">
		<?php wizard('iemessage'); ?><br /><br />
		Click the link below to download it for free
		<table width="100%" cellpadding="10" cellspacing="10" border="0">
			<tr>
				<td align="right"><a href="http://google.com/chrome/">Get Google Chrome</a></td>
				<td> or </td>
				<td align="left"><a href="http://mozilla.com/">Get Mozilla Firefox</a></td>
			</tr>
		</table>
	</div>
</div>
</div>