<?php
/****************************************************
*
* @Plugin:		ABIwizard
* @Author:		Unapzeus Adinovic
* @URL  : 		www.bimsala.com
* @Package:		Theme Plugin
* @Action:		This plugin is a core library to run the theme with multiple configurations. 
*
*****************************************************/

# get correct id for plugin
$lang=basename(__FILE__, ".php");

# get upload permission
if (!defined('GSADMIN')) {
	define('GSADMIN', 'admin');
}

# add in this plugin's language file
i18n_merge($lang) || i18n_merge($lang, 'en_US');

# register plugin
register_plugin(
	$lang,#ID
	i18n_r($lang.'/ABIWIZARD_TITLE'),# Title
	'1.0',# Version
	'Unapzeus Adinovic',# Author
	'http://bimsala.com',# Author URL
	i18n_r($lang.'/ABIWIZARD_DESC'),# Description
	'theme',# Type
	'ABIwizard_show'# Function
);

# hooks
add_action('theme-sidebar','createSideMenu',array($lang, i18n_r($lang.'/ABIWIZARD_TITLE')));

# add core script
register_script('core', $SITEURL.'plugins/'.$lang.'/js/core.js', '1.7.1', FALSE);
register_script('gallery', $SITEURL.'plugins/'.$lang.'/js/gallery.js', '2.0.4', FALSE);
register_style('gallery', $SITEURL.'plugins/'.$lang.'/css/gallery.css', '2.0.4', FALSE);
queue_script('core',GSBOTH);
queue_script('gallery',GSBOTH);
queue_style('gallery',GSBOTH);

#include library
require_once GSPLUGINPATH . 'ABIwizard/common.php';

function ABIwizard_show() {
	global $xmlfile, $social, $facebook, $twitter, $linkedin, $logo, $ads, $ie_detector, $ie_message, $color_opt, $background, $bgimg, $bgimgstyle, $bgcontent, $colorscheme, $wrapper, $copyright, $codeheader, $codefooter, $lang;
	$success=null;$error=null;
	
	# submitted form
	if (isset($_POST['submit'])) {
		$social; $facebook=null; $twitter=null; $linkedin=null; $logo=null; $ads; $ie_detector=null; $ie_message=null; $color_opt=null; $background=null; $bgimg=null; $bgimgstyle=null; $bgcontent=null; $colorscheme=null; $wrapper=null; $copyright=null; $codeheader=null; $codefooter=null;


		function url_check($str) {
			return preg_match("/^(http|https):\/\/([a-z0-9]([a-z0-9_-]*[a-z0-9])?\.)+[a-z]{2,6}|localhost\/?([a-z0-9\?\._-~&#=+%]*)?/", $str);
		}
		# check to see if the URLs provided are valid
		if ($_POST['facebook'] != '') {
			if (url_check($_POST['facebook'])) {
				$facebook = $_POST['facebook'];
			} else {
				$error .= i18n_r($lang.'/FACEBOOK_ERROR').' ';
			}
		}
		
		if ($_POST['twitter'] != '') {
			if (url_check($_POST['twitter'])) {
				$twitter = $_POST['twitter'];
			} else {
				$error .= i18n_r($lang.'/TWITTER_ERROR').' ';
			}
		}
		
		if ($_POST['linkedin'] != '') {
			if (url_check($_POST['linkedin'])) {
				$linkedin = $_POST['linkedin'];
			} else {
				$error .= i18n_r($lang.'/LINKEDIN_ERROR').' ';
			}
		}
		
		if ($_POST['logo'] != '') {
			if (url_check($_POST['logo'])) {
				$logo = $_POST['logo'];
			} else {
				$error .= i18n_r($lang.'/LOGO_ERROR').' ';
			}
		}
		
		if ($_POST['bgimg'] != '') {
			if (url_check($_POST['bgimg'])) {
				$bgimg = $_POST['bgimg'];
			} else {
				$error .= i18n_r($lang.'/BGIMG_ERROR').' ';
			}
		}

		if ($_POST['background']) {
			if (preg_match('/^#[A-Fa-f0-9]{6}$/i', $_POST['background'])) {
				$background = $_POST['background'];
			} else {
				$error .= i18n_r($lang.'/BACKGROUND_ERROR').' ';
			}
		}

		if ($_POST['bgcontent']) {
			if (preg_match('/^#[A-Fa-f0-9]{6}$/i', $_POST['bgcontent'])) {
				$bgcontent = $_POST['bgcontent'];
			} else {
				$error .= i18n_r($lang.'/BGCONTENT_ERROR').' ';
			}
		}

		if ($_POST['colorscheme']) {
			if (preg_match('/^#[A-Fa-f0-9]{6}$/i', $_POST['colorscheme'])) {
				$colorscheme = $_POST['colorscheme'];
			} else {
				$error .= i18n_r($lang.'/COLORSCHEME_ERROR').' ';
			}
		}

		# checked submit social account
		if (isset($_POST['social'])) {
			$social = $_POST['social'];
		}

		# checked submit ie detector
		if (isset($_POST['ie_detector'])) {
			$ie_detector = $_POST['ie_detector'];
		}

		# checked submit option
		if (isset($_POST['color_opt'])) {
			$color_opt = $_POST['color_opt'];
		}

		# selected submit option
		if (isset($_POST['bgimgstyle'])) {
			$bgimgstyle = $_POST['bgimgstyle'];
		}
		
		# if there are no errors, save data
		if (!$error) {
			$facebook = htmlentities($_POST['facebook'], ENT_QUOTES, 'UTF-8');
			$twitter = htmlentities($_POST['twitter'], ENT_QUOTES, 'UTF-8');
			$linkedin = htmlentities($_POST['linkedin'], ENT_QUOTES, 'UTF-8');
			$logo = htmlentities($_POST['logo'], ENT_QUOTES, 'UTF-8');
			$ads = html_entity_decode($_POST['ads'], ENT_QUOTES, 'UTF-8');
			$ie_message = html_entity_decode($_POST['ie_message'], ENT_QUOTES, 'UTF-8');
			$background = htmlentities($_POST['background'], ENT_QUOTES, 'UTF-8');
			$bgimg = htmlentities($_POST['bgimg'], ENT_QUOTES, 'UTF-8');
			$bgcontent = htmlentities($_POST['bgcontent'], ENT_QUOTES, 'UTF-8');
			$colorscheme = htmlentities($_POST['colorscheme'], ENT_QUOTES, 'UTF-8');
			$wrapper = htmlentities($_POST['wrapper'], ENT_QUOTES, 'UTF-8');
			$copyright = html_entity_decode($_POST['copyright'], ENT_QUOTES, 'UTF-8');
			$codeheader = html_entity_decode($_POST['codeheader'], ENT_QUOTES, 'UTF-8');
			$codefooter = html_entity_decode($_POST['codefooter'], ENT_QUOTES, 'UTF-8');

			$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
			$xml->addChild('social', $social);
			$xml->addChild('facebook', $facebook);
			$xml->addChild('twitter', $twitter);
			$xml->addChild('linkedin', $linkedin);
			$xml->addChild('logo', $logo);
			$xml->addChild('ads')->addCData($ads);
			$xml->addChild('ie_detector', $ie_detector);
			$xml->addChild('ie_message')->addCData($ie_message);
			$xml->addChild('color_opt', $color_opt);
			$xml->addChild('background', $background);
			$xml->addChild('bgimg', $bgimg);
			$xml->addChild('bgimgstyle', $bgimgstyle);
			$xml->addChild('bgcontent', $bgcontent);
			$xml->addChild('colorscheme', $colorscheme);
			$xml->addChild('wrapper', $wrapper);
			$xml->addChild('copyright')->addCData($copyright);
			$xml->addChild('codeheader')->addCData($codeheader);
			$xml->addChild('codefooter')->addCData($codefooter);
			XMLsave($xml, $xmlfile);
			
			if (! $xml->asXML($xmlfile)) {
				$error = i18n_r('CHMOD_ERROR');
			} else {
				$x = getXML($xmlfile);
				$social = stripslashes($x->social);
				$facebook = stripslashes($x->facebook);
				$twitter = stripslashes($x->twitter);
				$linkedin = stripslashes($x->linkedin);
				$logo = stripslashes($x->logo);
				$ads = stripslashes($x->ads);
				$ie_detector = stripslashes($x->ie_detector);
				$ie_message = stripslashes($x->ie_message);
				$color_opt = stripslashes($x->color_opt);
				$background = stripslashes($x->background);
				$bgimg = stripslashes($x->bgimg);
				$bgimgstyle = stripslashes($x->bgimgstyle);
				$bgcontent = stripslashes($x->bgcontent);
				$colorscheme = stripslashes($x->colorscheme);
				$wrapper = stripslashes($x->wrapper);
				$copyright = stripslashes($x->copyright);
				$codeheader = stripslashes($x->codeheader);
				$codefooter = stripslashes($x->codefooter);
				$success = i18n_r('SETTINGS_UPDATED');
			}
		}
	}

	# checked function
	if ($social == 'Y') {
		$social_check = 'checked';
	}else{
		$social_check = '';
	}
	if ($ie_detector == 'Y') {
		$ie_detector_check = 'checked';
	}else{
		$ie_detector_check = '';
	}
	if ($color_opt == 'Y') {
		$color_opt_check = 'checked';
	}else{
		$color_opt_check = '';
	}

$config = GSDATAOTHERPATH . 'website.xml';
if (file_exists($config)) {
	$set = getXML($config);
	$url = $set->SITEURL;
	$theme = $set->TEMPLATE;
}else{
	$url = '';
	$theme = '';
}
?>

<div class="head">
	<center><img src="<?php echo $url.'plugins/ABIwizard/images/logo.png'; ?>"/></center><br />
	<center><h2><?php i18n($lang.'/ABIWIZARD_TITLE'); ?> for <font color="blue"><?php echo $theme; ?></font></h2></center>
<?php 
	if($success) { 
		echo '<div class="updated"><b>'. $success .'</b></div>';
	} 
	if($error) { 
		echo '<div class="updated" style="background:#FF0000;color:#FFFFFF;"><b>'. $error .'</b></div>';
	}
?>
</div>
<div style="text-align:right;">
<a rel="doc" href="<?php echo $url.'plugins/ABIwizard/doc/'; ?>">Plugin Documentation and Developer Info</a>
</div>

<form method="post" action="<?php	echo $_SERVER ['REQUEST_URI']?>">
	<table class="abiform" width="100%" cellpadding="5" cellspacing="5" border="0">
		<tr>
			<td class="abilabel">
				<?php i18n($lang.'/LOGO_LABEL'); ?> <br />
				<i><?php i18n($lang.'/LOGO_DESC'); ?></i>
			</td>
			<td class="abidata">
				<center>
					<img id="logoimg" src="<?php if (isset($logo)&&strlen($logo)>4){ echo $logo;}else{ echo $url.'plugins/ABIwizard/images/loadlogo.gif';} ?>" />
				</center>
				<br />
				<input type="text" name="logo" value="<?php echo $logo; ?>" style="width:320px;float:left;" id="logo"/> <a rel="logo" href="<?php echo $url; ?><?php echo GSADMIN; ?>/upload.php?" style="padding:3px;text-decoration:none;border:1px solid #888;float:right;">Browse</a><div class="clear">
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/WRAPPER_LABEL'); ?> <br />
				<i><?php i18n($lang.'/WRAPPER_DESC'); ?></i>
			</td>
			<td class="abidata">
				<select name="wrapper">
					<?php if ($wrapper == 'boxes') {
						echo '<option value="boxes" selected>Boxes</option> <option value="fluid">Fluid</option>';
					}else{
						echo '<option value="boxes">Boxes</option> <option value="fluid" selected>Fluid</option>';
					} ?>
				</select>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/COLOR_OPT_LABEL'); ?><br />
				<i><?php i18n($lang.'/COLOR_OPT_DESC'); ?></i>
			</td>
			<td class="abidata">
				<input id="skincheck" type="checkbox" style="width:20px; float:left;" name="color_opt" value="Y" <?php echo $color_opt_check; ?> /> <b><?php i18n($lang.'/COLOR_OPT_CHECK'); ?></b> <br /> 
				<div id="skin">
					<?php i18n($lang.'/COLORSCHEME_LABEL'); ?><br />
					<input type="text" name="colorscheme" value="<?php echo $colorscheme; ?>" />
					<br />
					<?php i18n($lang.'/BACKGROUND_LABEL'); ?><br />
					<input type="text" name="background" value="<?php echo $background; ?>" />
					<br />
					<?php i18n($lang.'/BGCONTENT_LABEL'); ?><br />
					<input type="text" name="bgcontent" value="<?php echo $bgcontent; ?>" /> 
					<br />
					<?php i18n($lang.'/BGIMG_LABEL'); ?><br />
					<input type="text" name="bgimg" value="<?php echo $bgimg; ?>" style="width:320px;float:left;" id="background"/>
					<a rel="bgimg" href="<?php echo $url; ?><?php echo GSADMIN; ?>/upload.php?" style="background:#ddd;padding:3px;text-decoration:none;border:1px solid #888;float:right;">Browse</a>
					<div class="clear"></div>
					<a rel="facybox_i" href="<?php if (isset($bgimg)&&strlen($bgimg)>4){ echo $bgimg;}else{ echo $url.'plugins/ABIwizard/images/loadbg.gif';} ?>">
						<img id="backgroundimg" src="<?php if (isset($bgimg)&&strlen($bgimg)>4){ echo $bgimg;}else{ echo $url.'plugins/ABIwizard/images/loadbg.gif';} ?>" width="390" style="margin: 5px 0;"/>
					</a><br />
					<?php i18n($lang.'/BGIMGSTYLE_LABEL'); ?><br />
					<small><?php i18n($lang.'/BGIMGSTYLE_DESC'); ?></small><br />
					<select name="bgimgstyle">
						<option value="tile"<?php if ($bgimgstyle == 'tile') { echo 'selected'; } ?>>Tile</option>
						<option value="stretch"<?php if ($bgimgstyle == 'stretch') { echo 'selected'; } ?>>Stretch</option>
						<option value="stretchfix"<?php if ($bgimgstyle == 'stretchfix') { echo 'selected'; } ?>>Stretch Fixed</option>
					</select>
				</div>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/SOCIAL_LABEL'); ?><br />
				<i><?php i18n($lang.'/SOCIAL_DESC'); ?></i>
			</td>
			<td class="abidata">
				<input id="socialcheck" type="checkbox" style="width:20px; float:left;" name="social" value="Y" <?php echo $social_check; ?> /> <b><?php i18n($lang.'/SOCIAL_CHECK'); ?></b> <br /> 
				<div id="social">
					<span><label for="facebook" title="<?php i18n($lang.'/FACEBOOK_DESC'); ?>"><?php i18n($lang.'/FACEBOOK_LABEL'); ?></label></span>
					<input type="text" name="facebook" value="<?php echo $facebook; ?>" />

					<span><label for="twitter" title="<?php i18n($lang.'/TWITTER_DESC'); ?>"><?php i18n($lang.'/TWITTER_LABEL'); ?></label></span>
					<input type="text" name="twitter" value="<?php echo $twitter; ?>" />

					<span><label for="linkedin" title="<?php i18n($lang.'/LINKEDIN_DESC'); ?>"><?php i18n($lang.'/LINKEDIN_LABEL'); ?></label></span>
					<input type="text" name="linkedin" value="<?php echo $linkedin; ?>" />
				</div>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/IE_DETECTOR_LABEL'); ?><br />
				<i><?php i18n($lang.'/IE_DETECTOR_DESC'); ?></i>
			</td>
			<td class="abidata">
				<input id="iecheck" type="checkbox" style="width:20px; float:left;" name="ie_detector" value="Y" <?php echo $ie_detector_check; ?> /> <b><?php i18n($lang.'/IE_DETECTOR_CHECK'); ?></b>
				<div id="ie">
					<?php i18n($lang.'/IE_MESSAGE_INFO'); ?>
					<textarea name="ie_message"><?php echo $ie_message; ?></textarea>
				</div>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/ADS_LABEL'); ?><br />
				<i><?php i18n($lang.'/ADS_DESC'); ?></i>
			</td>
			<td class="abidata">
				<textarea name="ads"><?php echo $ads; ?></textarea>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/COPYRIGHT_LABEL'); ?><br />
				<i><?php i18n($lang.'/COPYRIGHT_DESC'); ?></i>
			</td>
			<td class="abidata">
				<textarea name="copyright"><?php echo $copyright; ?></textarea>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/CODEHEAD_LABEL'); ?><br />
				<i><?php i18n($lang.'/CODEHEAD_DESC'); ?></i>
			</td>
			<td class="abidata">
				<textarea name="codeheader"><?php echo $codeheader; ?></textarea>
			</td>
		</tr><tr>
			<td class="abilabel">
				<?php i18n($lang.'/CODEFOO_LABEL'); ?><br />
				<i><?php i18n($lang.'/CODEFOO_DESC'); ?></i>
			</td>
			<td class="abidata">
				<textarea name="codefooter"><?php echo $codefooter; ?></textarea>
			</td>
				
		</tr><tr>
			<td class="abilabel">
				<input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" />
			</td>
			<td></td>
		</tr>
	</table>
</form>
<style>
table.abiform{
	position:relative;
}
.abiform input:hover, .abiform select:hover, .abiform textarea:hover{
	background:#eff;
	transition:all .5s ease-in-out;
	-moz-transition:all .5s ease-in-out;
	-webkit-transition:all .5s ease-in-out;
	-o-transition:all .5s ease-in-out;
}
td.abilabel{
	width:220px;
	font:16px Georgia;
	font-weight:bold;
	color:#09f;
	text-shadow:1px 1px 0 #888;
	vertical-align:top;
}
td.abilabel input[type="submit"]{
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	-o-border-radius:3px;
	-khtml-border-radius:3px;
	border-radius:3px;
	border:1px solid #888;
	background:#000;
	color:#fff;
	font:16px Arial;
	font-weight:bold;
	width:100%;
	padding:8px 15px;
}
td.abilabel input[type="submit"]:hover{
	background:#f60;
	cursor:pointer;
}
td.abilabel i, td.abidata i{
	font:13px Arial;
	color:navy;
	text-shadow:none;
	font-style:italic;
}
td.abidata{
	vertical-align:top;
}
td.abidata img{
	max-width:400px;
}
td.abidata input, td.abidata select, td.abidata textarea{
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	-o-border-radius:3px;
	-khtml-border-radius:3px;
	border-radius:3px;
	border:1px solid #888;
	background:#fff;
	font:14px Arial;
	width:400px;
	padding:6px;
}
td.abidata input[type="checkbox"]{
	width:24px;
	height:24px;
	border:1px solid #888;
}
td.abidata textarea{
	height:100px;
}
#ie, #skin, #social {
	padding:10px;
	background:#888;
}
#ie input, #ie textarea, #skin input, #skin textarea, #social input, #social textarea{
	width:380px;
}
</style>
<script>
$("#socialcheck").live("click", function () {
	$("#social").slideToggle("fast");
});
if ($("#socialcheck").is(":checked")) {} else {
	$("#social").css("display", "none");
}
$("#iecheck").live("click", function () {
	$("#ie").slideToggle("fast");
});
if ($("#iecheck").is(":checked")) {} else {
	$("#ie").css("display", "none");
}
$("#skincheck").live("click", function () {
	$("#skin").slideToggle("fast");
});
if ($("#skincheck").is(":checked")) {} else {
	$("#skin").css("display", "none");
}
$("#logo").keyup(function () {
  var imgurl = $("#logo").val();
  $("#logoimg").attr("src",imgurl).error(function() {
    $(this).attr("src",'../plugins/ABIwizard/images/loadlogo.gif');
  });
});
$("#background").keyup(function () {
  var imgurl = $("#background").val();
  $("#backgroundimg").attr("src",imgurl).error(function() {
    $(this).attr("src",'../plugins/ABIwizard/images/loadbg.gif');
  });
});
$('a[rel*=doc]').fancybox({
    'type':'iframe'
});
$('a[rel*=logo]').fancybox({
    'type':'iframe'
});
$('a[rel*=bgimg]').fancybox({
    'type':'iframe'
});
</script>
<?php
}