<?php
/*
Name: GST AdminLock
Description: Allows user to pass a custom $_GET parameter and password to gain access to admin login page
Version: 1.1
Author: RocketSmart Media / GetSimpleThemes
Author URI: http://www.getsimplethemes.com/
*/

# get correct id for plugin
$thisfile = basename(__FILE__,".php");

# register plugin
register_plugin(
	$thisfile,
	'GST AdminLock',
	'1.0',
	'RocketSmart Media / GetSimpleThemes',
	'http://www.getsimplethemes.com/',
	'Description: Allows users to pass a custom $_GET parameter and password to gain access to admin login page',
	'settings',
	'lock_settings'
);

add_action('settings-sidebar','createSideMenu',array($thisfile,'GST AdminLock'));//puts an extra item in the sidebar
add_action('common','check_admin_login_page',array($_GET));


/* 
	lock_settings()	
*/
function lock_settings()
{	
	if(!file_exists(GSDATAOTHERPATH."admin_lock.xml"))
	{
		//file doesn't exist, let's create it
		$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
		$note = $xml->addChild('status');
		$note->addCData('disabled');
		$xml->asXML(GSDATAOTHERPATH."admin_lock.xml");
	}
	
	if(isset($_POST['submitBtn']))
		submitLockData($_POST);	
	
	//get Data
	$thedata = getXML(GSDATAOTHERPATH."admin_lock.xml");
	$dataArray = array();

	foreach($thedata->children() as $child)
	{
		$dataArray[$child->getName()] = (string) $child;
	}
	
	if($dataArray['status'] == "enabled")
		$pluginStatus = true;
	else
		$pluginStatus = false;

	extract($dataArray);

	if (defined('GSADMIN')) { $adminFolder = GSADMIN; } else {	$adminFolder = 'admin'; }

	?>
    	<h3>GST AdminLock</h3>
        
        <p>Using GST AdminLock you are able to securely deny access to your admin panel with a custom $_GET variable (a variable which is inserted into the URL) along with a security code.</p>
        
        <p><strong>yourwebsite.com/<?php echo $adminFolder; ?></strong> becomes
        <strong>yourwebsite.com/<?php echo $adminFolder; ?>?<span style="color:#CF3805">mySecretVar</span>=<span style="color:#CF3805">mySecretPassword</span></strong></p>
        <br/>
        
        <form method="post"> 
            
            <input type="hidden" name="mySecretVar" value="<?php echo (isset($mySecretVar) ? $mySecretVar : ''); ?>" />
            <input type="hidden" name="mySecretPassword" value="<?php echo (isset($mySecretPassword) ? $mySecretPassword : ''); ?>" />
            <input type="hidden" name="actionTaken" value="<?php echo (isset($actionTaken) ? $actionTaken : ''); ?>" />
            <input type="hidden" name="customMessage" value="<?php echo (isset($customMessage) ? safe_strip_decode($customMessage) : ''); ?>" />
        
        	<div style="width:100%">
                <div style="width:50%;float:left;">
                	<?php if($pluginStatus) { ?>
		        	<input type="hidden" name="status" value="disabled" />                    
                    <input class="submit" type="submit" name="submitBtn"
                    value="Disable GST AdminLock" style="margin-top:-8px;" />  
                    <?php } else { ?>
		        	<input type="hidden" name="status" value="enabled" />                                     
                    <input class="submit" type="submit" name="submitBtn"
                    value="Enable GST AdminLock" style="margin-top:-8px;" />                                       
                    <?php } ?>
                </div>    
                <div style="width:50%;float:left;">
                    <p style="float:right;">
                    	<b>GST AdminLock is currently 
                    		<span style="color:#<?php echo ($pluginStatus == true ? '159a04' : 'F00'); ?>">
								<?php echo strtoupper($status); ?>
	                        </span>
                       	</b>
                    </p>
                </div>            
			</div>
    		
            <br clear="all"/>
            
        </form>
        
    <?php	
	if($pluginStatus)
	{
		?>	
        <style>
		.input {
			margin: 10px 10px 10px 0;
			padding: 5px;
		}
		</style>
        <form method="post">    
            
            <div>
                <label>mySecretVar Value:</label>
                <input type="text" value="<?php echo (isset($mySecretVar) ? $mySecretVar : ''); ?>" name="mySecretVar" class="input"
                autocomplete="off" />
            </div>            
            <div>            
                <label>mySecretPassword Value:</label>
                <input type="text" value="<?php echo (isset($mySecretPassword) ? $mySecretPassword : ''); ?>" name="mySecretPassword" class="input"
                autocomplete="off" />                        
            </div>
            <div>            
                <label>Action taken when AdminLock variables are not provided or are incorrect?</label>
                <select class="input" name="actionTaken" onchange="actionType(this.value)">
                    <?php
						$redirect = "selected='selected'";							
						$customMessageSelect = "";
						$display = "none";													
						if($actionTaken == "customMessage")
						{
							$display = "";
							$customMessageSelect = "selected='selected'";
						}
                    ?>
                    <option <?php echo $redirect; ?> value="redirect">Redirect to Homepage</option>
                    <option <?php echo $customMessageSelect; ?> value="customMessage">Display a Custom Message</option>
                </select>
            </div>
            <div class="customMessage" style="display:<?php echo $display; ?>">
				<textarea id="post-content" name="customMessage"><?php echo safe_strip_decode($customMessage); ?></textarea>
			</div>
            <div style="margin-top:10px;">
            	<input type="hidden" name="status" value="<?php echo $status; ?>" />                       
	            <input class="submit" type="submit" value="Submit" name="submitBtn" />        
			</div>        
		</form>
        
	<?php 
	$EDHEIGHT = '150px';
	if (defined('GSEDITORLANG')) { $EDLANG = GSEDITORLANG; } else {	$EDLANG = i18n_r('CKEDITOR_LANG'); }
	if (defined('GSEDITORTOOL')) { $EDTOOL = GSEDITORTOOL; } else {	$EDTOOL = 'basic'; }
	if (defined('GSEDITOROPTIONS') && trim(GSEDITOROPTIONS)!="") { $EDOPTIONS = ", ".GSEDITOROPTIONS; } else {	$EDOPTIONS = ''; }
	
	$toolbar = "['Bold', 'Italic', 'Underline','JustifyLeft','JustifyCenter','JustifyRight','RemoveFormat', 'Source']";
	?>
		<script type="text/javascript" src="template/js/ckeditor/ckeditor.js"></script>
			<script type="text/javascript">
			function actionType(value)
			{
				if(value == "customMessage")
					$('.customMessage').slideDown(500);
				else
				{
					$('#post-content').val('');
					$('.customMessage').slideUp(500);					
				}
			}
			var editor = CKEDITOR.replace( 'post-content', {
					skin : 'getsimple',
					forcePasteAsPlainText : true,
					language : '<?php echo $EDLANG; ?>',
					defaultLanguage : 'en',
					entities : false,
					uiColor : '#FFFFFF',
					height: '<?php echo $EDHEIGHT; ?>',
					toolbar : 
					[
					<?php echo $toolbar; ?>
					]
					<?php echo $EDOPTIONS; ?>,					
					tabSpaces:10,
					filebrowserBrowseUrl : 'filebrowser.php?type=all',
					filebrowserImageBrowseUrl : 'filebrowser.php?type=images',
					filebrowserWindowWidth : '730',
					filebrowserWindowHeight : '500'
			});
			</script>
		<?php
	}	
}

/* 
	submitLockData($_POST)	
	
		Pass post variables to admin_lock.xml - store as key / value pairs 
 */
function submitLockData($POST)
{
	$xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><item></item>');
			
	foreach($POST as $key => $value)
	{
		if($key == "customMessage")
			$value = safe_slash_html($value);
		
		$note = $xml->addChild($key);
		$note->addCData($value);	
	}
		
	$xml->asXML(GSDATAOTHERPATH."admin_lock.xml");
	
	$isSuccess = true;
	$msg = "GST AdminLock Settings Updated";
	?>
	<script type="text/javascript">
      $(function() {
        $('div.bodycontent').before('<div class="<?php echo $isSuccess ? 'updated' : 'error'; ?>" style="display:block;">'+
                <?php echo json_encode($msg); ?>+'</div>');
        $(".updated, .error").fadeOut(500).fadeIn(500);
      });
    </script>
    <?php
}

/* 
	check_admin_login_page($_GET)	
		Confirm if plugin is enabled.
		Confirm key and value are correct
			proceed if correct
			redirect to home if incorrect or display message dependant on users choice.
 */
function check_admin_login_page($GET)
{
	if (defined('GSADMIN')) { $adminFolder = GSADMIN; } else {	$adminFolder = 'admin'; }

	//is login page?
	if (strpos($_SERVER['SCRIPT_NAME'],"/$adminFolder/index.php") !== false) 
	{
		//admin_lock file exist?
		if(file_exists(GSDATAOTHERPATH."admin_lock.xml"))
		{
			//get Data
			$thedata = getXML(GSDATAOTHERPATH."admin_lock.xml");
			$dataArray = array();
		
			foreach($thedata->children() as $child)
			{
				$dataArray[$child->getName()] = $child;
			}
			
			//is enabled?
			if($dataArray['status'] == "enabled")
			{
				$key = (string) $dataArray['mySecretVar'];
				$value = (string) $dataArray['mySecretPassword'];
				
				// $_GET var key and value correct
				if(!isset($GET[$key]) || ($GET[$key] != $value ))
				{
					//if redirect
					if($dataArray['actionTaken'] == "redirect")
						header( 'Location: ../' );
					else
					{
						//echo message
						echo safe_strip_decode($dataArray['customMessage']);
						exit;
					}
				}
			}
		}

	}
}

?>