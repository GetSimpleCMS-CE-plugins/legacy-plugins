-------- ABOUT THE PLUGIN ----------

Plugin aleksmir_math for GetSimple simple to add mathematical formulas to your pages. This plugin allows you to add mathematical formulas to your pages by writing simple tags. Used library of "Katex" from the developer khanacademy.org.

------ INSTALATION --------

Unzip the file aleksmir_math.zip in the plugins folder. Enable the plugin in admin panel.

Before the </head> in the theme must be a team:

<?php get_header(); ?>

The formula in the editor page is typed between the tags (%m .... m%)

The full list of commands is available at: https://github.com/Khan/KaTeX/wiki/Function-Support-in-KaTeX or in the plugin folder in the file katex/samples/functions.htm.

The most complete list of examples: http://www.intmath.com/cg5/katex-mathjax-comparison.php or in the plugin folder in the file katex/samples/samples.htm.
