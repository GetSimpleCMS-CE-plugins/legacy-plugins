<?php

// Plugin aleksmir_math for GetSimple
// Simple to add mathematical formulas to your pages
// This plugin allows you to add mathematical formulas to your pages by writing simple tags.
// This file is the handle of aleksmir_math for GetSimple.
// Author of plugin: Aleksey Smirnov, email: aleksmir@list.ru
// Used library of "Katex" from the developer https://www.khanacademy.org/
// Version 16.07.02

// Obtaining the correct ID for plugin
$thisfile = basename(__FILE__, '.php');

// To register plug-in system
register_plugin(
	$thisfile, 	               // ID of plugin, should be filename minus php
	'aleksmir_math',           // Title of plugin
	'16.07.02',                // Version of plugin
	'Aleksey Smirnov',	       // Author of plugin
	'http://aleksmir.ru',      // Author URL
	'Simple to add mathematical formulas to your pages', // Plugin Description
	'plugins', 	               // Page type of plugin
	''     					   // Function that displays content
);

// Add action "Theme Header"
add_action('theme-header', 'aleksmir_math_katex');

// Add action "content-top"
add_action('content-top', 'aleksmir_math_content');

// Function: processing events "Theme Header"
function aleksmir_math_katex() {
	// Define the path to the folder plugin
	$strPath = '/plugins/aleksmir_math/';
	// Add begin block "Katex"
	$strHTML = "\n".'<!-- Begin block "Katex" -->';
	// Add link to file CSS
	$strHTML.= "\n\t".'<link rel="stylesheet" href="'.$strPath.'katex/katex.min.css" />';
	// Add link to file JS
	$strHTML.= "\n\t".'<script type="text/javascript" src="'.$strPath.'katex/katex.min.js"></script>';
	// Font size increase
	$strHTML.= "\n\t".'<style type="text/css">.katex { font-size: 2em !important; } </style>';
	// Add end block "Katex"
	$strHTML.= "\n".'<!-- End block "Katex" -->';
	// Show result
	echo $strHTML;
}

// Function: the event action "content"
function aleksmir_math_content() {
    // Content extract
    global $content;
	// The definition tags
	$strTagBeg = '(%m';
	$strTagEnd = 'm%)';    
    // If there are fields (:m ... m:)
    if (preg_match('/\('.$strTagBeg.'.*?'.$strTagEnd.'\)/is', $content)) {
		// The definition of the beginning of the script
		$strBeg = '<script type="text/javascript">';
		$strBeg.= 'document.write(katex.renderToString("';
		// The definition of the end of the script
		$strEnd.= '"));';
		$strEnd.= '</script>';		
		// The find and replace in formula
		$masOne = explode($strTagEnd, $content);
		foreach ($masOne as &$strLine) {
		    if (stripos($strLine, $strTagBeg) !== false) {
    		    $masTwo = explode($strTagBeg, $strLine);
    	        $masTwo[1] = str_replace('<p>', ' ', $masTwo[1]);
    	        $masTwo[1] = str_replace('</p>', ' ', $masTwo[1]);
    	        $masTwo[1] = str_replace("\n", ' ', $masTwo[1]);
    	        $masTwo[1] = str_replace('<br />', ' ', $masTwo[1]);
    	        $masTwo[1] = str_replace('&nbsp;', ' ', $masTwo[1]);
    	        $masTwo[1] = str_replace('\\', '\\\\', $masTwo[1]);
    	        $strLine = implode($strBeg, $masTwo);
		    }
		}
		unset($strLine);
		$content = implode($strEnd, $masOne);
    }
}

?>