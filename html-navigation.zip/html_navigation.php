<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/*
Plugin Name: HTML Navigation
Description: Static  Pages
Version: 1.0
GS : 3.0
Author: Abhishek Shukla<abhishek.simsree@gmail.com>
Author URI: http://www.eeyesolutions.com/
Updated 03-APR-2012
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 	# ID of plugin, should be filename minus php
	'HTML Navigation', 	# Title of plugin
	'1.0', 		# Version of plugin
	'Abhishek Shukla',	# Author of plugin
	'http://www.eeyesolutions.com/', 	# Author URL
	'HTML pages are generated at GS Root', 	# Plugin Description
	'pages', 	# Page type of plugin
	'html_navigation'  	# Function that displays content
);

# hooks
add_action('pages-sidebar','createSideMenu',array($thisfile,'HTML Navigation')); //to allow configuration
add_action('theme-header', 'hn_theme_header_js');

function hn_theme_header_js(){
//auto redirect to html pages
 global $SITEURL;
 if (file_exists(GSROOTPATH.'index.html') && $_GET['create']<>'html') {
 echo'<script type="text/javascript"> 
<!--
 window.location="'.$SITEURL.'index.html"; 
 //--> 
	</script>
 ';
 }
}

function html_navigation(){
  //constants
  $msg = '';
  global $SITEURL;
  //recreate all static files at root
  if (isset($_POST['recreateatroot'])) {
	
	  $files = scandir(GSDATAPAGESPATH);
	   $msg ="No HTML File Created";
	  foreach ($files as $file){
		if (strpos($file,'.xml') > 0) {
		  $id = strpos($file,'.xml');
		  $id = substr($file,0,$id);
		  hn_wwwcopy($SITEURL."index.php?id=$id&create=html",GSROOTPATH."$id.html") ;
		  $msg = 'HTML pages recreated at GS ROOT. Visit Site to navigate html pages.';
		}
	  }
	  hn_handle_fancy_url();
	  /*$msg .= '<br>Put the following code in header of current template for html navigation<br>';
	  $msg .= "<textarea cols=50 rows=12><?php\r\n global \$SITEURL;\r\n if (file_exists('index.html')) {\r\n echo'<script type=\"text/javascript\"> \r\n<!--\r\n window.location=\"'.\$SITEURL.'index.html\"; \r\n //--> \r\n	</script>\r\n ';\r\n }\r\n?></textarea>";
	  */
  }
  
   //delete created all static files
  if (isset($_POST['deleteatroot'])) {
		$msg = hn_delete_html_files(GSROOTPATH);
  }

  //check whether pages are already created
	if (file_exists(GSROOTPATH."index.html")) { $createinputvalue="Recreate HTML Files";}
	else{ $createinputvalue="Create HTML Files";}
?>
<h2>HTML Navigation</h2>
<h3>Version : 1.0 by Abhishek Shukla &ltabhishek.simsree@gmail.com&gt -
<small><small><a href="http://get-simple.info/forum/topic/3750/html-navigation-plugin/" target="_blank">Support Forum</a></small></small></h3>
<div>
<ul>
<li>Create HTML Files at GET-SIMPLE ROOT to start HTML Navigation in the front-end. </li> 
<li>Deleting HTML Pages will stop HTML Navigation and restore usual navigation.</li> 
<li>The plugin also works with fancy URLs.</li> 
<li>Changes in site/ content/ theme will reflect in the front-end only after Recreating HTML Pages.</li> 
</ul>
<p>NB: Adding 'DirectoryIndex index.html index.php' to .htaccess of GS ROOT will ensure that 
index.html gets priority over index.php and avoid chances of php redirecting to html everytime the home page is visited.</p>

<form method='post'><input style='padding:5px;' type='submit' name='recreateatroot' value='<?php echo $createinputvalue;?>'>
                    <input style='padding:5px;' type='submit' name='deleteatroot' value='Delete HTML Files'>
                    </form><br/></div>
<?php $list=hn_list_html_files(GSROOTPATH,$SITEURL);
	if($list<>''){
		echo "<h3>List of HTML Files Created</h3><ol>".$list."</ol>";
	}
?>
					<br/>
<div style='margin-top:10px;color:red'><p ><?php echo $msg; ?></p></div>
<?php  

}

function hn_delete_html_files($directory){
	$msg = 'No File to delete. HTML Navigation disabled in the front-end.';
	$files = scandir($directory);
	  foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			unlink(GSROOTPATH.$file);
			$msg = 'HTML files deleted from GS ROOT. HTML Navigation disabled in the front-end.';
		}
	 }
	return $msg;
}

function hn_list_html_files($directory,$directoryurl=''){
	$list= '';
	$files = scandir($directory);
	  foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			if ($directoryurl && $directoryurl<>''){
				$list .=  '<li><a href="'.$directoryurl.$file.'" target="_blank">'.$file.'</a></li>';
			}
			else{
				$list .=  '<li>'.$file.'</li>';
			}
		}
	 }
	return $list;
}

function hn_handle_fancy_url(){
	global $SITEURL;
	$files = scandir(GSROOTPATH);
	$i=0;
	//array of fancy urls an corresponding html url
	foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			$fancyurl[$i]=str_replace('.html','/',$SITEURL.$file);
			$normalurl[$i]=str_replace('.html','',$SITEURL."index.php?id=".$file);
			$htmlurl[$i]=$SITEURL.$file;
			$i++;
		}
	}
	foreach ($files as $file){
		if (strpos($file,'.html') > 0 && $file != '.' && $file != '..') {
			$html = file_get_contents(GSROOTPATH.$file); 
			$html = str_replace($fancyurl,$htmlurl,$html);
			$html = str_replace($normalurl,$htmlurl,$html);
			//fix for extra characters before/after valid html
			$matchexp='/\S*\s*<!DOCTYPE/';
			$html =preg_replace($matchexp,"<!DOCTYPE" , $html);
			$matchexp='/<\/html\s*\S*\s*\S*/';
			//$html =preg_replace($matchexp,"</html>" , $html);
			file_put_contents(GSROOTPATH.$file,$html);
		}
	}
}

function hn_wwwcopy($link,$file){ 
   $fp = @fopen($link,"r"); 
   while(!feof($fp)) 
   { 
       $cont.= fread($fp,1024); 
   } 
   fclose($fp); 

   $fp2 = @fopen($file,"w"); 
   fwrite($fp2,$cont); 
   fclose($fp2); 
}
?>