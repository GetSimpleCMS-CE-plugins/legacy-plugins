$(document).ready(function(){
   $('#my_moveable').sortable();
});