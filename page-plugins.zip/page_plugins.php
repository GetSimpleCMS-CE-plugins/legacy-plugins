<?php
/*
Plugin Name: Page Plugins
Description: Allows admin to turn on/off plugins by page
Version: 1.0
Author: David Shaner
Author URI: http://www.shaner.us/
*/

# get correct id for plugin
$thisfile_pl = basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile_pl, 
	'Page Plugins', 	
	'1.1', 		
	'David Shaner',
	'http://www.shaner.us/', 
	'Allows admin to change the plugin loader order',
	'plugins',
	'plugin_on_off'  
);

# Get website URL
$my_website_xml = GSDATAOTHERPATH.'website.xml';
$myx = getXML($my_website_xml);
$my_website = $myx->SITEURL;

# Check to see if URL has trailing slash
$my_trailing_slash = substr($my_website,-1);

if($my_trailing_slash !== '/'){
    $my_website = $my_website.'/';
}

# Create Sidebar
add_action('plugins-sidebar','createSideMenu',array($thisfile_pl,'Turn Plugins On/Off By Page','plugin_on_off'));

# Plugin XML file
$my_plugin_xml = GSDATAOTHERPATH .'plugins.xml';

#XML Storage folder
$my_storage_dir = GSDATAOTHERPATH.'page_plugins/';

/**
 * Main Function
 */
function plugin_on_off(){
    global $my_website, $my_storage_dir;
    
    register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', '1.7.1', FALSE);
    queue_script('jquery',GSBACK);

    register_script('jqueryui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js', '1.8.18', TRUE);
    queue_script('jqueryui',GSBACK);

    register_script('plugin_ui', $my_website.'plugins/page_plugins/js/plugin_ui.js', '1.0', TRUE);
    queue_script('plugin_ui',GSBACK);
    
    // Make directory to store page_plugin xml
    if(!is_dir($my_storage_dir))
    {
        mkdir($my_storage_dir);
    }
    
    $my_action_url = $_SERVER['QUERY_STRING'];
    $my_action = explode('&',$my_action_url);
    $my_action = $my_action[1];
    
    switch($my_action){
        case 'plugin_on_off':
            my_plugin_get_xml();
            break;
    }
}

/**
 * Read in XML File
 */
function my_plugin_get_xml(){
    
    global $my_plugin_xml, $plugin_reorder_xml, $my_plugin, $my_enabled, $my_website;
    $myx = null;
    if (file_exists($my_plugin_xml)) {
        my_create_plugin_form();
    } else {
        echo '<p style="color:#cc0000;"><b>There are no plugins to reorder.</b></p>';
    }
}

/**
 * Create the Plugin Reorder Form
 */
function my_create_plugin_form(){
    global $my_plugin_xml;
    
    if(isset($_POST['my_submit'])){
        $my_selected = $_POST['my_page_select'];
        $my_plugins = $_POST['my_plugin'];
        $my_plugins_status = $_POST['my_plugin_off'];
        
        
        my_create_plugin_xml($my_selected,$my_plugins,$my_plugins_status);
    }
    ?>
    <style type="text/css">
    #my_moveable{
        cursor:move;
    }
    .my_moveable{
        text-indent:10px;
        font-size:14px;
        font-weight:bold;
        font-family: Verdana, Arial, sans-serif;
        width:100%;
        height:30px;
        line-height:30px;
        background-color:#CF3805;
        color:#ffffff;
        border-bottom:1px double #ffffff;
    }
    </style>
    <h3>Plugins for Page</h3>
    <form action="<?php	echo $_SERVER ['REQUEST_URI']?>" method="post">
    <?php
    $my_page_scan = scandir(GSDATAPAGESPATH);
    foreach($my_page_scan as $my_page)
    {
        if(substr($my_page,-4) == '.xml')
        {
            $my_pages[] = $my_page;
        }
    }
    ?>
    <p>Page to create custom plugin file for: 
    <select id="my_page_select" name="my_page_select">
        <?php
        foreach($my_pages as $my_option){
            echo '<option value="'.$my_option.'">'.substr($my_option,0,-4).'</option>'."\n";
        }
        ?>
    </select>
    </p>
    <p>Drag the plugins to the order you want them to display on the frontend</p>
    <div id="my_moveable">
        <?php
        $my_plugin = null;
        $my_on_off = null;
        $x = getXML($my_plugin_xml);
        foreach($x as $y){
            $my_plugin = $y->plugin;
            $my_on_off = $y->enabled;
        
            if($my_plugin != 'page_plugins.php' && $my_on_off == 'true')
            {
            ?>
            <div class="my_moveable">
                <select name="my_plugin_off[]">
                    <option value="true" selected="selected">Turn On</option>
                    <option value="false">Turn Off</option>
                </select>
                <?php echo $my_plugin; ?>
                <input type="hidden" name="my_plugin[]" value="<?php echo $my_plugin; ?>"/>
            </div>
            <?php
            }
        }
        ?>
    </div>
    <br/>
    <p><input type="submit" id="submit" class="submit" value="Save Page Plugins" name="my_submit" /></p>
    </form>
    
    <?php
}

/**
 * Create the Plugin XML
 */
function my_create_plugin_xml($my_selected,$my_plugins,$my_plugins_status){
    global $my_storage_dir;
    
    $xml = @new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><channel></channel>'); 
    
    for($i=0; $i < count($my_plugins); $i++){
        $components = $xml->addChild('item');  
        $c_note = $components->addChild('plugin');
        $c_note->addCData($my_plugins[$i]);
        $c_note = $components->addChild('enabled');
        $c_note->addCData($my_plugins_status[$i]);  
    }
    $success = XMLsave($xml, $my_storage_dir.$my_selected);
    
    if($success === TRUE){
        echo '<p style="color:#669933;"><b>File was saved.</b></p>';
    }
    
}
?>