<?php

/**
 * Scroll Me Up by mod1fy.net for GetSimple CMS
 * =======================================================
 * Main CSS file of the plugin
 * Contains all CSS definitions of the plugin.
 * =======================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * =======================================================
 * @package    mod1fy_scroll_me_up
 * @subpackage mod1fy_scroll_me_up/css/scrollmeup_css.php
 * =======================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */
 
header("Content-type: text/css");
?>
/* TO TOP*/
#toTop-right {
	display:none;
	text-decoration:none;
	position:fixed;
	bottom:20px;
	right:20px;
	outline:none;
}
#toTop-left {
	display:none;
	text-decoration:none;
	position:fixed;
	bottom:20px;
	left:20px;
	outline:none;
}
#toTop-center {
	display:none;
	text-decoration:none;
	position:fixed;
	bottom:10px;
	left:50%;
	margin-left:-20px;
	outline:none;
}
.smubtn a:link {
	text-decoration:none !important;
}
.smubtn {
	color: #333;
	text-decoration:none !important;
	background-color: #fff;
	border-color: #ccc;
	padding: 6px 10px;
	font-size: 14px;
	line-height: 1.33;
	border-radius: 25px;
	display: inline-block;
	margin-bottom: 0;
	font-weight: normal;
	line-height: 1.42857143;
	text-align: center;
	white-space: nowrap;
	vertical-align: middle;
	-ms-touch-action: manipulation;
	touch-action: manipulation;
	cursor: pointer;
	-webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
	user-select: none;
	background-image: none;
	border: 1px solid #ccc;
}
.smubtn:focus,
.smubtn:active:focus,
.smubtn.active:focus,
.smubtn.focus,
.smubtn:active.focus,
.smubtn.active.focus {
	outline: thin dotted;
	outline: 5px auto -webkit-focus-ring-color;
	outline-offset: -2px;
}
.smubtn:hover,
.smubtn:focus,
.smubtn.focus {
	color: #333;
	background-color: #e6e6e6;
	border-color: #adadad;
	text-decoration: none;
}
.smubtn:active,
.smubtn.active {
	background-image: none;
	outline: 0;
	-webkit-box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
	box-shadow: inset 0 3px 5px rgba(0, 0, 0, .125);
}
label.infotext {
	padding-top:10px;
	font-style:italic;
	font-weight:normal;
}
span.smu {
	padding:10px;
}
div.smu {
	clear:both;
	padding:10px;
	border:1px solid #ccc;
	border-left:4px solid #5b8dc2;
	border-radius:10px;
	background:#ffffcf;
}
p.smu {
	padding:10px;
	border:1px solid #ccc;
	border-left:4px solid #5b8dc2;
	border-radius:10px;
	background:#ffffcf;
}
span.lighton {
	padding:5px;
	cursor:pointer;
	display:inline;
	float:left;
	background-color:#FAFAFA;
	border:1px solid #ccc;
	border-radius:10px;
}
span.lightoff {
	padding:5px;
	cursor:pointer;
	display:inline;
	float:right;
	background-color:#FAFAFA;
	border:1px solid #ccc;
	border-radius:10px;
}
hr.smu {
    height: 30px;
    border-style: solid;
    border-color: black;
    border-width: 1px 0 0 0;
    border-radius: 20px;
}
hr.smu:before {
    display: block;
    content: "";
    height: 30px;
    margin-top: -31px;    
    border-style: solid;
    border-color: black;
    border-width: 0 0 1px 0;
    border-radius: 20px;
}