Scroll Me Up by Mod1fy.net - Readme file

*****************************************************

Support : http://mod1fy.net/gsplugins/scroll-me-up/

Requires: at least GetSimple v. 3.0.0

Tested up to : 3.3.4

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html

*****************************************************

Scroll-To-Top Function

Welcome !

If this plugin is activated, it adds an customizable button to the bottom right of your GetSimple site, which will appear after 400 Pixels of page scrolling, and grants your visitors a shiny animated way to get fast back to the top of your site.

The button and animation can be customized within the settings - page.
You have also the choice to enable the FontAwesome icon font, or if already exists, to disable it. This Option is enabled by default.

You can use this icons very easy within your scroll-to-top button. Just paste the special icon code into the defined field. Example : fa fa-chevron-up. Other combinations are possible too, like this example : fa fa-chevron-up fa-3x pull-left fa-border.

If you are using Twitter Bootstrap with your theme, you can surely use all glyphicons too.

Scroll-To-Content Function

This plugin is able to find anchors within the content of your site. With anchors you can grant your visitors a comfortable way to scroll fast to content sections of interest within large contents.

For example you could apply an table of contents at the top of an article, so your visitors can jump fast to the defined content anchors. This works also without this plugin. The plugin grants only the shiny animation :) .

Anchorpoints can easy defined with help from the getsimples ckeditor anchor-button. Linking to these anchors can be done with the ckeditors link-button in submenu anchor of this site. The plugins animation works from top to bottom as well as bottom to top.

If your editor has no anchor button, you can set anchors manually. A anchor is defined by an empty link with ID. The definded anchors can be selected by klicking on the add link button and choose link to anchor in the text.

Example : <a id="heading1" name="heading1"></a>

Version : 1.0.5

== Changelog ==

v. 1.0.5

* Added: More info @ infopage
* Added: Some translations
* Fixed: A bug with the preview button
* Fixed: UI tweaks

v. 1.0.4

* Added: Redo function
* Added: Information page
* Added: English language file
* Fixed: Some smaller bugs

v. 1.0.3

* Added: jQuery.localScroll 1.3.5
* Added: jQuery.scrollTo 1.4.14
* Added: Color picker function
* Added: Preview background switcher
* Fixed: More bugs

v. 1.0.2

* Added: Button opacity option
* Added: Button color option
* Added: Button live preview
* Added: FontAwesome option
* Fixed: Some bugs

v. 1.0.1

* Added: Button icon option
* Added: Button CSS option
* Added: Button text option
* Added: Animation types
* Added: Animation delay function
* Added: jQuery Easing v1.3
* Added: German language file

v. 1.0.0

* First stable version

== ToDo features ==

* Changeable scroll-to-content animations
* Add more animations
* Button position changeable
* Button image option

� 2014 Dennis Maassen

http://mod1fy.net