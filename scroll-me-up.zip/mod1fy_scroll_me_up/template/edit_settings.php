<?php if (!defined('IN_GS')) {die('no script kiddies please.');}

/**
 * Scroll Me Up by Mod1fy.net for GetSimple CMS
 * ==========================================================
 * Main Settings File
 * Contains the backend settings page.
 * ==========================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * ==========================================================
 * @package    mod1fy_scroll_me_up
 * @subpackage mod1fy_scroll_me_up/template/edit_settings.php
 * ==========================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * @Main admin function
 * @since 1.0.0
 *
 */
function smu_admin() {

	$smuconfig = smu_read_config();
	$error = "";
	$success = "";
	$canUndo = false;

	if (isset($_POST['submit'])) {

		$smuconfig['scroll_speed'] = intval($_POST['scroll_speed']);
		$smuconfig['btn_text']     = strval($_POST['btn_text']);
		$smuconfig['animation']    = strval($_POST['animation']);
		$smuconfig['btn_style']    = strval($_POST['btn_style']);
		$smuconfig['load_fa']      = intval($_POST['load_fa'] ? 1 : 0);
		$smuconfig['btn_icon']     = strval($_POST['btn_icon']);
		$smuconfig['btn_color']    = strval($_POST['btn_color']);
		$smuconfig['icon_color']   = strval($_POST['icon_color']);
		$smuconfig['text_color']   = strval($_POST['text_color']);
		$smuconfig['btn_opacity']  = strval(str_replace(",",".",$_POST['btn_opacity']));

		if ($error == "") {

			if (! smu_write_config($smuconfig)) {

				$error = i18n_r('CHMOD_ERROR');

			} else {

				$smuconfig = smu_read_config();
				$success = i18n_r('SETTINGS_UPDATED');
			}
		}
		if($success) {

			$msg = $success;
		}
		if($error) {

			$msg = $error;
		}
	}
	if (isset($_POST['defaults'])) {

		if (file_exists(GSDATAOTHERPATH.'mod1fy_scroll_me_up.xml')) {

			if (copy(GSDATAOTHERPATH.'mod1fy_scroll_me_up.xml', GSBACKUPSPATH.'other/'.'mod1fy_scroll_me_up.xml')) {

				$canUndo = true;
			}
		}
		$success = !file_exists(SMUSETTINGS_XML) || unlink(SMUSETTINGS_XML);
		$smuconfig = smu_read_config();
		$msg = $success ? i18n_r('mod1fy_scroll_me_up/SMU_DEFAULTSSUCCESS') : i18n_r('mod1fy_scroll_me_up/SMU_DEFAULTSERROR');

		if ($success && $canUndo) $msg .= ' <a href="load.php?id=mod1fy_scroll_me_up&view=settings&undo">' . i18n_r('UNDO') . '</a>';
	}
	if (isset($_REQUEST['undo'])) {

		if (file_exists(GSBACKUPSPATH.'other/'.'mod1fy_scroll_me_up.xml')) {

			if (copy(GSBACKUPSPATH.'other/'.'mod1fy_scroll_me_up.xml', GSDATAOTHERPATH.'mod1fy_scroll_me_up.xml')) {

				$success = true;
			}
		}
		$smuconfig = smu_read_config();
		$msg = $success ? i18n_r('mod1fy_scroll_me_up/SMU_UNDOSUCCESS') : i18n_r('mod1fy_scroll_me_up/SMU_UNDOFAILURE');
	}

	$view = @$_REQUEST['view'];
	if (!$view) $view = 'description';
		$link = "load.php?id=mod1fy_scroll_me_up&view=settings";
?>
<h3 class="floated" style="float:left"><?php i18n("mod1fy_scroll_me_up/SMU_SETTINGSPAGE"); ?></h3>
	<div class="edit-nav" >
		<p>
			<a href="<?php echo $link; ?>&view=description" <?php echo $view=='description' ? 'class="current"' : ''; ?> ><?php echo i18n_r('mod1fy_scroll_me_up/SMU_VIEWDESCRIPTION'); ?></a>
			<a href="<?php echo $link; ?>&view=settings" <?php echo $view=='settings' ? 'class="current"' : ''; ?> ><?php echo i18n_r('mod1fy_scroll_me_up/SMU_VIEWSETTINGS'); ?></a>
		</p>
    <div class="clear" ></div>
	</div>
<?php if ($view == 'settings') { ?>
<form class="largeform" id="settings" action="<?php echo $link; ?>" method="post" accept-charset="utf-8" onSubmit="window.location.reload()">
	<div style="padding-right:10px;width:47%;" class="leftsec">
		<p class="smu" style="padding-bottom:20px;">           
			<label for="scroll_speed"><?php i18n("mod1fy_scroll_me_up/SMU_SCROLLSPEED"); ?><span style="float:right;" id="t1"><?php echo $smuconfig['scroll_speed']; ?></span></label>
			<input type="range" min="500" max="3000" step="100" id="scroll_speed" name="scroll_speed" class="text" onchange="outputUpdate(value)" value="<?php echo $smuconfig['scroll_speed']; ?>">
			<span>
				<span style="float:left;width:33.3333%;text-align:left;"><?php i18n("mod1fy_scroll_me_up/SMU_FAST"); ?></span>
				<span style="float:left;width:33.3333%;text-align:center;"><?php i18n("mod1fy_scroll_me_up/SMU_MIDDLE"); ?></span>
				<span style="float:left;width:33.3333%;text-align:right;"><?php i18n("mod1fy_scroll_me_up/SMU_SLOW"); ?></span>
			</span>
		</p>
        <p class="smu">
            <label for="animation"><?php i18n("mod1fy_scroll_me_up/SMU_ANIMATION"); ?></label>
            <input type="radio" id="easeOutBounce" name="animation" value="easeOutBounce" <?php if ($smuconfig['animation'] == 'easeOutBounce') echo "checked=\"checked\""; ?> /> Bounce</br>
			<input type="radio" id="linear" name="animation" value="linear" <?php if ($smuconfig['animation'] == 'linear') echo "checked=\"checked\""; ?> /> Linear</br>
			<input type="radio" id="swing" name="animation" value="swing" <?php if ($smuconfig['animation'] == 'swing') echo "checked=\"checked\""; ?> /> Swing
			<label class="infotext"><?php i18n("mod1fy_scroll_me_up/SMU_ANIMATIONINFO"); ?></label>
        </p>
		<p class="smu">
            <label for="btn_text"><?php i18n("mod1fy_scroll_me_up/SMU_BTNTEXT"); ?></label>
            <input id="btn_text" name="btn_text" class="text" value="<?php echo $smuconfig['btn_text']; ?>" />
			<label class="infotext"><?php i18n("mod1fy_scroll_me_up/SMU_BTNTEXTINFO"); ?></label>
        </p>
		<p class="smu">
            <label for="btn_style"><?php i18n("mod1fy_scroll_me_up/SMU_BTNSTYLE"); ?></label>
            <input id="btn_style" name="btn_style" class="text" value="<?php echo $smuconfig['btn_style']; ?>" />
			<label class="infotext"><?php i18n("mod1fy_scroll_me_up/SMU_BTNSTYLEINFO"); ?><br><a href="http://getbootstrap.com/" target="_blank">Bootstrap Website</a></label>
        </p>
		<p class="smu">
            <label for="btn_icon"><?php i18n("mod1fy_scroll_me_up/SMU_BTNICON"); ?></label>
            <input id="btn_icon" name="btn_icon" class="text" value="<?php echo $smuconfig['btn_icon']; ?>" />
        </p>
	</div>
	<div style="padding-left:10px;width:47%;" class="rightsec">
		<p class="smu"><label for="btn_preview"><?php i18n("mod1fy_scroll_me_up/SMU_BTNPREVIEW"); ?></label></p>
		<p>
			<div id="preview" class="smu" style="text-align:center;">
			<span id="lighton" class="lighton"><?php i18n("mod1fy_scroll_me_up/SMU_LIGHTOFF"); ?></span>
			<span id="lightoff" class="lightoff"><?php i18n("mod1fy_scroll_me_up/SMU_LIGHTON"); ?></span>
				<div id="btn_preview" style="background-color:#<?php echo $smuconfig['btn_color']; ?>;opacity:<?php echo $smuconfig['btn_opacity']; ?>;" class="<?php echo $smuconfig['btn_style']; ?>">
					<i style="color:#<?php echo $smuconfig['icon_color']; ?>" class="<?php $data = @getXML(SMUSETTINGS_XML); $SMUBTNICON = isset($data->btn_icon) ? $data->btn_icon : 'fa fa-chevron-up'; echo $SMUBTNICON; ?>"> </i>
					<span id="btn_preview" style="color:#<?php echo $smuconfig['text_color']; ?>"><?php echo $smuconfig['btn_text']; ?></span>
				</div>
			</div>
		</p>
		<div class="smu">
			<p>
				<label for="btn_color"><?php i18n("mod1fy_scroll_me_up/SMU_BTNCOLOR"); ?></label>
				<input type="text" class="text" name="btn_color" maxlength="6" id="btn_color" value="<?php echo $smuconfig['btn_color']; ?>" />
			</p>
			<p>
				<label for="icon_color"><?php i18n("mod1fy_scroll_me_up/SMU_ICONCOLOR"); ?></label>
				<input type="text" class="text" name="icon_color" maxlength="6" id="icon_color" value="<?php echo $smuconfig['icon_color']; ?>" />
			</p>
			<p>
				<label for="text_color"><?php i18n("mod1fy_scroll_me_up/SMU_TEXTCOLOR"); ?></label>
				<input type="text" class="text" name="text_color" maxlength="6" id="text_color" value="<?php echo $smuconfig['text_color']; ?>" />
			</p>
		</div>
		<p class="smu" style="padding-bottom:20px;margin-top:20px;">           
			<label for="btn_opacity"><?php i18n("mod1fy_scroll_me_up/SMU_BTNOPACITY"); ?><span style="float:right;" id="t2"><?php echo (str_replace(",",".",$smuconfig['btn_opacity'])); ?></span></label>
			<input type="range" min="0" max="1" step="0.05" id="btn_opacity" name="btn_opacity" class="text" onchange="outputUpdate(value)" value="<?php echo $smuconfig['btn_opacity']; ?>">
			<span>
				<span style="float:left;width:33.3333%;text-align:left;">0 %</span>
				<span style="float:left;width:33.3333%;text-align:center;">50 %</span>
				<span style="float:left;width:33.3333%;text-align:right;">100 %</span>
			</span>
		</p>
		<p class="smu">
            <label for="load_fa"><?php i18n("mod1fy_scroll_me_up/SMU_LOADFA"); ?></label>
            <input type="checkbox" id="load_fa" name="load_fa" value="1" <?php if ($smuconfig['load_fa'] == 1) echo "checked=\"checked\""; ?> />
			<label class="infotext"><?php i18n("mod1fy_scroll_me_up/SMU_FONTAWESOMEINFO"); ?><br><a href="http://fortawesome.github.io/Font-Awesome/icons/" target="_blank">FontAwesome Website</a></label>
		</p>
	</div>
	<div class="clear">
	<hr>
	</div>
	<input onClick="window.location.reload()" type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" />
	<input onClick="window.location.reload()" type="submit" id="defaults" class="submit" value="<?php i18n("mod1fy_scroll_me_up/SMU_BTNDEFAULTS"); ?>" name="defaults" />
</form>
<script type="text/javascript">
$(function() {
<?php if (isset($msg)) { ?>
	$('div.bodycontent').before('<div class="<?php echo $success ? 'updated' : 'error'; ?>" style="display:block;">'+<?php echo json_encode($msg); ?>+'</div>');
<?php } ?>
});
document.getElementById('scroll_speed').onchange = function() {
	document.getElementById('t1').innerHTML = this.value;
}
document.getElementById('btn_opacity').onchange = function() {
	document.getElementById('t2','btn_preview').innerHTML = this.value;
	$('#btn_preview').css('opacity', this.value);
}
document.getElementById('lighton').onclick = function() {
	$('#preview').css('backgroundColor', '#464646');
}
document.getElementById('lightoff').onclick = function() {
	$('#preview').css('backgroundColor', '#ffffcf');
}
$('#btn_color').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		$(el).val(hex);
		$(el).ColorPickerHide();
		$('#btn_preview').css('backgroundColor', '#' + hex);
	},
	onBeforeShow: function () {
		$(this).ColorPickerSetColor(this.value);
	}
})
$('#icon_color').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		$(el).val(hex);
		$(el).ColorPickerHide();
		$('#btn_preview .fa').css('color', '#' + hex);
	},
	onBeforeShow: function () {
		$(this).ColorPickerSetColor(this.value);
	}
})
$('#text_color').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		$(el).val(hex);
		$(el).ColorPickerHide();
		$('#btn_preview span').css('color', '#' + hex);
	},
	onBeforeShow: function () {
		$(this).ColorPickerSetColor(this.value);
	}
})
</script>
<?php } else { ?>
<div class="smu">
<?php i18n('mod1fy_scroll_me_up/SMU_DESCHEAD1'); ?>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO2'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO3'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO4'); ?><br><br>
<a href="http://fortawesome.github.io/Font-Awesome/examples/" target="_blank"><?php i18n('mod1fy_scroll_me_up/SMU_FALINK'); ?></a> -
<a href="http://getbootstrap.com/" target="_blank"><?php i18n('mod1fy_scroll_me_up/SMU_BOOTSTRAPLINK'); ?></a>
</div><br>
<div class="smu">
<?php i18n('mod1fy_scroll_me_up/SMU_DESCHEAD2'); ?>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO5'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO6'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO7'); ?><br><br>
<img src="<?php echo '../plugins/mod1fy_scroll_me_up/images/anker.jpg' ?>" /><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_DESCINTRO8'); ?><br><br>
<?php i18n('mod1fy_scroll_me_up/SMU_EXAMPLE'); ?> <code>&lt;a id="heading1" name="heading1"&gt;&lt;/a&gt;</code><br><br>
<center><img src="<?php echo '../plugins/mod1fy_scroll_me_up/images/anker2.jpg' ?>" /></center><br><br>
</div><br>
<div style="padding-right:1%;width:49%;" class="leftsec">
<div style="font-family:consolas;" class="smu">
Version : <?php echo SMUVERSION; ?><br><br>
== Changelog ==<br><br>
v. 1.0.5<br><br>
* Added: More info @ infopage<br>
* Added: Some translations<br>
* Fixed: A bug with the preview button<br>
* Fixed: UI tweaks<br><br>
v. 1.0.4<br><br>
* Added: Redo function<br>
* Added: Information page<br>
* Added: English language file<br>
* Fixed: Some smaller bugs<br><br>
v. 1.0.3<br><br>
* Added: jQuery.localScroll 1.3.5<br>
* Added: jQuery.scrollTo 1.4.14<br>
* Added: Color picker function<br>
* Added: Preview background switcher<br>
* Fixed: More bugs<br><br>
v. 1.0.2<br><br>
* Added: Button opacity option<br>
* Added: Button color option<br>
* Added: Button live preview<br>
* Added: FontAwesome option<br>
* Fixed: Some bugs<br><br>
v. 1.0.1<br><br>
* Added: Button icon option<br>
* Added: Button CSS option<br>
* Added: Button text option<br>
* Added: Animation types<br>
* Added: Animation delay function<br>
* Added: jQuery Easing v1.3<br>
* Added: German language file<br><br>
v. 1.0.0<br><br>
* First stable version<br>
</div>
</div>
<div style="padding-left:1%;width:49%;" class="rightsec">
	<div style="text-align:center;" class="smu">
		&copy; 2014 Dennis Maassen<br><br>
		<a href="http://mod1fy.net/" target="_blank">http://mod1fy.net</a><br><br>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="S8FN58PVGSVC4">
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
			<img alt="" border="0" src="https://www.paypalobjects.com/de_DE/i/scr/pixel.gif" width="1" height="1">
		</form><br><br>
		<div style="text-align:left;font-family:consolas;">
		== ToDo features ==<br><br>
		* Changeable scroll-to-content animations<br>
		* Add more animations<br>
		* Button position changeable<br>
		* Button image option<br>
		</div>
	</div>
</div>
<div class="clear"></div>
<?php }
} ?>