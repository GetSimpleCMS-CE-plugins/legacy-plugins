<?php if (!defined('IN_GS')) {die('no script kiddies please.');}

/**
 * Scroll Me Up by mod1fy.net for GetSimple CMS
 * =======================================================
 * Main settings Functions File
 * Contains all needed functions by the plugin.
 * =======================================================
 * @link:      http://mod1fy.net
 * @since      1.0.0
 * =======================================================
 * @package    mod1fy_scroll_me_up
 * @subpackage mod1fy_scroll_me_up/inc/settings.php
 * =======================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

/**
 * @Get settings or load defaults
 * @since 1.0.1
 *
 */
$data = @getXML(SMUSETTINGS_XML);

$SMUSCROLLSPEED = isset($data->scroll_speed) ? $data->scroll_speed : '1700';
$SMUBTNTEXT     = isset($data->btn_text) ? $data->btn_text : 'Top';
$SMUANIMATION   = isset($data->animation) ? $data->animation : 'easeOutBounce';
$SMUBTNSTYLE    = isset($data->btn_style) ? $data->btn_style : 'smubtn';
$SMULOADFA      = isset($data->load_fa) ? $data->load_fa : 1;
$SMUBTNICON     = isset($data->btn_icon) ? $data->btn_icon : 'fa fa-chevron-up';
$SMUBTNCOLOR    = isset($data->btn_color) ? $data->btn_color : 'FFFFFF';
$SMUICONCOLOR   = isset($data->icon_color) ? $data->icon_color : '333333';
$SMUTEXTCOLOR   = isset($data->text_color) ? $data->text_color : '333333';
$SMUBTNOPACITY  = isset($data->btn_opacity) ? $data->btn_opacity : '0.75';

/**
 * @Get languages
 * @since 1.0.0
 *
 */
function smu_get_languages() {

	$languages = array();
	$files = getFiles(SMULANGPATH);

	foreach ($files as $file) {

		if (isFile($file, SMULANGPATH, 'php')) {

			$lang = basename($file, '.php');
			$languages[$lang] = SMULANGPATH . $file;
		}
	}
	ksort($languages);
	return $languages;
}

/**
 * @Read config or define defaults
 * @since 1.0.0
 *
 */
function smu_read_config() {

	$smuconfig = array();

    if (file_exists(SMUSETTINGS_XML)) {

		$SMUSCROLLSPEED = getXML(SMUSETTINGS_XML);
		$SMUBTNTEXT     = getXML(SMUSETTINGS_XML);
		$SMUANIMATION   = getXML(SMUSETTINGS_XML);
		$SMUBTNSTYLE    = getXML(SMUSETTINGS_XML);
		$SMULOADFA      = getXML(SMUSETTINGS_XML);
		$SMUBTNICON     = getXML(SMUSETTINGS_XML);
		$SMUBTNCOLOR    = getXML(SMUSETTINGS_XML);
		$SMUICONCOLOR   = getXML(SMUSETTINGS_XML);
		$SMUTEXTCOLOR   = getXML(SMUSETTINGS_XML);
		$SMUBTNOPACITY  = getXML(SMUSETTINGS_XML);

		$smuconfig['scroll_speed'] = intval($SMUSCROLLSPEED->scroll_speed);
		$smuconfig['btn_text']     = strval($SMUBTNTEXT->btn_text);
		$smuconfig['animation']    = strval($SMUANIMATION->animation);
		$smuconfig['btn_style']    = strval($SMUBTNSTYLE->btn_style);
		$smuconfig['load_fa']      = intval($SMULOADFA->load_fa);
		$smuconfig['btn_icon']     = strval($SMUBTNICON->btn_icon);
		$smuconfig['btn_color']    = strval($SMUBTNCOLOR->btn_color);
		$smuconfig['icon_color']   = strval($SMUICONCOLOR->icon_color);
		$smuconfig['text_color']   = strval($SMUTEXTCOLOR->text_color);
		$smuconfig['btn_opacity']  = strval(str_replace(",",".",$SMUBTNOPACITY->btn_opacity));

    } else {

		$smuconfig['scroll_speed'] = '1700';
		$smuconfig['btn_text']     = 'Top';
		$smuconfig['animation']    = 'easeOutBounce';
		$smuconfig['btn_style']    = 'smubtn';
		$smuconfig['load_fa']      = 1;
		$smuconfig['btn_icon']     = 'fa fa-chevron-up';
		$smuconfig['btn_color']    = 'FFFFFF';
		$smuconfig['icon_color']   = '333333';
		$smuconfig['text_color']   = '333333';
		$smuconfig['btn_opacity']  = '0.75';
    }
    return $smuconfig;
}

/**
 * @Save config to xml
 * @since 1.0.0
 *
 */
function smu_write_config($smuconfig) {

    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><item></item>');

	$xml->addChild('scroll_speed', $smuconfig['scroll_speed']);
	$xml->addChild('btn_text', $smuconfig['btn_text']);
	$xml->addChild('animation', $smuconfig['animation']);
	$xml->addChild('btn_style', $smuconfig['btn_style']);
	$xml->addChild('load_fa', $smuconfig['load_fa']);
	$xml->addChild('btn_icon', $smuconfig['btn_icon']);
	$xml->addChild('btn_color', $smuconfig['btn_color']);
	$xml->addChild('icon_color', $smuconfig['icon_color']);
	$xml->addChild('text_color', $smuconfig['text_color']);
	$xml->addChild('btn_opacity', $smuconfig['btn_opacity']);

	return @XMLsave($xml, SMUSETTINGS_XML);
}
?>