<?php

/**
 * Scroll Me Up by mod1fy.net for GetSimple CMS
 * =======================================================
 * English language file of the plugin
 * =======================================================
 * @link:      http://mod1fy.net
 * @since      1.0.4
 * =======================================================
 * @package    mod1fy_scroll_me_up
 * @subpackage mod1fy_scroll_me_up/lang/en_US.php
 * =======================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

$i18n = array(

"SMU_NAME"        	  =>  "Scroll Me Up by Mod1fy.net",
"SMU_SETTINGS"	  	  =>  "Scroll Me Up Settings",
"SMU_SCROLLSPEED"	  =>  "Animation Delay / ms :",
"SMU_SETTINGSPAGE"	  =>  "Scroll Me Up by Mod1fy.net - Settings Page",
"SMU_SAVESUCCESS"	  =>  "Saving success !",
"SMU_SAVEERROR"		  =>  "Error while saving !",
"SMU_LANG"		  	  =>  "Language",
"SMU_BTNTEXT"		  =>  "Text on the to-top button",
"SMU_ANIMATION"		  =>  "Animation of the scrolling effect",
"SMU_BTNSTYLE"		  =>  "CSS class of the button",
"SMU_LOADFA"		  =>  "Enable FontAwesome icons ?",
"SMU_FAST"		      =>  "Fast",
"SMU_MIDDLE"		  =>  "Middle",
"SMU_SLOW"		      =>  "Slow",
"SMU_BTNICON"		  =>  "Button icon",
"SMU_BTNDEFAULTS"	  =>  "Restore default settings",
"SMU_DEFAULTSSUCCESS" =>  "Defaults successful restored.",
"SMU_DEFAULTSERROR"   =>  "Error occurred while restoring !.",
"SMU_BTNPREVIEW"      =>  "Live preview of the button :",
"SMU_BTNCOLOR"        =>  "Button color",
"SMU_ICONCOLOR"       =>  "Icon color",
"SMU_TEXTCOLOR"       =>  "Text color",
"SMU_BTNTEXTINFO"     =>  "This Text will appear on the right side of the Icon.",
"SMU_BTNSTYLEINFO"    =>  "You can define a CSS class right here. If you are using Twitter Bootstrap, you can use all Bootstrap defined buttons here. Badges or labels are possible too, example : 'badge badge-warning' 'btn btn-large btn-danger'.",
"SMU_ANIMATIONINFO"   =>  "The bounce animation will scroll up fast and bounces some times at the top of your page. The linear animation scrolls equally to the top. The swing animation starts fast and gets slower till the end.",
"SMU_FONTAWESOMEINFO" =>  "If this option is selected, the FontAwesome icon font will be loaded in the header of your page. This will grant you more than 400 icons. Bootstrap glyphicons are possible too, if existing.",
"SMU_UNDOSUCCESS"     =>  "Redo settings success !",
"SMU_UNDOFAILURE"     =>  "Error while trying redo settings !",
"SMU_BTNOPACITY"      =>  "Button transparency",
"SMU_LIGHTON"         =>  "Light on",
"SMU_LIGHTOFF"        =>  "Light off",
"SMU_VIEWDESCRIPTION" =>  "Information",
"SMU_VIEWSETTINGS"    =>  "Settings",
"SMU_DESCHEAD1"       =>  "<h3>Scroll-To-Top Function</h3>",
"SMU_DESCHEAD2"       =>  "<h3>Scroll-To-Content Function</h3>",
"SMU_DESCINTRO"       =>  "<b>Welcome !</b><br><br>If this plugin is activated, it adds an customizable button to the bottom right of your GetSimple site, which will appear after 400 Pixels of page scrolling, and grants your visitors a shiny animated way to get fast back to the top of your site.",
"SMU_DESCINTRO2"      =>  "The button and animation can be customized within the settings - page.<br>You have also the choice to enable the FontAwesome icon font, or if already exists, to disable it. This Option is enabled by default.",
"SMU_DESCINTRO3"      =>  "You can use this icons very easy within your scroll-to-top button. Just paste the special icon code into the defined field. Example : <b>fa fa-chevron-up</b>. Other combinations are possible too, like this example : <b>fa fa-chevron-up fa-3x pull-left fa-border</b>.",
"SMU_DESCINTRO4"      =>  "If you are using Twitter Bootstrap with your theme, you can surely use all glyphicons too.",
"SMU_FALINK"          =>  "Link to the FontAwesome website",
"SMU_BOOTSTRAPLINK"   =>  "Link to the Bootstrap website",
"SMU_DESCINTRO5"      =>  "This plugin is able to find anchors within the content of your site. With anchors you can grant your visitors a comfortable way to scroll fast to content sections of interest within large contents.",
"SMU_DESCINTRO6"      =>  "For example you could apply an table of contents at the top of an article, so your visitors can jump fast to the defined content anchors. This works also without this plugin. The plugin grants only the shiny animation :) .",
"SMU_DESCINTRO7"      =>  "Anchorpoints can easy defined with help from the getsimples ckeditor anchor-button. Linking to these anchors can be done with the ckeditors link-button in submenu anchor of this site. The plugins animation works from top to bottom as well as bottom to top.",
"SMU_DESCINTRO8"      =>  "If your editor has no anchor button, you can set anchors manually. A anchor is defined by an empty link with ID. The definded anchors can be selected by klicking on the add link button and choose link to anchor in the text.",
"SMU_EXAMPLE"		  =>  "Example :",

);

?>