<?php

/**
 * Scroll Me Up by mod1fy.net for GetSimple CMS
 * =======================================================
 * German language file of the plugin
 * =======================================================
 * @link:      http://mod1fy.net
 * @since      1.0.1
 * =======================================================
 * @package    mod1fy_scroll_me_up
 * @subpackage mod1fy_scroll_me_up/lang/de_DE.php
 * =======================================================
 * @author:    Dennis Maassen / dennis-maassen@t-online.de
 */

$i18n = array(

"SMU_NAME"        	  =>  "Scroll Me Up by Mod1fy.net",
"SMU_SETTINGS"	  	  =>  "Scroll Me Up Einstellungen",
"SMU_SCROLLSPEED"	  =>  "Animations Verzögerung / ms :",
"SMU_SETTINGSPAGE"	  =>  "Scroll Me Up by Mod1fy.net - Einstellungen",
"SMU_SAVESUCCESS"	  =>  "Speichern erfolgreich !",
"SMU_SAVEERROR"		  =>  "Fehler beim Speichern !",
"SMU_LANG"		  	  =>  "Sprache",
"SMU_BTNTEXT"		  =>  "Text auf dem To-Top Button",
"SMU_ANIMATION"		  =>  "Animation des Scrolleffekts",
"SMU_BTNSTYLE"		  =>  "CSS Klasse des Buttons",
"SMU_LOADFA"		  =>  "FontAwesome Icon Fonts einschalten ?",
"SMU_FAST"		      =>  "Schnell",
"SMU_MIDDLE"		  =>  "Mittel",
"SMU_SLOW"		      =>  "Langsam",
"SMU_BTNICON"		  =>  "Das Icon des Buttons",
"SMU_BTNDEFAULTS"	  =>  "Standart Einstellungen laden",
"SMU_DEFAULTSSUCCESS" =>  "Standart Einstellungen wurden wiederhergestellt.",
"SMU_DEFAULTSERROR"   =>  "Fehler beim wiederherstellen !.",
"SMU_BTNPREVIEW"      =>  "Live Vorschau des Buttons :",
"SMU_BTNCOLOR"        =>  "Farbe des Buttons",
"SMU_ICONCOLOR"       =>  "Farbe des Icons",
"SMU_TEXTCOLOR"       =>  "Farbe des Textes",
"SMU_BTNTEXTINFO"     =>  "Dieser Text erscheint rechts neben dem Icon.",
"SMU_BTNSTYLEINFO"    =>  "Hier kann eine CSS Klasse für den Button definiert werden. Falls du Twitter Bootstrap nutzt, kannst du hier alle Bootstrap Buttons nutzen. Auch Badges oder Labels sind möglich, Beispiel : 'badge badge-warning' 'btn btn-large btn-danger'.",
"SMU_ANIMATIONINFO"   =>  "Bei der Bounce Animation scrollt die Seite linear nach oben und prallt einige male wie ein Flummi am Seitenanfang ab. Die lineare Animation scrollt gleichbleibend nach oben. Die Swing Animation beginnt erst schnell, und wird am Ende wieder langsamer.",
"SMU_FONTAWESOMEINFO" =>  "Wenn diese Option gewählt ist, wird der FontAwesome Icon Font in den Header deiner Seite geladen, was dir Zugriff auf über 400 Icons ermöglicht. Bootstrap Glyphicons sind auch möglich, wenn vorhanden.",
"SMU_UNDOSUCCESS"     =>  "Rückgängig machen erfolgreich !",
"SMU_UNDOFAILURE"     =>  "Rückgängig machen fehlgeschlagen !",
"SMU_BTNOPACITY"      =>  "Button Transparenz",
"SMU_LIGHTON"         =>  "Licht an",
"SMU_LIGHTOFF"        =>  "Licht aus",
"SMU_VIEWDESCRIPTION" =>  "Information",
"SMU_VIEWSETTINGS"    =>  "Einstellungen",
"SMU_DESCHEAD1"       =>  "<h3>Scroll-To-Top Funktion</h3>",
"SMU_DESCHEAD2"       =>  "<h3>Scroll-To-Content Funktion</h3>",
"SMU_DESCINTRO"       =>  "<b>Willkommen !</b><br><br>Sobald dieses Plugin aktiviert wird, fügt es deiner GetSimple Seite unten rechts einen kleinen Button hinzu, der nach 400 gescrollten Pixeln einblendet, und deinen Besuchern die Möglichkeit gibt mit einer schicken Animation schnell zum Seitenanfang zu springen.",
"SMU_DESCINTRO2"      =>  "Der Button sowie die Animation können über die Einstellungen - Seite nach belieben angepasst werden.<br>Ebenso besteht die Möglichkeit den FontAwesome Icon Font einzubinden, oder falls bereits vorhanden, diese auszuschalten. Diese Option ist standartmässig aktiviert.",
"SMU_DESCINTRO3"      =>  "Diese Icons können alle sehr einfach für den Scroll-To-Top Button verwendet werden. Einfach dazu den jeweiligen Icon Code in das entsprechende Feld eintragen. Beispiel : <b>fa fa-chevron-up</b>. Auch andere Kombinationen sind möglich, wie zum Beispiel : <b>fa fa-chevron-up fa-3x pull-left fa-border</b>.",
"SMU_DESCINTRO4"      =>  "Falls du in deinem Theme Bootstrap nutzt, können selbstverständlich auch alle Glyphicons verwendet werden.",
"SMU_FALINK"          =>  "Link zur FontAwesome Webseite",
"SMU_BOOTSTRAPLINK"   =>  "Link zur Bootstrap Webseite",
"SMU_DESCINTRO5"      =>  "Dieses Plugin wirkt sich auch auf Anker innerhalb einer Seite aus. Mit Ankern kann man bei längeren Inhalten, die sich über mehrere Seiten erstrecken, dem Besucher eine komfortable Möglichkeit geben schnell zu bestimmten Punkten innerhalb der Seite zu scrollen.",
"SMU_DESCINTRO6"      =>  "Man könnte zum Beispiel am Anfang eines Artikels ein Inhaltsverzeichniss erstellen, mit dessen Hilfe eure Besucher direkt zum Abschnitt ihrer Wahl scrollen können. Dies funktioniert auch ohne dieses Plugin. Das Plugin sorgt nur für die schicke Animation :) .",
"SMU_DESCINTRO7"      =>  "Ankerpunkte können mithilfe des Anker Buttons im GetSimple eigenen CKEditor gesetzt werden. Um diese anzusteuern muss mithilfe des Link Buttons ein Link zu einem Anker innerhalb der Seite erzeugt werden. Die Animation funktioniert sowohl von oben nach unten, als auch von unten nach oben.",
"SMU_DESCINTRO8"      =>  "Falls der Anker Button in deinem Editor nicht vorhanden sein sollte, kannst du Ankerpunkte auch manuell setzen. Einen Anker definiert ein leerer Link mit passender ID. Die definierten Anker kann man nun auswählen indem man auf den Button Link einfügen klickt, und Link zu einem Anker innerhalb dieser Seite auswählt.",
"SMU_EXAMPLE"		  =>  "Beispiel :",

);

?>