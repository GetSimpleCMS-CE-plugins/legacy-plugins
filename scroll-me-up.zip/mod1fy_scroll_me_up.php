<?php
/*
Plugin Name: Scroll Me Up by mod1fy.net
Description: Adds an full customizable jQuery scroll-to-top button and scroll-to-content functions to your GetSimple site.
Version: 1.0.5
Author: Dennis Maassen
Author URI: http://mod1fy.net
*/

/**
 * @Plugin version
 * @since 1.0.0
 *
 */
define('SMUVERSION', '1.0.5');

/**
 * @Get the plugins id
 * @since 1.0.0
 *
 */
$thisfile=basename(__FILE__, ".php");

/**
 * @Register the plugin
 * @since 1.0.0
 *
 */
register_plugin(
	$thisfile,
	'Scroll Me Up by mod1fy.net',
	'1.0.5',
	'Dennis Maassen',
	'http://mod1fy.net/',
	'Adds an full customizable jQuery scroll-to-top button and scroll-to-content functions to your GetSimple site.',
	'plugins',
	'smu_admin'
);

/**
 * @Define plugin paths
 * @since 1.0.0
 *
 */
define('SMUSETTINGS_XML', GSDATAOTHERPATH . 'mod1fy_scroll_me_up.xml');
define('SMULANGPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/lang/');
define('SMUINCPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/inc/');
define('SMUIMGPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/images/');
define('SMUCSSPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/css/');
define('SMUJSPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/js/');
define('SMUTEMPLATEPATH', GSPLUGINPATH . 'mod1fy_scroll_me_up/template/');

/**
 * @Includes
 * @since 1.0.0
 *
 */
require_once(SMUINCPATH . 'settings.php');

/**
 * @Load I18N
 * @since 1.0.1
 *
 */
i18n_merge('mod1fy_scroll_me_up') || i18n_merge('mod1fy_scroll_me_up','en_US');

/**
 * @Add a link to the admin plugins tab
 * @since 1.0.0
 *
 */
add_action('plugins-sidebar','createSideMenu',array($thisfile,i18n_r('mod1fy_scroll_me_up/SMU_SETTINGS')));

/**
 * @Register and queue scripts
 * @since 1.0.0
 *
 */
register_script('scrollmeup', $SITEURL.'plugins/mod1fy_scroll_me_up/js/scrollmeup_js.php', '1.0.0', FALSE);
register_script('colorpicker', $SITEURL.'plugins/mod1fy_scroll_me_up/js/colorpicker.js', '1.0.0', FALSE);
queue_script('jquery',GSFRONT);
queue_script('scrollmeup',GSFRONT);

/**
 * @Register and queue plugin styles
 * @since 1.0.0
 *
 */
register_style('scrollmeup', $SITEURL.'plugins/mod1fy_scroll_me_up/css/scrollmeup_css.php', '1.0.0', 'screen');
register_style('colorpicker', $SITEURL.'plugins/mod1fy_scroll_me_up/css/colorpicker.css', '1.0.0', 'screen');
queue_style('scrollmeup',GSBOTH);

/**
 * @Queue colorpicker scripts & styles only when needed
 * @since 1.0.2
 *
 */
$view = @$_REQUEST['view'];
if ($view == 'settings') {
	queue_script('colorpicker',GSBACK);
	queue_style('colorpicker',GSBACK);
}

// Register FontAwesome
register_style('font-awesome', $SITEURL.'plugins/mod1fy_scroll_me_up/css/font-awesome.min.css', '4.2.0', 'screen');
// Queue FontAwesome if setting = true
if (file_exists(GSDATAOTHERPATH.'mod1fy_scroll_me_up.xml')) {
	$data = @getXML(SMUSETTINGS_XML);
	$SMULOADFA = isset($data->load_fa) ? $data->load_fa : 1;
}
if ($SMULOADFA == 1) queue_style('font-awesome',GSBOTH);
/**
 * @Include admin template
 * @since 1.0.0
 *
 */
require_once(SMUTEMPLATEPATH . 'edit_settings.php');