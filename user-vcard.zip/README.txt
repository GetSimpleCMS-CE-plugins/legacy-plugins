User vCard GetSimple Plugin that allows the users of a site to
dynamically create profile pages and a downloadable vCards

Current Version 1.0
Author. Lluís Gesa Boté, lluis.gesa@gmail.com

* Install

Copy 'user-vcard.php' and  'user-vcard' folder inside plugins folder
of your GetSimple structure.

In order to enable photo uploading, file admin/settings.php must be
modified adding : enctype="multipart/form-data" in the main form.

A nice look&feel modification is to also move
<?php exec_action('settings-user-extras'); ?>

from current position to just before summit button.

Plugin is configured to only accept photos in jpeg format and size
less than 8kb. Accepted size can be changed in user-vcard.php file.

In another side, CSS controlling the contact information can be
modified in user-vcard/vcard.css

* Changelog

--------- v1.0. Initial release. 16/Apr/2012

 * Enabled a form inside user settings for user contact information.
 * Enabled a page auto-attach information.
 * Enabled a Downloadable vcard generation.
 * i18n not supported.

