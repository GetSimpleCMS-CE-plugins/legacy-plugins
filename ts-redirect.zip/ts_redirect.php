<?php
/*
Plugin Name: TS_Redirect
Description: Redirect any page wherever you want.
Version: 0.1
Author: Lars Flintzak
Author URI: 
*/
# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 					# ID of plugin, should be filename minus php
	'TS Redirect', 					# Title of plugin
	'0.1a', 					# Version of plugin
	'Lars Flintzak',				# Author of plugin
	'http://www.gowep.de/gsplugins', 		# Author URL
	'Redirect any page wherever you want.', 	# Plugin Description
	'pages', 					# Page type of plugin
	''  						# Function that displays content
);

# activate filter
add_action( 'index-pretemplate', 'ts_redirect' );

function ts_redirect()
{
	$kw = get_page_meta_keywords(false);
	if($kw=="_redirect")
	{
		$c = returnPageContent(return_page_slug());
		$d = get_page_meta_desc(false);
		preg_match('#(http://)?www\.[a-zA-Z0-9_-]{2,255}\.[a-zA-Z]{2,4}/?#',$c, $treffer);
		preg_match('#(?i)target="([^>]+)">(.+?)#',$c, $tar);
		if($tar[1])
		{
		echo '<script type="text/javascript">
		window.open("'.$treffer[0].'","'.$tar[1].'");
		</script>';
		exit;
		}		
		header("location: ".$treffer[0]);
		exit;
	}
}
?>
