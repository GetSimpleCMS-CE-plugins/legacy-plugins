<?php
/*
Plugin Name: LinkMenus
Description: Allows creation of link menus!
Version: 0.1
Author: Igor Randjelovic
Author URI: none
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

//Path To website.xml File
$thisfilew=GSDATAOTHERPATH .'website.xml';

//Path To User Login plugin Settings File (user-login.xml)
$pluginfile=GSDATAOTHERPATH .'user-login.xml';


# register plugin
register_plugin(
	$thisfile, 													# ID of plugin, should be filename minus php
	'Link Menus', 												# Title of plugin
	'0.1', 														# Version of plugin
	'Igor Randjelovic',											# Author of plugin
	'', 														# Author URL
	'Allows creation of link menus!', 							# Plugin Description
	'pages', 													# Page type of plugin
	'LinkMenus_admin'  											# Function that displays content
);

# hooks

//Launch Function 'user_login_check' before the template is loaded on the front-end
//add_action('index-pretemplate','user_login_check');

//Adds 'Link Menu' Check Box In edit.php
add_action('edit-extras','LinkMenus_admin');

//Saves 'Linkmenu' checkbox selection when a page is saved
add_action('changedata-save','LinkMenus_admin_save');


//Displays members Only Checkbox In edit.php
function LinkMenus_admin()
{
//Check If Checkbox For Current Page Editing Is Already Checked
	$current_page_edit = $_GET['id'];
	$the_page_slug_xml = GSDATAPAGESPATH.$current_page_edit.'.xml';
	$page_data = getXML($the_page_slug_xml);
	
	//Check If Page Is LinkMenu
	if($page_data->linkmenu == "yes")
	{
		$member_checkbox = "checked";
	}
	else
	{
		$member_checkbox = "";
	}
	if($page_data->linkmenuurl != "")
	{
		$url = $page_data->linkmenuurl;
	}
	else
	{
		$url = "Url..";
	}
	
	echo '
	<p class="inline">
		<label for="1">Link Menu? </label>        <input type="checkbox" value="linkmenu" id="2" name="option" '.$member_checkbox.'/>					
	</p>
	<input type="text" name="url" style="width:80%" value="'.$url.'" onFocus="if(this.value == \'Url..\') {this.value = \'\';}" onBlur="if (this.value == \'\') {this.value = \'Url..\';}" /><br><br>
	';
}

//Saves Value Of Checkbox in function - LinkMenus_admin()
function LinkMenus_admin_save()
{
	global $xml; // SimpleXML to save to
		  if(isset($_POST['option']) && isset($_POST['url']))
		  { 
			$opt=$_POST['option'];
			if($opt=="linkmenu"){
			  $node = $xml->addChild(strtolower('linkmenu'))->addCData(stripslashes("yes"));
			  $node = $xml->addChild(strtolower('linkmenuurl'))->addCData(stripslashes($_POST['url']));				  
			}
			  
		  }	  
}

?>