<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } 
//  ***************************************************** //
//  @Author: Justin Y. - ChompDigital.com - Add me at https://plus.google.com/+JustinY 
//  Support: GSThemes Google+ Community - https://plus.google.com/communities/114264401791184387123
//  ***************************************************** //

// Get correct id for plugin
$thisfile = basename(__FILE__, '.php');

// Data save file
$file_cd_og_data_file = GSDATAOTHERPATH . 'CD-Open-Graph-Settings.xml';
$site_url = $SITEURL;
$plugin_folder = basename(GSPLUGINPATH);
$plugin_url = $site_url.$plugin_folder; 

# register this plugin
register_plugin(
	$thisfile, 
	'CD - Open Graph & Social Integrations', 	
	'1.1', 		
	'Justin Y. - ChompDigital.com',
	'http://chompdigital.com/', 
	'This plugin provides Open Graph and other social integrations.',
	'plugins',
    'file_cd_og_admin_process'
); 

// CHANGE THE NAME TO BRAND IT TO YOUR THEME //
add_action ( 'plugins-sidebar', 'createSideMenu', array( $thisfile, 'CD - Open Graph / Social Settings' ) ); 
 
function insert_cd_opengraph() { 
	$file = GSDATAOTHERPATH . 'CD-Open-Graph-Settings.xml';  
	if (file_exists($file)) {
		$s = getXML($file);   
		// SET VARS /////////////////
		$g_plus_page = false;
		$g_plus_author = false;
		$fb_page_id = false;
		$fb_admin_id = false;
		$op_image = false;
		$twitter_id = false;
		$twitter_username = false;
 		$blog_pages = 'blog';
		/////////////////////////////
		$fb_page_id = $s->fb_page_id;
		$fb_admin_id = $s->fb_admin_id;
		$op_image = $s->op_image;   
		$g_plus_page = $s->g_plus_page;
		$g_plus_author = $s->g_plus_author;  
		$twitter_id = $s->twitter_id;
		$twitter_username = $s->twitter_username; 
	 	$blog_pages = $s->blog_pages;  
		/////////////////////////////////////////
		
		
		echo "\n<!-- CD OPENGRAPH TAGS -->\n"; 
		 
		if ( $g_plus_page == true )  {  
		$g_pub_link = '<link href="' . $g_plus_page .'" rel="publisher" />';
		
		$page = return_page_slug();
		// INCLUDE ON THE FOLLOWING PAGE SLUGS //
		if( $page  == 'index' )     { echo $g_pub_link; echo "\n"; }
		if( $page  == 'about' )     { echo $g_pub_link; echo "\n"; }
		if( $page  == 'contact' )   { echo $g_pub_link; echo "\n"; }
		if( $page  == 'team' )      { echo $g_pub_link; echo "\n"; }
		if( $page  == 'portfolio' ) { echo $g_pub_link; echo "\n"; }   
		}
		
		// INCLUDE AUTHOR TAG ON BLOG ONLY //
		if ( $g_plus_author == true ) {  
		$g_auth_link = '<link href="' . $g_plus_author .'" rel="author" />';
		
		$page = return_page_slug(); 
		if ( $page == "$blog_pages" ) { echo $g_auth_link; echo "\n"; }  
		 
		$page_parent = get_parent(0); 
		if ( $page_parent ==  "$blog_pages" ) { echo $g_auth_link; echo "\n"; }
		 
		}
		 
		 
		// ADD OPEN GRAPH TAGS //
		if ( $twitter_id == true )  { 
		echo '<meta property="twitter:account_id" content="'. $twitter_id . '" />';
		echo "\n"; 
		}
		if ( $twitter_username == true )  {
        echo '<meta name="twitter:site" content="@' .$twitter_username . '">';
		echo "\n";
		}
		if ( $fb_page_id == true )  {
		echo '<meta property="fb:page_id" content="' . $fb_page_id . '" />';
		echo "\n";
		}
		if ( $fb_admin_id == true )  {
 		echo '<meta property="fb:admins" content="' . $fb_admin_id . '" />';  
		echo "\n";
		}
		echo '<meta property="og:title" content="'; get_page_clean_title(); echo  '"/>';  
		echo "\n";
		if ( $op_image == true )  {
		echo '<meta property="og:image" content="' .$op_image . '"/>'; 
		echo "\n";
		}
		echo '<meta property="og:site_name" content="'; get_site_name(); echo '"/>';
		echo "\n"; 
		echo '<meta property="og:description" content="';  
		$og_desc_clean = get_page_excerpt($len=140);   
		 
	    echo preg_replace("/\s+/", ' ', $clear2) ;  echo '"/>';  
		echo "\n<!-- end CD OPENGRAPH TAGS -->\n";
		return true;
		 
	} else {
		return false;
	}  
}
add_action ( 'theme-header', 'insert_cd_opengraph' );

  	
function cd_og_theme_form_process () { 
  global $file_cd_og_settings;
  }
 
 

// BACKEND SCRIPT
function file_cd_og_is_backend() {
    $path_parts = pathinfo( $_SERVER['PHP_SELF'] );
    if( function_exists( 'get_site_url' ) or $path_parts['basename'] == 'index.php' or $path_parts['basename'] == 'logout.php' ) {
        return false;
    } else {
        return true;
    }
}

// FORM PROCESS
function file_cd_og_admin_process() {
    
    global $file_cd_og_data_file;
    // Check for submitted data
    if( isset( $_POST['submit'] ) ) {
        
        // Save submitted data 
		$file_cd_og_submitted_data['fb_page_id'] = $_POST['fb_page_id']; 
		$file_cd_og_submitted_data['fb_admin_id'] = $_POST['fb_admin_id'];
		$file_cd_og_submitted_data['op_image'] = $_POST['op_image'];    
		$file_cd_og_submitted_data['g_plus_page'] = $_POST['g_plus_page'];  
		$file_cd_og_submitted_data['g_plus_author'] = $_POST['g_plus_author'];
		$file_cd_og_submitted_data['twitter_id'] = $_POST['twitter_id'];
		$file_cd_og_submitted_data['twitter_username'] = $_POST['twitter_username'];
		$file_cd_og_submitted_data['blog_pages'] = $_POST['blog_pages'];     
        $result = file_cd_og_save_settings( $file_cd_og_submitted_data );
        
    }
    
    
// READ SUBMIITED DATA	
	$file_cd_og_settings = file_cd_og_read_settings();
    echo '<h3>CD Open Graph / Social Settings</h3>';
    
    if( isset( $result ) ) {
        if( $result == true ) { 
            echo '<p class="updated" style="width: 100%; background: #DFF8D9; border: none; padding: 10px; color: #777">Settings saved.</p>';
			 
			echo "<meta http-equiv='refresh' content='0.75;url=". $_SERVER ['REQUEST_URI']. "'>";
        } elseif( $result == false ) { 
            echo '<p class="error">Error saving data. Check permissions.</p>';
        }
    }
 

?> 
    <form method="post" id="modern-admin" class="modern_admin2" action="<?php echo $_SERVER ['REQUEST_URI']; ?>" ononSubmit="window.location.reload()" value="refresh">
    
       <hr />
       <br /> 
       <br /> 
       <h3>Facebook Settings</h3>
       <p> 
        <label><b>Facebook Page ID</b></label><br />
        <input id="fb_page_id" name="fb_page_id" class="text" value="<?php echo $file_cd_og_settings['fb_page_id']; ?>" style="width: 220px;" />
       </p>
       <p> 
        <label><b>Facebook Admin ID</b></label><br />
        <input id="fb_admin_id" name="fb_admin_id" class="text" value="<?php echo $file_cd_og_settings['fb_admin_id']; ?>" style="width: 220px;" />
       </p>
       <p> 
        <label><b>Open Graph Image Path <small>(Optional)</small></b></label><br />
        <input id="op_image" name="op_image" class="text" value="<?php echo $file_cd_og_settings['op_image']; ?>" style="width: 220px;" />
       </p> 
       <br /> 
       <h3>Twitter Settings</h3>
       <p> 
        <label><b>Twitter Account ID</b></label><br />
        <input id="twitter_id" name="twitter_id" class="text" value="<?php echo $file_cd_og_settings['twitter_id']; ?>" style="width: 220px;" />
       </p>
       <p> 
        <label><b>Twitter Username</b></label><br />
        <input id="twitter_username" name="twitter_username" class="text" value="<?php echo $file_cd_og_settings['twitter_username']; ?>" style="width: 220px;" />
       </p>
       <br /> 
       <h3>Google+  Settings</h3>
       <p> 
        <label><b>Google+ Business Page URL</b></label><br />
        <input id="g_plus_page" name="g_plus_page" class="text" value="<?php echo $file_cd_og_settings['g_plus_page']; ?>" style="width: 220px;" />
        </p>
       <br />
        <p> 
        <label><b>Google+ Author URL</b></label><br />
        <input id="g_plus_author" name="g_plus_author" class="text" value="<?php echo $file_cd_og_settings['g_plus_author']; ?>" style="width: 220px;" />
        <br /> 
        <br /> 
        <br />
        <label><b>Enter the name of your main blog directory.</b></label> 
        <small>This will help to exlcude the use of G+ authorship tags on inapproriate pages.</small><br />
        <br />
        <input id="blog_pages" name="blog_pages" class="text" value="<?php echo $file_cd_og_settings['blog_pages']; ?>" style="width: 220px;">
        <br />Example and default setting is 'blog'. <br />
        </p>
        <br /> 
       <div style="clear:both; height: 10px"></div>
        <p>
      
         <input type="submit" id="submit" class="submit" value="<?php i18n('BTN_SAVESETTINGS'); ?>" name="submit" />
        </p>
    </form>
    
      
<?php
} 
function file_cd_og_read_settings() {
    
    global $file_cd_og_data_file;
    
    if( file_exists( $file_cd_og_data_file ) ) {
        
        $data = getXML( $file_cd_og_data_file );
		$file_cd_og_settings['fb_page_id'] = $data->fb_page_id;
		$file_cd_og_settings['fb_admin_id'] = $data->fb_admin_id; 
		$file_cd_og_settings['op_image'] = $data->op_image; 
		$file_cd_og_settings['twitter_id'] = $data->twitter_id;
		$file_cd_og_settings['twitter_username'] = $data->twitter_username;
		$file_cd_og_settings['g_plus_page'] = $data->g_plus_page;
		$file_cd_og_settings['g_plus_author'] = $data->g_plus_author; 
		$file_cd_og_settings['blog_pages'] = $data->blog_pages; 
    } else {
         
		$file_cd_og_settings['op_image'] = null;  
		$file_cd_og_settings['g_plus_page'] = null;
		$file_cd_og_settings['g_plus_author'] = null;
		$file_cd_og_settings['blog_pages'] = null;
        file_cd_og_save_settings( $file_cd_og_settings );
        
    }
    
    
    
    $file_cd_og_settings['site_root'] = '/';
    
    return $file_cd_og_settings;
    
}


function file_cd_og_save_settings( $settings ) {
    
    global $file_cd_og_data_file;
    
    $xml = @new simpleXMLElement( '<cd_og_admin_settings></cd_og_admin_settings>' );
	
    $xml->addChild( 'fb_page_id', $settings['fb_page_id'] );
	$xml->addChild( 'fb_admin_id', $settings['fb_admin_id'] );
	$xml->addChild( 'op_image', $settings['op_image'] ); 
	$xml->addChild( 'twitter_id', $settings['twitter_id'] );
	$xml->addChild( 'twitter_username', $settings['twitter_username'] );
	$xml->addChild( 'g_plus_page', $settings['g_plus_page'] ); 
	$xml->addChild( 'g_plus_author', $settings['g_plus_author'] );  
	$xml->addChild( 'blog_pages', $settings['blog_pages'] ); 
	
    return $xml->asXML( $file_cd_og_data_file );
    
} 
?>