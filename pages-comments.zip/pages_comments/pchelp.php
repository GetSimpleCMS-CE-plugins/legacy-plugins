<?php
       //Instruction of plugin
       echo '<h3>'.i18n_r('pages_comments/pc_instruc').'</h3>'; 
       echo i18n_r('pages_comments/pc_instruc1'); 



?>
