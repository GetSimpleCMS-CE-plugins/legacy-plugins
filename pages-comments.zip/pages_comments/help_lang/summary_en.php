<div style="font-family: Times New Roman; font-size: 15px;">
With this plugin we can do 2 mainly things:<br /><br />
<ul>
<li>1. ADD COMMENTS TO PAGES CREATED  BY GETSIMPLE from Admin > Pages.<br />
             &nbsp;&nbsp;To add the comments system, simply go to Admin > Pages > Pages&comments:<br />
     &nbsp;&nbsp;&nbsp;&nbsp;*Button <b>'Add Comments to Pages'</b>, there we see all the pages that don't have the comments system included. Click in 'Add' and later edit the options to choose  if you want captcha, emoticons, etc.<br />
     &nbsp;&nbsp;&nbsp;&nbsp;It is possible NOT to have comment in a page, choosing the option of 'No' to the comments; thus this page could be a contact form.</li><br />

<li>2. USING THE FRONT END USER PLUGIN of mikeh, we can have comments in pages, but only registred user or login in user can write comments in that page; example in:  <a href="http://cumbe.260mb.org/" target="_blank">http://cumbe.260mb.org/page-with-users/</a><br />
   &nbsp;&nbsp;&nbsp;&nbsp;In case that a page has marked <i>'Members only'</i> in his configuration from Admin > Edit page, only this page will be seen if the user is logged in.</li>
</ul>
For more information go to <a href="load.php?id=pages_comments&amp;action=pc_help&amp;read=readme_en">Readme</a>, or in his correspondent post.<br />
</div>
