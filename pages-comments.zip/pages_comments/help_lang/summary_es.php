<div style="font-family: Times New Roman; font-size: 15px;">
Con este plugin podemos hacer 2 cosas principalmente:<br /><br />
<ul>
<li>1. AÑADIR COMENTARIOS A PÁGINAS CREADAS POR GETSIMPLE desde Admin > Pages.<br />
         &nbsp;&nbsp;Para añadir el sistema de comentarios, simplemente ir a Admin > Pages > Pages&comments:<br />
     &nbsp;&nbsp;&nbsp;&nbsp;* Botón <b>'Add Comments to Pages'</b>, ahí vemos todas las páginas que NO tienen el sistema de comentarios incluido. Cliquear en 'Añadir' y luego edita las opciones para elegir si quieres captcha, emoticonos, etc<br />
     &nbsp;&nbsp;&nbsp;&nbsp;Se puede no tener comentarios en una página, eligiendo la opción de 'No' a los comentarios; de esta forma está página podría usarse de página de contacto.</li><br />

<li>2. USANDO EL FRONT END USER PLUGIN of mikeh, podemos tener comentarios en páginas, pero sólo pueden escribir comentarios los usuarios registrados y logeados a esa página; ejemplo en: <a href="http://cumbe.260mb.org/page-with-users/" target="_blank">http://cumbe.260mb.org/page-with-users/</a><br />
   &nbsp;&nbsp;&nbsp;&nbsp;En el caso de que una página tenga marcado <i>'Members only'</i> en su configuración desde Admin>Edit Page, sólo se verá esta página si el usuario está logeado.</li>
</ul>
Más información en extend, ó en el post correspondiente del foro.<br />
</div>
