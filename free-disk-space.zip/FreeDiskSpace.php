<?php
/*
Plugin Name: Free Disk Space
Description: Shows available free disk space on server in "Files" page
Version: 1.0
Author: joshas
Author URI: joshas@gmail.com
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile,
	'Free Disk Space',
	'1.0',
	'joshas',
	'mailto:joshas@gmail.com',
	'Shows available free disk space on server in "Files" page'
);

# attach hook
add_action('files-sidebar','display_disk_usage');

# functions
function decodeSize($bytes) {
	$types = array('B','KB','MB','GB','TB');
	for( $i = 0; $bytes >= 1024 && $i < ( count( $types ) -1 ); $bytes /= 1024, $i++ );
	return( round( $bytes, 2 ) . " " . $types[$i] );
}

function display_disk_usage() {
	$disk = GSDATAUPLOADPATH;
	$df = disk_free_space($disk);
	$ds = disk_total_space($disk);
	$du = $ds - $df;
	if ($ds > 0) $perc = number_format(100 * $du / $ds, 2); else $perc = 0;
	$color = '#ace97c';
	if ($perc > 75) $color = '#e8cf7d';
	if ($perc > 90) $color = '#e87d7d';
	echo '<li style="font-weight:800;padding:5px 15px;border-radius:4px;-moz-border-radius:4px;-webkit-border-radius:4px;background-color:#182227;margin-left:13px;color:#afc5cf;">'
		.'Available disk space'
		.'<div style="border:1px solid #ccc;width:100%;margin:2px 5px 2px 0;padding:1px">'
		.'<div style="width:'.$perc.'%;background-color:'.$color.';height:6px"></div></div>'
		.decodeSize($df).' of '.decodeSize($ds).' free'.'</li>';
}
?>
