<?php
// register plugin
$thisfile = basename(__FILE__, ".php");
register_plugin($thisfile,
	'Remove sitemap',
	'0.2',
	'Carlos Navarro',
	'http://www.cyberiada.org/cnb/',
	'For GS 3.1 - Deletes the root sitemap.xml file just after being generated', '', ''
);

if (!defined('GSDONOTPING')) {
	define('GSDONOTPING',1);
}

add_action('admin-pre-header','remove_sitemap_xml');

function remove_sitemap_xml() {
	if (file_exists(GSROOTPATH .'sitemap.xml')) {
		unlink(GSROOTPATH .'sitemap.xml');
	}
}
// end of file
