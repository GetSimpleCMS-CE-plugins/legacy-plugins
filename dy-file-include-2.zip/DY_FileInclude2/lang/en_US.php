<?php
/**
 * English Language File for DY File Include 2 Plugin
**/

$i18n = array(
  // Common
  'DESCRIPTION'     => 'Includes text file into a page content',
);
