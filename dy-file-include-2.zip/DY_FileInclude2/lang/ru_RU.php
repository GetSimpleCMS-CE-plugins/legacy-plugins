<?php
/**
 * Russian Language File for DY File Include 2 Plugin
**/

$i18n = array(
  // Common
  'DESCRIPTION'     => 'Включение содержания текстовых файлов в страницы веб-сайта',
);
