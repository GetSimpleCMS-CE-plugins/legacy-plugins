<?php
/*
Plugin Name: DY File Include 2
Version: 1.0
Description: Includes text file into a page content
Author: Dmitry Yakovlev
Author URI: http://dimayakovlev.ru/
*/

# get correct id for plugin
$thisfile = basename(__FILE__, ".php");

define('DY_FILE_INCLUDE_2', $thisfile);

i18n_merge(DY_FILE_INCLUDE_2) || i18n_merge(DY_FILE_INCLUDE_2, 'en_US');

# register plugin
register_plugin(
  $thisfile,                          # ID of plugin, should be filename minus php
  'DY File Include 2',                  # Title of plugin
  '1.0',                              # Version of plugin
  'Dmitry Yakovlev',                    # Author of plugin
  'http://dimayakovlev.ru/',          # Author URL
  i18n_r(DY_FILE_INCLUDE_2 . '/DESCRIPTION'),   # Plugin Description
  '',                                 # Page type of plugin
  ''                                  # Function that displays content
);

add_filter('content', 'dyFileInclude2Shortcode');

function dyFileInclude2Shortcode($content) {
  // (% dyFileInclude2 data.txt %)
  $pattern = '(\(%\s+dyFileInclude2\s+(.*)\s%\))';
  return preg_replace_callback($pattern, 'dyFileInclude2Callback', $content);
}

function dyFileInclude2Callback($matches) {
  if (isset($matches[1])) {
    $filename = GSDATAUPLOADPATH . trim(trim($matches[1], "'"), '"');
    if (is_readable($filename)) {
      // Checking cache
      $md5 = md5(serialize(array($filename, filemtime($filename))));
      $cachefile = GSCACHEPATH . DY_FILE_INCLUDE_2 .'-' . $md5 . '.txt';
      if (is_readable($cachefile)) {
        return file_get_contents($cachefile);
      } else {
        require_once(GSPLUGINPATH . DY_FILE_INCLUDE_2 . '/lib/Parsedown.php');
        $parsedown = new Parsedown();
        $result = $parsedown->text(file_get_contents($filename));
        file_put_contents($cachefile, $result);
        return $result;
      }
    }
  }
  return false;
}
?>