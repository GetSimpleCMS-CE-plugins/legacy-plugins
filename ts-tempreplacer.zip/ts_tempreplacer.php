<?php
/*
Plugin Name: TS TempReplacer
Description: Changes content on the fly.
Version: 0.1
Author: Lars Flintzak
Author URI: 
*/

# get correct id for plugin
$thisfile=basename(__FILE__, ".php");

# register plugin
register_plugin(
	$thisfile, 							# ID of plugin, should be filename minus php
	'TS TempReplacer', 					# Title of plugin
	'0.1', 								# Version of plugin
	'Lars Flintzak',					# Author of plugin
	'http://www.gowep.de/gsplugins', 	# Author URL
	'Changes content on the fly.', 		# Plugin Description
	'pages', 							# Page type of plugin
	'TempReplacer_tab'  				# Function that displays content
);

# activate filter
// add_filter('content','do_FastReplacer');
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, 'TS TempReplacer'));
add_filter('content','do_tempreplacer');


function TempReplacer_tab() {

	if (isset($_POST['save']))
	{
		$success =  ts_TempReplacer_save_settings( $_POST['search'],$_POST['replace']);
	}
	$settings = ts_TempReplacer_get_settings();
	echo '<form class="largeform" id="edit" action="load.php?id=ts_tempreplacer" method="post">
<h3 class="Floated">TS TempReplacer</h3>
Enter one item per line. Only the content will be affected and all changes are non destructive.<br>
<br>
<h3>Example:</h3>
<b>Search:</b><br>
foo<br>
<b>Replace:</b><br>
bar<br>
<br>
Changes foo to bar on the fly.<br>
<br>
		<div style="float:left;margin-right:10px">
		<label for="append1">Search:</label>
		<textarea id="search" name="search" style="height:250px;width:300px">'.$settings->search.'</textarea>
		</div>
		<div style="">
		<label for="append2">Replace:</label>
		<textarea id="replace" name="replace" style="height:250px;width:300px">'.$settings->replace.'</textarea>
		
		</div>
<br><br><br>
		<input name="save" type="submit" class="submit" value="Save changes" />

</form>';
}

function do_TempReplacer($contents)
{
	$settings  = ts_TempReplacer_get_settings();
	$ss = explode("\n", $settings->search);
	$rr = explode("\n", $settings->replace);
	
	# print_r($ss);
	# print_r($rr);
	
	$contents = str_replace($ss, $rr, $contents);
	return $contents;
}

function ts_TempReplacer_get_settings() 
{
    $file = GSDATAOTHERPATH . 'ts_TempReplacer.xml';
	if (!file_exists($file)) {
		ts_TempReplacer_save_settings(); //create empty one
	}
	$data = getXML($file);
	$settings = new stdClass();
	$settings->search = (string) $data->search;
	$settings->replace = (string) $data->replace;
	return $settings;
}

function ts_TempReplacer_save_settings($s = '',$r = '') 
{
    $file = GSDATAOTHERPATH . 'ts_TempReplacer.xml';
	$xml = new SimpleXMLExtended('<?xml version="1.0" encoding="UTF-8"?><settings></settings>');
	$obj = $xml->addChild('search');
	$obj->addCData($s);
	$obj = $xml->addChild('replace');
	$obj->addCData($r);
	return XMLsave($xml, $file) === true ? true : false;
}
?>
