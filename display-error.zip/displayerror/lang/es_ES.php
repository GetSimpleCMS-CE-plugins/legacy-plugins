<?php
//set internationalization


	$i18n = array (
	"cbsee_errors" => 'Ver Errores',
	"cbgslog" => 'Errores log GS',
	"cb404log" => 'Errores 404',
	"cbdelfilelog" => 'Eliminar fichero log',
	"cbdelfile404" => 'Eliminar fichero errores 404',
	"cbdeletedfile" => 'Fichero eliminado',
	"cbdeleteselect" => 'Eliminar seleccionados',
	"cberrorsrecgs" => 'GS Log con errores recibidos',
	"cberrorsrec404" => 'Log con errores 404 recibidos',
	"cbfilenoexits" => 'El fichero log no existe',
	"cbnumberlines" => 'Líneas en total',
	"cblast" => 'Vemos últimas',
	"cblines" => 'líneas',
	"cbnumber" => 'Número de',
	"cbdata" => 'registros',
	"cbndel" => 'Eliminar este registro',
	"cbndelc" => 'Eliminar registro nº',
	"cbdelsure" => '¿Estás seguro?',
	"cbregdel" => 'Registro eliminado!!!',
	"cbsummarize" => 'Resumir',
	"cbsummarize404" => 'Resumir por número de visitas',
	"cbdate" => 'Fecha',
	"cball" => 'Seleccionar todos'
	);

?>
