<?php
//set internationalization


	$i18n = array (
	"cbsee_errors" => 'Display errors',
	"cbgslog" => 'GS error log',
	"cb404log" => '404 error log',
	"cbdelfilelog" => 'Delete log file',
	"cbdelfile404" => 'Delete 404 error log file',
	"cbdeletedfile" => 'File deleted',
	"cbdeleteselect" => 'Delete selected',
	"cberrorsrecgs" => 'Errors found in GS Log',
	"cberrorsrec404" => 'Errors found in 404 error log',
	"cbfilenoexits" => 'Log file does not exist',
	"cbnumberlines" => 'Total lines',
	"cblast" => 'Last',
	"cblines" => 'lines',
	"cbnumber" => 'Number of',
	"cbdata" => 'records',
	"cbndel" => 'Remove this register',
	"cbndelc" => 'Remove register number ',
	"cbdelsure" => 'Are you sure?',
	"cbregdel" => 'Register has been deleted!',
	"cbsummarize" => 'Summarize',
	"cbsummarize404" => 'Summarize by number of visits',
	"cbdate" => 'Date',
	"cball" => 'Select all'
	);

?>
