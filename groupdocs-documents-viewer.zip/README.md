getsimple-groupdocs-viewer-source
=================================

GroupDocs Viewer plugin for GetSimple CMS (Source code)

### CMS Installation:
 * Download CMS package
 * Upload all files to your virtual host.
 * Access vhostname (for example - getsimple/) and you will be redirected to http://getsimple/admin/install.php
 * Check requirements and continue installation if all is ok.
 * Enter website name, username and email (password will be generated dinamically)
 * Check admin password and you are all set.

### Plugin installation:
 * Upload plugin's files to getsimplewebfolder/plugins/
 * Go to http://getsimple/admin/plugins.php (Plugin tab in the admin panel) and check plugins list.
 * You can deactivate/activate plugins. By default installed plugin is activated so you can start to use it.

###Sign, Manage, Annotate, Assemble, Compare and Convert Documents with GroupDocs
* [View PDF, Word, Excel, Powerpoint and Images online with GroupDocs Viewer](http://groupdocs.com/apps/viewer)
* [See package for GroupDocs Viewer plugin for GetSimple CMS](https://github.com/groupdocs/getsimple-groupdocs-viewer)



###Created by [GroupDocs Marketplace Team](http://groupdocs.com/marketplace/).
