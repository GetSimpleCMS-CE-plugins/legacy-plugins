<?php
//$class = 'label'		// original class for label div
$class = 'form-group has-feedback';	// class for label parent <div>
$html = "<div class='{$class}'>";
$class = 'control-label';		// class for <label>
$html .= "<label class='{$class}' for='{$for}'>";

$html .= (!empty($this->title)) ? $this->title : ucfirst($this->form->lang($this->type));

$html .= $this->required ? ' <strong style="color:red">*</strong>' : '';

if (!empty($this->error)) {
  $html .= ' <span style="font-size:0.7em;color:red">' . $this->form->lang($this->error) . '</span>';
}
if ($this->type != 'captcha') { // captcha close label after image
  $html .= '</label>';
}
