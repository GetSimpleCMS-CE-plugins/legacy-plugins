<?php
/* form-control */
$class = 'btn btn-primary btn-lg';	// class for submit button
$html = '<form action="#simple-c' . $this->id . '" autocomplete="off" id="simple-c' . $this->id . '" class="simple-c" method="post" enctype="multipart/form-data">';
$html .= $this->html_status();
if ($this->status != 'sent') {
 foreach ($this->fields as $id => $field) {
  $html .= $field->html();
 }
 $html .= '<div>';
 $html .= '<input name="simple-c_form[id]" type="hidden" value="' . $this->id . '" />';
 $html .= '<input name="simple-c_form[token]" type="hidden" value="' . $this->SimpleC->get_token() . '" />';
 $html .= '<input class="submit ' . $class . '" type="submit" value="' . $this->lang('send') . '" />';
 $html .= '</div>';
}
$html .= '</form>';
?>
