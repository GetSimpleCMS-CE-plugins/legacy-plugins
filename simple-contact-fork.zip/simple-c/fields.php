<?php
$class = 'form-control input-sm';		// class for form fields (input, textarea & etc.)
$id = 'simple-c' . $this->form->get_id() . '_field' . $this->id;
$name = 'simple-c_fields[' . $this->id . ']';
$type = $this->general_type();
$value = $this->value;
$disabled = $this->locked ? ' disabled="disabled"' : '';
$optional = 'optional';			// temporary unused

$placeholder = $this->html_placeholder($id);

// Make params from value
$tarr = array('id', 'name', 'value', 'type', 'placeholder', 'class');
foreach ($tarr as &$tvar) {
 $tvar = (isset($$tvar))&&(!is_array($$tvar)) ? "{$tvar}='{$$tvar}'" : "";
}
list($fi, $fn, $fv, $ft, $fp, $fc) = $tarr;
$fd = $disabled;
$ftt = "type='text'";
$ftf = "type='file'";

$html = '<div class="field ' . $type . '">';
if ($this->type != 'askcopy') { // not needed here, the value say everything
 $html .= $this->html_label($id);  // comment it twice (see below) if using placeholder instead of label or hide by CSS form label {display:none;}
}

switch ($type) {
 case 'text' :
  $html .= "<input {$fc} {$ft} {$fi} {$fn} {$fp} {$fd} {$fv} />";
  break;
 case 'textarea' :
  $html .= "<textarea rows='10' {$fc} {$fi} {$fn} {$fp} {$fd}>{$value}</textarea>";
  break;
 case 'file' : 
  $html .= "<input {$ftf} {$fc} {$ft} {$fi} {$fn} {$fp} {$fv} />";
  break;
 case 'password' :
  $html .= "<input {$fc} {$ft} {$fi} {$fn} {$fp} {$fd}/>";
  break;
 case 'captcha' :
  $html .= '<div class="captchaimg">';
  $html .= '<img id="captchaimg" src="' . $this->securimage_url() . 'securimage_show.php" alt="CAPTCHA Image" />';
  $html .= '</div>';
//  $html .= '</label></div>';
  $html .= '</label>';
  $html .= '<a href="#" onclick="document.getElementById(\'captchaimg\').src = \'' . $this->securimage_url() . 'securimage_show.php?\' + Math.random(); return false">' . $this->form->lang('reload') . '</a>';
  $html .= "<input {$fc} {$ftt} {$fi} {$fn} {$fp} {$fd} size='10' maxlength='6' />";
  break;
 case 'fieldcaptcha' :
  $html .= "<input {$fc} {$ftt} {$fi} {$fn} />";
  break;
 case 'checkbox' :
  foreach ($this->value as $i => $v) {
   $value = !empty($v[1]) ? ' ' . $v[1] : '';
   $fi = "id='{$id}_option{$i}'";
   $fn = "name='{$name}[{$i}]'";
   $fv = "value='{$value}'";
   $fs = !empty($v[2]) && $v[2] == 'selected' ? 'checked' : '';
   $html .= "<input {$fc} {$ft} {$fi} {$fn} {$fv} {$fd} {$fs} />{$value}";
  }
  break;
 case 'select' :
  $html .= "<select {$fc} {$fi} {$fn} {$fd} >";
  $fs = "selected";
  $fd = "disabled";
  $html .= "<option {$fc} {$fd} {$fs}>{$placeholder}</option>";
  foreach ($this->value as $i => $v) {
   $value = !empty($v[1]) ? $v[1] : 'Default';
   $fi = "id='{$id}_option{$i}'";
   $fv = "value='{$value}'";
   $fs = !empty($v[2]) && $v[2] == 'selected' ? 'selected' : '';
   $html .= "<option {$fc} {$fi} {$fv} {$fs}>{$value}</option>";
  }
  $html.= '</select>';
  break;
 case 'radio' :
  foreach ($this->value as $i => $v) {
   $value = !empty($v[1]) ? ' ' . $v[1] : ' Default';
   $fi = "id='{$id}_option{$i}'";
   $fv = "value='{$value}'";
   $fs = !empty($v[2]) && $v[2] == 'selected' ? ' checked' : '';
   $html .= "<input {$fc} {$ft} {$fi} {$fn} {$fv} {$fd} {$fs} /> {$value}";
  }
  break;
}
$html .= '</div>';
if ($this->type != 'askcopy') { // askcopy doesn't open <div>
 $html .= '</div>';  // comment it twice (see before) if using placeholder instead of label or hide by CSS form label {display:none;}
}
?>
