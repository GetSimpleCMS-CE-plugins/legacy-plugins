<?php
/**
 * "Simple-C Fork" for GetSimple - Simply add contact forms in your pages
 *
 * This plugin is a fork from fFrancesco Simone Carta's Simple-C fork from Nicolas Liautaud's p01-contact plugin
 * 
 * @link http://get-simple.info/extend/plugin/simple-c/914 Latest Version
 * @link http://get-simple.info/extend/plugin/simple-c/784 Simple-C
 * @link http://get-simple.info/extend/plugin/p01-contact/35 Original Version
 * @author wakh.ru
 * @package simple-c fork
 * @version 1.2
 */

require_once GSPLUGINPATH . 'simple-c/simple-c-functions.php';
$simple_c = new SimpleC();
$simple_c->default_email = simple_c_default_email();
$simple_c->default_lang = $LANG;
$simple_c->securimage_url = $SITEURL . 'plugins/simple-c/captcha/';

$thisfile = basename(__FILE__, '.php');
i18n_merge('simple-c') || i18n_merge('simple-c', 'en_US');

register_plugin(
        $thisfile, // ID of plugin, should be filename minus php
        'Simple C(ontact) Fork', // Title of plugin
        $simple_c->version, // Version of plugin
        'wakh.ru', // Author of plugin
        'http://wakh.ru', // Author URL
        'Simply add contact forms in your pages.', // Plugin Description
        'plugins', // Page type of plugin
        'simple_c_action'     // Function that displays content
);

add_filter('content', 'simple_c_filter');
add_action('plugins-sidebar', 'createSideMenu', array($thisfile, $simple_c->lang('menu_settings_text'), 'settings'));

/*
 * Handle for GS content filter (parse GS pages)
 */

function simple_c_filter($contents) {
  global $simple_c;
  global $i18n;
  $contents = $simple_c->parse($contents);
  if ($simple_c->settings('debug')) {
    $simple_c->debug();
  }
  return $contents;
}

/*
 * Handle for GS action (display admin panel)
 */

function simple_c_action() {
  global $simple_c;
  echo $simple_c->panel();
}

/*
 * Return email of the first GS user found
 * @return string
 */

function simple_c_default_email() {
  $files = scandir(GSUSERSPATH);
  foreach ($files as $filename) {
    if (preg_match("#\.xml$#", $filename)) {
      $data = getXML(GSUSERSPATH . $filename);
      return $data->EMAIL;
    }
  }
  return "";
}
